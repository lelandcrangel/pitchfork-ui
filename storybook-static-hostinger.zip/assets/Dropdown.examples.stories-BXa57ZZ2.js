import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { S as Icon, ut as init_dist, y as Dropdown } from "./dist-D1zMThSa.js";
//#region src/Dropdown.examples.stories.tsx
var Dropdown_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Basic: () => Basic,
	EndAligned: () => EndAligned,
	WithDisabledItem: () => WithDisabledItem,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Basic, EndAligned, WithDisabledItem, __namedExportsOrder;
var init_Dropdown_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Dropdown",
		component: Dropdown,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		]
	};
	Basic = { args: {
		label: "Actions",
		items: [
			{
				label: "Profile",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "user",
					"aria-hidden": true
				})
			},
			{
				label: "Settings",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "rectangle-list",
					"aria-hidden": true
				})
			},
			{
				label: "Delete",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "trash-can",
					"aria-hidden": true
				}),
				destructive: true
			}
		]
	} };
	EndAligned = { args: {
		label: "More",
		align: "end",
		items: [
			{
				label: "Rename",
				shortcut: "R"
			},
			{
				label: "Duplicate",
				shortcut: "D"
			},
			{
				label: "Archive",
				shortcut: "A"
			}
		]
	} };
	WithDisabledItem = { args: {
		label: "Manage",
		items: [
			{ label: "Edit" },
			{ label: "Share" },
			{
				label: "Delete",
				destructive: true,
				disabled: true
			}
		]
	} };
	Basic.parameters = {
		...Basic.parameters,
		docs: {
			...Basic.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Actions',\n    items: [{\n      label: 'Profile',\n      icon: <Icon name=\"user\" aria-hidden />\n    }, {\n      label: 'Settings',\n      icon: <Icon name=\"rectangle-list\" aria-hidden />\n    }, {\n      label: 'Delete',\n      icon: <Icon name=\"trash-can\" aria-hidden />,\n      destructive: true\n    }]\n  }\n}",
				...Basic.parameters?.docs?.source
			}
		}
	};
	EndAligned.parameters = {
		...EndAligned.parameters,
		docs: {
			...EndAligned.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'More',\n    align: 'end',\n    items: [{\n      label: 'Rename',\n      shortcut: 'R'\n    }, {\n      label: 'Duplicate',\n      shortcut: 'D'\n    }, {\n      label: 'Archive',\n      shortcut: 'A'\n    }]\n  }\n}",
				...EndAligned.parameters?.docs?.source
			}
		}
	};
	WithDisabledItem.parameters = {
		...WithDisabledItem.parameters,
		docs: {
			...WithDisabledItem.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Manage',\n    items: [{\n      label: 'Edit'\n    }, {\n      label: 'Share'\n    }, {\n      label: 'Delete',\n      destructive: true,\n      disabled: true\n    }]\n  }\n}",
				...WithDisabledItem.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Basic",
		"EndAligned",
		"WithDisabledItem"
	];
}));
//#endregion
init_Dropdown_examples_stories();
export { Basic, EndAligned, WithDisabledItem, __namedExportsOrder, meta as default, init_Dropdown_examples_stories as n, Dropdown_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { n as Avatar, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Avatar.stories.tsx
var Avatar_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Interactive, __namedExportsOrder;
var init_Avatar_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Components/Avatar",
		component: Avatar,
		tags: ["ai-generated", "test"],
		args: {
			name: "Leland Rangel",
			size: "md",
			status: "online"
		},
		argTypes: {
			size: {
				control: "select",
				options: [
					"sm",
					"md",
					"lg",
					"xl"
				]
			},
			status: {
				control: "select",
				options: [
					"online",
					"away",
					"busy",
					"offline"
				]
			}
		}
	};
	Interactive = {};
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Avatar_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Avatar_stories as n, Avatar_stories_exports as t };

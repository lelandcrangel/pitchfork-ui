import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Default, Disabled, Prefilled, WithError, n as init_Textarea_examples_stories, t as Textarea_examples_stories_exports } from "./Textarea.examples.stories-DR6I-v7s.js";
import { n as init_Textarea_stories, t as Textarea_stories_exports } from "./Textarea.stories-BpYDX_yi.js";
//#region src/Textarea.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Textarea_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "textarea",
			children: "Textarea"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Textarea captures longer free-form content where multi-line entry is needed." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: Textarea_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "prefilled",
			children: "Prefilled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Prefilled,
			meta: Textarea_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-error",
			children: "With error"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithError,
			meta: Textarea_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled",
			children: "Disabled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Disabled,
			meta: Textarea_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Textarea_stories();
	init_Textarea_examples_stories();
}))();
export { MDXContent as default };

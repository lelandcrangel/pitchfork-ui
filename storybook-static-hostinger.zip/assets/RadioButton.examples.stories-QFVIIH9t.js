import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { U as RadioButton, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/RadioButton.examples.stories.tsx
var RadioButton_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Checked: () => Checked,
	Disabled: () => Disabled,
	Pair: () => Pair,
	Unchecked: () => Unchecked,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, expect, meta, Unchecked, Checked, Disabled, Pair, __namedExportsOrder;
var init_RadioButton_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	({expect} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Radio Buttons",
		component: RadioButton,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			label: "Email notifications",
			name: "notification-preference"
		}
	};
	Unchecked = {};
	Checked = {
		args: {
			label: "Product updates",
			name: "product-updates",
			defaultChecked: true
		},
		play: async ({ canvas }) => {
			await expect(canvas.getByLabelText(/product updates/i)).toBeChecked();
		}
	};
	Disabled = { args: {
		label: "Disabled option",
		name: "disabled-option",
		disabled: true
	} };
	Pair = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gap: 8
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioButton, {
			label: "Starter",
			name: "plan",
			defaultChecked: true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioButton, {
			label: "Pro",
			name: "plan"
		})]
	}) };
	Unchecked.parameters = {
		...Unchecked.parameters,
		docs: {
			...Unchecked.parameters?.docs,
			source: {
				originalSource: "{}",
				...Unchecked.parameters?.docs?.source
			}
		}
	};
	Checked.parameters = {
		...Checked.parameters,
		docs: {
			...Checked.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Product updates',\n    name: 'product-updates',\n    defaultChecked: true\n  },\n  play: async ({\n    canvas\n  }) => {\n    await expect(canvas.getByLabelText(/product updates/i)).toBeChecked();\n  }\n}",
				...Checked.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Disabled option',\n    name: 'disabled-option',\n    disabled: true\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	Pair.parameters = {
		...Pair.parameters,
		docs: {
			...Pair.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <div style={{\n    display: 'grid',\n    gap: 8\n  }}>\n      <RadioButton label=\"Starter\" name=\"plan\" defaultChecked />\n      <RadioButton label=\"Pro\" name=\"plan\" />\n    </div>\n}",
				...Pair.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Unchecked",
		"Checked",
		"Disabled",
		"Pair"
	];
}));
//#endregion
init_RadioButton_examples_stories();
export { Checked, Disabled, Pair, Unchecked, __namedExportsOrder, meta as default, init_RadioButton_examples_stories as n, RadioButton_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin, s as __toESM } from "./preload-helper-UB4_TMNL.js";
import { k as require_react } from "./iframe-DMCHwO1W.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { A as Modal, o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Modal.stories.tsx
var Modal_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_react, import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_Modal_stories = __esmMin((() => {
	import_react = /* @__PURE__ */ __toESM(require_react(), 1);
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Modals",
		component: Modal,
		tags: ["ai-generated", "test"],
		args: {
			title: "Edit workspace",
			description: "Update workspace details and access settings.",
			size: "md",
			closeOnOverlayClick: true,
			showCloseButton: true
		},
		argTypes: {
			footer: { control: false },
			children: { control: false },
			onOpenChange: { control: false }
		}
	};
	Interactive = {
		args: { open: false },
		render: (args) => {
			const [open, setOpen] = (0, import_react.useState)(false);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen(true),
				children: "Open modal"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				...args,
				open,
				onOpenChange: setOpen,
				footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setOpen(false),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setOpen(false),
					children: "Save changes"
				})] }),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					style: { margin: 0 },
					children: "This modal demonstrates overlay dismissal, escape handling, and a footer action row."
				})
			})] });
		}
	};
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    open: false\n  },\n  render: args => {\n    const [open, setOpen] = useState(false);\n    return <>\n        <Button onClick={() => setOpen(true)}>Open modal</Button>\n        <Modal {...args} open={open} onOpenChange={setOpen} footer={<>\n              <Button variant=\"secondary\" onClick={() => setOpen(false)}>\n                Cancel\n              </Button>\n              <Button onClick={() => setOpen(false)}>Save changes</Button>\n            </>}>\n          <p style={{\n          margin: 0\n        }}>\n            This modal demonstrates overlay dismissal, escape handling, and a\n            footer action row.\n          </p>\n        </Modal>\n      </>;\n  }\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Modal_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Modal_stories as n, Modal_stories_exports as t };

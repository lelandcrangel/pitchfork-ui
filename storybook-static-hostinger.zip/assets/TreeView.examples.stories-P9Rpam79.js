import { i as __esmMin, s as __toESM } from "./preload-helper-UB4_TMNL.js";
import { k as require_react } from "./iframe-DMCHwO1W.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { o as Button, ot as TreeView, r as Badge, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/TreeView.examples.stories.tsx
function ExpandCollapseAllDemo(args) {
	const treeRef = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gap: 12
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				gap: 8
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				onClick: () => treeRef.current?.expandAll(),
				children: "Expand all"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "secondary",
				onClick: () => treeRef.current?.collapseAll(),
				children: "Collapse all"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreeView, {
			ref: treeRef,
			...args
		})]
	});
}
var import_react, import_jsx_runtime, meta, Default, WithBadges, CompactRoot, DeepHierarchy, ExpandCollapseAll, __namedExportsOrder;
var init_TreeView_examples_stories = __esmMin((() => {
	import_react = /* @__PURE__ */ __toESM(require_react(), 1);
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Tree View",
		component: TreeView,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { nodes: [{
			value: "root",
			label: "Product",
			children: [
				{
					value: "docs",
					label: "Docs",
					badge: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "3" }),
					children: [
						{
							value: "guides",
							label: "Guides"
						},
						{
							value: "api",
							label: "API reference"
						},
						{
							value: "release",
							label: "Release notes"
						}
					]
				},
				{
					value: "apps",
					label: "Apps",
					children: [
						{
							value: "ios",
							label: "iOS"
						},
						{
							value: "android",
							label: "Android"
						},
						{
							value: "web",
							label: "Web"
						}
					]
				},
				{
					value: "archive",
					label: "Archive",
					disabled: true
				}
			]
		}] }
	};
	Default = { args: {
		defaultExpandedValues: ["root", "docs"],
		defaultSelectedValue: "api"
	} };
	WithBadges = { args: {
		defaultExpandedValues: ["root"],
		defaultSelectedValue: "docs"
	} };
	CompactRoot = { args: {
		nodes: [{
			value: "project",
			label: "Project files",
			children: [
				{
					value: "readme",
					label: "README.md"
				},
				{
					value: "changelog",
					label: "CHANGELOG.md"
				},
				{
					value: "contrib",
					label: "CONTRIBUTING.md"
				}
			]
		}],
		defaultExpandedValues: ["project"],
		defaultSelectedValue: "readme"
	} };
	DeepHierarchy = { args: {
		nodes: [{
			value: "program",
			label: "Program",
			children: [
				{
					value: "phase-1",
					label: "Phase 1",
					children: [{
						value: "phase-1-workstream-a",
						label: "Workstream A",
						children: [{
							value: "phase-1-epic-platform",
							label: "Epic: Platform",
							children: [{
								value: "phase-1-feature-observability",
								label: "Feature: Observability",
								children: [{
									value: "phase-1-task-tracing",
									label: "Task: Add distributed tracing"
								}]
							}]
						}]
					}, {
						value: "phase-1-workstream-b",
						label: "Workstream B",
						children: [{
							value: "phase-1-epic-growth",
							label: "Epic: Growth",
							children: [{
								value: "phase-1-feature-segments",
								label: "Feature: Segment builder",
								children: [{
									value: "phase-1-task-rollout",
									label: "Task: Launch cohort rollout"
								}]
							}]
						}]
					}]
				},
				{
					value: "phase-2",
					label: "Phase 2",
					children: [{
						value: "phase-2-workstream-a",
						label: "Workstream A",
						children: [{
							value: "phase-2-epic-security",
							label: "Epic: Security",
							children: [{
								value: "phase-2-feature-secrets",
								label: "Feature: Secrets rotation",
								children: [{
									value: "phase-2-task-kms",
									label: "Task: Integrate KMS provider"
								}]
							}]
						}]
					}, {
						value: "phase-2-workstream-b",
						label: "Workstream B",
						children: [{
							value: "phase-2-epic-reliability",
							label: "Epic: Reliability",
							children: [{
								value: "phase-2-feature-failover",
								label: "Feature: Region failover",
								children: [{
									value: "phase-2-task-drills",
									label: "Task: Run disaster drills"
								}]
							}]
						}]
					}]
				},
				{
					value: "phase-3",
					label: "Phase 3",
					children: [{
						value: "phase-3-workstream-a",
						label: "Workstream A",
						children: [{
							value: "phase-3-epic-experience",
							label: "Epic: Experience",
							children: [{
								value: "phase-3-feature-personalization",
								label: "Feature: Personalization",
								children: [{
									value: "phase-3-task-recommendations",
									label: "Task: Add recommendations rail"
								}]
							}]
						}]
					}, {
						value: "phase-3-workstream-b",
						label: "Workstream B",
						children: [{
							value: "phase-3-epic-operations",
							label: "Epic: Operations",
							children: [{
								value: "phase-3-feature-automation",
								label: "Feature: Workflow automation",
								children: [{
									value: "phase-3-task-runbooks",
									label: "Task: Generate runbooks from playbooks"
								}]
							}]
						}]
					}]
				}
			]
		}],
		defaultExpandedValues: [
			"program",
			"phase-1",
			"phase-1-workstream-a",
			"phase-1-epic-platform",
			"phase-1-feature-observability",
			"phase-1-workstream-b",
			"phase-1-epic-growth",
			"phase-1-feature-segments",
			"phase-2",
			"phase-2-workstream-a",
			"phase-2-epic-security",
			"phase-2-feature-secrets",
			"phase-2-workstream-b",
			"phase-2-epic-reliability",
			"phase-2-feature-failover",
			"phase-3",
			"phase-3-workstream-a",
			"phase-3-epic-experience",
			"phase-3-feature-personalization",
			"phase-3-workstream-b",
			"phase-3-epic-operations",
			"phase-3-feature-automation"
		],
		defaultSelectedValue: "phase-2-task-drills"
	} };
	ExpandCollapseAll = {
		render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpandCollapseAllDemo, { ...args }),
		args: {
			defaultExpandedValues: ["root"],
			defaultSelectedValue: "docs"
		}
	};
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultExpandedValues: ['root', 'docs'],\n    defaultSelectedValue: 'api'\n  }\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	WithBadges.parameters = {
		...WithBadges.parameters,
		docs: {
			...WithBadges.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultExpandedValues: ['root'],\n    defaultSelectedValue: 'docs'\n  }\n}",
				...WithBadges.parameters?.docs?.source
			}
		}
	};
	CompactRoot.parameters = {
		...CompactRoot.parameters,
		docs: {
			...CompactRoot.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    nodes: [{\n      value: 'project',\n      label: 'Project files',\n      children: [{\n        value: 'readme',\n        label: 'README.md'\n      }, {\n        value: 'changelog',\n        label: 'CHANGELOG.md'\n      }, {\n        value: 'contrib',\n        label: 'CONTRIBUTING.md'\n      }]\n    }],\n    defaultExpandedValues: ['project'],\n    defaultSelectedValue: 'readme'\n  }\n}",
				...CompactRoot.parameters?.docs?.source
			}
		}
	};
	DeepHierarchy.parameters = {
		...DeepHierarchy.parameters,
		docs: {
			...DeepHierarchy.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    nodes: [{\n      value: 'program',\n      label: 'Program',\n      children: [{\n        value: 'phase-1',\n        label: 'Phase 1',\n        children: [{\n          value: 'phase-1-workstream-a',\n          label: 'Workstream A',\n          children: [{\n            value: 'phase-1-epic-platform',\n            label: 'Epic: Platform',\n            children: [{\n              value: 'phase-1-feature-observability',\n              label: 'Feature: Observability',\n              children: [{\n                value: 'phase-1-task-tracing',\n                label: 'Task: Add distributed tracing'\n              }]\n            }]\n          }]\n        }, {\n          value: 'phase-1-workstream-b',\n          label: 'Workstream B',\n          children: [{\n            value: 'phase-1-epic-growth',\n            label: 'Epic: Growth',\n            children: [{\n              value: 'phase-1-feature-segments',\n              label: 'Feature: Segment builder',\n              children: [{\n                value: 'phase-1-task-rollout',\n                label: 'Task: Launch cohort rollout'\n              }]\n            }]\n          }]\n        }]\n      }, {\n        value: 'phase-2',\n        label: 'Phase 2',\n        children: [{\n          value: 'phase-2-workstream-a',\n          label: 'Workstream A',\n          children: [{\n            value: 'phase-2-epic-security',\n            label: 'Epic: Security',\n            children: [{\n              value: 'phase-2-feature-secrets',\n              label: 'Feature: Secrets rotation',\n              children: [{\n                value: 'phase-2-task-kms',\n                label: 'Task: Integrate KMS provider'\n              }]\n            }]\n          }]\n        }, {\n          value: 'phase-2-workstream-b',\n          label: 'Workstream B',\n          children: [{\n            value: 'phase-2-epic-reliability',\n            label: 'Epic: Reliability',\n            children: [{\n              value: 'phase-2-feature-failover',\n              label: 'Feature: Region failover',\n              children: [{\n                value: 'phase-2-task-drills',\n                label: 'Task: Run disaster drills'\n              }]\n            }]\n          }]\n        }]\n      }, {\n        value: 'phase-3',\n        label: 'Phase 3',\n        children: [{\n          value: 'phase-3-workstream-a',\n          label: 'Workstream A',\n          children: [{\n            value: 'phase-3-epic-experience',\n            label: 'Epic: Experience',\n            children: [{\n              value: 'phase-3-feature-personalization',\n              label: 'Feature: Personalization',\n              children: [{\n                value: 'phase-3-task-recommendations',\n                label: 'Task: Add recommendations rail'\n              }]\n            }]\n          }]\n        }, {\n          value: 'phase-3-workstream-b',\n          label: 'Workstream B',\n          children: [{\n            value: 'phase-3-epic-operations',\n            label: 'Epic: Operations',\n            children: [{\n              value: 'phase-3-feature-automation',\n              label: 'Feature: Workflow automation',\n              children: [{\n                value: 'phase-3-task-runbooks',\n                label: 'Task: Generate runbooks from playbooks'\n              }]\n            }]\n          }]\n        }]\n      }]\n    }],\n    defaultExpandedValues: ['program', 'phase-1', 'phase-1-workstream-a', 'phase-1-epic-platform', 'phase-1-feature-observability', 'phase-1-workstream-b', 'phase-1-epic-growth', 'phase-1-feature-segments', 'phase-2', 'phase-2-workstream-a', 'phase-2-epic-security', 'phase-2-feature-secrets', 'phase-2-workstream-b', 'phase-2-epic-reliability', 'phase-2-feature-failover', 'phase-3', 'phase-3-workstream-a', 'phase-3-epic-experience', 'phase-3-feature-personalization', 'phase-3-workstream-b', 'phase-3-epic-operations', 'phase-3-feature-automation'],\n    defaultSelectedValue: 'phase-2-task-drills'\n  }\n}",
				...DeepHierarchy.parameters?.docs?.source
			}
		}
	};
	ExpandCollapseAll.parameters = {
		...ExpandCollapseAll.parameters,
		docs: {
			...ExpandCollapseAll.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <ExpandCollapseAllDemo {...args} />,\n  args: {\n    defaultExpandedValues: ['root'],\n    defaultSelectedValue: 'docs'\n  }\n}",
				...ExpandCollapseAll.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"WithBadges",
		"CompactRoot",
		"DeepHierarchy",
		"ExpandCollapseAll"
	];
}));
//#endregion
init_TreeView_examples_stories();
export { CompactRoot, DeepHierarchy, Default, ExpandCollapseAll, WithBadges, __namedExportsOrder, meta as default, init_TreeView_examples_stories as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { R as PieChart, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/PieChart.examples.stories.tsx
var PieChart_examples_stories_exports = /* @__PURE__ */ __exportAll({
	ChannelSplit: () => ChannelSplit,
	CompactNoLegend: () => CompactNoLegend,
	EmptyState: () => EmptyState,
	RevenueMix: () => RevenueMix,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, RevenueMix, ChannelSplit, CompactNoLegend, EmptyState, __namedExportsOrder;
var init_PieChart_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/PieChart",
		component: PieChart,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { data: [{
			label: "Sample",
			value: 100
		}] }
	};
	RevenueMix = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieChart, {
		centerLabel: "$420k",
		data: [
			{
				label: "Subscriptions",
				value: 58
			},
			{
				label: "One-time",
				value: 24
			},
			{
				label: "Support",
				value: 18
			}
		]
	}) };
	ChannelSplit = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieChart, {
		centerLabel: "Q2",
		data: [
			{
				label: "Organic",
				value: 39,
				color: "#3b82f6"
			},
			{
				label: "Paid",
				value: 27,
				color: "#06b6d4"
			},
			{
				label: "Referral",
				value: 21,
				color: "#22c55e"
			},
			{
				label: "Partnerships",
				value: 13,
				color: "#f97316"
			}
		]
	}) };
	CompactNoLegend = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieChart, {
		size: 144,
		cutout: .66,
		showLegend: false,
		centerLabel: "67%",
		data: [{
			label: "Completed",
			value: 67,
			color: "#22c55e"
		}, {
			label: "Remaining",
			value: 33,
			color: "#e5e7eb"
		}]
	}) };
	EmptyState = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieChart, {
		centerLabel: "0",
		emptyLabel: "No data",
		data: [{
			label: "A",
			value: 0
		}, {
			label: "B",
			value: 0
		}]
	}) };
	RevenueMix.parameters = {
		...RevenueMix.parameters,
		docs: {
			...RevenueMix.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <PieChart centerLabel=\"$420k\" data={[{\n    label: 'Subscriptions',\n    value: 58\n  }, {\n    label: 'One-time',\n    value: 24\n  }, {\n    label: 'Support',\n    value: 18\n  }]} />\n}",
				...RevenueMix.parameters?.docs?.source
			}
		}
	};
	ChannelSplit.parameters = {
		...ChannelSplit.parameters,
		docs: {
			...ChannelSplit.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <PieChart centerLabel=\"Q2\" data={[{\n    label: 'Organic',\n    value: 39,\n    color: '#3b82f6'\n  }, {\n    label: 'Paid',\n    value: 27,\n    color: '#06b6d4'\n  }, {\n    label: 'Referral',\n    value: 21,\n    color: '#22c55e'\n  }, {\n    label: 'Partnerships',\n    value: 13,\n    color: '#f97316'\n  }]} />\n}",
				...ChannelSplit.parameters?.docs?.source
			}
		}
	};
	CompactNoLegend.parameters = {
		...CompactNoLegend.parameters,
		docs: {
			...CompactNoLegend.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <PieChart size={144} cutout={0.66} showLegend={false} centerLabel=\"67%\" data={[{\n    label: 'Completed',\n    value: 67,\n    color: '#22c55e'\n  }, {\n    label: 'Remaining',\n    value: 33,\n    color: '#e5e7eb'\n  }]} />\n}",
				...CompactNoLegend.parameters?.docs?.source
			}
		}
	};
	EmptyState.parameters = {
		...EmptyState.parameters,
		docs: {
			...EmptyState.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <PieChart centerLabel=\"0\" emptyLabel=\"No data\" data={[{\n    label: 'A',\n    value: 0\n  }, {\n    label: 'B',\n    value: 0\n  }]} />\n}",
				...EmptyState.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"RevenueMix",
		"ChannelSplit",
		"CompactNoLegend",
		"EmptyState"
	];
}));
//#endregion
init_PieChart_examples_stories();
export { ChannelSplit, CompactNoLegend, EmptyState, RevenueMix, __namedExportsOrder, meta as default, init_PieChart_examples_stories as n, PieChart_examples_stories_exports as t };

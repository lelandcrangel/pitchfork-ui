import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { i as BadgeGroup, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/BadgeGroup.stories.tsx
var BadgeGroup_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Interactive, __namedExportsOrder;
var init_BadgeGroup_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Components/Badge Group",
		component: BadgeGroup,
		tags: ["ai-generated", "test"],
		args: {
			label: "New feature",
			message: "We've just released a new feature",
			color: "brand",
			appearance: "pill",
			badgePosition: "leading"
		},
		argTypes: {
			color: {
				control: "select",
				options: [
					"gray",
					"brand",
					"error",
					"warning",
					"success"
				]
			},
			appearance: {
				control: "select",
				options: ["pill", "modern"]
			},
			badgePosition: {
				control: "select",
				options: ["leading", "trailing"]
			}
		}
	};
	Interactive = {};
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_BadgeGroup_stories();
export { Interactive, __namedExportsOrder, meta as default, init_BadgeGroup_stories as n, BadgeGroup_stories_exports as t };

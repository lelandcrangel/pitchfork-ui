import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { G as RatingBadge, K as RatingStars, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Rating.stories.tsx
var Rating_stories_exports = /* @__PURE__ */ __exportAll({
	InteractiveBadge: () => InteractiveBadge,
	InteractiveStars: () => InteractiveStars,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, InteractiveStars, InteractiveBadge, __namedExportsOrder;
var init_Rating_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Rating",
		component: RatingStars,
		tags: ["ai-generated", "test"],
		args: {
			value: 4.2,
			max: 5,
			size: 18,
			showValue: true
		},
		argTypes: {
			value: { control: {
				type: "range",
				min: 0,
				max: 5,
				step: .1
			} },
			max: { control: {
				type: "number",
				min: 1,
				step: 1
			} },
			size: { control: {
				type: "number",
				min: 12,
				max: 40,
				step: 1
			} },
			showValue: { control: "boolean" }
		}
	};
	InteractiveStars = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RatingStars, { ...args }) };
	InteractiveBadge = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RatingBadge, {
		value: args.value ?? 4.2,
		max: args.max ?? 5,
		reviews: 1284,
		size: "md"
	}) };
	InteractiveStars.parameters = {
		...InteractiveStars.parameters,
		docs: {
			...InteractiveStars.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <RatingStars {...args} />\n}",
				...InteractiveStars.parameters?.docs?.source
			}
		}
	};
	InteractiveBadge.parameters = {
		...InteractiveBadge.parameters,
		docs: {
			...InteractiveBadge.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <RatingBadge value={args.value ?? 4.2} max={args.max ?? 5} reviews={1284} size=\"md\" />\n}",
				...InteractiveBadge.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["InteractiveStars", "InteractiveBadge"];
}));
//#endregion
init_Rating_stories();
export { InteractiveBadge, InteractiveStars, __namedExportsOrder, meta as default, init_Rating_stories as n, Rating_stories_exports as t };

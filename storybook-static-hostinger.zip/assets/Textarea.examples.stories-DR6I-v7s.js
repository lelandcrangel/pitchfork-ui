import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { it as Textarea, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Textarea.examples.stories.tsx
var Textarea_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	Disabled: () => Disabled,
	Prefilled: () => Prefilled,
	WithError: () => WithError,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var expect, meta, Default, Prefilled, WithError, Disabled, __namedExportsOrder;
var init_Textarea_examples_stories = __esmMin((() => {
	init_dist();
	({expect} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Textarea",
		component: Textarea,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			label: "Description",
			placeholder: "Write a short project description...",
			description: "Keep it concise and specific.",
			rows: 4
		}
	};
	Default = {};
	Prefilled = { args: { defaultValue: "Pitchfork UI is a fast component library for product teams." } };
	WithError = {
		args: { error: "Please add at least 40 characters." },
		play: async ({ canvas }) => {
			await expect(canvas.getByLabelText(/description/i)).toHaveAttribute("aria-invalid", "true");
		}
	};
	Disabled = { args: {
		disabled: true,
		defaultValue: "Archived notes cannot be edited."
	} };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{}",
				...Default.parameters?.docs?.source
			}
		}
	};
	Prefilled.parameters = {
		...Prefilled.parameters,
		docs: {
			...Prefilled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultValue: 'Pitchfork UI is a fast component library for product teams.'\n  }\n}",
				...Prefilled.parameters?.docs?.source
			}
		}
	};
	WithError.parameters = {
		...WithError.parameters,
		docs: {
			...WithError.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    error: 'Please add at least 40 characters.'\n  },\n  play: async ({\n    canvas\n  }) => {\n    const field = canvas.getByLabelText(/description/i);\n    await expect(field).toHaveAttribute('aria-invalid', 'true');\n  }\n}",
				...WithError.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    disabled: true,\n    defaultValue: 'Archived notes cannot be edited.'\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"Prefilled",
		"WithError",
		"Disabled"
	];
}));
//#endregion
init_Textarea_examples_stories();
export { Default, Disabled, Prefilled, WithError, __namedExportsOrder, meta as default, init_Textarea_examples_stories as n, Textarea_examples_stories_exports as t };

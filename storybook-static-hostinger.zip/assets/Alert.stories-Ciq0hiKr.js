import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { t as Alert, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Alert.stories.tsx
var Alert_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_Alert_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Alert",
		component: Alert,
		tags: ["ai-generated", "test"],
		args: {
			variant: "info",
			heading: "Heads up",
			description: "This is an informational alert message.",
			dismissible: false
		},
		argTypes: {
			variant: {
				control: "inline-radio",
				options: [
					"info",
					"success",
					"warning",
					"danger"
				]
			},
			dismissible: { control: "boolean" }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <Alert {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Alert_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Alert_stories as n, Alert_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { I as PageHeader, o as Button, r as Badge, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/PageHeader.stories.tsx
var PageHeader_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_PageHeader_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Page Headers",
		component: PageHeader,
		tags: ["ai-generated", "test"],
		args: {
			eyebrow: "Overview",
			heading: "Analytics workspace",
			description: "Monitor team activity, exports, and performance from a single view.",
			breadcrumbs: [
				{
					label: "Home",
					href: "#"
				},
				{
					label: "Workspace",
					href: "#"
				},
				{
					label: "Analytics",
					current: true
				}
			],
			metadata: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "brand",
				children: "Live"
			}),
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				children: "New report"
			})
		},
		argTypes: {
			metadata: { control: false },
			actions: { control: false }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <PageHeader {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_PageHeader_stories();
export { Interactive, __namedExportsOrder, meta as default, init_PageHeader_stories as n, PageHeader_stories_exports as t };

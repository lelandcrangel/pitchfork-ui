import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { ct as VideoPlayer, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/VideoPlayer.stories.tsx
var VideoPlayer_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_VideoPlayer_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Video Player",
		component: VideoPlayer,
		tags: ["ai-generated", "test"],
		args: {
			label: "Intro video",
			description: "Watch the short introduction clip.",
			src: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
			controls: true,
			aspectRatio: "16/9",
			muted: false,
			loop: false,
			autoPlay: false
		},
		argTypes: {
			aspectRatio: {
				control: "select",
				options: [
					"16/9",
					"4/3",
					"1/1"
				]
			},
			controls: { control: "boolean" },
			muted: { control: "boolean" },
			loop: { control: "boolean" },
			autoPlay: { control: "boolean" },
			poster: { control: "text" }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoPlayer, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <VideoPlayer {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_VideoPlayer_stories();
export { Interactive, __namedExportsOrder, meta as default, init_VideoPlayer_stories as n, VideoPlayer_stories_exports as t };

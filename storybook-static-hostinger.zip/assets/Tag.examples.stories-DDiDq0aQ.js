import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { rt as Tag, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Tag.examples.stories.tsx
var Tag_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Brand: () => Brand,
	Dismissible: () => Dismissible,
	Neutral: () => Neutral,
	Success: () => Success,
	Warning: () => Warning,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var expect, fn, meta, Neutral, Brand, Success, Warning, Dismissible, __namedExportsOrder;
var init_Tag_examples_stories = __esmMin((() => {
	init_dist();
	({expect, fn} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Tag",
		component: Tag,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			children: "Design",
			variant: "neutral"
		}
	};
	Neutral = {};
	Brand = { args: {
		children: "Product",
		variant: "brand"
	} };
	Success = { args: {
		children: "Published",
		variant: "success"
	} };
	Warning = { args: {
		children: "Needs review",
		variant: "warning"
	} };
	Dismissible = {
		args: {
			children: "Removable",
			dismissible: true,
			onDismiss: fn()
		},
		play: async ({ args, canvas, userEvent }) => {
			await userEvent.click(canvas.getByRole("button", { name: /remove tag/i }));
			await expect(args.onDismiss).toHaveBeenCalled();
		}
	};
	Neutral.parameters = {
		...Neutral.parameters,
		docs: {
			...Neutral.parameters?.docs,
			source: {
				originalSource: "{}",
				...Neutral.parameters?.docs?.source
			}
		}
	};
	Brand.parameters = {
		...Brand.parameters,
		docs: {
			...Brand.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    children: 'Product',\n    variant: 'brand'\n  }\n}",
				...Brand.parameters?.docs?.source
			}
		}
	};
	Success.parameters = {
		...Success.parameters,
		docs: {
			...Success.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    children: 'Published',\n    variant: 'success'\n  }\n}",
				...Success.parameters?.docs?.source
			}
		}
	};
	Warning.parameters = {
		...Warning.parameters,
		docs: {
			...Warning.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    children: 'Needs review',\n    variant: 'warning'\n  }\n}",
				...Warning.parameters?.docs?.source
			}
		}
	};
	Dismissible.parameters = {
		...Dismissible.parameters,
		docs: {
			...Dismissible.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    children: 'Removable',\n    dismissible: true,\n    onDismiss: fn()\n  },\n  play: async ({\n    args,\n    canvas,\n    userEvent\n  }) => {\n    await userEvent.click(canvas.getByRole('button', {\n      name: /remove tag/i\n    }));\n    await expect(args.onDismiss).toHaveBeenCalled();\n  }\n}",
				...Dismissible.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Neutral",
		"Brand",
		"Success",
		"Warning",
		"Dismissible"
	];
}));
//#endregion
init_Tag_examples_stories();
export { Brand, Dismissible, Neutral, Success, Warning, __namedExportsOrder, meta as default, init_Tag_examples_stories as n, Tag_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { r as Badge, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Badge.examples.stories.tsx
var Badge_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Brand: () => Brand,
	Neutral: () => Neutral,
	Success: () => Success,
	Warning: () => Warning,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Neutral, Brand, Success, Warning, __namedExportsOrder;
var init_Badge_examples_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Examples/Badge",
		component: Badge,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			children: "React",
			variant: "neutral"
		},
		argTypes: { variant: {
			control: "select",
			options: [
				"neutral",
				"brand",
				"success",
				"warning"
			]
		} }
	};
	Neutral = {};
	Brand = { args: {
		variant: "brand",
		children: "Brand"
	} };
	Success = { args: {
		variant: "success",
		children: "Success"
	} };
	Warning = { args: {
		variant: "warning",
		children: "Warning"
	} };
	Neutral.parameters = {
		...Neutral.parameters,
		docs: {
			...Neutral.parameters?.docs,
			source: {
				originalSource: "{}",
				...Neutral.parameters?.docs?.source
			}
		}
	};
	Brand.parameters = {
		...Brand.parameters,
		docs: {
			...Brand.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    variant: 'brand',\n    children: 'Brand'\n  }\n}",
				...Brand.parameters?.docs?.source
			}
		}
	};
	Success.parameters = {
		...Success.parameters,
		docs: {
			...Success.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    variant: 'success',\n    children: 'Success'\n  }\n}",
				...Success.parameters?.docs?.source
			}
		}
	};
	Warning.parameters = {
		...Warning.parameters,
		docs: {
			...Warning.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    variant: 'warning',\n    children: 'Warning'\n  }\n}",
				...Warning.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Neutral",
		"Brand",
		"Success",
		"Warning"
	];
}));
//#endregion
init_Badge_examples_stories();
export { Brand, Neutral, Success, Warning, __namedExportsOrder, meta as default, init_Badge_examples_stories as n, Badge_examples_stories_exports as t };

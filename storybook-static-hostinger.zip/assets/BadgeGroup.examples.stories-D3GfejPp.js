import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { i as BadgeGroup, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/BadgeGroup.examples.stories.tsx
var BadgeGroup_examples_stories_exports = /* @__PURE__ */ __exportAll({
	ModernLeadingWarning: () => ModernLeadingWarning,
	ModernTrailingError: () => ModernTrailingError,
	PillLeadingBrand: () => PillLeadingBrand,
	PillTrailingSuccess: () => PillTrailingSuccess,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, PillLeadingBrand, PillTrailingSuccess, ModernLeadingWarning, ModernTrailingError, __namedExportsOrder;
var init_BadgeGroup_examples_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Examples/Badge Group",
		component: BadgeGroup,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		]
	};
	PillLeadingBrand = { args: {
		label: "New feature",
		message: "We've just released a new feature",
		appearance: "pill",
		color: "brand",
		badgePosition: "leading"
	} };
	PillTrailingSuccess = { args: {
		label: "Success",
		message: "You've updated your profile and details",
		appearance: "pill",
		color: "success",
		badgePosition: "trailing"
	} };
	ModernLeadingWarning = { args: {
		label: "Warning",
		message: "Just to let you know this might be a problem",
		appearance: "modern",
		color: "warning",
		badgePosition: "leading"
	} };
	ModernTrailingError = { args: {
		label: "Error",
		message: "There was a problem with that action",
		appearance: "modern",
		color: "error",
		badgePosition: "trailing"
	} };
	PillLeadingBrand.parameters = {
		...PillLeadingBrand.parameters,
		docs: {
			...PillLeadingBrand.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'New feature',\n    message: \"We've just released a new feature\",\n    appearance: 'pill',\n    color: 'brand',\n    badgePosition: 'leading'\n  }\n}",
				...PillLeadingBrand.parameters?.docs?.source
			}
		}
	};
	PillTrailingSuccess.parameters = {
		...PillTrailingSuccess.parameters,
		docs: {
			...PillTrailingSuccess.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Success',\n    message: \"You've updated your profile and details\",\n    appearance: 'pill',\n    color: 'success',\n    badgePosition: 'trailing'\n  }\n}",
				...PillTrailingSuccess.parameters?.docs?.source
			}
		}
	};
	ModernLeadingWarning.parameters = {
		...ModernLeadingWarning.parameters,
		docs: {
			...ModernLeadingWarning.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Warning',\n    message: 'Just to let you know this might be a problem',\n    appearance: 'modern',\n    color: 'warning',\n    badgePosition: 'leading'\n  }\n}",
				...ModernLeadingWarning.parameters?.docs?.source
			}
		}
	};
	ModernTrailingError.parameters = {
		...ModernTrailingError.parameters,
		docs: {
			...ModernTrailingError.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Error',\n    message: 'There was a problem with that action',\n    appearance: 'modern',\n    color: 'error',\n    badgePosition: 'trailing'\n  }\n}",
				...ModernTrailingError.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"PillLeadingBrand",
		"PillTrailingSuccess",
		"ModernLeadingWarning",
		"ModernTrailingError"
	];
}));
//#endregion
init_BadgeGroup_examples_stories();
export { ModernLeadingWarning, ModernTrailingError, PillLeadingBrand, PillTrailingSuccess, __namedExportsOrder, meta as default, init_BadgeGroup_examples_stories as n, BadgeGroup_examples_stories_exports as t };

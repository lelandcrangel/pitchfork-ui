import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { g as ContentDivider, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/ContentDivider.examples.stories.tsx
var ContentDivider_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	Inset: () => Inset,
	Vertical: () => Vertical,
	WithLabel: () => WithLabel,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Default, WithLabel, Vertical, Inset, __namedExportsOrder;
var init_ContentDivider_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/ContentDivider",
		component: ContentDivider,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		]
	};
	Default = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContentDivider, {}) };
	WithLabel = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContentDivider, { label: "Billing" }) };
	Vertical = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			alignItems: "stretch",
			display: "flex",
			gap: 16,
			minHeight: 64
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Left pane" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContentDivider, { orientation: "vertical" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Right pane" })
		]
	}) };
	Inset = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContentDivider, {
		label: "Continue",
		inset: true
	}) };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <ContentDivider />\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	WithLabel.parameters = {
		...WithLabel.parameters,
		docs: {
			...WithLabel.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <ContentDivider label=\"Billing\" />\n}",
				...WithLabel.parameters?.docs?.source
			}
		}
	};
	Vertical.parameters = {
		...Vertical.parameters,
		docs: {
			...Vertical.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <div style={{\n    alignItems: 'stretch',\n    display: 'flex',\n    gap: 16,\n    minHeight: 64\n  }}>\n      <span>Left pane</span>\n      <ContentDivider orientation=\"vertical\" />\n      <span>Right pane</span>\n    </div>\n}",
				...Vertical.parameters?.docs?.source
			}
		}
	};
	Inset.parameters = {
		...Inset.parameters,
		docs: {
			...Inset.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <ContentDivider label=\"Continue\" inset />\n}",
				...Inset.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"WithLabel",
		"Vertical",
		"Inset"
	];
}));
//#endregion
init_ContentDivider_examples_stories();
export { Default, Inset, Vertical, WithLabel, __namedExportsOrder, meta as default, init_ContentDivider_examples_stories as n, ContentDivider_examples_stories_exports as t };

import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { CompactRoot, DeepHierarchy, Default, ExpandCollapseAll, WithBadges, t as init_TreeView_examples_stories } from "./TreeView.examples.stories-P9Rpam79.js";
import { n as init_TreeView_stories, t as TreeView_stories_exports } from "./TreeView.stories-DFgeQ_Tg.js";
//#region src/TreeView.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: TreeView_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "tree-views",
			children: "Tree Views"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "TreeView presents hierarchical structures that can be expanded and collapsed while keeping the context of each level visible." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "A balanced tree layout for workspace-style navigation." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, { of: Default }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-badges",
			children: "With badges"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Attach badges to highlight counts or status on important branches." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, { of: WithBadges }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "compact-root",
			children: "Compact root"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "A minimal tree structure for smaller content maps." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, { of: CompactRoot }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "deep-hierarchy-6-levels",
			children: "Deep hierarchy (6 levels)"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Demonstrates a six-level nested tree path for complex information architectures." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, { of: DeepHierarchy }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "expand-and-collapse-all",
			children: "Expand and collapse all"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Adds quick controls to open or close every branch in the tree." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, { of: ExpandCollapseAll })
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_TreeView_stories();
	init_TreeView_examples_stories();
}))();
export { MDXContent as default };

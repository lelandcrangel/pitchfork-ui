import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { S as Icon, st as UtilityButton, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/UtilityButton.examples.stories.tsx
var UtilityButton_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Brand: () => Brand,
	ClickAction: () => ClickAction,
	Danger: () => Danger,
	Disabled: () => Disabled,
	IconOnly: () => IconOnly,
	Neutral: () => Neutral,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, expect, fn, meta, Neutral, Brand, Danger, IconOnly, Disabled, ClickAction, __namedExportsOrder;
var init_UtilityButton_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	({expect, fn} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Utility Button",
		component: UtilityButton,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			children: "Quick action",
			variant: "neutral",
			size: "md",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				name: "rectangle-list",
				"aria-hidden": true
			}),
			onClick: fn()
		}
	};
	Neutral = {};
	Brand = { args: {
		variant: "brand",
		children: "Create",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			name: "square-plus",
			"aria-hidden": true
		})
	} };
	Danger = { args: {
		variant: "danger",
		children: "Delete",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			name: "trash-can",
			"aria-hidden": true
		})
	} };
	IconOnly = { args: {
		"aria-label": "More options",
		children: void 0,
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			name: "rectangle-list",
			"aria-hidden": true
		})
	} };
	Disabled = { args: { disabled: true } };
	ClickAction = {
		args: { children: "Run action" },
		play: async ({ canvas, userEvent, args }) => {
			await userEvent.click(canvas.getByRole("button", { name: /run action/i }));
			await expect(args.onClick).toHaveBeenCalled();
		}
	};
	Neutral.parameters = {
		...Neutral.parameters,
		docs: {
			...Neutral.parameters?.docs,
			source: {
				originalSource: "{}",
				...Neutral.parameters?.docs?.source
			}
		}
	};
	Brand.parameters = {
		...Brand.parameters,
		docs: {
			...Brand.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    variant: 'brand',\n    children: 'Create',\n    icon: <Icon name=\"square-plus\" aria-hidden />\n  }\n}",
				...Brand.parameters?.docs?.source
			}
		}
	};
	Danger.parameters = {
		...Danger.parameters,
		docs: {
			...Danger.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    variant: 'danger',\n    children: 'Delete',\n    icon: <Icon name=\"trash-can\" aria-hidden />\n  }\n}",
				...Danger.parameters?.docs?.source
			}
		}
	};
	IconOnly.parameters = {
		...IconOnly.parameters,
		docs: {
			...IconOnly.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    'aria-label': 'More options',\n    children: undefined,\n    icon: <Icon name=\"rectangle-list\" aria-hidden />\n  }\n}",
				...IconOnly.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    disabled: true\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	ClickAction.parameters = {
		...ClickAction.parameters,
		docs: {
			...ClickAction.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    children: 'Run action'\n  },\n  play: async ({\n    canvas,\n    userEvent,\n    args\n  }) => {\n    await userEvent.click(canvas.getByRole('button', {\n      name: /run action/i\n    }));\n    await expect(args.onClick).toHaveBeenCalled();\n  }\n}",
				...ClickAction.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Neutral",
		"Brand",
		"Danger",
		"IconOnly",
		"Disabled",
		"ClickAction"
	];
}));
//#endregion
init_UtilityButton_examples_stories();
export { Brand, ClickAction, Danger, Disabled, IconOnly, Neutral, __namedExportsOrder, meta as default, init_UtilityButton_examples_stories as n, UtilityButton_examples_stories_exports as t };

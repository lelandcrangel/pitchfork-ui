import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { W as RadioGroup, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/RadioGroup.examples.stories.tsx
var RadioGroup_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Basic: () => Basic,
	Disabled: () => Disabled,
	Horizontal: () => Horizontal,
	WithDescriptions: () => WithDescriptions,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var expect, planOptions, billingOptions, meta, Basic, Horizontal, WithDescriptions, Disabled, __namedExportsOrder;
var init_RadioGroup_examples_stories = __esmMin((() => {
	init_dist();
	({expect} = __STORYBOOK_MODULE_TEST__);
	planOptions = [
		{
			value: "starter",
			label: "Starter"
		},
		{
			value: "business",
			label: "Business"
		},
		{
			value: "enterprise",
			label: "Enterprise"
		}
	];
	billingOptions = [{
		value: "monthly",
		label: "Monthly billing",
		description: "Pay each month with flexibility to cancel any time."
	}, {
		value: "annual",
		label: "Annual billing",
		description: "Save 20% with a yearly subscription."
	}];
	meta = {
		title: "Examples/Radio Groups",
		component: RadioGroup,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			name: "plan",
			legend: "Choose a plan",
			options: planOptions
		}
	};
	Basic = {
		args: {
			name: "plan-basic",
			defaultValue: "business"
		},
		play: async ({ canvas }) => {
			await expect(canvas.getByLabelText(/business/i)).toBeChecked();
		}
	};
	Horizontal = { args: {
		name: "plan-horizontal",
		orientation: "horizontal",
		defaultValue: "starter"
	} };
	WithDescriptions = { args: {
		name: "billing-cycle",
		legend: "Billing cycle",
		options: billingOptions,
		defaultValue: "annual"
	} };
	Disabled = { args: {
		name: "plan-disabled",
		defaultValue: "enterprise",
		disabled: true
	} };
	Basic.parameters = {
		...Basic.parameters,
		docs: {
			...Basic.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    name: 'plan-basic',\n    defaultValue: 'business'\n  },\n  play: async ({\n    canvas\n  }) => {\n    await expect(canvas.getByLabelText(/business/i)).toBeChecked();\n  }\n}",
				...Basic.parameters?.docs?.source
			}
		}
	};
	Horizontal.parameters = {
		...Horizontal.parameters,
		docs: {
			...Horizontal.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    name: 'plan-horizontal',\n    orientation: 'horizontal',\n    defaultValue: 'starter'\n  }\n}",
				...Horizontal.parameters?.docs?.source
			}
		}
	};
	WithDescriptions.parameters = {
		...WithDescriptions.parameters,
		docs: {
			...WithDescriptions.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    name: 'billing-cycle',\n    legend: 'Billing cycle',\n    options: billingOptions,\n    defaultValue: 'annual'\n  }\n}",
				...WithDescriptions.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    name: 'plan-disabled',\n    defaultValue: 'enterprise',\n    disabled: true\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Basic",
		"Horizontal",
		"WithDescriptions",
		"Disabled"
	];
}));
//#endregion
init_RadioGroup_examples_stories();
export { Basic, Disabled, Horizontal, WithDescriptions, __namedExportsOrder, meta as default, init_RadioGroup_examples_stories as n, RadioGroup_examples_stories_exports as t };

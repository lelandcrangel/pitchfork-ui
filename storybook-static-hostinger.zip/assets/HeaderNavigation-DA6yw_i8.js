import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { ActionGroup, Default, NoActions, n as init_HeaderNavigation_examples_stories, t as HeaderNavigation_examples_stories_exports } from "./HeaderNavigation.examples.stories-Dn0-rQFj.js";
import { n as init_HeaderNavigation_stories, t as HeaderNavigation_stories_exports } from "./HeaderNavigation.stories-DZfr3Nis.js";
//#region src/HeaderNavigation.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: HeaderNavigation_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "header-navigation",
			children: "Header Navigation"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "HeaderNavigation provides a top-level nav pattern with brand, links, and optional actions." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: HeaderNavigation_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "no-actions",
			children: "No actions"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: NoActions,
			meta: HeaderNavigation_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "action-group",
			children: "Action group"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: ActionGroup,
			meta: HeaderNavigation_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_HeaderNavigation_stories();
	init_HeaderNavigation_examples_stories();
}))();
export { MDXContent as default };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { tt as Table, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Table.examples.stories.tsx
var Table_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	DenseStriped: () => DenseStriped,
	EmptyState: () => EmptyState,
	StickyHeader: () => StickyHeader,
	WithCaption: () => WithCaption,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Default, DenseStriped, WithCaption, StickyHeader, EmptyState, __namedExportsOrder;
var init_Table_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Table",
		component: Table,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			columns: [
				{
					key: "invoice",
					header: "Invoice",
					width: 140,
					sortable: true
				},
				{
					key: "customer",
					header: "Customer",
					sortable: true
				},
				{
					key: "dueDate",
					header: "Due date",
					sortable: true
				},
				{
					key: "amount",
					header: "Amount",
					align: "right",
					sortable: true,
					sortValue: (row) => {
						const raw = String(row.amount ?? "").replace(/[$,]/g, "");
						return Number(raw) || 0;
					}
				},
				{
					key: "status",
					header: "Status",
					sortable: true
				}
			],
			rows: [
				{
					invoice: "INV-1043",
					customer: "Acme Labs",
					dueDate: "May 14, 2026",
					amount: "$2,440.00",
					status: "Paid"
				},
				{
					invoice: "INV-1042",
					customer: "Northstar Health",
					dueDate: "May 21, 2026",
					amount: "$9,150.00",
					status: "Pending"
				},
				{
					invoice: "INV-1041",
					customer: "Solaris Group",
					dueDate: "May 22, 2026",
					amount: "$1,290.00",
					status: "Past due"
				},
				{
					invoice: "INV-1040",
					customer: "Parallel Works",
					dueDate: "May 25, 2026",
					amount: "$3,620.00",
					status: "Pending"
				},
				{
					invoice: "INV-1039",
					customer: "Borealis Ops",
					dueDate: "May 29, 2026",
					amount: "$4,830.00",
					status: "Paid"
				},
				{
					invoice: "INV-1038",
					customer: "Lumen Retail",
					dueDate: "Jun 02, 2026",
					amount: "$7,010.00",
					status: "Pending"
				},
				{
					invoice: "INV-1037",
					customer: "Vantage Co.",
					dueDate: "Jun 05, 2026",
					amount: "$540.00",
					status: "Paid"
				},
				{
					invoice: "INV-1036",
					customer: "Cinder Studio",
					dueDate: "Jun 08, 2026",
					amount: "$3,005.00",
					status: "Pending"
				}
			]
		}
	};
	Default = {};
	DenseStriped = { args: {
		dense: true,
		striped: true
	} };
	WithCaption = { args: { caption: "Outstanding invoices for Q2 billing cycle." } };
	StickyHeader = {
		args: {
			stickyHeader: true,
			striped: true
		},
		render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
			...args,
			style: { maxHeight: 260 }
		})
	};
	EmptyState = { args: {
		rows: [],
		emptyState: "No invoices were found for this filter set."
	} };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{}",
				...Default.parameters?.docs?.source
			}
		}
	};
	DenseStriped.parameters = {
		...DenseStriped.parameters,
		docs: {
			...DenseStriped.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    dense: true,\n    striped: true\n  }\n}",
				...DenseStriped.parameters?.docs?.source
			}
		}
	};
	WithCaption.parameters = {
		...WithCaption.parameters,
		docs: {
			...WithCaption.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    caption: 'Outstanding invoices for Q2 billing cycle.'\n  }\n}",
				...WithCaption.parameters?.docs?.source
			}
		}
	};
	StickyHeader.parameters = {
		...StickyHeader.parameters,
		docs: {
			...StickyHeader.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    stickyHeader: true,\n    striped: true\n  },\n  render: args => <Table {...args} style={{\n    maxHeight: 260\n  }} />\n}",
				...StickyHeader.parameters?.docs?.source
			}
		}
	};
	EmptyState.parameters = {
		...EmptyState.parameters,
		docs: {
			...EmptyState.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    rows: [],\n    emptyState: 'No invoices were found for this filter set.'\n  }\n}",
				...EmptyState.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"DenseStriped",
		"WithCaption",
		"StickyHeader",
		"EmptyState"
	];
}));
//#endregion
init_Table_examples_stories();
export { Default, DenseStriped, EmptyState, StickyHeader, WithCaption, __namedExportsOrder, meta as default, init_Table_examples_stories as n, Table_examples_stories_exports as t };

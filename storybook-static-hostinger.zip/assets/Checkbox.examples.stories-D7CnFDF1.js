import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { m as Checkbox, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Checkbox.examples.stories.tsx
var Checkbox_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Checked: () => Checked,
	Disabled: () => Disabled,
	Unchecked: () => Unchecked,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var expect, meta, Unchecked, Checked, Disabled, __namedExportsOrder;
var init_Checkbox_examples_stories = __esmMin((() => {
	init_dist();
	({expect} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Checkbox",
		component: Checkbox,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { label: "Enable notifications" }
	};
	Unchecked = {};
	Checked = {
		args: {
			defaultChecked: true,
			label: "Accessible by default"
		},
		play: async ({ canvas }) => {
			await expect(canvas.getByLabelText(/accessible by default/i)).toBeChecked();
		}
	};
	Disabled = { args: {
		disabled: true,
		label: "Disabled option"
	} };
	Unchecked.parameters = {
		...Unchecked.parameters,
		docs: {
			...Unchecked.parameters?.docs,
			source: {
				originalSource: "{}",
				...Unchecked.parameters?.docs?.source
			}
		}
	};
	Checked.parameters = {
		...Checked.parameters,
		docs: {
			...Checked.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultChecked: true,\n    label: 'Accessible by default'\n  },\n  play: async ({\n    canvas\n  }) => {\n    await expect(canvas.getByLabelText(/accessible by default/i)).toBeChecked();\n  }\n}",
				...Checked.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    disabled: true,\n    label: 'Disabled option'\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Unchecked",
		"Checked",
		"Disabled"
	];
}));
//#endregion
init_Checkbox_examples_stories();
export { Checked, Disabled, Unchecked, __namedExportsOrder, meta as default, init_Checkbox_examples_stories as n, Checkbox_examples_stories_exports as t };

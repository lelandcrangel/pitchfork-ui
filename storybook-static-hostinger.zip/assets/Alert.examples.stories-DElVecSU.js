import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as Alert, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Alert.examples.stories.tsx
var Alert_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Danger: () => Danger,
	Dismissible: () => Dismissible,
	Info: () => Info,
	Success: () => Success,
	Warning: () => Warning,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var fn, meta, Info, Success, Warning, Danger, Dismissible, __namedExportsOrder;
var init_Alert_examples_stories = __esmMin((() => {
	init_dist();
	({fn} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Alert",
		component: Alert,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			heading: "Heads up",
			description: "This is an informational alert message."
		}
	};
	Info = { args: { variant: "info" } };
	Success = { args: {
		variant: "success",
		heading: "Saved successfully",
		description: "Your settings have been updated."
	} };
	Warning = { args: {
		variant: "warning",
		heading: "Storage almost full",
		description: "You have less than 10% storage remaining."
	} };
	Danger = { args: {
		variant: "danger",
		heading: "Action failed",
		description: "We could not process your request. Please try again."
	} };
	Dismissible = { args: {
		dismissible: true,
		onDismiss: fn()
	} };
	Info.parameters = {
		...Info.parameters,
		docs: {
			...Info.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    variant: 'info'\n  }\n}",
				...Info.parameters?.docs?.source
			}
		}
	};
	Success.parameters = {
		...Success.parameters,
		docs: {
			...Success.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    variant: 'success',\n    heading: 'Saved successfully',\n    description: 'Your settings have been updated.'\n  }\n}",
				...Success.parameters?.docs?.source
			}
		}
	};
	Warning.parameters = {
		...Warning.parameters,
		docs: {
			...Warning.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    variant: 'warning',\n    heading: 'Storage almost full',\n    description: 'You have less than 10% storage remaining.'\n  }\n}",
				...Warning.parameters?.docs?.source
			}
		}
	};
	Danger.parameters = {
		...Danger.parameters,
		docs: {
			...Danger.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    variant: 'danger',\n    heading: 'Action failed',\n    description: 'We could not process your request. Please try again.'\n  }\n}",
				...Danger.parameters?.docs?.source
			}
		}
	};
	Dismissible.parameters = {
		...Dismissible.parameters,
		docs: {
			...Dismissible.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    dismissible: true,\n    onDismiss: fn()\n  }\n}",
				...Dismissible.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Info",
		"Success",
		"Warning",
		"Danger",
		"Dismissible"
	];
}));
//#endregion
init_Alert_examples_stories();
export { Danger, Dismissible, Info, Success, Warning, __namedExportsOrder, meta as default, init_Alert_examples_stories as n, Alert_examples_stories_exports as t };

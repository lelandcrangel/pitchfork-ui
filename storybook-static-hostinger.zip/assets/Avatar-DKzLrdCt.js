import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Initials, PresenceStatus, Sizes, WithImage, n as init_Avatar_examples_stories, t as Avatar_examples_stories_exports } from "./Avatar.examples.stories-DVO_0KCv.js";
import { n as init_Avatar_stories, t as Avatar_stories_exports } from "./Avatar.stories-CHDjnYpe.js";
//#region src/Avatar.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Avatar_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "avatar",
			children: "Avatar"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Avatars display people with either profile images or initials, plus optional status." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "initials",
			children: "Initials"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Initials,
			meta: Avatar_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-image",
			children: "With image"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithImage,
			meta: Avatar_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "sizes",
			children: "Sizes"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Sizes,
			meta: Avatar_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "presence-status",
			children: "Presence status"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: PresenceStatus,
			meta: Avatar_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Avatar_stories();
	init_Avatar_examples_stories();
}))();
export { MDXContent as default };

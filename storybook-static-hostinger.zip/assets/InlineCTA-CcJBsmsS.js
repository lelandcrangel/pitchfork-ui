import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Default, Info, Success, WarningWithActionGroup, n as init_InlineCTA_examples_stories, t as InlineCTA_examples_stories_exports } from "./InlineCTA.examples.stories-jpLVtdyJ.js";
import { n as init_InlineCTA_stories, t as InlineCTA_stories_exports } from "./InlineCTA.stories-CFor4JeH.js";
//#region src/InlineCTA.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: InlineCTA_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "inline-cta",
			children: "Inline CTA"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "InlineCTA surfaces short, contextual prompts with optional actions." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: InlineCTA_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "info",
			children: "Info"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Info,
			meta: InlineCTA_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "success",
			children: "Success"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Success,
			meta: InlineCTA_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "warning-with-action-group",
			children: "Warning with action group"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WarningWithActionGroup,
			meta: InlineCTA_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_InlineCTA_stories();
	init_InlineCTA_examples_stories();
}))();
export { MDXContent as default };

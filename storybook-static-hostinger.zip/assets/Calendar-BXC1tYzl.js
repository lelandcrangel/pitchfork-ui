import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { BoundedYearRange, Default, DisabledWeekends, NoOutsideDays, WithError, n as init_Calendar_examples_stories, t as Calendar_examples_stories_exports } from "./Calendar.examples.stories-DoM0hPZl.js";
import { n as init_Calendar_stories, t as Calendar_stories_exports } from "./Calendar.stories-CJp-gD8w.js";
//#region src/Calendar.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Calendar_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "calendar",
			children: "Calendar"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Calendar presents a month grid for choosing a date with keyboard-friendly controls and optional disabled dates." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: Calendar_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "no-outside-days",
			children: "No outside days"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: NoOutsideDays,
			meta: Calendar_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled-weekends",
			children: "Disabled weekends"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: DisabledWeekends,
			meta: Calendar_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "bounded-year-range",
			children: "Bounded year range"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: BoundedYearRange,
			meta: Calendar_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-error",
			children: "With error"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithError,
			meta: Calendar_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Calendar_stories();
	init_Calendar_examples_stories();
}))();
export { MDXContent as default };

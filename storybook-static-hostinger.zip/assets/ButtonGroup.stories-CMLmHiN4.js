import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { s as ButtonGroup, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/ButtonGroup.stories.tsx
var ButtonGroup_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Interactive, __namedExportsOrder;
var init_ButtonGroup_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Components/Button Group",
		component: ButtonGroup,
		tags: ["ai-generated", "test"],
		args: {
			"aria-label": "Time range",
			items: [
				{
					value: "today",
					label: "Today"
				},
				{
					value: "tomorrow",
					label: "Tomorrow"
				},
				{
					value: "week",
					label: "This week"
				}
			],
			defaultValue: "today"
		},
		argTypes: {
			multiple: { control: "boolean" },
			disabled: { control: "boolean" }
		}
	};
	Interactive = { args: {
		"aria-label": "Time range",
		items: [
			{
				value: "today",
				label: "Today"
			},
			{
				value: "tomorrow",
				label: "Tomorrow"
			},
			{
				value: "week",
				label: "This week"
			}
		],
		defaultValue: "today"
	} };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    'aria-label': 'Time range',\n    items: [{\n      value: 'today',\n      label: 'Today'\n    }, {\n      value: 'tomorrow',\n      label: 'Tomorrow'\n    }, {\n      value: 'week',\n      label: 'This week'\n    }],\n    defaultValue: 'today'\n  }\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_ButtonGroup_stories();
export { Interactive, __namedExportsOrder, meta as default, init_ButtonGroup_stories as n, ButtonGroup_stories_exports as t };

const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/blocks-OZ7n4nQC.js","assets/preload-helper-UB4_TMNL.js","assets/iframe-DMCHwO1W.js","assets/iframe-TudRqJbl.css","assets/react-dom-C5JFGGtM.js","assets/jsx-runtime-t3EfFlgk.js"])))=>i.map(i=>d[i]);
import { i as __esmMin, n as init_preload_helper, s as __toESM, t as __vitePreload } from "./preload-helper-UB4_TMNL.js";
import { k as require_react } from "./iframe-DMCHwO1W.js";
import { a as HeadersMdx, i as Docs, r as CodeOrSourceMdx, s as init_blocks, t as AnchorMdx } from "./blocks-OZ7n4nQC.js";
import { i as unmountElement, r as renderElement, t as init_react_18 } from "./react-18-BznVrT6D.js";
//#region ../../node_modules/@storybook/addon-docs/dist/_browser-chunks/chunk-OATZR77O.js
var import_react, defaultComponents, ErrorBoundary, DocsRenderer;
var init_chunk_OATZR77O = __esmMin((() => {
	import_react = /* @__PURE__ */ __toESM(require_react(), 1);
	init_react_18();
	init_blocks();
	init_preload_helper();
	defaultComponents = {
		code: CodeOrSourceMdx,
		a: AnchorMdx,
		...HeadersMdx
	}, ErrorBoundary = class extends import_react.Component {
		constructor() {
			super(...arguments);
			this.state = { hasError: !1 };
		}
		static getDerivedStateFromError() {
			return { hasError: !0 };
		}
		componentDidCatch(err) {
			let { showException } = this.props;
			showException(err);
		}
		render() {
			let { hasError } = this.state, { children } = this.props;
			return hasError ? null : import_react.createElement(import_react.Fragment, null, children);
		}
	}, DocsRenderer = class {
		constructor() {
			this.render = async (context, docsParameter, element) => {
				let components = {
					...defaultComponents,
					...docsParameter?.components
				}, TDocs = Docs;
				return new Promise((resolve, reject) => {
					__vitePreload(async () => {
						const { MDXProvider } = await import("./blocks-OZ7n4nQC.js").then((n) => (n.P(), n.F));
						return { MDXProvider };
					}, __vite__mapDeps([0,1,2,3,4,5])).then(({ MDXProvider }) => renderElement(import_react.createElement(ErrorBoundary, {
						showException: reject,
						key: Math.random()
					}, import_react.createElement(MDXProvider, { components }, import_react.createElement(TDocs, {
						context,
						docsParameter
					}))), element)).then(() => resolve());
				});
			}, this.unmount = (element) => {
				unmountElement(element);
			};
		}
	};
}));
//#endregion
__esmMin((() => {
	init_chunk_OATZR77O();
}))();
export { DocsRenderer };

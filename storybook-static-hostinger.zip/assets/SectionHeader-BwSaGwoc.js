import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Default, EndAligned, WithActionsAndMeta, n as init_SectionHeader_examples_stories, t as SectionHeader_examples_stories_exports } from "./SectionHeader.examples.stories-D7zQFGmU.js";
import { n as init_SectionHeader_stories, t as SectionHeader_stories_exports } from "./SectionHeader.stories-CMj5HH_N.js";
//#region src/SectionHeader.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: SectionHeader_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "section-headers",
			children: "Section Headers"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "SectionHeader provides a consistent top area for section titles, context, and actions." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: SectionHeader_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-actions-and-metadata",
			children: "With actions and metadata"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithActionsAndMeta,
			meta: SectionHeader_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "end-aligned",
			children: "End aligned"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: EndAligned,
			meta: SectionHeader_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_SectionHeader_stories();
	init_SectionHeader_examples_stories();
}))();
export { MDXContent as default };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { r as Badge, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Badge.stories.tsx
var Badge_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Interactive, __namedExportsOrder;
var init_Badge_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Components/Badge",
		component: Badge,
		tags: ["ai-generated", "test"],
		args: {
			children: "React",
			variant: "neutral"
		},
		argTypes: { variant: {
			control: "select",
			options: [
				"neutral",
				"brand",
				"success",
				"warning"
			]
		} }
	};
	Interactive = { args: {
		children: "Interactive badge",
		variant: "neutral"
	} };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    children: 'Interactive badge',\n    variant: 'neutral'\n  }\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Badge_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Badge_stories as n, Badge_stories_exports as t };

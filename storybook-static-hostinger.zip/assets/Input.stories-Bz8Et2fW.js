import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { ut as init_dist, w as Input } from "./dist-D1zMThSa.js";
//#region src/Input.stories.tsx
var Input_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Interactive, __namedExportsOrder;
var init_Input_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Components/Input",
		component: Input,
		tags: ["ai-generated", "test"],
		args: {
			label: "Email address",
			placeholder: "you@example.com",
			description: "We will never share your email."
		}
	};
	Interactive = { args: {
		label: "Interactive input",
		placeholder: "Type here",
		description: "Edit this input with controls."
	} };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Interactive input',\n    placeholder: 'Type here',\n    description: 'Edit this input with controls.'\n  }\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Input_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Input_stories as n, Input_stories_exports as t };

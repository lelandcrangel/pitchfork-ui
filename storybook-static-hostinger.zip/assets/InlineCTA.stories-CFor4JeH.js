import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { C as InlineCTA, o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/InlineCTA.stories.tsx
var InlineCTA_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_InlineCTA_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/InlineCTA",
		component: InlineCTA,
		tags: ["ai-generated", "test"],
		args: {
			heading: "Upgrade available",
			description: "Unlock additional features by upgrading your plan.",
			tone: "default",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				children: "Upgrade"
			})
		},
		argTypes: {
			tone: {
				control: "inline-radio",
				options: [
					"default",
					"info",
					"success",
					"warning"
				]
			},
			action: { control: false },
			icon: { control: false }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineCTA, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <InlineCTA {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_InlineCTA_stories();
export { Interactive, __namedExportsOrder, meta as default, init_InlineCTA_stories as n, InlineCTA_stories_exports as t };

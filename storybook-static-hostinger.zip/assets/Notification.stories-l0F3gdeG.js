import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { F as NotificationStack, P as Notification, o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Notification.stories.tsx
var Notification_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_Notification_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Notifications",
		component: Notification,
		tags: ["ai-generated", "test"],
		args: {
			heading: "New export is ready",
			description: "Your analytics export finished processing and is ready to download.",
			variant: "info",
			placement: "top-right",
			dismissible: true,
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "secondary",
				children: "Download"
			})
		},
		argTypes: {
			placement: {
				control: "inline-radio",
				options: [
					"top-right",
					"top-left",
					"bottom-right",
					"bottom-left"
				]
			},
			icon: { control: false },
			action: { control: false },
			onDismiss: { control: false }
		}
	};
	Interactive = {
		args: { placement: "top-right" },
		render: ({ placement, ...args }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationStack, {
			placement,
			style: { maxWidth: 420 },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notification, { ...args })
		})
	};
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    placement: 'top-right'\n  },\n  render: ({\n    placement,\n    ...args\n  }) => <NotificationStack placement={placement} style={{\n    maxWidth: 420\n  }}>\n      <Notification {...args} />\n    </NotificationStack>\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Notification_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Notification_stories as n, Notification_stories_exports as t };

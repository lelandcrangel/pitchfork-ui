import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { MinimalNoLegend, ProductHealth, TeamComparisonStyle, n as init_RadarChart_examples_stories, t as RadarChart_examples_stories_exports } from "./RadarChart.examples.stories-DMXVbGG9.js";
import { n as init_RadarChart_stories, t as RadarChart_stories_exports } from "./RadarChart.stories-KUfHc9oN.js";
//#region src/RadarChart.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: RadarChart_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "radar-charts",
			children: "Radar Charts"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "RadarChart visualizes strengths across multiple dimensions on a radial axis." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "product-health",
			children: "Product health"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: ProductHealth,
			meta: RadarChart_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "team-comparison-style",
			children: "Team comparison style"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: TeamComparisonStyle,
			meta: RadarChart_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "minimal-without-legend",
			children: "Minimal without legend"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: MinimalNoLegend,
			meta: RadarChart_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_RadarChart_stories();
	init_RadarChart_examples_stories();
}))();
export { MDXContent as default };

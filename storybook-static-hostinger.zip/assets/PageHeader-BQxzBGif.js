import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { CompactMobileFriendly, Default, WithBreadcrumbsAndMeta, n as init_PageHeader_examples_stories, t as PageHeader_examples_stories_exports } from "./PageHeader.examples.stories-B1cGgp7r.js";
import { n as init_PageHeader_stories, t as PageHeader_stories_exports } from "./PageHeader.stories-DGe7-F_Q.js";
//#region src/PageHeader.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: PageHeader_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "page-headers",
			children: "Page Headers"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "PageHeader combines page titling, supporting description, breadcrumbs, metadata, and actions into a reusable top-of-page layout." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: PageHeader_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-breadcrumbs-and-meta",
			children: "With breadcrumbs and meta"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithBreadcrumbsAndMeta,
			meta: PageHeader_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "compact-mobile-friendly",
			children: "Compact mobile friendly"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: CompactMobileFriendly,
			meta: PageHeader_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_PageHeader_stories();
	init_PageHeader_examples_stories();
}))();
export { MDXContent as default };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { S as Icon, lt as getAvailableIconNames, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Icon.examples.stories.tsx
var Icon_examples_stories_exports = /* @__PURE__ */ __exportAll({
	RegularSet: () => RegularSet,
	Sizes: () => Sizes,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, stackStyle, rowStyle, iconTileStyle, iconNameStyle, regularNames, IconGrid, meta, RegularSet, Sizes, __namedExportsOrder;
var init_Icon_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	stackStyle = {
		display: "grid",
		gap: 16
	};
	rowStyle = {
		display: "grid",
		gap: 14,
		gridTemplateColumns: "repeat(auto-fill, minmax(110px, 1fr))"
	};
	iconTileStyle = {
		alignItems: "center",
		border: "1px solid var(--color-semantic-border-default)",
		borderRadius: 8,
		color: "var(--color-semantic-text-default)",
		display: "grid",
		gap: 8,
		justifyItems: "center",
		minHeight: 74,
		padding: 10,
		textAlign: "center"
	};
	iconNameStyle = {
		color: "var(--color-semantic-text-muted)",
		fontSize: 12,
		lineHeight: 1.25
	};
	regularNames = getAvailableIconNames();
	IconGrid = ({ names, size }) => {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: rowStyle,
			children: names.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: iconTileStyle,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name,
					size
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					style: iconNameStyle,
					children: name
				})]
			}, name))
		});
	};
	meta = {
		title: "Examples/Icon",
		component: Icon,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			name: "circle-check",
			label: "Circle check icon"
		}
	};
	RegularSet = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconGrid, {
		names: regularNames,
		size: "lg"
	}) };
	Sizes = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: stackStyle,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: rowStyle,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "circle-check",
					size: "xs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "circle-check",
					size: "sm"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "circle-check",
					size: "lg"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "circle-check",
					size: "xl"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "circle-check",
					size: "2x"
				})
			]
		})
	}) };
	RegularSet.parameters = {
		...RegularSet.parameters,
		docs: {
			...RegularSet.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <IconGrid names={regularNames} size=\"lg\" />\n}",
				...RegularSet.parameters?.docs?.source
			}
		}
	};
	Sizes.parameters = {
		...Sizes.parameters,
		docs: {
			...Sizes.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <div style={stackStyle}>\n      <div style={rowStyle}>\n        <Icon name=\"circle-check\" size=\"xs\" />\n        <Icon name=\"circle-check\" size=\"sm\" />\n        <Icon name=\"circle-check\" size=\"lg\" />\n        <Icon name=\"circle-check\" size=\"xl\" />\n        <Icon name=\"circle-check\" size=\"2x\" />\n      </div>\n    </div>\n}",
				...Sizes.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["RegularSet", "Sizes"];
}));
//#endregion
init_Icon_examples_stories();
export { RegularSet, Sizes, __namedExportsOrder, meta as default, init_Icon_examples_stories as n, Icon_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { W as RadioGroup, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/RadioGroup.stories.tsx
var RadioGroup_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_RadioGroup_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Radio Groups",
		component: RadioGroup,
		tags: ["ai-generated", "test"],
		argTypes: {
			orientation: {
				control: { type: "inline-radio" },
				options: ["vertical", "horizontal"]
			},
			disabled: { control: { type: "boolean" } }
		},
		args: {
			name: "plan",
			legend: "Choose a plan",
			options: [
				{
					value: "starter",
					label: "Starter"
				},
				{
					value: "business",
					label: "Business"
				},
				{
					value: "enterprise",
					label: "Enterprise"
				}
			],
			defaultValue: "business",
			orientation: "vertical",
			disabled: false
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <RadioGroup {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_RadioGroup_stories();
export { Interactive, __namedExportsOrder, meta as default, init_RadioGroup_stories as n, RadioGroup_stories_exports as t };

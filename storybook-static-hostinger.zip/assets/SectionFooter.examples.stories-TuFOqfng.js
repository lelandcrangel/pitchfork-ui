import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { J as SectionFooter, o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/SectionFooter.examples.stories.tsx
var SectionFooter_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	EndAlignedActions: () => EndAlignedActions,
	NoDivider: () => NoDivider,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Default, NoDivider, EndAlignedActions, __namedExportsOrder;
var init_SectionFooter_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Section Footer",
		component: SectionFooter,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		]
	};
	Default = { args: {
		heading: "Finalize this section",
		description: "Changes are autosaved, but publishing makes them visible to users.",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "secondary",
			children: "Preview"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			children: "Publish"
		})] })
	} };
	NoDivider = { args: {
		heading: "No divider layout",
		description: "Useful when the parent card already has a border.",
		divider: false,
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			children: "Continue"
		})
	} };
	EndAlignedActions = { args: {
		align: "end",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "secondary",
			children: "Back"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			children: "Next step"
		})] })
	} };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    heading: 'Finalize this section',\n    description: 'Changes are autosaved, but publishing makes them visible to users.',\n    actions: <>\n        <Button size=\"sm\" variant=\"secondary\">\n          Preview\n        </Button>\n        <Button size=\"sm\">Publish</Button>\n      </>\n  }\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	NoDivider.parameters = {
		...NoDivider.parameters,
		docs: {
			...NoDivider.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    heading: 'No divider layout',\n    description: 'Useful when the parent card already has a border.',\n    divider: false,\n    actions: <Button size=\"sm\">Continue</Button>\n  }\n}",
				...NoDivider.parameters?.docs?.source
			}
		}
	};
	EndAlignedActions.parameters = {
		...EndAlignedActions.parameters,
		docs: {
			...EndAlignedActions.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    align: 'end',\n    actions: <>\n        <Button size=\"sm\" variant=\"secondary\">\n          Back\n        </Button>\n        <Button size=\"sm\">Next step</Button>\n      </>\n  }\n}",
				...EndAlignedActions.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"NoDivider",
		"EndAlignedActions"
	];
}));
//#endregion
init_SectionFooter_examples_stories();
export { Default, EndAlignedActions, NoDivider, __namedExportsOrder, meta as default, init_SectionFooter_examples_stories as n, SectionFooter_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { B as ProgressCircle, ut as init_dist, z as ProgressBar } from "./dist-D1zMThSa.js";
//#region src/ProgressIndicators.examples.stories.tsx
var ProgressIndicators_examples_stories_exports = /* @__PURE__ */ __exportAll({
	CircularDefault: () => CircularDefault,
	CircularLarge: () => CircularLarge,
	LinearComplete: () => LinearComplete,
	LinearDefault: () => LinearDefault,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, LinearDefault, LinearComplete, CircularDefault, CircularLarge, __namedExportsOrder;
var init_ProgressIndicators_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Progress Indicators",
		component: ProgressBar,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		]
	};
	LinearDefault = {
		args: { value: 32 },
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, { value: 32 })
	};
	LinearComplete = {
		args: { value: 100 },
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, { value: 100 })
	};
	CircularDefault = {
		args: { value: 68 },
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressCircle, { value: 68 })
	};
	CircularLarge = {
		args: { value: 84 },
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressCircle, {
			value: 84,
			size: 88,
			strokeWidth: 8
		})
	};
	LinearDefault.parameters = {
		...LinearDefault.parameters,
		docs: {
			...LinearDefault.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    value: 32\n  },\n  render: () => <ProgressBar value={32} />\n}",
				...LinearDefault.parameters?.docs?.source
			}
		}
	};
	LinearComplete.parameters = {
		...LinearComplete.parameters,
		docs: {
			...LinearComplete.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    value: 100\n  },\n  render: () => <ProgressBar value={100} />\n}",
				...LinearComplete.parameters?.docs?.source
			}
		}
	};
	CircularDefault.parameters = {
		...CircularDefault.parameters,
		docs: {
			...CircularDefault.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    value: 68\n  },\n  render: () => <ProgressCircle value={68} />\n}",
				...CircularDefault.parameters?.docs?.source
			}
		}
	};
	CircularLarge.parameters = {
		...CircularLarge.parameters,
		docs: {
			...CircularLarge.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    value: 84\n  },\n  render: () => <ProgressCircle value={84} size={88} strokeWidth={8} />\n}",
				...CircularLarge.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"LinearDefault",
		"LinearComplete",
		"CircularDefault",
		"CircularLarge"
	];
}));
//#endregion
init_ProgressIndicators_examples_stories();
export { CircularDefault, CircularLarge, LinearComplete, LinearDefault, __namedExportsOrder, meta as default, init_ProgressIndicators_examples_stories as n, ProgressIndicators_examples_stories_exports as t };

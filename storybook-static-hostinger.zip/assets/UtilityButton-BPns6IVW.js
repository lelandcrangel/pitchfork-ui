import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Brand, ClickAction, Danger, Disabled, IconOnly, Neutral, n as init_UtilityButton_examples_stories, t as UtilityButton_examples_stories_exports } from "./UtilityButton.examples.stories-D-Vkpmp1.js";
import { n as init_UtilityButton_stories, t as UtilityButton_stories_exports } from "./UtilityButton.stories-_-aP86K5.js";
//#region src/UtilityButton.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: UtilityButton_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "utility-button",
			children: "Utility Button"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Utility buttons are compact action controls for toolbars, menus, and contextual UI actions." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "neutral",
			children: "Neutral"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Neutral,
			meta: UtilityButton_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "brand",
			children: "Brand"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Brand,
			meta: UtilityButton_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "danger",
			children: "Danger"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Danger,
			meta: UtilityButton_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "icon-only",
			children: "Icon only"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: IconOnly,
			meta: UtilityButton_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled",
			children: "Disabled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Disabled,
			meta: UtilityButton_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "click-action",
			children: "Click action"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: ClickAction,
			meta: UtilityButton_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_UtilityButton_stories();
	init_UtilityButton_examples_stories();
}))();
export { MDXContent as default };

import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Default, MultipleSources, MutedLoop, WithError, WithPoster, n as init_VideoPlayer_examples_stories, t as VideoPlayer_examples_stories_exports } from "./VideoPlayer.examples.stories--2qvrwFQ.js";
import { n as init_VideoPlayer_stories, t as VideoPlayer_stories_exports } from "./VideoPlayer.stories-CiheEcUd.js";
//#region src/VideoPlayer.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: VideoPlayer_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "video-player",
			children: "Video Player"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "VideoPlayer wraps the native HTML5 video element with consistent field labeling, sizing, and error states." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: VideoPlayer_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-poster",
			children: "With poster"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithPoster,
			meta: VideoPlayer_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "muted-loop",
			children: "Muted loop"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: MutedLoop,
			meta: VideoPlayer_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "multiple-sources",
			children: "Multiple sources"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: MultipleSources,
			meta: VideoPlayer_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-error",
			children: "With error"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithError,
			meta: VideoPlayer_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_VideoPlayer_stories();
	init_VideoPlayer_examples_stories();
}))();
export { MDXContent as default };

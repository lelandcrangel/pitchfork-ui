import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { CharacterLimit, Disabled, Empty, ErrorState, WithStartingContent, n as init_RichTextEditor_examples_stories, t as RichTextEditor_examples_stories_exports } from "./RichTextEditor.examples.stories-eO0EFxWf.js";
import { n as init_RichTextEditor_stories, t as RichTextEditor_stories_exports } from "./RichTextEditor.stories-C_YTJfzI.js";
//#region src/RichTextEditor.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: RichTextEditor_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "rich-text-editor",
			children: "Rich Text Editor"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Rich text editors allow formatted content entry for product descriptions, comments, and structured notes." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "empty",
			children: "Empty"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Empty,
			meta: RichTextEditor_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-starting-content",
			children: "With starting content"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithStartingContent,
			meta: RichTextEditor_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "character-limit",
			children: "Character limit"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: CharacterLimit,
			meta: RichTextEditor_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled",
			children: "Disabled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Disabled,
			meta: RichTextEditor_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "error-state",
			children: "Error state"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: ErrorState,
			meta: RichTextEditor_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_RichTextEditor_stories();
	init_RichTextEditor_examples_stories();
}))();
export { MDXContent as default };

import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { LargePanel, LeftPlacement, RightPlacement, n as init_SlideoutMenu_examples_stories, t as SlideoutMenu_examples_stories_exports } from "./SlideoutMenu.examples.stories-bAzFME7c.js";
import { n as init_SlideoutMenu_stories, t as SlideoutMenu_stories_exports } from "./SlideoutMenu.stories-CsBcf96s.js";
//#region src/SlideoutMenu.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: SlideoutMenu_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "slideout-menus",
			children: "Slideout Menus"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "SlideoutMenu presents tasks in a side panel while preserving context on the underlying page." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "right-placement",
			children: "Right placement"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: RightPlacement,
			meta: SlideoutMenu_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "left-placement",
			children: "Left placement"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: LeftPlacement,
			meta: SlideoutMenu_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "large-panel",
			children: "Large panel"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: LargePanel,
			meta: SlideoutMenu_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_SlideoutMenu_stories();
	init_SlideoutMenu_examples_stories();
}))();
export { MDXContent as default };

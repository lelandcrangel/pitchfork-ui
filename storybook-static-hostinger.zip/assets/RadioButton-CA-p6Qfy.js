import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Checked, Disabled, Pair, Unchecked, n as init_RadioButton_examples_stories, t as RadioButton_examples_stories_exports } from "./RadioButton.examples.stories-QFVIIH9t.js";
import { n as init_RadioButton_stories, t as RadioButton_stories_exports } from "./RadioButton.stories-GQCcSCu7.js";
//#region src/RadioButton.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: RadioButton_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "radio-buttons",
			children: "Radio Buttons"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Radio buttons are ideal for selecting one option from a small set of mutually exclusive choices." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "basic",
			children: "Basic"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Unchecked,
			meta: RadioButton_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "checked-by-default",
			children: "Checked by default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Checked,
			meta: RadioButton_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled",
			children: "Disabled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Disabled,
			meta: RadioButton_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "option-pair",
			children: "Option pair"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Pair,
			meta: RadioButton_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_RadioButton_stories();
	init_RadioButton_examples_stories();
}))();
export { MDXContent as default };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { G as RatingBadge, K as RatingStars, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Rating.examples.stories.tsx
var Rating_examples_stories_exports = /* @__PURE__ */ __exportAll({
	BadgeDefault: () => BadgeDefault,
	BadgeSmall: () => BadgeSmall,
	StarsCompact: () => StarsCompact,
	StarsDefault: () => StarsDefault,
	StarsLarge: () => StarsLarge,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, StarsDefault, StarsCompact, StarsLarge, BadgeDefault, BadgeSmall, __namedExportsOrder;
var init_Rating_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Rating",
		component: RatingStars,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			value: 4.6,
			max: 5,
			size: 18,
			showValue: true
		}
	};
	StarsDefault = {};
	StarsCompact = { args: {
		value: 3.8,
		size: 14,
		showValue: false
	} };
	StarsLarge = { args: {
		value: 4.9,
		size: 24
	} };
	BadgeDefault = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RatingBadge, {
		value: 4.8,
		reviews: 2048
	}) };
	BadgeSmall = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RatingBadge, {
		value: 4.2,
		reviews: 324,
		size: "sm"
	}) };
	StarsDefault.parameters = {
		...StarsDefault.parameters,
		docs: {
			...StarsDefault.parameters?.docs,
			source: {
				originalSource: "{}",
				...StarsDefault.parameters?.docs?.source
			}
		}
	};
	StarsCompact.parameters = {
		...StarsCompact.parameters,
		docs: {
			...StarsCompact.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    value: 3.8,\n    size: 14,\n    showValue: false\n  }\n}",
				...StarsCompact.parameters?.docs?.source
			}
		}
	};
	StarsLarge.parameters = {
		...StarsLarge.parameters,
		docs: {
			...StarsLarge.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    value: 4.9,\n    size: 24\n  }\n}",
				...StarsLarge.parameters?.docs?.source
			}
		}
	};
	BadgeDefault.parameters = {
		...BadgeDefault.parameters,
		docs: {
			...BadgeDefault.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <RatingBadge value={4.8} reviews={2048} />\n}",
				...BadgeDefault.parameters?.docs?.source
			}
		}
	};
	BadgeSmall.parameters = {
		...BadgeSmall.parameters,
		docs: {
			...BadgeSmall.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <RatingBadge value={4.2} reviews={324} size=\"sm\" />\n}",
				...BadgeSmall.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"StarsDefault",
		"StarsCompact",
		"StarsLarge",
		"BadgeDefault",
		"BadgeSmall"
	];
}));
//#endregion
init_Rating_examples_stories();
export { BadgeDefault, BadgeSmall, StarsCompact, StarsDefault, StarsLarge, __namedExportsOrder, meta as default, init_Rating_examples_stories as n, Rating_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin, s as __toESM } from "./preload-helper-UB4_TMNL.js";
import { k as require_react } from "./iframe-DMCHwO1W.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { Q as SlideoutMenu, o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/SlideoutMenu.stories.tsx
var SlideoutMenu_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_react, import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_SlideoutMenu_stories = __esmMin((() => {
	import_react = /* @__PURE__ */ __toESM(require_react(), 1);
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Slideout Menus",
		component: SlideoutMenu,
		tags: ["ai-generated", "test"],
		args: {
			title: "Edit profile",
			description: "Update account settings and notification preferences.",
			placement: "right",
			size: "md",
			closeOnOverlayClick: true,
			showCloseButton: true
		},
		argTypes: {
			placement: {
				control: "select",
				options: ["left", "right"]
			},
			size: {
				control: "select",
				options: [
					"sm",
					"md",
					"lg"
				]
			},
			footer: { control: false },
			children: { control: false },
			onOpenChange: { control: false }
		}
	};
	Interactive = {
		args: { open: false },
		render: (args) => {
			const [open, setOpen] = (0, import_react.useState)(false);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen(true),
				children: "Open slideout"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideoutMenu, {
				...args,
				open,
				onOpenChange: setOpen,
				footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setOpen(false),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setOpen(false),
					children: "Save changes"
				})] }),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					style: { marginTop: 0 },
					children: "Slideout menus are useful for editing flows that should keep page context visible in the background."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					style: { marginBottom: 0 },
					children: "You can control placement, size, overlay behavior, and footer actions from this interactive story."
				})]
			})] });
		}
	};
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    open: false\n  },\n  render: args => {\n    const [open, setOpen] = useState(false);\n    return <>\n        <Button onClick={() => setOpen(true)}>Open slideout</Button>\n        <SlideoutMenu {...args} open={open} onOpenChange={setOpen} footer={<>\n              <Button variant=\"secondary\" onClick={() => setOpen(false)}>\n                Cancel\n              </Button>\n              <Button onClick={() => setOpen(false)}>Save changes</Button>\n            </>}>\n          <p style={{\n          marginTop: 0\n        }}>\n            Slideout menus are useful for editing flows that should keep page\n            context visible in the background.\n          </p>\n          <p style={{\n          marginBottom: 0\n        }}>\n            You can control placement, size, overlay behavior, and footer\n            actions from this interactive story.\n          </p>\n        </SlideoutMenu>\n      </>;\n  }\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_SlideoutMenu_stories();
export { Interactive, __namedExportsOrder, meta as default, init_SlideoutMenu_stories as n, SlideoutMenu_stories_exports as t };

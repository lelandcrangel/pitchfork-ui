import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { AutoStatusFromCurrent, CheckoutFlow, VerticalOnboarding, n as init_ProgressSteps_examples_stories, t as ProgressSteps_examples_stories_exports } from "./ProgressSteps.examples.stories-DCjLPRqU.js";
import { n as init_ProgressSteps_stories, t as ProgressSteps_stories_exports } from "./ProgressSteps.stories-BA2pTgpf.js";
//#region src/ProgressSteps.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: ProgressSteps_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "progress-steps",
			children: "Progress Steps"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "ProgressSteps shows multi-step workflows with clear complete, current, and upcoming states." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "checkout-flow",
			children: "Checkout flow"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: CheckoutFlow,
			meta: ProgressSteps_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "vertical-onboarding",
			children: "Vertical onboarding"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: VerticalOnboarding,
			meta: ProgressSteps_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "auto-status-from-current",
			children: "Auto status from current"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: AutoStatusFromCurrent,
			meta: ProgressSteps_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_ProgressSteps_stories();
	init_ProgressSteps_examples_stories();
}))();
export { MDXContent as default };

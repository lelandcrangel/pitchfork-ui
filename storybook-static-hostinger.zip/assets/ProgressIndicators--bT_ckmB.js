import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { CircularDefault, CircularLarge, LinearComplete, LinearDefault, n as init_ProgressIndicators_examples_stories, t as ProgressIndicators_examples_stories_exports } from "./ProgressIndicators.examples.stories-q_VWjRbT.js";
import { n as init_ProgressIndicators_stories, t as ProgressIndicators_stories_exports } from "./ProgressIndicators.stories-CWJbL1Cc.js";
//#region src/ProgressIndicators.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: ProgressIndicators_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "progress-indicators",
			children: "Progress Indicators"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Progress indicators provide visual feedback for completion status in linear and circular formats." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "linear-default",
			children: "Linear default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: LinearDefault,
			meta: ProgressIndicators_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "linear-complete",
			children: "Linear complete"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: LinearComplete,
			meta: ProgressIndicators_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "circular-default",
			children: "Circular default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: CircularDefault,
			meta: ProgressIndicators_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "circular-large",
			children: "Circular large"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: CircularLarge,
			meta: ProgressIndicators_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_ProgressIndicators_stories();
	init_ProgressIndicators_examples_stories();
}))();
export { MDXContent as default };

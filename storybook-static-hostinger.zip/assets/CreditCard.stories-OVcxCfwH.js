import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { _ as CreditCard, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/CreditCard.stories.tsx
var CreditCard_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Interactive, __namedExportsOrder;
var init_CreditCard_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Components/Credit Card",
		component: CreditCard,
		tags: ["ai-generated", "test"],
		args: {
			brand: "visa",
			cardNumber: "4242 4242 4242 4242",
			cardholderName: "Leland Rangel",
			expiry: "10/29",
			cvc: "123",
			masked: true
		},
		argTypes: {
			brand: {
				control: "select",
				options: [
					"generic",
					"visa",
					"mastercard",
					"amex"
				]
			},
			masked: { control: "boolean" }
		}
	};
	Interactive = {};
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_CreditCard_stories();
export { Interactive, __namedExportsOrder, meta as default, init_CreditCard_stories as n, CreditCard_stories_exports as t };

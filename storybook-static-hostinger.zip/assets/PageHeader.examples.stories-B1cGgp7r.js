import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { I as PageHeader, o as Button, r as Badge, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/PageHeader.examples.stories.tsx
var PageHeader_examples_stories_exports = /* @__PURE__ */ __exportAll({
	CompactMobileFriendly: () => CompactMobileFriendly,
	Default: () => Default,
	WithBreadcrumbsAndMeta: () => WithBreadcrumbsAndMeta,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Default, WithBreadcrumbsAndMeta, CompactMobileFriendly, __namedExportsOrder;
var init_PageHeader_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Page Headers",
		component: PageHeader,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		]
	};
	Default = { args: {
		heading: "Projects",
		description: "Track delivery, ownership, and recent activity across your organization.",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			children: "Create project"
		})
	} };
	WithBreadcrumbsAndMeta = { args: {
		eyebrow: "Revenue",
		heading: "Q2 growth report",
		description: "Review top-line performance and compare against targets.",
		breadcrumbs: [
			{
				label: "Reports",
				href: "#"
			},
			{
				label: "Finance",
				href: "#"
			},
			{
				label: "Q2 growth report",
				current: true
			}
		],
		metadata: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "success",
			children: "Published"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Updated 2 hours ago" })] }),
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "secondary",
			children: "Share"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			children: "Export"
		})] })
	} };
	CompactMobileFriendly = { args: {
		heading: "Team settings",
		description: "Manage members, roles, and permissions.",
		metadata: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "24 members" })
	} };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    heading: 'Projects',\n    description: 'Track delivery, ownership, and recent activity across your organization.',\n    actions: <Button size=\"sm\">Create project</Button>\n  }\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	WithBreadcrumbsAndMeta.parameters = {
		...WithBreadcrumbsAndMeta.parameters,
		docs: {
			...WithBreadcrumbsAndMeta.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    eyebrow: 'Revenue',\n    heading: 'Q2 growth report',\n    description: 'Review top-line performance and compare against targets.',\n    breadcrumbs: [{\n      label: 'Reports',\n      href: '#'\n    }, {\n      label: 'Finance',\n      href: '#'\n    }, {\n      label: 'Q2 growth report',\n      current: true\n    }],\n    metadata: <>\n        <Badge variant=\"success\">Published</Badge>\n        <span>Updated 2 hours ago</span>\n      </>,\n    actions: <>\n        <Button size=\"sm\" variant=\"secondary\">\n          Share\n        </Button>\n        <Button size=\"sm\">Export</Button>\n      </>\n  }\n}",
				...WithBreadcrumbsAndMeta.parameters?.docs?.source
			}
		}
	};
	CompactMobileFriendly.parameters = {
		...CompactMobileFriendly.parameters,
		docs: {
			...CompactMobileFriendly.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    heading: 'Team settings',\n    description: 'Manage members, roles, and permissions.',\n    metadata: <span>24 members</span>\n  }\n}",
				...CompactMobileFriendly.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"WithBreadcrumbsAndMeta",
		"CompactMobileFriendly"
	];
}));
//#endregion
init_PageHeader_examples_stories();
export { CompactMobileFriendly, Default, WithBreadcrumbsAndMeta, __namedExportsOrder, meta as default, init_PageHeader_examples_stories as n, PageHeader_examples_stories_exports as t };

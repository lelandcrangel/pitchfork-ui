import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { J as SectionFooter, o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/SectionFooter.stories.tsx
var SectionFooter_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_SectionFooter_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Section Footers",
		component: SectionFooter,
		tags: ["ai-generated", "test"],
		args: {
			heading: "Need to review before publishing?",
			description: "Resolve pending checks or save this section as draft.",
			align: "between",
			divider: true,
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "secondary",
				children: "Save draft"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				children: "Publish changes"
			})] })
		},
		argTypes: { actions: { control: false } }
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionFooter, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <SectionFooter {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_SectionFooter_stories();
export { Interactive, __namedExportsOrder, meta as default, init_SectionFooter_stories as n, SectionFooter_stories_exports as t };

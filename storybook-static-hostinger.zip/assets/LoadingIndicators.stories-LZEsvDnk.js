import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { D as LoadingSpinner, E as LoadingSkeleton, T as LoadingDots, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/LoadingIndicators.stories.tsx
var LoadingIndicators_stories_exports = /* @__PURE__ */ __exportAll({
	InteractiveDots: () => InteractiveDots,
	InteractiveSkeleton: () => InteractiveSkeleton,
	InteractiveSpinner: () => InteractiveSpinner,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, InteractiveSpinner, InteractiveDots, InteractiveSkeleton, __namedExportsOrder;
var init_LoadingIndicators_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Loading Indicators",
		component: LoadingSpinner,
		tags: ["ai-generated", "test"],
		args: {
			size: 28,
			label: "Loading"
		},
		argTypes: { label: { control: "text" } }
	};
	InteractiveSpinner = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSpinner, { ...args }) };
	InteractiveDots = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingDots, {
		size: "md",
		label: args.label
	}) };
	InteractiveSkeleton = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
		width: 220,
		height: 16,
		rounded: false,
		label: args.label
	}) };
	InteractiveSpinner.parameters = {
		...InteractiveSpinner.parameters,
		docs: {
			...InteractiveSpinner.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <LoadingSpinner {...args} />\n}",
				...InteractiveSpinner.parameters?.docs?.source
			}
		}
	};
	InteractiveDots.parameters = {
		...InteractiveDots.parameters,
		docs: {
			...InteractiveDots.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <LoadingDots size=\"md\" label={args.label} />\n}",
				...InteractiveDots.parameters?.docs?.source
			}
		}
	};
	InteractiveSkeleton.parameters = {
		...InteractiveSkeleton.parameters,
		docs: {
			...InteractiveSkeleton.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <LoadingSkeleton width={220} height={16} rounded={false} label={args.label} />\n}",
				...InteractiveSkeleton.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"InteractiveSpinner",
		"InteractiveDots",
		"InteractiveSkeleton"
	];
}));
//#endregion
init_LoadingIndicators_stories();
export { InteractiveDots, InteractiveSkeleton, InteractiveSpinner, __namedExportsOrder, meta as default, init_LoadingIndicators_stories as n, LoadingIndicators_stories_exports as t };

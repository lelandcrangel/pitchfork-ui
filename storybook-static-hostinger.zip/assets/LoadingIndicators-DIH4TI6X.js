import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { DotsVariants, SkeletonContentBlock, SpinnerSizes, n as init_LoadingIndicators_examples_stories, t as LoadingIndicators_examples_stories_exports } from "./LoadingIndicators.examples.stories-g0GlYfmZ.js";
import { n as init_LoadingIndicators_stories, t as LoadingIndicators_stories_exports } from "./LoadingIndicators.stories-LZEsvDnk.js";
//#region src/LoadingIndicators.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: LoadingIndicators_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "loading-indicators",
			children: "Loading Indicators"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Loading indicators communicate in-progress states for asynchronous actions and content fetching." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "spinner-sizes",
			children: "Spinner sizes"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: SpinnerSizes,
			meta: LoadingIndicators_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "dots-variants",
			children: "Dots variants"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: DotsVariants,
			meta: LoadingIndicators_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "skeleton-content-block",
			children: "Skeleton content block"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: SkeletonContentBlock,
			meta: LoadingIndicators_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_LoadingIndicators_stories();
	init_LoadingIndicators_examples_stories();
}))();
export { MDXContent as default };

import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { BoundedYearRange, Default, DisabledWeekends, NoOutsideDays, WithError, n as init_DatePicker_examples_stories, t as DatePicker_examples_stories_exports } from "./DatePicker.examples.stories-BPrO-45g.js";
import { n as init_DatePicker_stories, t as DatePicker_stories_exports } from "./DatePicker.stories-pJN9vXPO.js";
//#region src/DatePicker.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: DatePicker_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "date-picker",
			children: "Date Picker"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "DatePicker combines a field trigger with the Calendar component for selecting a single date." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: DatePicker_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "no-outside-days",
			children: "No outside days"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: NoOutsideDays,
			meta: DatePicker_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled-weekends",
			children: "Disabled weekends"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: DisabledWeekends,
			meta: DatePicker_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "bounded-year-range",
			children: "Bounded year range"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: BoundedYearRange,
			meta: DatePicker_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-error",
			children: "With error"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithError,
			meta: DatePicker_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_DatePicker_stories();
	init_DatePicker_examples_stories();
}))();
export { MDXContent as default };

import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Default, Scrollable, ToolbarOnly, WithLineNumbers, n as init_CodeSnippet_examples_stories, t as CodeSnippet_examples_stories_exports } from "./CodeSnippet.examples.stories-BppLV2WD.js";
import { n as init_CodeSnippet_stories, t as CodeSnippet_stories_exports } from "./CodeSnippet.stories-Bas_dQ2m.js";
//#region src/CodeSnippet.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: CodeSnippet_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "code-snippet",
			children: "Code Snippet"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "CodeSnippet presents code in a readable block with optional line numbers and one-click copy." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: CodeSnippet_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-line-numbers",
			children: "With line numbers"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithLineNumbers,
			meta: CodeSnippet_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "scrollable",
			children: "Scrollable"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Scrollable,
			meta: CodeSnippet_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "toolbar-only",
			children: "Toolbar only"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: ToolbarOnly,
			meta: CodeSnippet_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_CodeSnippet_stories();
	init_CodeSnippet_examples_stories();
}))();
export { MDXContent as default };

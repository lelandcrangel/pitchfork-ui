import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { q as RichTextEditor, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/RichTextEditor.examples.stories.tsx
var RichTextEditor_examples_stories_exports = /* @__PURE__ */ __exportAll({
	CharacterLimit: () => CharacterLimit,
	Disabled: () => Disabled,
	Empty: () => Empty,
	ErrorState: () => ErrorState,
	WithStartingContent: () => WithStartingContent,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Empty, WithStartingContent, Disabled, ErrorState, CharacterLimit, __namedExportsOrder;
var init_RichTextEditor_examples_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Examples/Rich Text Editor",
		component: RichTextEditor,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			label: "Description",
			description: "Use formatting controls to style your text.",
			placeholder: "Write product details...",
			minHeight: 160
		}
	};
	Empty = {};
	WithStartingContent = { args: { defaultValue: "<p><strong>Limited launch:</strong> Orders ship within 24 hours.</p><p>Includes free returns for 30 days.</p>" } };
	Disabled = { args: {
		disabled: true,
		defaultValue: "<p>Editing is disabled for archived records.</p>"
	} };
	ErrorState = { args: { error: "Please add at least 40 characters." } };
	CharacterLimit = { args: {
		label: "Product summary",
		description: "Keep this concise so it fits in card layouts.",
		characterMax: 120,
		defaultValue: "<p>Compact, fast, and flexible UI primitives for modern teams.</p>"
	} };
	Empty.parameters = {
		...Empty.parameters,
		docs: {
			...Empty.parameters?.docs,
			source: {
				originalSource: "{}",
				...Empty.parameters?.docs?.source
			}
		}
	};
	WithStartingContent.parameters = {
		...WithStartingContent.parameters,
		docs: {
			...WithStartingContent.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultValue: '<p><strong>Limited launch:</strong> Orders ship within 24 hours.</p><p>Includes free returns for 30 days.</p>'\n  }\n}",
				...WithStartingContent.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    disabled: true,\n    defaultValue: '<p>Editing is disabled for archived records.</p>'\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	ErrorState.parameters = {
		...ErrorState.parameters,
		docs: {
			...ErrorState.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    error: 'Please add at least 40 characters.'\n  }\n}",
				...ErrorState.parameters?.docs?.source
			}
		}
	};
	CharacterLimit.parameters = {
		...CharacterLimit.parameters,
		docs: {
			...CharacterLimit.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Product summary',\n    description: 'Keep this concise so it fits in card layouts.',\n    characterMax: 120,\n    defaultValue: '<p>Compact, fast, and flexible UI primitives for modern teams.</p>'\n  }\n}",
				...CharacterLimit.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Empty",
		"WithStartingContent",
		"Disabled",
		"ErrorState",
		"CharacterLimit"
	];
}));
//#endregion
init_RichTextEditor_examples_stories();
export { CharacterLimit, Disabled, Empty, ErrorState, WithStartingContent, __namedExportsOrder, meta as default, init_RichTextEditor_examples_stories as n, RichTextEditor_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { c as Calendar, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Calendar.stories.tsx
var Calendar_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_Calendar_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Calendar",
		component: Calendar,
		tags: ["ai-generated", "test"],
		args: {
			label: "Billing date",
			description: "Pick the date your billing cycle starts.",
			defaultValue: new Date(2026, 4, 22),
			showOutsideDays: true
		},
		argTypes: {
			showOutsideDays: { control: "boolean" },
			startYear: { control: {
				type: "number",
				min: 1900,
				max: 2100,
				step: 1
			} },
			endYear: { control: {
				type: "number",
				min: 1900,
				max: 2100,
				step: 1
			} }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <Calendar {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Calendar_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Calendar_stories as n, Calendar_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { p as Carousel, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Carousel.stories.tsx
var Carousel_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_Carousel_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Carousel",
		component: Carousel,
		tags: ["ai-generated", "test"],
		args: {
			slides: [
				{
					title: "Q2 Product Launch",
					text: "Track release milestones with slide-based highlights.",
					tone: "var(--color-semantic-action-primary)"
				},
				{
					title: "Customer Feedback",
					text: "Rotate key signals from support and product analytics.",
					tone: "#0284c7"
				},
				{
					title: "Weekly Metrics",
					text: "Show revenue, retention, and activation snapshots.",
					tone: "#0f766e"
				}
			].map((slide) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				style: {
					alignItems: "flex-start",
					background: `linear-gradient(135deg, ${slide.tone} 0%, color-mix(in srgb, ${slide.tone} 72%, white) 100%)`,
					color: "white",
					display: "flex",
					flexDirection: "column",
					gap: "8px",
					justifyContent: "center",
					minHeight: "180px",
					padding: "16px"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					style: {
						fontSize: "16px",
						margin: 0
					},
					children: slide.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					style: {
						margin: 0,
						maxWidth: "32ch",
						opacity: .95
					},
					children: slide.text
				})]
			}, slide.title)),
			loop: true,
			showIndicators: true,
			autoPlay: false,
			autoPlayInterval: 4e3
		},
		argTypes: {
			initialIndex: { control: {
				type: "number",
				min: 0,
				max: 4,
				step: 1
			} },
			loop: { control: "boolean" },
			showIndicators: { control: "boolean" },
			autoPlay: { control: "boolean" },
			autoPlayInterval: { control: {
				type: "number",
				min: 1e3,
				max: 1e4,
				step: 500
			} },
			slides: { control: false },
			onIndexChange: { control: false }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Carousel, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <Carousel {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Carousel_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Carousel_stories as n, Carousel_stories_exports as t };

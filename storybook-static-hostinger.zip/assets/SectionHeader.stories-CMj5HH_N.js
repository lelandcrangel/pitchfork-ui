import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { Y as SectionHeader, o as Button, r as Badge, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/SectionHeader.stories.tsx
var SectionHeader_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_SectionHeader_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Section Headers",
		component: SectionHeader,
		tags: ["ai-generated", "test"],
		args: {
			eyebrow: "Overview",
			heading: "Team activity",
			description: "Review status, ownership, and delivery metrics for this section.",
			divider: true,
			align: "between",
			metadata: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "brand",
				children: "Live"
			}),
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "secondary",
				children: "Export"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				children: "Create report"
			})] })
		},
		argTypes: {
			align: {
				control: "select",
				options: [
					"start",
					"between",
					"end"
				]
			},
			metadata: {
				control: "select",
				options: [
					"live",
					"healthy",
					"none"
				],
				mapping: {
					live: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "brand",
						children: "Live"
					}),
					healthy: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "success",
						children: "Healthy"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Updated 10m ago" })] }),
					none: null
				}
			},
			actions: {
				control: "select",
				options: [
					"export-and-create",
					"reset-and-apply",
					"none"
				],
				mapping: {
					"export-and-create": /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "secondary",
						children: "Export"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						children: "Create report"
					})] }),
					"reset-and-apply": /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "secondary",
						children: "Reset"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						children: "Apply"
					})] }),
					none: null
				}
			}
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <SectionHeader {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_SectionHeader_stories();
export { Interactive, __namedExportsOrder, meta as default, init_SectionHeader_stories as n, SectionHeader_stories_exports as t };

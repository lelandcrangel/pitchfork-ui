import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { ut as init_dist, w as Input } from "./dist-D1zMThSa.js";
//#region src/Input.examples.stories.tsx
var Input_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	WithError: () => WithError,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var expect, meta, Default, WithError, __namedExportsOrder;
var init_Input_examples_stories = __esmMin((() => {
	init_dist();
	({expect} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Input",
		component: Input,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			label: "Email address",
			placeholder: "you@example.com",
			description: "We will never share your email."
		}
	};
	Default = {};
	WithError = {
		args: { error: "Enter a valid email address." },
		play: async ({ canvas }) => {
			await expect(canvas.getByLabelText(/email address/i)).toHaveAttribute("aria-invalid", "true");
		}
	};
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{}",
				...Default.parameters?.docs?.source
			}
		}
	};
	WithError.parameters = {
		...WithError.parameters,
		docs: {
			...WithError.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    error: 'Enter a valid email address.'\n  },\n  play: async ({\n    canvas\n  }) => {\n    const input = canvas.getByLabelText(/email address/i);\n    await expect(input).toHaveAttribute('aria-invalid', 'true');\n  }\n}",
				...WithError.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Default", "WithError"];
}));
//#endregion
init_Input_examples_stories();
export { Default, WithError, __namedExportsOrder, meta as default, init_Input_examples_stories as n, Input_examples_stories_exports as t };

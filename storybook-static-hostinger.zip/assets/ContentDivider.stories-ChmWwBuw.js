import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { g as ContentDivider, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/ContentDivider.stories.tsx
var ContentDivider_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_ContentDivider_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/ContentDivider",
		component: ContentDivider,
		tags: ["ai-generated", "test"],
		args: {
			label: "Section title",
			orientation: "horizontal",
			inset: false
		},
		argTypes: {
			orientation: {
				control: "inline-radio",
				options: ["horizontal", "vertical"]
			},
			inset: { control: "boolean" }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: { minHeight: 120 },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContentDivider, { ...args })
	}) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <div style={{\n    minHeight: 120\n  }}>\n      <ContentDivider {...args} />\n    </div>\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_ContentDivider_stories();
export { Interactive, __namedExportsOrder, meta as default, init_ContentDivider_stories as n, ContentDivider_stories_exports as t };

import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { Danger, Dismissible, Info, Success, Warning, n as init_Alert_examples_stories, t as Alert_examples_stories_exports } from "./Alert.examples.stories-DElVecSU.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { n as init_Alert_stories, t as Alert_stories_exports } from "./Alert.stories-Ciq0hiKr.js";
//#region src/Alert.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Alert_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "alert",
			children: "Alert"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Alert surfaces contextual feedback with semantic variants and optional dismissal." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "info",
			children: "Info"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Info,
			meta: Alert_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "success",
			children: "Success"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Success,
			meta: Alert_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "warning",
			children: "Warning"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Warning,
			meta: Alert_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "danger",
			children: "Danger"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Danger,
			meta: Alert_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "dismissible",
			children: "Dismissible"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Dismissible,
			meta: Alert_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Alert_stories();
	init_Alert_examples_stories();
}))();
export { MDXContent as default };

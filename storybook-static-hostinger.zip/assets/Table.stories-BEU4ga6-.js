import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { tt as Table, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Table.stories.tsx
var Table_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Interactive, __namedExportsOrder;
var init_Table_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Components/Tables",
		component: Table,
		tags: ["ai-generated", "test"],
		args: {
			columns: [
				{
					key: "name",
					header: "Name",
					sortable: true
				},
				{
					key: "role",
					header: "Role",
					sortable: true
				},
				{
					key: "status",
					header: "Status",
					sortable: true
				},
				{
					key: "location",
					header: "Location",
					sortable: true
				},
				{
					key: "revenue",
					header: "Revenue",
					align: "right",
					sortable: true,
					sortValue: (row) => {
						const raw = String(row.revenue ?? "").replace(/[$,]/g, "");
						return Number(raw) || 0;
					}
				}
			],
			rows: [
				{
					name: "Olivia Rhye",
					role: "Product Designer",
					status: "Active",
					location: "Austin, TX",
					revenue: "$124,000"
				},
				{
					name: "Phoenix Baker",
					role: "Frontend Engineer",
					status: "Active",
					location: "Seattle, WA",
					revenue: "$143,000"
				},
				{
					name: "Lana Steiner",
					role: "Engineering Manager",
					status: "On leave",
					location: "Denver, CO",
					revenue: "$167,000"
				},
				{
					name: "Demi Wilkinson",
					role: "Sales Lead",
					status: "Active",
					location: "Chicago, IL",
					revenue: "$118,000"
				},
				{
					name: "Candice Wu",
					role: "Customer Success",
					status: "Inactive",
					location: "Portland, OR",
					revenue: "$102,000"
				}
			],
			caption: "Team performance snapshot for the current quarter.",
			dense: false,
			striped: false,
			hoverable: true,
			stickyHeader: false,
			defaultSortState: {
				key: "name",
				direction: "asc"
			}
		},
		argTypes: {
			columns: { control: false },
			rows: { control: false },
			emptyState: { control: "text" }
		}
	};
	Interactive = {};
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Table_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Table_stories as n, Table_stories_exports as t };

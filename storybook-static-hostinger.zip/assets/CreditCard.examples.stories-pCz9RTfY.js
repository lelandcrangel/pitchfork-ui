import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { _ as CreditCard, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/CreditCard.examples.stories.tsx
var CreditCard_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Mastercard: () => Mastercard,
	UnmaskedAmex: () => UnmaskedAmex,
	Visa: () => Visa,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Visa, Mastercard, UnmaskedAmex, __namedExportsOrder;
var init_CreditCard_examples_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Examples/Credit Card",
		component: CreditCard,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		]
	};
	Visa = { args: {
		brand: "visa",
		cardNumber: "4242 4242 4242 4242",
		cardholderName: "Leland Rangel",
		expiry: "10/29",
		cvc: "123"
	} };
	Mastercard = { args: {
		brand: "mastercard",
		cardNumber: "5555 4444 3333 2222",
		cardholderName: "Ava Parker",
		expiry: "08/28",
		cvc: "842"
	} };
	UnmaskedAmex = { args: {
		brand: "amex",
		cardNumber: "3782 822463 10005",
		cardholderName: "Jordan Kim",
		expiry: "03/30",
		cvc: "9421",
		masked: false
	} };
	Visa.parameters = {
		...Visa.parameters,
		docs: {
			...Visa.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    brand: 'visa',\n    cardNumber: '4242 4242 4242 4242',\n    cardholderName: 'Leland Rangel',\n    expiry: '10/29',\n    cvc: '123'\n  }\n}",
				...Visa.parameters?.docs?.source
			}
		}
	};
	Mastercard.parameters = {
		...Mastercard.parameters,
		docs: {
			...Mastercard.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    brand: 'mastercard',\n    cardNumber: '5555 4444 3333 2222',\n    cardholderName: 'Ava Parker',\n    expiry: '08/28',\n    cvc: '842'\n  }\n}",
				...Mastercard.parameters?.docs?.source
			}
		}
	};
	UnmaskedAmex.parameters = {
		...UnmaskedAmex.parameters,
		docs: {
			...UnmaskedAmex.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    brand: 'amex',\n    cardNumber: '3782 822463 10005',\n    cardholderName: 'Jordan Kim',\n    expiry: '03/30',\n    cvc: '9421',\n    masked: false\n  }\n}",
				...UnmaskedAmex.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Visa",
		"Mastercard",
		"UnmaskedAmex"
	];
}));
//#endregion
init_CreditCard_examples_stories();
export { Mastercard, UnmaskedAmex, Visa, __namedExportsOrder, meta as default, init_CreditCard_examples_stories as n, CreditCard_examples_stories_exports as t };

import { i as __esmMin, s as __toESM } from "./preload-helper-UB4_TMNL.js";
import { k as require_react } from "./iframe-DMCHwO1W.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { t as require_react_dom } from "./react-dom-C5JFGGtM.js";
//#region ../../packages/react/dist/index.js
function cx(...classes) {
	return classes.filter(Boolean).join(" ");
}
/*!
* Font Awesome Free 7.2.0 by @fontawesome - https://fontawesome.com
* License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
* Copyright 2026 Fonticons, Inc.
*/
/*!
* Font Awesome Free 7.2.0 by @fontawesome - https://fontawesome.com
* License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
* Copyright 2026 Fonticons, Inc.
*/
function _arrayLikeToArray(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function _arrayWithHoles(r) {
	if (Array.isArray(r)) return r;
}
function _arrayWithoutHoles(r) {
	if (Array.isArray(r)) return _arrayLikeToArray(r);
}
function _classCallCheck(a, n) {
	if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties(e, r) {
	for (var t = 0; t < r.length; t++) {
		var o = r[t];
		o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o);
	}
}
function _createClass(e, r, t) {
	return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function _createForOfIteratorHelper(r, e) {
	var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (!t) {
		if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
			t && (r = t);
			var n = 0, F = function() {};
			return {
				s: F,
				n: function() {
					return n >= r.length ? { done: !0 } : {
						done: !1,
						value: r[n++]
					};
				},
				e: function(r) {
					throw r;
				},
				f: F
			};
		}
		throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
	}
	var o, a = !0, u = !1;
	return {
		s: function() {
			t = t.call(r);
		},
		n: function() {
			var r = t.next();
			return a = r.done, r;
		},
		e: function(r) {
			u = !0, o = r;
		},
		f: function() {
			try {
				a || null == t.return || t.return();
			} finally {
				if (u) throw o;
			}
		}
	};
}
function _defineProperty(e, r, t) {
	return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _iterableToArray(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _iterableToArrayLimit(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = !0, o = !1;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = !0, n = r;
		} finally {
			try {
				if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _nonIterableRest() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _nonIterableSpread() {
	throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread2(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _slicedToArray(r, e) {
	return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
function _toConsumableArray(r) {
	return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
}
function _toPrimitive(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _toPropertyKey(t) {
	var i = _toPrimitive(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof(o);
}
function _unsupportedIterableToArray(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
	}
}
function familyProxy(obj) {
	return new Proxy(obj, { get: function get(target, prop) {
		return prop in target ? target[prop] : target[i];
	} });
}
function getAttrConfig(attr) {
	var element = DOCUMENT.querySelector("script[" + attr + "]");
	if (element) return element.getAttribute(attr);
}
function coerce(val) {
	if (val === "") return true;
	if (val === "false") return false;
	if (val === "true") return true;
	return val;
}
function onChange(cb) {
	_onChangeCb.push(cb);
	return function() {
		_onChangeCb.splice(_onChangeCb.indexOf(cb), 1);
	};
}
function insertCss(css) {
	if (!css || !IS_DOM) return;
	var style = DOCUMENT.createElement("style");
	style.setAttribute("type", "text/css");
	style.innerHTML = css;
	var headChildren = DOCUMENT.head.childNodes;
	var beforeChild = null;
	for (var i = headChildren.length - 1; i > -1; i--) {
		var child = headChildren[i];
		var tagName = (child.tagName || "").toUpperCase();
		if (["STYLE", "LINK"].indexOf(tagName) > -1) beforeChild = child;
	}
	DOCUMENT.head.insertBefore(style, beforeChild);
	return css;
}
function nextUniqueId() {
	var size = 12;
	var id = "";
	while (size-- > 0) id += idPool[Math.random() * 62 | 0];
	return id;
}
function toArray(obj) {
	var array = [];
	for (var i = (obj || []).length >>> 0; i--;) array[i] = obj[i];
	return array;
}
function classArray(node) {
	if (node.classList) return toArray(node.classList);
	else return (node.getAttribute("class") || "").split(" ").filter(function(i) {
		return i;
	});
}
function htmlEscape(str) {
	return "".concat(str).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function joinAttributes(attributes) {
	return Object.keys(attributes || {}).reduce(function(acc, attributeName) {
		return acc + "".concat(attributeName, "=\"").concat(htmlEscape(attributes[attributeName]), "\" ");
	}, "").trim();
}
function joinStyles(styles) {
	return Object.keys(styles || {}).reduce(function(acc, styleName) {
		return acc + "".concat(styleName, ": ").concat(styles[styleName].trim(), ";");
	}, "");
}
function transformIsMeaningful(transform) {
	return transform.size !== meaninglessTransform.size || transform.x !== meaninglessTransform.x || transform.y !== meaninglessTransform.y || transform.rotate !== meaninglessTransform.rotate || transform.flipX || transform.flipY;
}
function transformForSvg(_ref) {
	var transform = _ref.transform, containerWidth = _ref.containerWidth, iconWidth = _ref.iconWidth;
	var outer = { transform: "translate(".concat(containerWidth / 2, " 256)") };
	var innerTranslate = "translate(".concat(transform.x * 32, ", ").concat(transform.y * 32, ") ");
	var innerScale = "scale(".concat(transform.size / 16 * (transform.flipX ? -1 : 1), ", ").concat(transform.size / 16 * (transform.flipY ? -1 : 1), ") ");
	var innerRotate = "rotate(".concat(transform.rotate, " 0 0)");
	return {
		outer,
		inner: { transform: "".concat(innerTranslate, " ").concat(innerScale, " ").concat(innerRotate) },
		path: { transform: "translate(".concat(iconWidth / 2 * -1, " -256)") }
	};
}
function transformForCss(_ref2) {
	var transform = _ref2.transform, _ref2$width = _ref2.width, width = _ref2$width === void 0 ? UNITS_IN_GRID : _ref2$width, _ref2$height = _ref2.height, height = _ref2$height === void 0 ? UNITS_IN_GRID : _ref2$height, _ref2$startCentered = _ref2.startCentered, startCentered = _ref2$startCentered === void 0 ? false : _ref2$startCentered;
	var val = "";
	if (startCentered && IS_IE) val += "translate(".concat(transform.x / d$2 - width / 2, "em, ").concat(transform.y / d$2 - height / 2, "em) ");
	else if (startCentered) val += "translate(calc(-50% + ".concat(transform.x / d$2, "em), calc(-50% + ").concat(transform.y / d$2, "em)) ");
	else val += "translate(".concat(transform.x / d$2, "em, ").concat(transform.y / d$2, "em) ");
	val += "scale(".concat(transform.size / d$2 * (transform.flipX ? -1 : 1), ", ").concat(transform.size / d$2 * (transform.flipY ? -1 : 1), ") ");
	val += "rotate(".concat(transform.rotate, "deg) ");
	return val;
}
function css() {
	var dcp = DEFAULT_CSS_PREFIX;
	var drc = DEFAULT_REPLACEMENT_CLASS;
	var fp = config.cssPrefix;
	var rc = config.replacementClass;
	var s = baseStyles;
	if (fp !== dcp || rc !== drc) {
		var dPatt = new RegExp("\\.".concat(dcp, "\\-"), "g");
		var customPropPatt = new RegExp("\\--".concat(dcp, "\\-"), "g");
		var rPatt = new RegExp("\\.".concat(drc), "g");
		s = s.replace(dPatt, ".".concat(fp, "-")).replace(customPropPatt, "--".concat(fp, "-")).replace(rPatt, ".".concat(rc));
	}
	return s;
}
function ensureCss() {
	if (config.autoAddCss && !_cssInserted) {
		insertCss(css());
		_cssInserted = true;
	}
}
function domready(fn) {
	if (!IS_DOM) return;
	loaded ? setTimeout(fn, 0) : functions.push(fn);
}
function toHtml(abstractNodes) {
	var tag = abstractNodes.tag, _abstractNodes$attrib = abstractNodes.attributes, attributes = _abstractNodes$attrib === void 0 ? {} : _abstractNodes$attrib, _abstractNodes$childr = abstractNodes.children, children = _abstractNodes$childr === void 0 ? [] : _abstractNodes$childr;
	if (typeof abstractNodes === "string") return htmlEscape(abstractNodes);
	else return "<".concat(tag, " ").concat(joinAttributes(attributes), ">").concat(children.map(toHtml).join(""), "</").concat(tag, ">");
}
function iconFromMapping(mapping, prefix, iconName) {
	if (mapping && mapping[prefix] && mapping[prefix][iconName]) return {
		prefix,
		iconName,
		icon: mapping[prefix][iconName]
	};
}
/**
* Return hexadecimal string for a unicode character
* Returns `null` when more than one character (not bytes!) are passed
* For example: 'K' → '7B'
*/
function toHex(unicode) {
	if (_toConsumableArray(unicode).length !== 1) return null;
	return unicode.codePointAt(0).toString(16);
}
function normalizeIcons(icons) {
	return Object.keys(icons).reduce(function(acc, iconName) {
		var icon = icons[iconName];
		if (!!icon.icon) acc[icon.iconName] = icon.icon;
		else acc[iconName] = icon;
		return acc;
	}, {});
}
function defineIcons(prefix, icons) {
	var _params$skipHooks = (arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}).skipHooks, skipHooks = _params$skipHooks === void 0 ? false : _params$skipHooks;
	var normalized = normalizeIcons(icons);
	if (typeof namespace.hooks.addPack === "function" && !skipHooks) namespace.hooks.addPack(prefix, normalizeIcons(icons));
	else namespace.styles[prefix] = _objectSpread2(_objectSpread2({}, namespace.styles[prefix] || {}), normalized);
	/**
	* Font Awesome 4 used the prefix of `fa` for all icons. With the introduction
	* of new styles we needed to differentiate between them. Prefix `fa` is now an alias
	* for `fas` so we'll ease the upgrade process for our users by automatically defining
	* this as well.
	*/
	if (prefix === "fas") defineIcons("fa", icons);
}
function isReserved(name) {
	return ~RESERVED_CLASSES.indexOf(name);
}
function getIconName(cssPrefix, cls) {
	var parts = cls.split("-");
	var prefix = parts[0];
	var iconName = parts.slice(1).join("-");
	if (prefix === cssPrefix && iconName !== "" && !isReserved(iconName)) return iconName;
	else return null;
}
function byUnicode(prefix, unicode) {
	return (_byUnicode[prefix] || {})[unicode];
}
function byLigature(prefix, ligature) {
	return (_byLigature[prefix] || {})[ligature];
}
function byAlias(prefix, alias) {
	return (_byAlias[prefix] || {})[alias];
}
function byOldName(name) {
	return _byOldName[name] || {
		prefix: null,
		iconName: null
	};
}
function byOldUnicode(unicode) {
	var oldUnicode = _byOldUnicode[unicode];
	var newUnicode = byUnicode("fas", unicode);
	return oldUnicode || (newUnicode ? {
		prefix: "fas",
		iconName: newUnicode
	} : null) || {
		prefix: null,
		iconName: null
	};
}
function getDefaultUsablePrefix() {
	return _defaultUsablePrefix;
}
function getFamilyId(values) {
	var family = i;
	var famProps = FAMILY_NAMES.reduce(function(acc, familyId) {
		acc[familyId] = "".concat(config.cssPrefix, "-").concat(familyId);
		return acc;
	}, {});
	dt.forEach(function(familyId) {
		if (values.includes(famProps[familyId]) || values.some(function(v$$1) {
			return PREFIXES_FOR_FAMILY[familyId].includes(v$$1);
		})) family = familyId;
	});
	return family;
}
function getCanonicalPrefix(styleOrPrefix) {
	var _params$family = (arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}).family, family = _params$family === void 0 ? i : _params$family;
	var style = PREFIX_TO_STYLE[family][styleOrPrefix];
	if (family === t && !styleOrPrefix) return "fad";
	var prefix = STYLE_TO_PREFIX[family][styleOrPrefix] || STYLE_TO_PREFIX[family][style];
	var defined = styleOrPrefix in namespace.styles ? styleOrPrefix : null;
	return prefix || defined || null;
}
function moveNonFaClassesToRest(classNames) {
	var rest = [];
	var iconName = null;
	classNames.forEach(function(cls) {
		var result = getIconName(config.cssPrefix, cls);
		if (result) iconName = result;
		else if (cls) rest.push(cls);
	});
	return {
		iconName,
		rest
	};
}
function sortedUniqueValues(arr) {
	return arr.sort().filter(function(value, index, arr) {
		return arr.indexOf(value) === index;
	});
}
function getCanonicalIcon(values) {
	var _params$skipLookups = (arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}).skipLookups, skipLookups = _params$skipLookups === void 0 ? false : _params$skipLookups;
	var givenPrefix = null;
	var faStyleOrFamilyClasses = sortedUniqueValues(values.filter(function(cls) {
		return _faCombinedClasses.includes(cls);
	}));
	var nonStyleOrFamilyClasses = sortedUniqueValues(values.filter(function(cls) {
		return !_faCombinedClasses.includes(cls);
	}));
	var _faStyles$ = _slicedToArray(faStyleOrFamilyClasses.filter(function(cls) {
		givenPrefix = cls;
		return !Z.includes(cls);
	}), 1)[0], styleFromValues = _faStyles$ === void 0 ? null : _faStyles$;
	var family = getFamilyId(faStyleOrFamilyClasses);
	var canonical = _objectSpread2(_objectSpread2({}, moveNonFaClassesToRest(nonStyleOrFamilyClasses)), {}, { prefix: getCanonicalPrefix(styleFromValues, { family }) });
	return _objectSpread2(_objectSpread2(_objectSpread2({}, canonical), getDefaultCanonicalPrefix({
		values,
		family,
		styles,
		config,
		canonical,
		givenPrefix
	})), applyShimAndAlias(skipLookups, givenPrefix, canonical));
}
function applyShimAndAlias(skipLookups, givenPrefix, canonical) {
	var prefix = canonical.prefix, iconName = canonical.iconName;
	if (skipLookups || !prefix || !iconName) return {
		prefix,
		iconName
	};
	var shim = givenPrefix === "fa" ? byOldName(iconName) : {};
	var aliasIconName = byAlias(prefix, iconName);
	iconName = shim.iconName || aliasIconName || iconName;
	prefix = shim.prefix || prefix;
	if (prefix === "far" && !styles["far"] && styles["fas"] && !config.autoFetchSvg) prefix = "fas";
	return {
		prefix,
		iconName
	};
}
function getDefaultCanonicalPrefix(prefixOptions) {
	var values = prefixOptions.values, family = prefixOptions.family, canonical = prefixOptions.canonical, _prefixOptions$givenP = prefixOptions.givenPrefix, givenPrefix = _prefixOptions$givenP === void 0 ? "" : _prefixOptions$givenP, _prefixOptions$styles = prefixOptions.styles, styles = _prefixOptions$styles === void 0 ? {} : _prefixOptions$styles, _prefixOptions$config = prefixOptions.config, config$$1 = _prefixOptions$config === void 0 ? {} : _prefixOptions$config;
	var isDuotoneFamily = family === t;
	var valuesHasDuotone = values.includes("fa-duotone") || values.includes("fad");
	var defaultFamilyIsDuotone = config$$1.familyDefault === "duotone";
	var canonicalPrefixIsDuotone = canonical.prefix === "fad" || canonical.prefix === "fa-duotone";
	if (!isDuotoneFamily && (valuesHasDuotone || defaultFamilyIsDuotone || canonicalPrefixIsDuotone)) canonical.prefix = "fad";
	if (values.includes("fa-brands") || values.includes("fab")) canonical.prefix = "fab";
	if (!canonical.prefix && newCanonicalFamilies.includes(family)) {
		if (Object.keys(styles).find(function(key) {
			return newCanonicalStyles.includes(key);
		}) || config$$1.autoFetchSvg) {
			canonical.prefix = Et.get(family).defaultShortPrefixId;
			canonical.iconName = byAlias(canonical.prefix, canonical.iconName) || canonical.iconName;
		}
	}
	if (canonical.prefix === "fa" || givenPrefix === "fa") canonical.prefix = getDefaultUsablePrefix() || "fas";
	return canonical;
}
function registerPlugins(nextPlugins, _ref) {
	var obj = _ref.mixoutsTo;
	_plugins = nextPlugins;
	_hooks = {};
	Object.keys(providers).forEach(function(k) {
		if (defaultProviderKeys.indexOf(k) === -1) delete providers[k];
	});
	_plugins.forEach(function(plugin) {
		var mixout = plugin.mixout ? plugin.mixout() : {};
		Object.keys(mixout).forEach(function(tk) {
			if (typeof mixout[tk] === "function") obj[tk] = mixout[tk];
			if (_typeof(mixout[tk]) === "object") Object.keys(mixout[tk]).forEach(function(sk) {
				if (!obj[tk]) obj[tk] = {};
				obj[tk][sk] = mixout[tk][sk];
			});
		});
		if (plugin.hooks) {
			var hooks = plugin.hooks();
			Object.keys(hooks).forEach(function(hook) {
				if (!_hooks[hook]) _hooks[hook] = [];
				_hooks[hook].push(hooks[hook]);
			});
		}
		if (plugin.provides) plugin.provides(providers);
	});
	return obj;
}
function chainHooks(hook, accumulator) {
	for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) args[_key - 2] = arguments[_key];
	(_hooks[hook] || []).forEach(function(hookFn) {
		accumulator = hookFn.apply(null, [accumulator].concat(args));
	});
	return accumulator;
}
function callHooks(hook) {
	for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) args[_key2 - 1] = arguments[_key2];
	(_hooks[hook] || []).forEach(function(hookFn) {
		hookFn.apply(null, args);
	});
}
function callProvided() {
	var hook = arguments[0];
	var args = Array.prototype.slice.call(arguments, 1);
	return providers[hook] ? providers[hook].apply(null, args) : void 0;
}
function findIconDefinition(iconLookup) {
	if (iconLookup.prefix === "fa") iconLookup.prefix = "fas";
	var iconName = iconLookup.iconName;
	var prefix = iconLookup.prefix || getDefaultUsablePrefix();
	if (!iconName) return;
	iconName = byAlias(prefix, iconName) || iconName;
	return iconFromMapping(library.definitions, prefix, iconName) || iconFromMapping(namespace.styles, prefix, iconName);
}
function domVariants(val, abstractCreator) {
	Object.defineProperty(val, "abstract", { get: abstractCreator });
	Object.defineProperty(val, "html", { get: function get() {
		return val.abstract.map(function(a) {
			return toHtml(a);
		});
	} });
	Object.defineProperty(val, "node", { get: function get() {
		if (!IS_DOM) return void 0;
		var container = DOCUMENT.createElement("div");
		container.innerHTML = val.html;
		return container.children;
	} });
	return val;
}
function asIcon(_ref) {
	var children = _ref.children, main = _ref.main, mask = _ref.mask, attributes = _ref.attributes, styles = _ref.styles, transform = _ref.transform;
	if (transformIsMeaningful(transform) && main.found && !mask.found) {
		var offset = {
			x: main.width / main.height / 2,
			y: .5
		};
		attributes["style"] = joinStyles(_objectSpread2(_objectSpread2({}, styles), {}, { "transform-origin": "".concat(offset.x + transform.x / 16, "em ").concat(offset.y + transform.y / 16, "em") }));
	}
	return [{
		tag: "svg",
		attributes,
		children
	}];
}
function asSymbol(_ref) {
	var prefix = _ref.prefix, iconName = _ref.iconName, children = _ref.children, attributes = _ref.attributes, symbol = _ref.symbol;
	var id = symbol === true ? "".concat(prefix, "-").concat(config.cssPrefix, "-").concat(iconName) : symbol;
	return [{
		tag: "svg",
		attributes: { style: "display: none;" },
		children: [{
			tag: "symbol",
			attributes: _objectSpread2(_objectSpread2({}, attributes), {}, { id }),
			children
		}]
	}];
}
function isLabeled(attributes) {
	return [
		"aria-label",
		"aria-labelledby",
		"title",
		"role"
	].some(function(label) {
		return label in attributes;
	});
}
function makeInlineSvgAbstract(params) {
	var _params$icons = params.icons, main = _params$icons.main, mask = _params$icons.mask, prefix = params.prefix, iconName = params.iconName, transform = params.transform, symbol = params.symbol, maskId = params.maskId, extra = params.extra, _params$watchable = params.watchable, watchable = _params$watchable === void 0 ? false : _params$watchable;
	var _ref = mask.found ? mask : main, width = _ref.width, height = _ref.height;
	var attrClass = [config.replacementClass, iconName ? "".concat(config.cssPrefix, "-").concat(iconName) : ""].filter(function(c) {
		return extra.classes.indexOf(c) === -1;
	}).filter(function(c) {
		return c !== "" || !!c;
	}).concat(extra.classes).join(" ");
	var content = {
		children: [],
		attributes: _objectSpread2(_objectSpread2({}, extra.attributes), {}, {
			"data-prefix": prefix,
			"data-icon": iconName,
			"class": attrClass,
			"role": extra.attributes.role || "img",
			"viewBox": "0 0 ".concat(width, " ").concat(height)
		})
	};
	if (!isLabeled(extra.attributes) && !extra.attributes["aria-hidden"]) content.attributes["aria-hidden"] = "true";
	if (watchable) content.attributes[DATA_FA_I2SVG] = "";
	var args = _objectSpread2(_objectSpread2({}, content), {}, {
		prefix,
		iconName,
		main,
		mask,
		maskId,
		transform,
		symbol,
		styles: _objectSpread2({}, extra.styles)
	});
	var _ref2 = mask.found && main.found ? callProvided("generateAbstractMask", args) || {
		children: [],
		attributes: {}
	} : callProvided("generateAbstractIcon", args) || {
		children: [],
		attributes: {}
	}, children = _ref2.children, attributes = _ref2.attributes;
	args.children = children;
	args.attributes = attributes;
	if (symbol) return asSymbol(args);
	else return asIcon(args);
}
function makeLayersTextAbstract(params) {
	var content = params.content, width = params.width, height = params.height, transform = params.transform, extra = params.extra, _params$watchable2 = params.watchable, watchable = _params$watchable2 === void 0 ? false : _params$watchable2;
	var attributes = _objectSpread2(_objectSpread2({}, extra.attributes), {}, { class: extra.classes.join(" ") });
	if (watchable) attributes[DATA_FA_I2SVG] = "";
	var styles = _objectSpread2({}, extra.styles);
	if (transformIsMeaningful(transform)) {
		styles["transform"] = transformForCss({
			transform,
			startCentered: true,
			width,
			height
		});
		styles["-webkit-transform"] = styles["transform"];
	}
	var styleString = joinStyles(styles);
	if (styleString.length > 0) attributes["style"] = styleString;
	var val = [];
	val.push({
		tag: "span",
		attributes,
		children: [content]
	});
	return val;
}
function makeLayersCounterAbstract(params) {
	var content = params.content, extra = params.extra;
	var attributes = _objectSpread2(_objectSpread2({}, extra.attributes), {}, { class: extra.classes.join(" ") });
	var styleString = joinStyles(extra.styles);
	if (styleString.length > 0) attributes["style"] = styleString;
	var val = [];
	val.push({
		tag: "span",
		attributes,
		children: [content]
	});
	return val;
}
function asFoundIcon(icon) {
	var width = icon[0];
	var height = icon[1];
	var vectorData = _slicedToArray(icon.slice(4), 1)[0];
	var element = null;
	if (Array.isArray(vectorData)) element = {
		tag: "g",
		attributes: { class: "".concat(config.cssPrefix, "-").concat(DUOTONE_CLASSES.GROUP) },
		children: [{
			tag: "path",
			attributes: {
				class: "".concat(config.cssPrefix, "-").concat(DUOTONE_CLASSES.SECONDARY),
				fill: "currentColor",
				d: vectorData[0]
			}
		}, {
			tag: "path",
			attributes: {
				class: "".concat(config.cssPrefix, "-").concat(DUOTONE_CLASSES.PRIMARY),
				fill: "currentColor",
				d: vectorData[1]
			}
		}]
	};
	else element = {
		tag: "path",
		attributes: {
			fill: "currentColor",
			d: vectorData
		}
	};
	return {
		found: true,
		width,
		height,
		icon: element
	};
}
function maybeNotifyMissing(iconName, prefix) {
	if (!PRODUCTION && !config.showMissingIcons && iconName) console.error("Icon with name \"".concat(iconName, "\" and prefix \"").concat(prefix, "\" is missing."));
}
function findIcon(iconName, prefix) {
	var givenPrefix = prefix;
	if (prefix === "fa" && config.styleDefault !== null) prefix = getDefaultUsablePrefix();
	return new Promise(function(resolve, reject) {
		if (givenPrefix === "fa") {
			var shim = byOldName(iconName) || {};
			iconName = shim.iconName || iconName;
			prefix = shim.prefix || prefix;
		}
		if (iconName && prefix && styles$1[prefix] && styles$1[prefix][iconName]) {
			var icon = styles$1[prefix][iconName];
			return resolve(asFoundIcon(icon));
		}
		maybeNotifyMissing(iconName, prefix);
		resolve(_objectSpread2(_objectSpread2({}, missingIconResolutionMixin), {}, { icon: config.showMissingIcons && iconName ? callProvided("missingIconAbstract") || {} : {} }));
	});
}
function isWatched(node) {
	return typeof (node.getAttribute ? node.getAttribute(DATA_FA_I2SVG) : null) === "string";
}
function hasPrefixAndIcon(node) {
	var prefix = node.getAttribute ? node.getAttribute(DATA_PREFIX) : null;
	var icon = node.getAttribute ? node.getAttribute(DATA_ICON) : null;
	return prefix && icon;
}
function hasBeenReplaced(node) {
	return node && node.classList && node.classList.contains && node.classList.contains(config.replacementClass);
}
function getMutator() {
	if (config.autoReplaceSvg === true) return mutators.replace;
	return mutators[config.autoReplaceSvg] || mutators.replace;
}
function createElementNS(tag) {
	return DOCUMENT.createElementNS("http://www.w3.org/2000/svg", tag);
}
function createElement(tag) {
	return DOCUMENT.createElement(tag);
}
function convertSVG(abstractObj) {
	var _params$ceFn = (arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}).ceFn, ceFn = _params$ceFn === void 0 ? abstractObj.tag === "svg" ? createElementNS : createElement : _params$ceFn;
	if (typeof abstractObj === "string") return DOCUMENT.createTextNode(abstractObj);
	var tag = ceFn(abstractObj.tag);
	Object.keys(abstractObj.attributes || []).forEach(function(key) {
		tag.setAttribute(key, abstractObj.attributes[key]);
	});
	(abstractObj.children || []).forEach(function(child) {
		tag.appendChild(convertSVG(child, { ceFn }));
	});
	return tag;
}
function nodeAsComment(node) {
	var comment = " ".concat(node.outerHTML, " ");
	comment = "".concat(comment, "Font Awesome fontawesome.com ");
	return comment;
}
function performOperationSync(op) {
	op();
}
function perform(mutations, callback) {
	var callbackFunction = typeof callback === "function" ? callback : noop$2;
	if (mutations.length === 0) callbackFunction();
	else {
		var frame = performOperationSync;
		if (config.mutateApproach === MUTATION_APPROACH_ASYNC) frame = WINDOW.requestAnimationFrame || performOperationSync;
		frame(function() {
			var mutator = getMutator();
			var mark = perf.begin("mutate");
			mutations.map(mutator);
			mark();
			callbackFunction();
		});
	}
}
function disableObservation() {
	disabled = true;
}
function enableObservation() {
	disabled = false;
}
function observe(options) {
	if (!MUTATION_OBSERVER) return;
	if (!config.observeMutations) return;
	var _options$treeCallback = options.treeCallback, treeCallback = _options$treeCallback === void 0 ? noop$2 : _options$treeCallback, _options$nodeCallback = options.nodeCallback, nodeCallback = _options$nodeCallback === void 0 ? noop$2 : _options$nodeCallback, _options$pseudoElemen = options.pseudoElementsCallback, pseudoElementsCallback = _options$pseudoElemen === void 0 ? noop$2 : _options$pseudoElemen, _options$observeMutat = options.observeMutationsRoot, observeMutationsRoot = _options$observeMutat === void 0 ? DOCUMENT : _options$observeMutat;
	mo = new MUTATION_OBSERVER(function(objects) {
		if (disabled) return;
		var defaultPrefix = getDefaultUsablePrefix();
		toArray(objects).forEach(function(mutationRecord) {
			if (mutationRecord.type === "childList" && mutationRecord.addedNodes.length > 0 && !isWatched(mutationRecord.addedNodes[0])) {
				if (config.searchPseudoElements) pseudoElementsCallback(mutationRecord.target);
				treeCallback(mutationRecord.target);
			}
			if (mutationRecord.type === "attributes" && mutationRecord.target.parentNode && config.searchPseudoElements) pseudoElementsCallback([mutationRecord.target], true);
			if (mutationRecord.type === "attributes" && isWatched(mutationRecord.target) && ~ATTRIBUTES_WATCHED_FOR_MUTATION.indexOf(mutationRecord.attributeName)) {
				if (mutationRecord.attributeName === "class" && hasPrefixAndIcon(mutationRecord.target)) {
					var _getCanonicalIcon = getCanonicalIcon(classArray(mutationRecord.target)), prefix = _getCanonicalIcon.prefix, iconName = _getCanonicalIcon.iconName;
					mutationRecord.target.setAttribute(DATA_PREFIX, prefix || defaultPrefix);
					if (iconName) mutationRecord.target.setAttribute(DATA_ICON, iconName);
				} else if (hasBeenReplaced(mutationRecord.target)) nodeCallback(mutationRecord.target);
			}
		});
	});
	if (!IS_DOM) return;
	mo.observe(observeMutationsRoot, {
		childList: true,
		attributes: true,
		characterData: true,
		subtree: true
	});
}
function disconnect() {
	if (!mo) return;
	mo.disconnect();
}
function styleParser(node) {
	var style = node.getAttribute("style");
	var val = [];
	if (style) val = style.split(";").reduce(function(acc, style) {
		var styles = style.split(":");
		var prop = styles[0];
		var value = styles.slice(1);
		if (prop && value.length > 0) acc[prop] = value.join(":").trim();
		return acc;
	}, {});
	return val;
}
function classParser(node) {
	var existingPrefix = node.getAttribute("data-prefix");
	var existingIconName = node.getAttribute("data-icon");
	var innerText = node.innerText !== void 0 ? node.innerText.trim() : "";
	var val = getCanonicalIcon(classArray(node));
	if (!val.prefix) val.prefix = getDefaultUsablePrefix();
	if (existingPrefix && existingIconName) {
		val.prefix = existingPrefix;
		val.iconName = existingIconName;
	}
	if (val.iconName && val.prefix) return val;
	if (val.prefix && innerText.length > 0) val.iconName = byLigature(val.prefix, node.innerText) || byUnicode(val.prefix, toHex(node.innerText));
	if (!val.iconName && config.autoFetchSvg && node.firstChild && node.firstChild.nodeType === Node.TEXT_NODE) val.iconName = node.firstChild.data;
	return val;
}
function attributesParser(node) {
	return toArray(node.attributes).reduce(function(acc, attr) {
		if (acc.name !== "class" && acc.name !== "style") acc[attr.name] = attr.value;
		return acc;
	}, {});
}
function blankMeta() {
	return {
		iconName: null,
		prefix: null,
		transform: meaninglessTransform,
		symbol: false,
		mask: {
			iconName: null,
			prefix: null,
			rest: []
		},
		maskId: null,
		extra: {
			classes: [],
			styles: {},
			attributes: {}
		}
	};
}
function parseMeta(node) {
	var parser = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : { styleParser: true };
	var _classParser = classParser(node), iconName = _classParser.iconName, prefix = _classParser.prefix, extraClasses = _classParser.rest;
	var extraAttributes = attributesParser(node);
	var pluginMeta = chainHooks("parseNodeAttributes", {}, node);
	return _objectSpread2({
		iconName,
		prefix,
		transform: meaninglessTransform,
		mask: {
			iconName: null,
			prefix: null,
			rest: []
		},
		maskId: null,
		symbol: false,
		extra: {
			classes: extraClasses,
			styles: parser.styleParser ? styleParser(node) : [],
			attributes: extraAttributes
		}
	}, pluginMeta);
}
function generateMutation(node) {
	var nodeMeta = config.autoReplaceSvg === "nest" ? parseMeta(node, { styleParser: false }) : parseMeta(node);
	if (~nodeMeta.extra.classes.indexOf(LAYERS_TEXT_CLASSNAME)) return callProvided("generateLayersText", node, nodeMeta);
	else return callProvided("generateSvgReplacementMutation", node, nodeMeta);
}
function getKnownPrefixes() {
	return [].concat(_toConsumableArray(Ht), _toConsumableArray(lo));
}
function onTree(root) {
	var callback = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
	if (!IS_DOM) return Promise.resolve();
	var htmlClassList = DOCUMENT.documentElement.classList;
	var hclAdd = function hclAdd(suffix) {
		return htmlClassList.add("".concat(HTML_CLASS_I2SVG_BASE_CLASS, "-").concat(suffix));
	};
	var hclRemove = function hclRemove(suffix) {
		return htmlClassList.remove("".concat(HTML_CLASS_I2SVG_BASE_CLASS, "-").concat(suffix));
	};
	var prefixes = config.autoFetchSvg ? getKnownPrefixes() : Z.concat(Object.keys(styles$2));
	if (!prefixes.includes("fa")) prefixes.push("fa");
	var prefixesDomQuery = [".".concat(LAYERS_TEXT_CLASSNAME, ":not([").concat(DATA_FA_I2SVG, "])")].concat(prefixes.map(function(p$$1) {
		return ".".concat(p$$1, ":not([").concat(DATA_FA_I2SVG, "])");
	})).join(", ");
	if (prefixesDomQuery.length === 0) return Promise.resolve();
	var candidates = [];
	try {
		candidates = toArray(root.querySelectorAll(prefixesDomQuery));
	} catch (e$$1) {}
	if (candidates.length > 0) {
		hclAdd("pending");
		hclRemove("complete");
	} else return Promise.resolve();
	var mark = perf.begin("onTree");
	var mutations = candidates.reduce(function(acc, node) {
		try {
			var mutation = generateMutation(node);
			if (mutation) acc.push(mutation);
		} catch (e$$1) {
			if (!PRODUCTION) {
				if (e$$1.name === "MissingIcon") console.error(e$$1);
			}
		}
		return acc;
	}, []);
	return new Promise(function(resolve, reject) {
		Promise.all(mutations).then(function(resolvedMutations) {
			perform(resolvedMutations, function() {
				hclAdd("active");
				hclAdd("complete");
				hclRemove("pending");
				if (typeof callback === "function") callback();
				mark();
				resolve();
			});
		}).catch(function(e$$1) {
			mark();
			reject(e$$1);
		});
	});
}
function onNode(node) {
	var callback = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : null;
	generateMutation(node).then(function(mutation) {
		if (mutation) perform([mutation], callback);
	});
}
function resolveIcons(next) {
	return function(maybeIconDefinition) {
		var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		var iconDefinition = (maybeIconDefinition || {}).icon ? maybeIconDefinition : findIconDefinition(maybeIconDefinition || {});
		var mask = params.mask;
		if (mask) mask = (mask || {}).icon ? mask : findIconDefinition(mask || {});
		return next(iconDefinition, _objectSpread2(_objectSpread2({}, params), {}, { mask }));
	};
}
function hexValueFromContent(content) {
	return toHex(_toConsumableArray(content.replace(CLEAN_CONTENT_PATTERN, ""))[0] || "");
}
function isSecondaryLayer(styles) {
	var hasStylisticSet = styles.getPropertyValue("font-feature-settings").includes("ss01");
	var cleaned = styles.getPropertyValue("content").replace(CLEAN_CONTENT_PATTERN, "");
	var codePoint = cleaned.codePointAt(0);
	var isPrependTen = codePoint >= SECONDARY_UNICODE_RANGE[0] && codePoint <= SECONDARY_UNICODE_RANGE[1];
	var isDoubled = cleaned.length === 2 ? cleaned[0] === cleaned[1] : false;
	return isPrependTen || isDoubled || hasStylisticSet;
}
function getPrefix(fontFamily, fontWeight) {
	var fontFamilySanitized = fontFamily.replace(/^['"]|['"]$/g, "").toLowerCase();
	var fontWeightInteger = parseInt(fontWeight);
	var fontWeightSanitized = isNaN(fontWeightInteger) ? "normal" : fontWeightInteger;
	return (FONT_FAMILY_WEIGHT_TO_PREFIX[fontFamilySanitized] || {})[fontWeightSanitized] || FONT_FAMILY_WEIGHT_FALLBACK[fontFamilySanitized];
}
function replaceForPosition(node, position) {
	var pendingAttribute = "".concat(DATA_FA_PSEUDO_ELEMENT_PENDING).concat(position.replace(":", "-"));
	return new Promise(function(resolve, reject) {
		if (node.getAttribute(pendingAttribute) !== null) return resolve();
		var alreadyProcessedPseudoElement = toArray(node.children).filter(function(c$$1) {
			return c$$1.getAttribute(DATA_FA_PSEUDO_ELEMENT) === position;
		})[0];
		var styles = WINDOW.getComputedStyle(node, position);
		var fontFamily = styles.getPropertyValue("font-family");
		var fontFamilyMatch = fontFamily.match(FONT_FAMILY_PATTERN);
		var fontWeight = styles.getPropertyValue("font-weight");
		var content = styles.getPropertyValue("content");
		if (alreadyProcessedPseudoElement && !fontFamilyMatch) {
			node.removeChild(alreadyProcessedPseudoElement);
			return resolve();
		} else if (fontFamilyMatch && content !== "none" && content !== "") {
			var _content = styles.getPropertyValue("content");
			var prefix = getPrefix(fontFamily, fontWeight);
			var hexValue = hexValueFromContent(_content);
			var isV4 = fontFamilyMatch[0].startsWith("FontAwesome");
			var isSecondary = isSecondaryLayer(styles);
			var iconName = byUnicode(prefix, hexValue);
			var iconIdentifier = iconName;
			if (isV4) {
				var iconName4 = byOldUnicode(hexValue);
				if (iconName4.iconName && iconName4.prefix) {
					iconName = iconName4.iconName;
					prefix = iconName4.prefix;
				}
			}
			if (iconName && !isSecondary && (!alreadyProcessedPseudoElement || alreadyProcessedPseudoElement.getAttribute(DATA_PREFIX) !== prefix || alreadyProcessedPseudoElement.getAttribute(DATA_ICON) !== iconIdentifier)) {
				node.setAttribute(pendingAttribute, iconIdentifier);
				if (alreadyProcessedPseudoElement) node.removeChild(alreadyProcessedPseudoElement);
				var meta = blankMeta();
				var extra = meta.extra;
				extra.attributes[DATA_FA_PSEUDO_ELEMENT] = position;
				findIcon(iconName, prefix).then(function(main) {
					var abstract = makeInlineSvgAbstract(_objectSpread2(_objectSpread2({}, meta), {}, {
						icons: {
							main,
							mask: emptyCanonicalIcon()
						},
						prefix,
						iconName: iconIdentifier,
						extra,
						watchable: true
					}));
					var element = DOCUMENT.createElementNS("http://www.w3.org/2000/svg", "svg");
					if (position === "::before") node.insertBefore(element, node.firstChild);
					else node.appendChild(element);
					element.outerHTML = abstract.map(function(a$$1) {
						return toHtml(a$$1);
					}).join("\n");
					node.removeAttribute(pendingAttribute);
					resolve();
				}).catch(reject);
			} else resolve();
		} else resolve();
	});
}
function replace(node) {
	return Promise.all([replaceForPosition(node, "::before"), replaceForPosition(node, "::after")]);
}
function processable(node) {
	return node.parentNode !== document.head && !~TAGNAMES_TO_SKIP_FOR_PSEUDOELEMENTS.indexOf(node.tagName.toUpperCase()) && !node.getAttribute(DATA_FA_PSEUDO_ELEMENT) && (!node.parentNode || node.parentNode.tagName !== "svg");
}
function searchPseudoElements(root) {
	var useAsNodeList = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
	if (!IS_DOM) return;
	var nodeList;
	if (useAsNodeList) nodeList = root;
	else if (config.searchPseudoElementsFullScan) nodeList = root.querySelectorAll("*");
	else {
		var selectorSet = /* @__PURE__ */ new Set();
		var _iterator2 = _createForOfIteratorHelper(document.styleSheets), _step2;
		try {
			for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
				var stylesheet = _step2.value;
				try {
					var _iterator3 = _createForOfIteratorHelper(stylesheet.cssRules), _step3;
					try {
						for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
							var rule = _step3.value;
							var _iterator4 = _createForOfIteratorHelper(parseCSSRuleForPseudos(rule.selectorText)), _step4;
							try {
								for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
									var selector = _step4.value;
									selectorSet.add(selector);
								}
							} catch (err) {
								_iterator4.e(err);
							} finally {
								_iterator4.f();
							}
						}
					} catch (err) {
						_iterator3.e(err);
					} finally {
						_iterator3.f();
					}
				} catch (e$$1) {
					if (config.searchPseudoElementsWarnings) console.warn("Font Awesome: cannot parse stylesheet: ".concat(stylesheet.href, " (").concat(e$$1.message, ")\nIf it declares any Font Awesome CSS pseudo-elements, they will not be rendered as SVG icons. Add crossorigin=\"anonymous\" to the <link>, enable searchPseudoElementsFullScan for slower but more thorough DOM parsing, or suppress this warning by setting searchPseudoElementsWarnings to false."));
				}
			}
		} catch (err) {
			_iterator2.e(err);
		} finally {
			_iterator2.f();
		}
		if (!selectorSet.size) return;
		var cleanSelectors = Array.from(selectorSet).join(", ");
		try {
			nodeList = root.querySelectorAll(cleanSelectors);
		} catch (_unused) {}
	}
	return new Promise(function(resolve, reject) {
		var operations = toArray(nodeList).filter(processable).map(replace);
		var end = perf.begin("searchPseudoElements");
		disableObservation();
		Promise.all(operations).then(function() {
			end();
			enableObservation();
			resolve();
		}).catch(function() {
			end();
			enableObservation();
			reject();
		});
	});
}
function fillBlack(abstract) {
	var force = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
	if (abstract.attributes && (abstract.attributes.fill || force)) abstract.attributes.fill = "black";
	return abstract;
}
function deGroup(abstract) {
	if (abstract.tag === "g") return abstract.children;
	else return [abstract];
}
function _isNumerical(object) {
	object = object - 0;
	return object === object;
}
function camelize(string) {
	if (_isNumerical(string)) return string;
	string = string.replace(/[_-]+(.)?/g, (_, chr) => {
		return chr ? chr.toUpperCase() : "";
	});
	return string.charAt(0).toLowerCase() + string.slice(1);
}
function capitalize(val) {
	return val.charAt(0).toUpperCase() + val.slice(1);
}
function styleToObject(style) {
	if (styleCache.has(style)) return styleCache.get(style);
	const result = {};
	let start = 0;
	const len = style.length;
	while (start < len) {
		const semicolonIndex = style.indexOf(";", start);
		const end = semicolonIndex === -1 ? len : semicolonIndex;
		const pair = style.slice(start, end).trim();
		if (pair) {
			const colonIndex = pair.indexOf(":");
			if (colonIndex > 0) {
				const rawProp = pair.slice(0, colonIndex).trim();
				const value = pair.slice(colonIndex + 1).trim();
				if (rawProp && value) {
					const prop = camelize(rawProp);
					result[prop.startsWith("webkit") ? capitalize(prop) : prop] = value;
				}
			}
		}
		start = end + 1;
	}
	if (styleCache.size === STYLE_CACHE_LIMIT) {
		const oldestKey = styleCache.keys().next().value;
		if (oldestKey) styleCache.delete(oldestKey);
	}
	styleCache.set(style, result);
	return result;
}
function convert(createElement, element, extraProps = {}) {
	if (typeof element === "string") return element;
	const children = (element.children || []).map((child) => {
		let element2 = child;
		if (("fill" in extraProps || extraProps.gradientFill) && child.tag === "path" && "fill" in child.attributes) element2 = {
			...child,
			attributes: {
				...child.attributes,
				fill: void 0
			}
		};
		return convert(createElement, element2);
	});
	const elementAttributes = element.attributes || {};
	const attrs = {};
	for (const [key, val] of Object.entries(elementAttributes)) switch (true) {
		case key === "class":
			attrs.className = val;
			break;
		case key === "style":
			attrs.style = styleToObject(String(val));
			break;
		case key.startsWith("aria-"):
		case key.startsWith("data-"):
			attrs[key.toLowerCase()] = val;
			break;
		default: attrs[camelize(key)] = val;
	}
	const { style: existingStyle, role: existingRole, "aria-label": ariaLabel, gradientFill, ...remaining } = extraProps;
	if (existingStyle) attrs.style = attrs.style ? {
		...attrs.style,
		...existingStyle
	} : existingStyle;
	if (existingRole) attrs.role = existingRole;
	if (ariaLabel) {
		attrs["aria-label"] = ariaLabel;
		attrs["aria-hidden"] = "false";
	}
	if (gradientFill) {
		attrs.fill = `url(#${gradientFill.id})`;
		const { type: gradientType, stops: gradientStops = [], ...gradientProps } = gradientFill;
		children.unshift(createElement(gradientType === "linear" ? "linearGradient" : "radialGradient", {
			...gradientProps,
			id: gradientFill.id
		}, gradientStops.map(createGradientStops)));
	}
	return createElement(element.tag, {
		...attrs,
		...remaining
	}, ...children);
}
function withPrefix(cls) {
	const prefix = config$1.cssPrefix || config$1.familyPrefix || DEFAULT_CLASSNAME_PREFIX;
	return prefix === DEFAULT_CLASSNAME_PREFIX ? cls : cls.replace(new RegExp(String.raw`(?<=^|\s)${DEFAULT_CLASSNAME_PREFIX}-`, "g"), `${prefix}-`);
}
function getClassListFromProps(props) {
	const { beat, fade, beatFade, bounce, shake, spin, spinPulse, spinReverse, pulse, fixedWidth, inverse, border, flip, size, rotation, pull, swapOpacity, rotateBy, widthAuto, className } = props;
	const result = [];
	if (className) result.push(...className.split(" "));
	if (beat) result.push(ANIMATION_CLASSES.beat);
	if (fade) result.push(ANIMATION_CLASSES.fade);
	if (beatFade) result.push(ANIMATION_CLASSES.beatFade);
	if (bounce) result.push(ANIMATION_CLASSES.bounce);
	if (shake) result.push(ANIMATION_CLASSES.shake);
	if (spin) result.push(ANIMATION_CLASSES.spin);
	if (spinReverse) result.push(ANIMATION_CLASSES.spinReverse);
	if (spinPulse) result.push(ANIMATION_CLASSES.spinPulse);
	if (pulse) result.push(ANIMATION_CLASSES.pulse);
	if (fixedWidth) result.push(STYLE_CLASSES.fixedWidth);
	if (inverse) result.push(STYLE_CLASSES.inverse);
	if (border) result.push(STYLE_CLASSES.border);
	if (flip === true) result.push(STYLE_CLASSES.flip);
	if (flip === "horizontal" || flip === "both") result.push(STYLE_CLASSES.flipHorizontal);
	if (flip === "vertical" || flip === "both") result.push(STYLE_CLASSES.flipVertical);
	if (size !== void 0 && size !== null) result.push(SIZE_CLASSES[size]);
	if (rotation !== void 0 && rotation !== null && rotation !== 0) result.push(ROTATE_CLASSES[rotation]);
	if (pull !== void 0 && pull !== null) result.push(PULL_CLASSES[pull]);
	if (swapOpacity) result.push(STYLE_CLASSES.swapOpacity);
	if (!getIsVersion7OrLater()) return result;
	if (rotateBy) result.push(STYLE_CLASSES.rotateBy);
	if (widthAuto) result.push(STYLE_CLASSES.widthAuto);
	return (config$1.cssPrefix || config$1.familyPrefix || DEFAULT_CLASSNAME_PREFIX) === DEFAULT_CLASSNAME_PREFIX ? result : result.map(withPrefix);
}
function normalizeIconArgs(icon) {
	if (!icon) return;
	if (isIconDefinition(icon)) return icon;
	return parse$1.icon(icon);
}
function typedObjectKeys(obj) {
	return Object.keys(obj);
}
function Icon({ name, label, className, ...props }) {
	const icon = resolveIcon(name);
	if (!icon) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FontAwesomeIcon, {
		icon,
		className: cx("pf-icon", className),
		"aria-hidden": label ? void 0 : true,
		"aria-label": label,
		...props
	});
}
function Alert({ className, variant = "info", heading, description, dismissible = false, onDismiss, icon, children, ...props }) {
	const resolvedIcon = icon ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		name: variantIcon$1[variant],
		"aria-hidden": true
	});
	const body = children ?? description;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-alert", `pf-alert--${variant}`, className),
		role: "alert",
		...props,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-alert__icon",
				"aria-hidden": true,
				children: resolvedIcon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pf-alert__content",
				children: [heading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-alert__title",
					children: heading
				}) : null, body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pf-alert__description",
					children: body
				}) : null]
			}),
			dismissible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "pf-alert__dismiss",
				"aria-label": "Dismiss alert",
				onClick: () => onDismiss?.(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "circle-xmark",
					"aria-hidden": true
				})
			}) : null
		]
	});
}
function Breadcrumbs({ className, items, separator = "/", "aria-label": ariaLabel = "Breadcrumb", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: cx("pf-breadcrumbs", className),
		"aria-label": ariaLabel,
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "pf-breadcrumbs__list",
			children: items.map((item, index) => {
				const isLast = index === items.length - 1;
				const isCurrent = item.current ?? isLast;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "pf-breadcrumbs__item",
					children: [item.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						onClick: item.onClick,
						className: cx("pf-breadcrumbs__link", isCurrent && "pf-breadcrumbs__link--current"),
						"aria-current": isCurrent ? "page" : void 0,
						children: item.label
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cx("pf-breadcrumbs__link", isCurrent && "pf-breadcrumbs__link--current"),
						"aria-current": isCurrent ? "page" : void 0,
						children: item.label
					}), !isLast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-breadcrumbs__separator",
						"aria-hidden": true,
						children: separator
					}) : null]
				}, `${index}-${typeof item.label === "string" ? item.label : "item"}`);
			})
		})
	});
}
function Badge({ className, variant = "neutral", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cx("pf-badge", `pf-badge--${variant}`, className),
		...props
	});
}
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-card", className),
		...props
	});
}
function CardHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-card__header", className),
		...props
	});
}
function CardContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-card__content", className),
		...props
	});
}
function CardFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-card__footer", className),
		...props
	});
}
function Calendar({ className, value, defaultValue, onValueChange, label, description, error, disabledDates, showOutsideDays = true, startYear, endYear, "aria-describedby": ariaDescribedBy, ...props }) {
	const generatedId = (0, import_react$1.useId)();
	const calendarId = props.id ?? generatedId;
	const descriptionId = description ? `${calendarId}-description` : void 0;
	const errorId = error ? `${calendarId}-error` : void 0;
	const describedBy = [
		ariaDescribedBy,
		descriptionId,
		errorId
	].filter(Boolean).join(" ") || void 0;
	const isControlled = value !== void 0;
	const [internalValue, setInternalValue] = (0, import_react$1.useState)(defaultValue ? toMidday$1(defaultValue) : void 0);
	const selectedDate = isControlled ? value ? toMidday$1(value) : void 0 : internalValue;
	const yearRange = (0, import_react$1.useMemo)(() => {
		const fallbackStart = (/* @__PURE__ */ new Date()).getFullYear() - 50;
		const fallbackEnd = (/* @__PURE__ */ new Date()).getFullYear() + 50;
		const nextStart = startYear ?? fallbackStart;
		const nextEnd = endYear ?? fallbackEnd;
		return {
			start: Math.min(nextStart, nextEnd),
			end: Math.max(nextStart, nextEnd)
		};
	}, [endYear, startYear]);
	const clampToYearRange = (date) => {
		const year = date.getFullYear();
		if (year < yearRange.start) return new Date(yearRange.start, 0, 1, 12);
		if (year > yearRange.end) return new Date(yearRange.end, 11, 1, 12);
		return date;
	};
	const [displayMonth, setDisplayMonth] = (0, import_react$1.useState)(() => {
		return clampToYearRange(startOfMonth(selectedDate ?? /* @__PURE__ */ new Date()));
	});
	(0, import_react$1.useEffect)(() => {
		if (!selectedDate) return;
		setDisplayMonth(clampToYearRange(startOfMonth(selectedDate)));
	}, [
		selectedDate,
		yearRange.end,
		yearRange.start
	]);
	const monthLabel = (0, import_react$1.useMemo)(() => {
		return new Intl.DateTimeFormat("en-US", {
			month: "long",
			year: "numeric"
		}).format(displayMonth);
	}, [displayMonth]);
	const yearOptions = (0, import_react$1.useMemo)(() => {
		const length = yearRange.end - yearRange.start + 1;
		return Array.from({ length }, (_, index) => yearRange.start + index);
	}, [yearRange.end, yearRange.start]);
	const isPrevMonthDisabled = displayMonth.getFullYear() === yearRange.start && displayMonth.getMonth() === 0;
	const isNextMonthDisabled = displayMonth.getFullYear() === yearRange.end && displayMonth.getMonth() === 11;
	const dayItems = (0, import_react$1.useMemo)(() => {
		return buildCalendarDays(displayMonth);
	}, [displayMonth]);
	const today = (0, import_react$1.useMemo)(() => toMidday$1(/* @__PURE__ */ new Date()), []);
	const selectDate = (nextDate) => {
		if (disabledDates?.(nextDate)) return;
		if (!isControlled) setInternalValue(nextDate);
		onValueChange?.(nextDate);
		setDisplayMonth(clampToYearRange(startOfMonth(nextDate)));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pf-field",
		children: [
			label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "pf-field__label",
				htmlFor: calendarId,
				children: label
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				...props,
				id: calendarId,
				className: cx("pf-calendar", error && "pf-calendar--invalid", className),
				"aria-invalid": error ? true : void 0,
				"aria-describedby": describedBy,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pf-calendar__header",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "pf-calendar__nav",
								"aria-label": "Previous month",
								disabled: isPrevMonthDisabled,
								onClick: () => {
									setDisplayMonth((current) => clampToYearRange(addMonths(current, -1)));
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									name: "square-caret-left",
									"aria-hidden": true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pf-calendar__month-controls",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "pf-calendar__control-label",
										htmlFor: `${calendarId}-month`,
										children: "Month"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										id: `${calendarId}-month`,
										className: "pf-calendar__control",
										value: displayMonth.getMonth(),
										"aria-label": "Select month",
										onChange: (event) => {
											const nextMonth = Number(event.target.value);
											setDisplayMonth((current) => clampToYearRange(new Date(current.getFullYear(), nextMonth, 1, 12)));
										},
										children: MONTH_OPTIONS.map((month) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: month.value,
											children: month.label
										}, month.value))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "pf-calendar__control-label",
										htmlFor: `${calendarId}-year`,
										children: "Year"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										id: `${calendarId}-year`,
										className: "pf-calendar__control",
										value: displayMonth.getFullYear(),
										"aria-label": "Select year",
										onChange: (event) => {
											const nextYear = Number(event.target.value);
											setDisplayMonth((current) => clampToYearRange(new Date(nextYear, current.getMonth(), 1, 12)));
										},
										children: yearOptions.map((year) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: year,
											children: year
										}, year))
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "pf-calendar__nav",
								"aria-label": "Next month",
								disabled: isNextMonthDisabled,
								onClick: () => {
									setDisplayMonth((current) => clampToYearRange(addMonths(current, 1)));
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									name: "square-caret-right",
									"aria-hidden": true
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pf-calendar__weekday-row",
						"aria-hidden": true,
						children: WEEKDAY_LABELS.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pf-calendar__weekday",
							children: day
						}, day))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pf-calendar__grid",
						role: "grid",
						"aria-label": monthLabel,
						children: dayItems.map(({ date, inCurrentMonth }) => {
							const isSelected = selectedDate ? isSameDay(selectedDate, date) : false;
							const isToday = isSameDay(today, date);
							const isDisabled = Boolean(disabledDates?.(date));
							if (!showOutsideDays && !inCurrentMonth) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pf-calendar__day-empty",
								"aria-hidden": true
							}, date.toISOString());
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								role: "gridcell",
								className: cx("pf-calendar__day", !inCurrentMonth && "pf-calendar__day--outside", isToday && "pf-calendar__day--today", isSelected && "pf-calendar__day--selected"),
								"aria-selected": isSelected,
								disabled: isDisabled,
								onClick: () => {
									selectDate(date);
								},
								children: date.getDate()
							}, date.toISOString());
						})
					})
				]
			}),
			description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pf-field__description",
				id: descriptionId,
				children: description
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pf-field__error",
				id: errorId,
				children: error
			}) : null
		]
	});
}
function Carousel({ className, slides, initialIndex = 0, loop = true, showIndicators = true, autoPlay = false, autoPlayInterval = 5e3, onIndexChange, "aria-label": ariaLabel = "Carousel", ...props }) {
	const totalSlides = slides.length;
	const [activeIndex, setActiveIndex] = (0, import_react$1.useState)(clamp$1(initialIndex, 0, Math.max(totalSlides - 1, 0)));
	(0, import_react$1.useEffect)(() => {
		setActiveIndex((current) => clamp$1(current, 0, Math.max(totalSlides - 1, 0)));
	}, [totalSlides]);
	const goToIndex = (nextIndex) => {
		if (totalSlides === 0) return;
		let resolvedIndex = nextIndex;
		if (loop) resolvedIndex = (nextIndex % totalSlides + totalSlides) % totalSlides;
		else resolvedIndex = clamp$1(nextIndex, 0, totalSlides - 1);
		setActiveIndex(resolvedIndex);
		onIndexChange?.(resolvedIndex);
	};
	(0, import_react$1.useEffect)(() => {
		if (!autoPlay || totalSlides < 2) return;
		const interval = window.setInterval(() => {
			setActiveIndex((current) => {
				const next = loop ? (current + 1) % totalSlides : Math.min(current + 1, totalSlides - 1);
				onIndexChange?.(next);
				return next;
			});
		}, autoPlayInterval);
		return () => {
			window.clearInterval(interval);
		};
	}, [
		autoPlay,
		autoPlayInterval,
		loop,
		onIndexChange,
		totalSlides
	]);
	const isPrevDisabled = !loop && activeIndex <= 0;
	const isNextDisabled = !loop && activeIndex >= totalSlides - 1;
	const slideLabel = (0, import_react$1.useMemo)(() => {
		if (totalSlides === 0) return "No slides";
		return `Slide ${activeIndex + 1} of ${totalSlides}`;
	}, [activeIndex, totalSlides]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-carousel", className),
		"aria-label": ariaLabel,
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pf-carousel__viewport",
			role: "region",
			"aria-roledescription": "carousel",
			"aria-label": slideLabel,
			children: totalSlides === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pf-carousel__empty",
				role: "status",
				children: "Add at least one slide."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pf-carousel__track",
				style: { transform: `translateX(-${activeIndex * 100}%)` },
				children: slides.map((slide, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pf-carousel__slide",
					role: "group",
					"aria-roledescription": "slide",
					"aria-label": `Slide ${index + 1} of ${totalSlides}`,
					"aria-hidden": index !== activeIndex,
					children: slide
				}, `slide-${index}`))
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-carousel__controls",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "pf-carousel__nav",
					"aria-label": "Previous slide",
					disabled: isPrevDisabled || totalSlides < 2,
					onClick: () => {
						goToIndex(activeIndex - 1);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						name: "square-caret-left",
						"aria-hidden": true
					})
				}),
				showIndicators && totalSlides > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pf-carousel__indicators",
					"aria-label": "Slide indicators",
					children: slides.map((_, index) => {
						const isActive = index === activeIndex;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: cx("pf-carousel__indicator", isActive && "pf-carousel__indicator--active"),
							"aria-label": `Go to slide ${index + 1}`,
							"aria-current": isActive ? "true" : void 0,
							onClick: () => {
								goToIndex(index);
							}
						}, `indicator-${index}`);
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "pf-carousel__indicator-spacer",
					"aria-hidden": true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "pf-carousel__nav",
					"aria-label": "Next slide",
					disabled: isNextDisabled || totalSlides < 2,
					onClick: () => {
						goToIndex(activeIndex + 1);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						name: "square-caret-right",
						"aria-hidden": true
					})
				})
			]
		})]
	});
}
function CodeSnippet({ className, code, language, title, showLineNumbers = false, maxHeight, copyLabel = "Copy", copiedLabel = "Copied", onCodeCopy, ...props }) {
	const [copied, setCopied] = (0, import_react$1.useState)(false);
	const [copyError, setCopyError] = (0, import_react$1.useState)(false);
	const liveRegionId = (0, import_react$1.useId)();
	const lines = splitLines(code);
	(0, import_react$1.useEffect)(() => {
		if (!copied) return;
		const timeout = window.setTimeout(() => {
			setCopied(false);
		}, 1600);
		return () => {
			window.clearTimeout(timeout);
		};
	}, [copied]);
	const handleCopy = async () => {
		try {
			if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) await navigator.clipboard.writeText(code);
			setCopied(true);
			setCopyError(false);
			onCodeCopy?.(code);
		} catch {
			setCopied(false);
			setCopyError(true);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: cx("pf-code-snippet", className),
		...props,
		children: [
			(title || language) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
				className: "pf-code-snippet__header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pf-code-snippet__meta",
					children: [title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-code-snippet__title",
						children: title
					}) : null, language ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-code-snippet__language",
						children: language
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "pf-code-snippet__copy",
					onClick: () => {
						handleCopy();
					},
					"aria-describedby": liveRegionId,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						name: copied ? "circle-check" : "copy",
						"aria-hidden": true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copied ? copiedLabel : copyLabel })]
				})]
			}),
			!(title || language) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pf-code-snippet__toolbar",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "pf-code-snippet__copy",
					onClick: () => {
						handleCopy();
					},
					"aria-describedby": liveRegionId,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						name: copied ? "circle-check" : "copy",
						"aria-hidden": true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copied ? copiedLabel : copyLabel })]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "pf-code-snippet__pre",
				style: maxHeight ? {
					maxHeight,
					overflow: "auto"
				} : void 0,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: showLineNumbers ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
					className: "pf-code-snippet__table",
					role: "presentation",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "pf-code-snippet__line-number",
						"aria-hidden": true,
						children: index + 1
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "pf-code-snippet__line-content",
						children: line || " "
					})] }, `${index}-${line}`)) })
				}) : code })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				id: liveRegionId,
				className: "pf-code-snippet__sr-only",
				"aria-live": "polite",
				children: copyError ? "Copy failed" : copied ? copiedLabel : ""
			})
		]
	});
}
function ContentDivider({ className, label, orientation = "horizontal", inset = false, ...props }) {
	if (orientation === "vertical") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		...props,
		className: cx("pf-content-divider", "pf-content-divider--vertical", inset && "pf-content-divider--inset", className),
		role: "separator",
		"aria-orientation": "vertical"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		...props,
		className: cx("pf-content-divider", inset && "pf-content-divider--inset", className),
		role: "separator",
		"aria-orientation": "horizontal",
		children: label ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-content-divider__line",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-content-divider__label",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-content-divider__line",
				"aria-hidden": true
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pf-content-divider__line",
			"aria-hidden": true
		})
	});
}
function DatePicker({ id, className, value, defaultValue, onValueChange, label, description, error, placeholder = "Select a date", disabled = false, allowClear = false, disabledDates, showOutsideDays = true, startYear, endYear, "aria-describedby": ariaDescribedBy, ...props }) {
	const generatedId = (0, import_react$1.useId)();
	const pickerId = id ?? generatedId;
	const descriptionId = description ? `${pickerId}-description` : void 0;
	const errorId = error ? `${pickerId}-error` : void 0;
	const describedBy = [
		ariaDescribedBy,
		descriptionId,
		errorId
	].filter(Boolean).join(" ") || void 0;
	const isControlled = value !== void 0;
	const [internalValue, setInternalValue] = (0, import_react$1.useState)(defaultValue ? toMidday(defaultValue) : void 0);
	const selectedDate = isControlled ? value ? toMidday(value) : void 0 : internalValue;
	const [isOpen, setIsOpen] = (0, import_react$1.useState)(false);
	const rootRef = (0, import_react$1.useRef)(null);
	const triggerRef = (0, import_react$1.useRef)(null);
	const popoverRef = (0, import_react$1.useRef)(null);
	const [popoverStyle, setPopoverStyle] = (0, import_react$1.useState)({});
	(0, import_react$1.useEffect)(() => {
		if (!isOpen) return;
		const updatePopoverPosition = () => {
			if (!triggerRef.current || !popoverRef.current) return;
			const viewportPadding = 8;
			const offset = 8;
			const triggerRect = triggerRef.current.getBoundingClientRect();
			const popoverRect = popoverRef.current.getBoundingClientRect();
			let left = triggerRect.left;
			const minLeft = viewportPadding;
			const maxLeft = window.innerWidth - viewportPadding - popoverRect.width;
			if (maxLeft >= minLeft) left = Math.min(Math.max(left, minLeft), maxLeft);
			else left = minLeft;
			let top = window.innerHeight - triggerRect.bottom >= popoverRect.height + offset + viewportPadding ? triggerRect.bottom + offset : triggerRect.top - popoverRect.height - offset;
			const minTop = viewportPadding;
			const maxTop = window.innerHeight - viewportPadding - popoverRect.height;
			if (maxTop >= minTop) top = Math.min(Math.max(top, minTop), maxTop);
			else top = minTop;
			setPopoverStyle({
				left,
				minWidth: triggerRect.width,
				top
			});
		};
		updatePopoverPosition();
		window.addEventListener("resize", updatePopoverPosition);
		window.addEventListener("scroll", updatePopoverPosition, true);
		return () => {
			window.removeEventListener("resize", updatePopoverPosition);
			window.removeEventListener("scroll", updatePopoverPosition, true);
		};
	}, [isOpen]);
	(0, import_react$1.useEffect)(() => {
		if (!isOpen) return;
		const onPointerDown = (event) => {
			const target = event.target;
			const isInsideTrigger = Boolean(rootRef.current?.contains(target));
			const isInsidePopover = Boolean(popoverRef.current?.contains(target));
			if (!isInsideTrigger && !isInsidePopover) setIsOpen(false);
		};
		const onEscape = (event) => {
			if (event.key === "Escape") setIsOpen(false);
		};
		document.addEventListener("mousedown", onPointerDown);
		document.addEventListener("keydown", onEscape);
		return () => {
			document.removeEventListener("mousedown", onPointerDown);
			document.removeEventListener("keydown", onEscape);
		};
	}, [isOpen]);
	const formattedDate = (0, import_react$1.useMemo)(() => {
		if (!selectedDate) return "";
		return new Intl.DateTimeFormat("en-US", {
			month: "short",
			day: "numeric",
			year: "numeric"
		}).format(selectedDate);
	}, [selectedDate]);
	const selectDate = (nextDate) => {
		const normalized = toMidday(nextDate);
		if (!isControlled) setInternalValue(normalized);
		onValueChange?.(normalized);
		setIsOpen(false);
	};
	const clearDate = () => {
		if (!isControlled) setInternalValue(void 0);
		onValueChange?.(void 0);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pf-field",
		ref: rootRef,
		children: [
			label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "pf-field__label",
				htmlFor: `${pickerId}-trigger`,
				children: label
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				...props,
				id: pickerId,
				className: cx("pf-date-picker", className),
				"aria-describedby": describedBy,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					ref: triggerRef,
					id: `${pickerId}-trigger`,
					type: "button",
					className: cx("pf-date-picker__trigger", error && "pf-date-picker__trigger--invalid"),
					disabled,
					"aria-invalid": error ? true : void 0,
					"aria-haspopup": "dialog",
					"aria-expanded": isOpen,
					onClick: () => {
						setIsOpen((current) => !current);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cx("pf-date-picker__value", !selectedDate && "pf-date-picker__value--placeholder"),
						children: formattedDate || placeholder
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "pf-date-picker__icons",
						children: [allowClear && selectedDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pf-date-picker__icon-button",
							role: "button",
							"aria-label": "Clear selected date",
							onClick: (event) => {
								event.stopPropagation();
								clearDate();
							},
							onKeyDown: (event) => {
								if (event.key === "Enter" || event.key === " ") {
									event.preventDefault();
									event.stopPropagation();
									clearDate();
								}
							},
							tabIndex: 0,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								name: "circle-xmark",
								"aria-hidden": true
							})
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							name: "calendar",
							"aria-hidden": true
						})]
					})]
				}), isOpen && typeof document !== "undefined" ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: popoverRef,
					className: "pf-date-picker__popover",
					role: "dialog",
					"aria-label": "Date picker calendar",
					style: popoverStyle,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, {
						value: selectedDate,
						onValueChange: selectDate,
						disabledDates,
						showOutsideDays,
						startYear,
						endYear
					})
				}), document.body) : null]
			}),
			description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pf-field__description",
				id: descriptionId,
				children: description
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pf-field__error",
				id: errorId,
				children: error
			}) : null
		]
	});
}
function FileUploader({ id, className, label, description, error, accept, multiple = true, maxFiles, maxFileSize, disabled = false, value, defaultValue = [], onFilesChange, "aria-describedby": ariaDescribedBy, ...props }) {
	const generatedId = (0, import_react$1.useId)();
	const uploaderId = id ?? generatedId;
	const inputId = `${uploaderId}-input`;
	const descriptionId = description ? `${uploaderId}-description` : void 0;
	const errorId = error ? `${uploaderId}-error` : void 0;
	const internalErrorId = `${uploaderId}-internal-error`;
	const describedBy = [
		ariaDescribedBy,
		descriptionId,
		errorId,
		internalErrorId
	].filter(Boolean).join(" ") || void 0;
	const isControlled = value !== void 0;
	const [internalFiles, setInternalFiles] = (0, import_react$1.useState)(defaultValue);
	const [dragActive, setDragActive] = (0, import_react$1.useState)(false);
	const [internalError, setInternalError] = (0, import_react$1.useState)(void 0);
	const files = isControlled ? value ?? [] : internalFiles;
	const inputRef = (0, import_react$1.useRef)(null);
	const setFiles = (nextFiles) => {
		if (!isControlled) setInternalFiles(nextFiles);
		onFilesChange?.(nextFiles);
	};
	const validateFiles = (incoming) => {
		if (maxFileSize) {
			const oversized = incoming.find((file) => file.size > maxFileSize);
			if (oversized) return `"${oversized.name}" exceeds the ${bytesToSize(maxFileSize)} size limit.`;
		}
		if (maxFiles && incoming.length > maxFiles) return `You can upload up to ${maxFiles} file${maxFiles === 1 ? "" : "s"}.`;
	};
	const addFiles = (selected) => {
		if (!selected || disabled) return;
		const incoming = Array.from(selected);
		const merged = multiple ? [...files, ...incoming] : incoming.slice(0, 1);
		const deduped = Array.from(new Map(merged.map((file) => [`${file.name}-${file.size}-${file.lastModified}`, file])).values());
		const nextFiles = maxFiles ? deduped.slice(0, maxFiles) : deduped;
		const nextError = validateFiles(nextFiles);
		if (nextError) {
			setInternalError(nextError);
			return;
		}
		setInternalError(void 0);
		setFiles(nextFiles);
		if (inputRef.current) inputRef.current.value = "";
	};
	const removeFile = (index) => {
		const next = files.filter((_, fileIndex) => fileIndex !== index);
		setInternalError(void 0);
		setFiles(next);
	};
	const hintText = (0, import_react$1.useMemo)(() => {
		const parts = [];
		if (accept) parts.push(`Accepted: ${accept}`);
		if (maxFileSize) parts.push(`Max size: ${bytesToSize(maxFileSize)}`);
		if (maxFiles) parts.push(`Max files: ${maxFiles}`);
		return parts.join(" | ");
	}, [
		accept,
		maxFileSize,
		maxFiles
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pf-field",
		children: [
			label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "pf-field__label",
				htmlFor: inputId,
				children: label
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				...props,
				id: uploaderId,
				className: cx("pf-file-uploader", className),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: inputRef,
						id: inputId,
						type: "file",
						className: "pf-file-uploader__input",
						accept,
						multiple,
						disabled,
						onChange: (event) => {
							addFiles(event.target.files);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: cx("pf-file-uploader__dropzone", dragActive && "pf-file-uploader__dropzone--active", (error || internalError) && "pf-file-uploader__dropzone--invalid"),
						onClick: () => {
							inputRef.current?.click();
						},
						onDragEnter: (event) => {
							event.preventDefault();
							if (!disabled) setDragActive(true);
						},
						onDragOver: (event) => {
							event.preventDefault();
						},
						onDragLeave: (event) => {
							event.preventDefault();
							setDragActive(false);
						},
						onDrop: (event) => {
							event.preventDefault();
							setDragActive(false);
							addFiles(event.dataTransfer.files);
						},
						disabled,
						"aria-invalid": error || internalError ? true : void 0,
						"aria-describedby": describedBy,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pf-file-uploader__icon",
								"aria-hidden": true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { name: "file-arrow-up" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pf-file-uploader__title",
								children: "Upload files"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pf-file-uploader__subtitle",
								children: "Drag and drop files here, or click to browse."
							}),
							hintText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pf-file-uploader__hint",
								children: hintText
							}) : null
						]
					}),
					files.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "pf-file-uploader__list",
						"aria-label": "Selected files",
						children: files.map((file, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "pf-file-uploader__list-item",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "pf-file-uploader__file-meta",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pf-file-uploader__file-name",
									children: file.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pf-file-uploader__file-size",
									children: bytesToSize(file.size)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "pf-file-uploader__remove",
								onClick: () => {
									removeFile(index);
								},
								"aria-label": `Remove ${file.name}`,
								disabled,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									name: "circle-xmark",
									"aria-hidden": true
								})
							})]
						}, `${file.name}-${file.size}-${file.lastModified}`))
					}) : null
				]
			}),
			description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pf-field__description",
				id: descriptionId,
				children: description
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pf-field__error",
				id: errorId,
				children: error
			}) : null,
			internalError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pf-field__error",
				id: internalErrorId,
				children: internalError
			}) : null
		]
	});
}
function HeaderNavigation({ className, brand, items, actions, "aria-label": ariaLabel = "Header navigation", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: cx("pf-header-navigation", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "pf-header-navigation__nav",
			"aria-label": ariaLabel,
			children: [
				brand ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pf-header-navigation__brand",
					children: brand
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "pf-header-navigation__list",
					children: items.map((item, index) => {
						const key = `${index}-${typeof item.label === "string" ? item.label : "item"}`;
						if (item.href) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "pf-header-navigation__item",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: item.href,
								onClick: item.onClick,
								className: cx("pf-header-navigation__link", item.active && "pf-header-navigation__link--active"),
								"aria-current": item.active ? "page" : void 0,
								children: item.label
							})
						}, key);
						if (item.onClick) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "pf-header-navigation__item",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: item.onClick,
								className: cx("pf-header-navigation__link", item.active && "pf-header-navigation__link--active"),
								"aria-current": item.active ? "page" : void 0,
								children: item.label
							})
						}, key);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "pf-header-navigation__item",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cx("pf-header-navigation__link", item.active && "pf-header-navigation__link--active"),
								"aria-current": item.active ? "page" : void 0,
								children: item.label
							})
						}, key);
					})
				}),
				actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pf-header-navigation__actions",
					children: actions
				}) : null
			]
		})
	});
}
function InlineCTA({ className, heading, description, action, icon, iconName = "circle-question", tone = "default", children, ...props }) {
	const resolvedIcon = icon ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		name: iconName,
		"aria-hidden": true
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-inline-cta", `pf-inline-cta--${tone}`, className),
		...props,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-inline-cta__icon",
				"aria-hidden": true,
				children: resolvedIcon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pf-inline-cta__content",
				children: [
					heading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pf-inline-cta__heading",
						children: heading
					}) : null,
					description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pf-inline-cta__description",
						children: description
					}) : null,
					children
				]
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pf-inline-cta__action",
				children: action
			}) : null
		]
	});
}
function LoadingSpinner({ className, size = 24, label = "Loading", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-loading-spinner", className),
		style: {
			width: size,
			height: size
		},
		role: "status",
		"aria-label": label,
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pf-sr-only",
			children: label
		})
	});
}
function LoadingDots({ className, size = "md", label = "Loading", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-loading-dots", `pf-loading-dots--${size}`, className),
		role: "status",
		"aria-label": label,
		...props,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-loading-dots__dot",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-loading-dots__dot",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-loading-dots__dot",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-sr-only",
				children: label
			})
		]
	});
}
function LoadingSkeleton({ className, width = "100%", height = 16, rounded = false, label = "Loading content", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-loading-skeleton", rounded ? "pf-loading-skeleton--rounded" : void 0, className),
		style: {
			width,
			height
		},
		role: "status",
		"aria-label": label,
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pf-sr-only",
			children: label
		})
	});
}
function MetricGrid({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-metric-grid", className),
		...props
	});
}
function MetricCard({ className, heading, value, description, trend = "neutral", trendLabel, icon, iconName, action, children, ...props }) {
	const resolvedIcon = icon ?? (iconName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		name: iconName,
		"aria-hidden": true
	}) : null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-metric-card", className),
		...props,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pf-metric-card__header",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pf-metric-card__heading-wrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pf-metric-card__heading",
						children: heading
					}), resolvedIcon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-metric-card__icon",
						"aria-hidden": true,
						children: resolvedIcon
					}) : null]
				}), action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pf-metric-card__action",
					children: action
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pf-metric-card__body",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-metric-card__value",
					children: value
				}), trendLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: cx("pf-metric-card__trend", `pf-metric-card__trend--${trend}`),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-metric-card__trend-symbol",
						"aria-hidden": true,
						children: trendSymbol[trend]
					}), trendLabel]
				}) : null]
			}),
			description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pf-metric-card__description",
				children: description
			}) : null,
			children
		]
	});
}
function ModalHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-modal__header", className),
		...props
	});
}
function ModalBody({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-modal__body", className),
		...props
	});
}
function ModalFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-modal__footer", className),
		...props
	});
}
function Modal({ className, open, onOpenChange, title, description, footer, size = "md", closeOnOverlayClick = true, showCloseButton = true, children, ...props }) {
	const titleId = (0, import_react$1.useId)();
	const descriptionId = (0, import_react$1.useId)();
	const dialogRef = (0, import_react$1.useRef)(null);
	const previousActiveRef = (0, import_react$1.useRef)(null);
	(0, import_react$1.useEffect)(() => {
		if (!open || typeof document === "undefined") return;
		previousActiveRef.current = document.activeElement;
		const originalOverflow = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		(dialogRef.current ? getFocusableElements(dialogRef.current)[0] : void 0)?.focus() ?? dialogRef.current?.focus();
		const onKeyDown = (event) => {
			if (event.key === "Escape") {
				onOpenChange?.(false);
				return;
			}
			if (event.key !== "Tab" || !dialogRef.current) return;
			const focusableElements = getFocusableElements(dialogRef.current);
			if (focusableElements.length === 0) {
				event.preventDefault();
				dialogRef.current.focus();
				return;
			}
			const firstElement = focusableElements[0];
			const lastElement = focusableElements[focusableElements.length - 1];
			const activeElement = document.activeElement;
			if (!(activeElement ? dialogRef.current.contains(activeElement) : false)) {
				event.preventDefault();
				(event.shiftKey ? lastElement : firstElement).focus();
				return;
			}
			if (event.shiftKey && activeElement === firstElement) {
				event.preventDefault();
				lastElement.focus();
				return;
			}
			if (!event.shiftKey && activeElement === lastElement) {
				event.preventDefault();
				firstElement.focus();
			}
		};
		document.addEventListener("keydown", onKeyDown);
		return () => {
			document.body.style.overflow = originalOverflow;
			document.removeEventListener("keydown", onKeyDown);
			previousActiveRef.current?.focus?.();
		};
	}, [open, onOpenChange]);
	if (!open || typeof document === "undefined") return null;
	return (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pf-modal__portal",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pf-modal__overlay",
			onClick: () => {
				if (closeOnOverlayClick) onOpenChange?.(false);
			}
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pf-modal__viewport",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: dialogRef,
				className: cx("pf-modal", `pf-modal--${size}`, className),
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": title ? titleId : void 0,
				"aria-describedby": description ? descriptionId : void 0,
				tabIndex: -1,
				...props,
				children: [
					title || description || showCloseButton ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ModalHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pf-modal__heading-group",
						children: [title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "pf-modal__title",
							id: titleId,
							children: title
						}) : null, description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pf-modal__description",
							id: descriptionId,
							children: description
						}) : null]
					}), showCloseButton ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "pf-modal__close",
						"aria-label": "Close modal",
						onClick: () => onOpenChange?.(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							name: "circle-xmark",
							"aria-hidden": true
						})
					}) : null] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModalBody, { children }),
					footer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModalFooter, { children: footer }) : null
				]
			})
		})]
	}), document.body);
}
function NotificationStack({ className, placement = "top-right", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-notification-stack", `pf-notification-stack--${placement}`, className),
		...props
	});
}
function Notification({ className, variant = "info", heading, description, icon, action, dismissible = false, onDismiss, children, ...props }) {
	const resolvedIcon = icon ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		name: variantIcon[variant],
		"aria-hidden": true
	});
	const body = children ?? description;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-notification", `pf-notification--${variant}`, className),
		role: "status",
		...props,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-notification__icon",
				"aria-hidden": true,
				children: resolvedIcon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pf-notification__content",
				children: [
					heading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pf-notification__title",
						children: heading
					}) : null,
					body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pf-notification__description",
						children: body
					}) : null,
					action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pf-notification__action",
						children: action
					}) : null
				]
			}),
			dismissible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "pf-notification__dismiss",
				"aria-label": "Dismiss notification",
				onClick: () => onDismiss?.(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "circle-xmark",
					"aria-hidden": true
				})
			}) : null
		]
	});
}
function PageHeaderMeta({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-page-header__meta", className),
		...props
	});
}
function PageHeader({ className, eyebrow, heading, description, breadcrumbs, metadata, actions, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cx("pf-page-header", className),
		...props,
		children: [breadcrumbs?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Breadcrumbs, {
			items: breadcrumbs,
			className: "pf-page-header__breadcrumbs"
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-page-header__row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pf-page-header__content",
				children: [
					eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pf-page-header__eyebrow",
						children: eyebrow
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "pf-page-header__heading",
						children: heading
					}),
					description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pf-page-header__description",
						children: description
					}) : null,
					metadata ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeaderMeta, { children: metadata }) : null,
					children
				]
			}), actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pf-page-header__actions",
				children: actions
			}) : null]
		})]
	});
}
function clampPage(page, totalPages) {
	if (totalPages <= 0) return 1;
	return Math.min(Math.max(page, 1), totalPages);
}
function getPaginationItems(currentPage, totalPages, siblingCount, boundaryCount) {
	const safeTotal = Math.max(totalPages, 1);
	const safeCurrent = clampPage(currentPage, safeTotal);
	const safeSiblingCount = Math.max(siblingCount, 0);
	const safeBoundaryCount = Math.max(boundaryCount, 0);
	const leftBoundaryEnd = Math.min(safeBoundaryCount, safeTotal);
	const rightBoundaryStart = Math.max(safeTotal - safeBoundaryCount + 1, 1);
	const start = Math.max(safeCurrent - safeSiblingCount, leftBoundaryEnd + 1);
	const end = Math.min(safeCurrent + safeSiblingCount, rightBoundaryStart - 1);
	const items = [];
	for (let page = 1; page <= leftBoundaryEnd; page += 1) items.push(page);
	if (start > leftBoundaryEnd + 1) items.push("ellipsis-left");
	for (let page = start; page <= end; page += 1) items.push(page);
	if (end < rightBoundaryStart - 1) items.push("ellipsis-right");
	for (let page = rightBoundaryStart; page <= safeTotal; page += 1) if (page > leftBoundaryEnd) items.push(page);
	if (!items.length) return [1];
	return items;
}
function Pagination({ className, page, defaultPage = 1, totalPages, siblingCount = 1, boundaryCount = 1, showPrevNext = true, disabled = false, onPageChange, prevLabel = "Previous", nextLabel = "Next", "aria-label": ariaLabel = "Pagination", ...props }) {
	const safeTotalPages = Math.max(totalPages, 1);
	const [internalPage, setInternalPage] = import_react.useState(() => clampPage(defaultPage, safeTotalPages));
	import_react.useEffect(() => {
		setInternalPage((current) => clampPage(current, safeTotalPages));
	}, [safeTotalPages]);
	const currentPage = clampPage(page ?? internalPage, safeTotalPages);
	const items = getPaginationItems(currentPage, safeTotalPages, siblingCount, boundaryCount);
	const canGoPrev = currentPage > 1;
	const canGoNext = currentPage < safeTotalPages;
	const setPage = import_react.useCallback((nextPage) => {
		const clamped = clampPage(nextPage, safeTotalPages);
		if (page === void 0) setInternalPage(clamped);
		onPageChange?.(clamped);
	}, [
		onPageChange,
		page,
		safeTotalPages
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
		className: cx("pf-pagination", disabled && "pf-pagination--disabled", className),
		"aria-label": ariaLabel,
		...props,
		children: [
			showPrevNext ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "pf-pagination__nav",
				onClick: () => setPage(currentPage - 1),
				disabled: disabled || !canGoPrev,
				children: prevLabel
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "pf-pagination__list",
				children: items.map((item, index) => {
					if (typeof item !== "number") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "pf-pagination__ellipsis",
						"aria-hidden": true,
						children: "..."
					}, `${item}-${index}`);
					const isCurrent = item === currentPage;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cx("pf-pagination__page", isCurrent && "pf-pagination__page--active"),
						onClick: () => setPage(item),
						disabled,
						"aria-current": isCurrent ? "page" : void 0,
						children: item
					}) }, item);
				})
			}),
			showPrevNext ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "pf-pagination__nav",
				onClick: () => setPage(currentPage + 1),
				disabled: disabled || !canGoNext,
				children: nextLabel
			}) : null
		]
	});
}
function clampCutout(value) {
	return Math.min(Math.max(value, 0), .88);
}
function prepareSegments(data) {
	const normalized = data.map((item, index) => ({
		...item,
		value: Math.max(item.value, 0),
		color: item.color ?? fallbackColors[index % fallbackColors.length]
	}));
	const total = normalized.reduce((sum, item) => sum + item.value, 0);
	if (total <= 0) return [];
	return normalized.filter((item) => item.value > 0).map((item) => ({
		...item,
		percentage: item.value / total * 100
	}));
}
function toConicGradient(segments) {
	let cursor = 0;
	return `conic-gradient(${segments.map((segment) => {
		const start = cursor;
		const end = cursor + segment.percentage;
		cursor = end;
		return `${segment.color} ${start}% ${end}%`;
	}).join(", ")})`;
}
function PieChart({ className, data, size = 192, cutout = .58, showLegend = true, centerLabel, emptyLabel = "No data", ...props }) {
	const segments = prepareSegments(data);
	const hasData = segments.length > 0;
	const chartSize = Math.max(size, 120);
	const safeCutout = clampCutout(cutout);
	const centerSize = Math.round(chartSize * safeCutout);
	const conicGradient = hasData ? toConicGradient(segments) : "conic-gradient(var(--color-semantic-background-subtle) 0% 100%)";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-pie-chart", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cx("pf-pie-chart__visual", !hasData && "pf-pie-chart__visual--empty"),
			style: {
				width: chartSize,
				height: chartSize,
				backgroundImage: conicGradient
			},
			role: "img",
			"aria-label": "Pie chart",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pf-pie-chart__center",
				style: {
					width: centerSize,
					height: centerSize
				},
				children: hasData ? centerLabel : emptyLabel
			})
		}), showLegend && hasData ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "pf-pie-chart__legend",
			children: segments.map((segment, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "pf-pie-chart__legend-item",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-pie-chart__legend-dot",
						style: { background: segment.color },
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-pie-chart__legend-label",
						children: segment.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "pf-pie-chart__legend-value",
						children: [Math.round(segment.percentage), "%"]
					})
				]
			}, `${index}-${segment.value}`))
		}) : null]
	});
}
function ProgressBar({ value, max = 100, showValue = true, className, ...props }) {
	const percent = clampPercent(value, max);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-progress-bar", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pf-progress-bar__track",
			role: "progressbar",
			"aria-valuemin": 0,
			"aria-valuemax": max,
			"aria-valuenow": Math.round(percent / 100 * max),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pf-progress-bar__fill",
				style: { width: `${percent}%` }
			})
		}), showValue ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "pf-progress-bar__value",
			children: [Math.round(percent), "%"]
		}) : null]
	});
}
function ProgressCircle({ value, max = 100, size = 64, strokeWidth = 6, showValue = true, className, ...props }) {
	const percent = clampPercent(value, max);
	const radius = (size - strokeWidth) / 2;
	const circumference = 2 * Math.PI * radius;
	const dashOffset = circumference * (1 - percent / 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-progress-circle", className),
		style: {
			width: size,
			height: size
		},
		role: "progressbar",
		"aria-valuemin": 0,
		"aria-valuemax": max,
		"aria-valuenow": Math.round(percent / 100 * max),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: `0 0 ${size} ${size}`,
			className: "pf-progress-circle__svg",
			"aria-hidden": true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				className: "pf-progress-circle__track",
				cx: size / 2,
				cy: size / 2,
				r: radius,
				strokeWidth
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				className: "pf-progress-circle__fill",
				cx: size / 2,
				cy: size / 2,
				r: radius,
				strokeWidth,
				strokeDasharray: circumference,
				strokeDashoffset: dashOffset
			})]
		}), showValue ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "pf-progress-circle__value",
			children: [Math.round(percent), "%"]
		}) : null]
	});
}
function inferStatus(index, steps) {
	const firstCurrent = steps.findIndex((step) => step.status === "current");
	if (steps[index]?.status) return steps[index].status;
	if (firstCurrent === -1) return index === 0 ? "current" : "upcoming";
	if (index < firstCurrent) return "complete";
	return index === firstCurrent ? "current" : "upcoming";
}
function ProgressSteps({ className, steps, orientation = "horizontal", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: cx("pf-progress-steps", `pf-progress-steps--${orientation}`, className),
		...props,
		children: steps.map((step, index) => {
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: cx("pf-progress-steps__item", `pf-progress-steps__item--${inferStatus(index, steps)}`),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pf-progress-steps__marker-wrap",
					"aria-hidden": true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-progress-steps__marker",
						children: index + 1
					}), index < steps.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pf-progress-steps__connector" }) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pf-progress-steps__content",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pf-progress-steps__title",
						children: step.title
					}), step.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pf-progress-steps__description",
						children: step.description
					}) : null]
				})]
			}, step.id ?? `step-${index}`);
		})
	});
}
function polarToCartesian(cx, cy, radius, angle) {
	return {
		x: cx + radius * Math.cos(angle),
		y: cy + radius * Math.sin(angle)
	};
}
function toPointsString(points) {
	return points.map((point) => `${point.x.toFixed(2)},${point.y.toFixed(2)}`).join(" ");
}
function RadarChart({ className, data, size = 280, max, levels = 4, showAxes = true, showLegend = true, strokeColor = "var(--color-semantic-action-primary)", fillColor = "rgb(249 115 22 / 0.18)", ...props }) {
	const safeData = data.filter((item) => item.value >= 0);
	const count = safeData.length;
	const safeSize = Math.max(size, 180);
	const safeLevels = Math.max(2, levels);
	if (count < 3) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cx("pf-radar-chart", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pf-radar-chart__empty",
			children: "RadarChart needs at least 3 data points."
		})
	});
	const center = safeSize / 2;
	const outerRadius = center - 36;
	const computedMax = max ?? Math.max(...safeData.map((item) => item.value), 1);
	const safeMax = computedMax > 0 ? computedMax : 1;
	const baseAngle = -Math.PI / 2;
	const angleStep = 2 * Math.PI / count;
	const axes = safeData.map((item, index) => {
		const angle = baseAngle + index * angleStep;
		return {
			item,
			angle,
			end: polarToCartesian(center, center, outerRadius, angle)
		};
	});
	const gridPolygons = Array.from({ length: safeLevels }, (_, levelIndex) => {
		const ratio = (levelIndex + 1) / safeLevels;
		return toPointsString(axes.map((axis) => polarToCartesian(center, center, outerRadius * ratio, axis.angle)));
	});
	const valuePoints = axes.map((axis) => {
		return polarToCartesian(center, center, outerRadius * Math.max(0, Math.min(1, axis.item.value / safeMax)), axis.angle);
	});
	const valuePolygon = toPointsString(valuePoints);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-radar-chart", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			className: "pf-radar-chart__svg",
			viewBox: `0 0 ${safeSize} ${safeSize}`,
			role: "img",
			"aria-label": "Radar chart",
			children: [
				gridPolygons.map((points, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
					className: "pf-radar-chart__grid",
					points
				}, `grid-${index}`)),
				showAxes ? axes.map((axis, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					className: "pf-radar-chart__axis",
					x1: center,
					y1: center,
					x2: axis.end.x,
					y2: axis.end.y
				}, `axis-${index}`)) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
					className: "pf-radar-chart__area",
					points: valuePolygon,
					style: {
						fill: fillColor,
						stroke: strokeColor
					}
				}),
				valuePoints.map((point, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					className: "pf-radar-chart__point",
					cx: point.x,
					cy: point.y,
					r: 3,
					style: { fill: strokeColor }
				}, `point-${index}`)),
				axes.map((axis, index) => {
					const labelPoint = polarToCartesian(center, center, outerRadius + 18, axis.angle);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						className: "pf-radar-chart__label",
						x: labelPoint.x,
						y: labelPoint.y,
						textAnchor: "middle",
						dominantBaseline: "middle",
						children: axis.item.label
					}, `label-${index}`);
				})
			]
		}), showLegend ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "pf-radar-chart__legend",
			children: safeData.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "pf-radar-chart__legend-item",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "pf-radar-chart__legend-label",
					children: item.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "pf-radar-chart__legend-value",
					children: item.value
				})]
			}, `${index}-${item.value}`))
		}) : null]
	});
}
function RatingStars({ value, max = 5, size = 18, showValue = false, ariaLabel, className, ...props }) {
	const clampedValue = clampRating(value, max);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-rating-stars", className),
		role: "img",
		"aria-label": ariaLabel ?? `Rating ${clampedValue} out of ${max}`,
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pf-rating-stars__track",
			"aria-hidden": true,
			children: Array.from({ length: max }, (_, index) => {
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "pf-rating-stars__star",
					style: {
						"--pf-rating-fill": `${getStarFillPercent(clampedValue, index)}%`,
						"--pf-rating-size": `${size}px`
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						name: "star",
						"aria-hidden": true,
						className: "pf-rating-stars__star-icon pf-rating-stars__star-icon--base"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-rating-stars__star-fill",
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							name: "star",
							className: "pf-rating-stars__star-icon pf-rating-stars__star-icon--fill"
						})
					})]
				}, index);
			})
		}), showValue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pf-rating-stars__value",
			children: clampedValue.toFixed(1)
		}) : null]
	});
}
function RatingBadge({ value, max = 5, reviews, size = "md", className, ...props }) {
	const clampedValue = clampRating(value, max);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cx("pf-rating-badge", `pf-rating-badge--${size}`, className),
		...props,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				name: "star",
				"aria-hidden": true,
				className: "pf-rating-badge__icon"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "pf-rating-badge__value",
				children: [
					clampedValue.toFixed(1),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-rating-badge__separator",
						children: "/"
					}),
					max.toFixed(1)
				]
			}),
			typeof reviews === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "pf-rating-badge__reviews",
				children: [
					"(",
					reviews.toLocaleString(),
					")"
				]
			}) : null
		]
	});
}
function SectionFooter({ className, heading, description, actions, divider = true, align = "between", children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: cx("pf-section-footer", divider && "pf-section-footer--divider", `pf-section-footer--${align}`, className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-section-footer__content",
			children: [
				heading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "pf-section-footer__heading",
					children: heading
				}) : null,
				description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-section-footer__description",
					children: description
				}) : null,
				children
			]
		}), actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pf-section-footer__actions",
			children: actions
		}) : null]
	});
}
function SectionHeader({ className, eyebrow, heading, description, metadata, actions, divider = false, align = "between", children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cx("pf-section-header", divider && "pf-section-header--divider", `pf-section-header--${align}`, className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-section-header__content",
			children: [
				eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-section-header__eyebrow",
					children: eyebrow
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "pf-section-header__heading",
					children: heading
				}),
				description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-section-header__description",
					children: description
				}) : null,
				metadata ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pf-section-header__metadata",
					children: metadata
				}) : null,
				children
			]
		}), actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pf-section-header__actions",
			children: actions
		}) : null]
	});
}
function renderItem(item, key) {
	const content = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		item.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pf-sidebar-navigation__icon",
			children: item.icon
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pf-sidebar-navigation__label",
			children: item.label
		}),
		item.badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pf-sidebar-navigation__badge",
			children: item.badge
		}) : null
	] });
	const className = cx("pf-sidebar-navigation__link", item.active && "pf-sidebar-navigation__link--active", item.disabled && "pf-sidebar-navigation__link--disabled");
	if (item.href && !item.disabled) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
		className: "pf-sidebar-navigation__item",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: item.href,
			onClick: item.onClick,
			className,
			"aria-current": item.active ? "page" : void 0,
			children: content
		})
	}, key);
	if (item.onClick) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
		className: "pf-sidebar-navigation__item",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: item.onClick,
			className,
			disabled: item.disabled,
			"aria-current": item.active ? "page" : void 0,
			children: content
		})
	}, key);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
		className: "pf-sidebar-navigation__item",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className,
			"aria-current": item.active ? "page" : void 0,
			children: content
		})
	}, key);
}
function SidebarNavigation({ className, sections, header, footer, "aria-label": ariaLabel = "Sidebar navigation", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: cx("pf-sidebar-navigation", className),
		...props,
		children: [
			header ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pf-sidebar-navigation__header",
				children: header
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "pf-sidebar-navigation__nav",
				"aria-label": ariaLabel,
				children: sections.map((section, sectionIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pf-sidebar-navigation__section",
					children: [section.title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pf-sidebar-navigation__section-title",
						children: section.title
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "pf-sidebar-navigation__list",
						children: section.items.map((item, itemIndex) => {
							return renderItem(item, `${sectionIndex}-${itemIndex}-${typeof item.label === "string" ? item.label : "item"}`);
						})
					})]
				}, `section-${sectionIndex}`))
			}),
			footer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pf-sidebar-navigation__footer",
				children: footer
			}) : null
		]
	});
}
function SlideoutMenu({ className, open, onOpenChange, title, description, footer, placement = "right", size = "md", closeOnOverlayClick = true, showCloseButton = true, children, ...props }) {
	const ANIMATION_DURATION_MS = 220;
	const titleId = (0, import_react$1.useId)();
	const descriptionId = (0, import_react$1.useId)();
	const panelRef = (0, import_react$1.useRef)(null);
	const previousActiveRef = (0, import_react$1.useRef)(null);
	const closeTimerRef = (0, import_react$1.useRef)(null);
	const [mounted, setMounted] = (0, import_react$1.useState)(open);
	const [visible, setVisible] = (0, import_react$1.useState)(open);
	(0, import_react$1.useEffect)(() => {
		if (typeof window === "undefined") return;
		if (open) {
			if (closeTimerRef.current) {
				clearTimeout(closeTimerRef.current);
				closeTimerRef.current = null;
			}
			setMounted(true);
			setVisible(false);
			closeTimerRef.current = setTimeout(() => {
				setVisible(true);
				closeTimerRef.current = null;
			}, 16);
			return;
		}
		setVisible(false);
		closeTimerRef.current = setTimeout(() => {
			setMounted(false);
		}, ANIMATION_DURATION_MS);
		return () => {
			if (closeTimerRef.current) {
				clearTimeout(closeTimerRef.current);
				closeTimerRef.current = null;
			}
		};
	}, [open]);
	(0, import_react$1.useEffect)(() => {
		if (!mounted || !open || typeof document === "undefined") return;
		const getFocusableElements = () => {
			if (!panelRef.current) return [];
			return Array.from(panelRef.current.querySelectorAll(FOCUSABLE_SELECTOR));
		};
		const focusFirstElement = () => {
			const focusableElements = getFocusableElements();
			if (focusableElements.length > 0) {
				focusableElements[0]?.focus();
				return;
			}
			panelRef.current?.focus();
		};
		const focusLastElement = () => {
			const focusableElements = getFocusableElements();
			if (focusableElements.length > 0) {
				focusableElements[focusableElements.length - 1]?.focus();
				return;
			}
			panelRef.current?.focus();
		};
		previousActiveRef.current = document.activeElement;
		const originalOverflow = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		focusFirstElement();
		const onKeyDown = (event) => {
			if (event.key === "Escape") {
				onOpenChange?.(false);
				return;
			}
			if (event.key !== "Tab" || !panelRef.current) return;
			const focusableElements = getFocusableElements();
			const activeElement = document.activeElement;
			if (!panelRef.current.contains(activeElement)) {
				event.preventDefault();
				if (event.shiftKey) {
					focusLastElement();
					return;
				}
				focusFirstElement();
				return;
			}
			if (focusableElements.length === 0) {
				event.preventDefault();
				panelRef.current.focus();
				return;
			}
			const firstElement = focusableElements[0];
			const lastElement = focusableElements[focusableElements.length - 1];
			if (event.shiftKey) {
				if (activeElement === firstElement || activeElement === panelRef.current) {
					event.preventDefault();
					focusLastElement();
				}
				return;
			}
			if (activeElement === lastElement) {
				event.preventDefault();
				focusFirstElement();
			}
		};
		const onFocusIn = (event) => {
			if (!panelRef.current) return;
			const target = event.target;
			if (target instanceof Node && panelRef.current.contains(target)) return;
			focusFirstElement();
		};
		document.addEventListener("keydown", onKeyDown);
		document.addEventListener("focusin", onFocusIn);
		return () => {
			document.body.style.overflow = originalOverflow;
			document.removeEventListener("keydown", onKeyDown);
			document.removeEventListener("focusin", onFocusIn);
			previousActiveRef.current?.focus?.();
		};
	}, [
		mounted,
		open,
		onOpenChange
	]);
	if (!mounted || typeof document === "undefined") return null;
	return (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pf-slideout__portal",
		"data-state": visible ? "open" : "closed",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pf-slideout__overlay",
			onClick: () => {
				if (closeOnOverlayClick) onOpenChange?.(false);
			}
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cx("pf-slideout__viewport", `pf-slideout__viewport--${placement}`),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: panelRef,
				className: cx("pf-slideout", `pf-slideout--${size}`, className),
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": title ? titleId : void 0,
				"aria-describedby": description ? descriptionId : void 0,
				tabIndex: -1,
				...props,
				children: [
					title || description || showCloseButton ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "pf-slideout__header",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pf-slideout__heading-group",
							children: [title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "pf-slideout__title",
								id: titleId,
								children: title
							}) : null, description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "pf-slideout__description",
								id: descriptionId,
								children: description
							}) : null]
						}), showCloseButton ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "pf-slideout__close",
							"aria-label": "Close slideout",
							onClick: () => onOpenChange?.(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								name: "circle-xmark",
								"aria-hidden": true
							})
						}) : null]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pf-slideout__body",
						children
					}),
					footer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
						className: "pf-slideout__footer",
						children: footer
					}) : null
				]
			})
		})]
	}), document.body);
}
function Tag({ className, variant = "neutral", dismissible = false, onDismiss, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cx("pf-tag", `pf-tag--${variant}`, className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pf-tag__label",
			children
		}), dismissible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "pf-tag__dismiss",
			"aria-label": "Remove tag",
			onClick: () => onDismiss?.(),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				name: "circle-xmark",
				"aria-hidden": true
			})
		}) : null]
	});
}
function Table({ className, columns, rows, caption, dense = false, striped = false, hoverable = true, stickyHeader = false, emptyState = "No data available.", defaultSortState, sortState, onSortStateChange, getRowKey, ...props }) {
	const [internalSortState, setInternalSortState] = (0, import_react$1.useState)(defaultSortState);
	const resolvedSortState = sortState ?? internalSortState;
	const sortedRows = (0, import_react$1.useMemo)(() => {
		if (!resolvedSortState) return rows;
		const sortColumn = columns.find((column) => column.key === resolvedSortState.key);
		if (!sortColumn || !sortColumn.sortable) return rows;
		const getValue = (row) => {
			const value = sortColumn.sortValue ? sortColumn.sortValue(row) : row[sortColumn.key];
			if (value instanceof Date) return value.getTime();
			if (typeof value === "number") return value;
			return value == null ? "" : String(value);
		};
		const directionFactor = resolvedSortState.direction === "asc" ? 1 : -1;
		return [...rows].sort((leftRow, rightRow) => {
			const leftValue = getValue(leftRow);
			const rightValue = getValue(rightRow);
			if (typeof leftValue === "number" && typeof rightValue === "number") return (leftValue - rightValue) * directionFactor;
			return String(leftValue).localeCompare(String(rightValue), void 0, {
				numeric: true,
				sensitivity: "base"
			}) * directionFactor;
		});
	}, [
		columns,
		resolvedSortState,
		rows
	]);
	const setSort = (nextState) => {
		if (!sortState) setInternalSortState(nextState);
		onSortStateChange?.(nextState);
	};
	const toggleSort = (column) => {
		if (!column.sortable) return;
		if (resolvedSortState?.key !== column.key) {
			setSort({
				key: column.key,
				direction: "asc"
			});
			return;
		}
		setSort({
			key: column.key,
			direction: resolvedSortState.direction === "asc" ? "desc" : "asc"
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-table", dense && "pf-table--dense", striped && "pf-table--striped", hoverable && "pf-table--hoverable", stickyHeader && "pf-table--sticky-header", className),
		...props,
		children: [caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pf-table__caption",
			children: caption
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "pf-table__native",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: columns.map((column) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: cx("pf-table__head-cell", `pf-table__cell--${column.align ?? "left"}`, column.className),
				scope: "col",
				"aria-sort": resolvedSortState?.key === column.key ? resolvedSortState.direction === "asc" ? "ascending" : "descending" : "none",
				style: column.width !== void 0 ? { width: typeof column.width === "number" ? `${column.width}px` : column.width } : void 0,
				children: column.sortable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "pf-table__sort-button",
					onClick: () => toggleSort(column),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: column.header }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-table__sort-indicator",
						"aria-hidden": true,
						children: resolvedSortState?.key === column.key ? resolvedSortState.direction === "asc" ? "^" : "v" : "-"
					})]
				}) : column.header
			}, column.key)) }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: sortedRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "pf-table__empty",
				colSpan: Math.max(columns.length, 1),
				children: emptyState
			}) }) : sortedRows.map((row, rowIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: columns.map((column) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: cx("pf-table__body-cell", `pf-table__cell--${column.align ?? "left"}`, column.className),
				children: row[column.key] ?? "—"
			}, column.key)) }, getRowKey?.(row, rowIndex) ?? rowIndex)) })]
		})]
	});
}
function getFirstEnabledValue(items) {
	return items.find((item) => !item.disabled)?.value;
}
function Tabs({ className, items, value, defaultValue, onValueChange, variant = "underline", size = "md", fullWidth = false, ...props }) {
	const baseId = (0, import_react$1.useId)();
	const isControlled = value !== void 0;
	const [internalValue, setInternalValue] = (0, import_react$1.useState)(defaultValue ?? getFirstEnabledValue(items));
	const selectedValue = isControlled ? value : internalValue;
	const selectedItem = (0, import_react$1.useMemo)(() => items.find((item) => item.value === selectedValue && !item.disabled) ?? items.find((item) => !item.disabled), [items, selectedValue]);
	const buttonRefs = (0, import_react$1.useRef)([]);
	const setSelectedValue = (nextValue) => {
		if (!isControlled) setInternalValue(nextValue);
		onValueChange?.(nextValue);
	};
	const enabledIndexes = items.map((item, index) => ({
		item,
		index
	})).filter(({ item }) => !item.disabled).map(({ index }) => index);
	const moveSelection = (currentIndex, direction) => {
		if (enabledIndexes.length === 0) return;
		let targetIndex = currentIndex;
		if (direction === "first") targetIndex = enabledIndexes[0] ?? currentIndex;
		else if (direction === "last") targetIndex = enabledIndexes[enabledIndexes.length - 1] ?? currentIndex;
		else {
			const currentEnabledPosition = enabledIndexes.indexOf(currentIndex);
			const fallbackPosition = direction === "next" ? 0 : enabledIndexes.length - 1;
			targetIndex = enabledIndexes[((currentEnabledPosition === -1 ? fallbackPosition : currentEnabledPosition) + (direction === "next" ? 1 : -1) + enabledIndexes.length) % enabledIndexes.length] ?? currentIndex;
		}
		const nextItem = items[targetIndex];
		if (!nextItem || nextItem.disabled) return;
		setSelectedValue(nextItem.value);
		buttonRefs.current[targetIndex]?.focus();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx("pf-tabs", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cx("pf-tabs__list", `pf-tabs__list--${variant}`, `pf-tabs__list--${size}`, fullWidth && "pf-tabs__list--full-width"),
			role: "tablist",
			"aria-orientation": "horizontal",
			children: items.map((item, index) => {
				const isSelected = item.value === selectedItem?.value;
				const tabId = `${baseId}-tab-${item.value}`;
				const panelId = `${baseId}-panel-${item.value}`;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					ref: (element) => {
						buttonRefs.current[index] = element;
					},
					id: tabId,
					type: "button",
					role: "tab",
					className: cx("pf-tabs__tab", `pf-tabs__tab--${variant}`, `pf-tabs__tab--${size}`, isSelected && "pf-tabs__tab--active"),
					"aria-controls": panelId,
					"aria-selected": isSelected,
					tabIndex: item.disabled ? -1 : 0,
					disabled: item.disabled,
					onClick: () => {
						if (!item.disabled) setSelectedValue(item.value);
					},
					onKeyDown: (event) => {
						if (event.key === "ArrowRight") {
							event.preventDefault();
							moveSelection(index, "next");
						} else if (event.key === "ArrowLeft") {
							event.preventDefault();
							moveSelection(index, "previous");
						} else if (event.key === "Home") {
							event.preventDefault();
							moveSelection(index, "first");
						} else if (event.key === "End") {
							event.preventDefault();
							moveSelection(index, "last");
						} else if (event.key === "Enter" || event.key === " ") {
							event.preventDefault();
							if (!item.disabled) setSelectedValue(item.value);
						}
					},
					children: item.label
				}, item.value);
			})
		}), selectedItem ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			id: `${baseId}-panel-${selectedItem.value}`,
			className: "pf-tabs__panel",
			role: "tabpanel",
			"aria-labelledby": `${baseId}-tab-${selectedItem.value}`,
			tabIndex: 0,
			children: selectedItem.content
		}) : null]
	});
}
function Tooltip({ content, children, placement = "top", delay = 120, disabled = false, className }) {
	const tooltipId = (0, import_react$1.useId)();
	const triggerRef = (0, import_react$1.useRef)(null);
	const tooltipRef = (0, import_react$1.useRef)(null);
	const showTimerRef = (0, import_react$1.useRef)(void 0);
	const [isOpen, setIsOpen] = (0, import_react$1.useState)(false);
	const [style, setStyle] = (0, import_react$1.useState)({});
	const clearShowTimer = () => {
		if (showTimerRef.current !== void 0) {
			window.clearTimeout(showTimerRef.current);
			showTimerRef.current = void 0;
		}
	};
	const openTooltip = () => {
		if (disabled) return;
		clearShowTimer();
		showTimerRef.current = window.setTimeout(() => {
			setIsOpen(true);
		}, delay);
	};
	const closeTooltip = () => {
		clearShowTimer();
		setIsOpen(false);
	};
	(0, import_react$1.useEffect)(() => {
		return () => {
			clearShowTimer();
		};
	}, []);
	(0, import_react$1.useEffect)(() => {
		if (!isOpen) return;
		const updatePosition = () => {
			if (!triggerRef.current || !tooltipRef.current) return;
			setStyle(getTooltipStyle(triggerRef.current.getBoundingClientRect(), tooltipRef.current.getBoundingClientRect(), placement));
		};
		updatePosition();
		window.addEventListener("resize", updatePosition);
		window.addEventListener("scroll", updatePosition, true);
		return () => {
			window.removeEventListener("resize", updatePosition);
			window.removeEventListener("scroll", updatePosition, true);
		};
	}, [isOpen, placement]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		ref: triggerRef,
		className: "pf-tooltip__trigger",
		onMouseEnter: openTooltip,
		onMouseLeave: closeTooltip,
		onFocus: openTooltip,
		onBlur: closeTooltip,
		onKeyDown: (event) => {
			if (event.key === "Escape") closeTooltip();
		},
		"aria-describedby": isOpen ? tooltipId : void 0,
		children: children ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
	}), isOpen && !disabled && typeof document !== "undefined" ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		id: tooltipId,
		ref: tooltipRef,
		role: "tooltip",
		className: cx("pf-tooltip", `pf-tooltip--${placement}`, className),
		style,
		children: content
	}), document.body) : null] });
}
function flattenVisibleNodes(nodes, expandedSet, level = 1, parentValue) {
	const flattened = [];
	for (const node of nodes) {
		flattened.push({
			node,
			level,
			parentValue
		});
		if (node.children && node.children.length > 0 && expandedSet.has(node.value)) flattened.push(...flattenVisibleNodes(node.children, expandedSet, level + 1, node.value));
	}
	return flattened;
}
function findFirstEnabledValue(nodes) {
	for (const node of nodes) {
		if (!node.disabled) return node.value;
		if (node.children && node.children.length > 0) {
			const childValue = findFirstEnabledValue(node.children);
			if (childValue) return childValue;
		}
	}
}
function collectExpandableNodeValues(nodes) {
	const values = [];
	for (const node of nodes) if (node.children && node.children.length > 0) {
		values.push(node.value);
		values.push(...collectExpandableNodeValues(node.children));
	}
	return values;
}
var import_react, import_react$1, import_jsx_runtime, import_react_dom, faSquareMinus, faMinusSquare, faCalendarCheck, faFaceKiss, faKiss, faPaste, faFileClipboard, faHandPointLeft, faFileExcel, faEnvelope, faSquareCaretDown, faCaretSquareDown, faTruck, faBell, faMessage, faCommentAlt, faFaceDizzy, faDizzy, faCalendarDays, faCalendarAlt, faHandPointUp, faHandLizard, faSquareFull, faCirclePause, faPauseCircle, faHardDrive, faHdd, faFileZipper, faFileArchive, faFloppyDisk, faSave, faFaceGrinTongueSquint, faGrinTongueSquint, faCamera, faCameraAlt, faFaceGrinStars, faGrinStars, faEye, faFaceSadTear, faSadTear, faShareFromSquare, faShareSquare, faNoteSticky, faStickyNote, faHandBackFist, faHandRock, faChessQueen, faFaceGrinTears, faGrinTears, faPenToSquare, faEdit, faFaceGrinBeamSweat, faGrinBeamSweat, faClock, faClockFour, faFaceLaughWink, faLaughWink, faPaperPlane, faHeart, faFontAwesome, faFontAwesomeFlag, faFontAwesomeLogoFull, faClone, faFolderOpen, faWindowMinimize, faStarHalf, faAlarmClock, faNewspaper, faHospital, faHospitalAlt, faHospitalWide, faCircleStop, faStopCircle, faObjectUngroup, faComment, faChessPawn, faCalendarPlus, faClipboard, faThumbsDown, faIdBadge, faSquareCheck, faCheckSquare, faChessBishop, faEnvelopeOpen, faCircleXmark, faTimesCircle, faXmarkCircle, faSquareCaretUp, faCaretSquareUp, faFileImage, faSquareCaretRight, faCaretSquareRight, faSun, faImage, faLightbulb, faAddressCard, faContactCard, faVcard, faFaceMeh, faMeh, faMap, faHandPointDown, faFaceMehBlank, faMehBlank, faFaceGrinTongue, faGrinTongue, faFutbol, faFutbolBall, faSoccerBall, faFaceSurprise, faSurprise, faFolder, faFolderBlank, faCloud, faCircle, faFaceGrinSquint, faGrinSquint, faCircleUser, faUserCircle, faRectangleList, faListAlt, faHand, faHandPaper, faThumbsUp, faBuilding, faChessRook, faCircleQuestion, faQuestionCircle, faFile, faFaceSadCry, faSadCry, faCalendarMinus, faFaceTired, faTired, faHandPointRight, faCircleUp, faArrowAltCircleUp, faHandScissors, faGem, faRectangleXmark, faRectangleTimes, faTimesRectangle, faWindowClose, faTrashCan, faTrashAlt, faLifeRing, faCopyright, faCircleLeft, faArrowAltCircleLeft, faCalendar, faFaceFrownOpen, faFrownOpen, faChartBar, faBarChart, faHouse, faHome, faHomeAlt, faHomeLgAlt, faFaceFrown, faFrown, faUser, faUserAlt, faUserLarge, faSnowflake, faBookmark, faSquareCaretLeft, faCaretSquareLeft, faHandshake, faHandshakeAlt, faHandshakeSimple, faFaceSmileWink, faSmileWink, faFaceGrinSquintTears, faGrinSquintTears, faFileAudio, faCalendarXmark, faCalendarTimes, faCircleDown, faArrowAltCircleDown, faFileLines, faFileAlt, faFileText, faComments, faCircleCheck, faCheckCircle, faMoon, faClosedCaptioning, faImages, faCircleRight, faArrowAltCircleRight, faIdCard, faDriversLicense, faCirclePlay, faPlayCircle, faFaceLaughBeam, faLaughBeam, faAddressBook, faContactBook, faHourglass, faHourglassEmpty, faHeadphones, faHeadphonesAlt, faHeadphonesSimple, faFilePowerpoint, faWindowMaximize, faCommentDots, faCommenting, faFaceGrinTongueWink, faGrinTongueWink, faHourglassHalf, faHourglass2, faCreditCard, faCreditCardAlt, faHandSpock, faBellSlash, faStar, faFlag, faLemon, faWindowRestore, faFaceGrinHearts, faGrinHearts, faFaceKissBeam, faKissBeam, faFilePdf, faFaceGrinWide, faGrinAlt, faFaceLaughSquint, faLaughSquint, faFaceKissWinkHeart, faKissWinkHeart, faCopy, faChessKing, faSquarePlus, faPlusSquare, faFileCode, faFaceGrinWink, faGrinWink, faMoneyBill1, faMoneyBillAlt, faEyeSlash, faFileWord, faFaceAngry, faAngry, faChessKnight, faFaceGrinBeam, faGrinBeam, faHandPeace, faCompass, faSquare, faFaceGrin, faGrin, faFaceSmile, faSmile, faFaceSmileBeam, faSmileBeam, faFolderClosed, faKeyboard, faFaceRollingEyes, faMehRollingEyes, faFaceGrimace, faGrimace, faCircleDot, faDotCircle, faObjectGroup, faFaceFlushed, faFlushed, faStarHalfStroke, faStarHalfAlt, faFileVideo, faFaceLaugh, icons, noop, _WINDOW, _DOCUMENT, _MUTATION_OBSERVER, _PERFORMANCE, _ref$userAgent, userAgent, WINDOW, DOCUMENT, MUTATION_OBSERVER, PERFORMANCE, IS_DOM, IS_IE, _ht, G, M, Q, X, Z, i, t, d, l, f, h, n, g, o, u, m, e, y, p, s, w, a, x, b, c, I, F, v, S, A, P, j, B, N, k, D, T, C, W, K, R, L, U, dt, yt, Kt, Et, Mt, Ht, Qt, Xt, sl, hl, nl, ml, _wt, t$1, f$1, Hl, Y$1, Xl, lo, $, z$1, q$1, so, fo, NAMESPACE_IDENTIFIER, UNITS_IN_GRID, DEFAULT_CSS_PREFIX, DEFAULT_REPLACEMENT_CLASS, DATA_FA_I2SVG, DATA_FA_PSEUDO_ELEMENT, DATA_FA_PSEUDO_ELEMENT_PENDING, DATA_PREFIX, DATA_ICON, HTML_CLASS_I2SVG_BASE_CLASS, MUTATION_APPROACH_ASYNC, TAGNAMES_TO_SKIP_FOR_PSEUDOELEMENTS, PSEUDO_ELEMENTS, PRODUCTION, _PREFIX_TO_STYLE, PREFIX_TO_STYLE, _STYLE_TO_PREFIX, STYLE_TO_PREFIX, _PREFIX_TO_LONG_STYLE, PREFIX_TO_LONG_STYLE, _LONG_STYLE_TO_PREFIX, ICON_SELECTION_SYNTAX_PATTERN, LAYERS_TEXT_CLASSNAME, FONT_FAMILY_PATTERN, ATTRIBUTES_WATCHED_FOR_MUTATION, DUOTONE_CLASSES, RESERVED_CLASSES, initial, _default, _config, config, _onChangeCb, d$2, meaninglessTransform, idPool, baseStyles, _cssInserted, InjectCSS, w$2, namespace, functions, _listener, loaded, bindInternal4, reduce, styles, shims, FAMILY_NAMES, PREFIXES_FOR_FAMILY, _defaultUsablePrefix, _byUnicode, _byLigature, _byOldName, _byOldUnicode, _byAlias, build, emptyCanonicalIcon, _faCombinedClasses, newCanonicalFamilies, newCanonicalStyles, Library, _plugins, _hooks, providers, defaultProviderKeys, library, api, autoReplace, styles$1, missingIconResolutionMixin, noop$1, p$2, preamble, begin, end, perf, noop$2, mutators, disabled, mo, styles$2, render, ReplaceElements, Layers, LayersCounter, LayersText, CLEAN_CONTENT_PATTERN, SECONDARY_UNICODE_RANGE, _FONT_FAMILY_WEIGHT_TO_PREFIX, FONT_FAMILY_WEIGHT_TO_PREFIX, FONT_FAMILY_WEIGHT_FALLBACK, hasPseudoElement, parseCSSRuleForPseudos, PseudoElements, _unwatched, MutationObserver$1, parseTransformString, PowerTransforms, ALL_SPACE, config$1, parse$1, icon, createGradientStops, styleCache, STYLE_CACHE_LIMIT, makeReactConverter, useAccessibilityId, Logger, SVG_CORE_VERSION, IS_VERSION_7_OR_LATER, getIsVersion7OrLater, DEFAULT_CLASSNAME_PREFIX, ANIMATION_CLASSES, PULL_CLASSES, ROTATE_CLASSES, SIZE_CLASSES, STYLE_CLASSES, LAYER_CLASSES, isIconDefinition, logger, DEFAULT_PROPS, DEFAULT_PROP_KEYS, FontAwesomeIcon, toLookup, regularIcons, toAliasLookup, regularAliases, legacyAliases, toKebabCase, normalizeName, getAvailableIconNames, resolveIcon, variantIcon$1, getInitials, Avatar, Button, BadgeGroup, isSelected, ButtonGroup, Input, maskCardNumber, formatCardNumber, CreditCard, Checkbox, WEEKDAY_LABELS, MONTH_OPTIONS, toMidday$1, isSameDay, startOfMonth, addMonths, buildCalendarDays, clamp$1, splitLines, toMidday, findNextEnabledIndex$2, findFirstEnabledIndex$2, Dropdown, bytesToSize, trendSymbol, getFocusableElements, findNextEnabledIndex$1, findFirstEnabledIndex$1, MultiSelect, variantIcon, fallbackColors, clampPercent, RadioButton, RadioGroup, clampRating, getStarFillPercent, normalizeHtml, getTextLength, RichTextEditor, FOCUSABLE_SELECTOR, Switch, findNextEnabledIndex, findFirstEnabledIndex, Select, clamp, Slider, Textarea, GAP, getTooltipStyle, TreeView, UtilityButton, VideoPlayer;
var init_dist = __esmMin((() => {
	import_react = /* @__PURE__ */ __toESM(require_react(), 1);
	import_react$1 = /* @__PURE__ */ __toESM(require_react(), 1);
	import_jsx_runtime = require_jsx_runtime();
	import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
	faSquareMinus = {
		prefix: "far",
		iconName: "square-minus",
		icon: [
			448,
			512,
			[61767, "minus-square"],
			"f146",
			"M64 80c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 80zM0 96C0 60.7 28.7 32 64 32l320 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zM136 232l176 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-176 0c-13.3 0-24-10.7-24-24s10.7-24 24-24z"
		]
	};
	faMinusSquare = faSquareMinus;
	faCalendarCheck = {
		prefix: "far",
		iconName: "calendar-check",
		icon: [
			448,
			512,
			[],
			"f274",
			"M328 0c13.3 0 24 10.7 24 24l0 40 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-40c0-13.3 10.7-24 24-24s24 10.7 24 24l0 40 160 0 0-40c0-13.3 10.7-24 24-24zM64 112c-8.8 0-16 7.2-16 16l0 288c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-288c0-8.8-7.2-16-16-16L64 112zm230.7 65.9c7.8-10.7 22.8-13.1 33.5-5.3 10.7 7.8 13.1 22.8 5.3 33.5L211.4 374.1c-4.1 5.7-10.5 9.3-17.5 9.8-7 .5-13.9-2-18.8-6.9l-55.9-55.9c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l36 36 105.6-145.2z"
		]
	};
	faFaceKiss = {
		prefix: "far",
		iconName: "face-kiss",
		icon: [
			512,
			512,
			[128535, "kiss"],
			"f596",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm240 0l32 0c26.5 0 48 21.5 48 48 0 12.3-4.6 23.5-12.2 32 7.6 8.5 12.2 19.7 12.2 32 0 26.5-21.5 48-48 48l-32 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm-96-48a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm192-32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"
		]
	};
	faKiss = faFaceKiss;
	faPaste = {
		prefix: "far",
		iconName: "paste",
		icon: [
			512,
			512,
			["file-clipboard"],
			"f0ea",
			"M64 48l224 0c8.8 0 16 7.2 16 16l0 48 48 0 0-48c0-35.3-28.7-64-64-64L64 0C28.7 0 0 28.7 0 64L0 384c0 35.3 28.7 64 64 64l112 0 0-48-112 0c-8.8 0-16-7.2-16-16L48 64c0-8.8 7.2-16 16-16zm176 72c0-13.3-10.7-24-24-24L104 96c-13.3 0-24 10.7-24 24s10.7 24 24 24l105.6 0c8.8-8.6 19-15.8 30.2-21.1 .1-.9 .2-1.9 .2-2.9zM448 464l-160 0c-8.8 0-16-7.2-16-16l0-224c0-8.8 7.2-16 16-16l101.5 0c4.2 0 8.3 1.7 11.3 4.7l58.5 58.5c3 3 4.7 7.1 4.7 11.3L464 448c0 8.8-7.2 16-16 16zM224 224l0 224c0 35.3 28.7 64 64 64l160 0c35.3 0 64-28.7 64-64l0-165.5c0-17-6.7-33.3-18.7-45.3l-58.5-58.5c-12-12-28.3-18.7-45.3-18.7L288 160c-35.3 0-64 28.7-64 64z"
		]
	};
	faFileClipboard = faPaste;
	faHandPointLeft = {
		prefix: "far",
		iconName: "hand-point-left",
		icon: [
			512,
			512,
			[],
			"f0a5",
			"M64 128l177.6 0c-1 5.2-1.6 10.5-1.6 16l0 16-176 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm224 16c0-17.7 14.3-32 32-32l24 0c66.3 0 120 53.7 120 120l0 48c0 52.5-33.7 97.1-80.7 113.4 .5-3.1 .7-6.2 .7-9.4 0-20-9.2-37.9-23.6-49.7 4.9-9 7.6-19.4 7.6-30.3 0-15.1-5.3-29-14-40 8.8-11 14-24.9 14-40l0-40c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 40c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-80zm32-80l0 0c-18 0-34.6 6-48 16L64 80C28.7 80 0 108.7 0 144s28.7 64 64 64l82 0c-1.3 5.1-2 10.5-2 16 0 25.3 14.7 47.2 36 57.6-2.6 7-4 14.5-4 22.4 0 20 9.2 37.9 23.6 49.7-4.9 9-7.6 19.4-7.6 30.3 0 35.3 28.7 64 64 64l88 0c92.8 0 168-75.2 168-168l0-48c0-92.8-75.2-168-168-168l-24 0zM256 400c-8.8 0-16-7.2-16-16s7.2-16 16-16l64 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-64 0zM240 224c0 5.5 .7 10.9 2 16l-34 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l32 0 0 16zm24 64l40 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-64 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l24 0z"
		]
	};
	faFileExcel = {
		prefix: "far",
		iconName: "file-excel",
		icon: [
			384,
			512,
			[],
			"f1c3",
			"M64 48l112 0 0 88c0 39.8 32.2 72 72 72l88 0 0 240c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16L48 64c0-8.8 7.2-16 16-16zM224 67.9l92.1 92.1-68.1 0c-13.3 0-24-10.7-24-24l0-68.1zM64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-261.5c0-17-6.7-33.3-18.7-45.3L242.7 18.7C230.7 6.7 214.5 0 197.5 0L64 0zm99.2 265.6c-8-10.6-23-12.8-33.6-4.8s-12.8 23-4.8 33.6L162 344 124.8 393.6c-8 10.6-5.8 25.6 4.8 33.6s25.6 5.8 33.6-4.8L192 384 220.8 422.4c8 10.6 23 12.8 33.6 4.8s12.8-23 4.8-33.6L222 344 259.2 294.4c8-10.6 5.8-25.6-4.8-33.6s-25.6-5.8-33.6 4.8L192 304 163.2 265.6z"
		]
	};
	faEnvelope = {
		prefix: "far",
		iconName: "envelope",
		icon: [
			512,
			512,
			[
				128386,
				9993,
				61443
			],
			"f0e0",
			"M61.4 64C27.5 64 0 91.5 0 125.4 0 126.3 0 127.1 .1 128L0 128 0 384c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-256-.1 0c0-.9 .1-1.7 .1-2.6 0-33.9-27.5-61.4-61.4-61.4L61.4 64zM464 192.3L464 384c0 8.8-7.2 16-16 16L64 400c-8.8 0-16-7.2-16-16l0-191.7 154.8 117.4c31.4 23.9 74.9 23.9 106.4 0L464 192.3zM48 125.4C48 118 54 112 61.4 112l389.2 0c7.4 0 13.4 6 13.4 13.4 0 4.2-2 8.2-5.3 10.7L280.2 271.5c-14.3 10.8-34.1 10.8-48.4 0L53.3 136.1c-3.3-2.5-5.3-6.5-5.3-10.7z"
		]
	};
	faSquareCaretDown = {
		prefix: "far",
		iconName: "square-caret-down",
		icon: [
			448,
			512,
			["caret-square-down"],
			"f150",
			"M384 432c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 80c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l320 0zm64-16c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l320 0c35.3 0 64 28.7 64 64l0 320zM224 352c-6.7 0-13-2.8-17.6-7.7l-104-112c-6.5-7-8.2-17.2-4.4-25.9S110.5 192 120 192l208 0c9.5 0 18.2 5.7 22 14.4s2.1 18.9-4.4 25.9l-104 112c-4.5 4.9-10.9 7.7-17.6 7.7z"
		]
	};
	faCaretSquareDown = faSquareCaretDown;
	faTruck = {
		prefix: "far",
		iconName: "truck",
		icon: [
			576,
			512,
			[128666, 9951],
			"f0d1",
			"M64 80c-8.8 0-16 7.2-16 16l0 288c0 8.8 7.2 16 16 16l3.3 0c10.4-36.9 44.4-64 84.7-64s74.2 27.1 84.7 64l102.6 0c4.9-17.4 15.1-32.7 28.7-43.9L368 96c0-8.8-7.2-16-16-16L64 80zm3.3 368L64 448c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l288 0c35.3 0 64 28.7 64 64l0 32 55.4 0c17 0 33.3 6.7 45.3 18.7l40.6 40.6c12 12 18.7 28.3 18.7 45.3L576 384c0 35.3-28.7 64-64 64l-3.3 0c-10.4 36.9-44.4 64-84.7 64s-74.2-27.1-84.7-64l-102.6 0c-10.4 36.9-44.4 64-84.7 64s-74.2-27.1-84.7-64zM416 256l112 0 0-23.4c0-4.2-1.7-8.3-4.7-11.3l-40.6-40.6c-3-3-7.1-4.7-11.3-4.7l-55.4 0 0 80zm0 48l0 32.4c2.6-.2 5.3-.4 8-.4 40.3 0 74.2 27.1 84.7 64l3.3 0c8.8 0 16-7.2 16-16l0-80-112 0zM152 464a40 40 0 1 0 0-80 40 40 0 1 0 0 80zm272 0a40 40 0 1 0 0-80 40 40 0 1 0 0 80z"
		]
	};
	faBell = {
		prefix: "far",
		iconName: "bell",
		icon: [
			448,
			512,
			[128276, 61602],
			"f0f3",
			"M224 0c-13.3 0-24 10.7-24 24l0 9.7C118.6 45.3 56 115.4 56 200l0 14.5c0 37.7-10 74.7-29 107.3L5.1 359.2C1.8 365 0 371.5 0 378.2 0 399.1 16.9 416 37.8 416l372.4 0c20.9 0 37.8-16.9 37.8-37.8 0-6.7-1.8-13.3-5.1-19L421 321.7c-19-32.6-29-69.6-29-107.3l0-14.5c0-84.6-62.6-154.7-144-166.3l0-9.7c0-13.3-10.7-24-24-24zM392.4 368l-336.9 0 12.9-22.1C91.7 306 104 260.6 104 214.5l0-14.5c0-66.3 53.7-120 120-120s120 53.7 120 120l0 14.5c0 46.2 12.3 91.5 35.5 131.4L392.4 368zM156.1 464c9.9 28 36.6 48 67.9 48s58-20 67.9-48l-135.8 0z"
		]
	};
	faMessage = {
		prefix: "far",
		iconName: "message",
		icon: [
			512,
			512,
			["comment-alt"],
			"f27a",
			"M203.7 512.9s0 0 0 0l-37.8 26.7c-7.3 5.2-16.9 5.8-24.9 1.7S128 529 128 520l0-72-32 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l320 0c53 0 96 43 96 96l0 224c0 53-43 96-96 96l-120.4 0-91.9 64.9zm64.3-104.1c8.1-5.7 17.8-8.8 27.7-8.8L416 400c26.5 0 48-21.5 48-48l0-224c0-26.5-21.5-48-48-48L96 80c-26.5 0-48 21.5-48 48l0 224c0 26.5 21.5 48 48 48l56 0c10.4 0 19.3 6.6 22.6 15.9 .9 2.5 1.4 5.2 1.4 8.1l0 49.7c32.7-23.1 63.3-44.7 91.9-64.9z"
		]
	};
	faCommentAlt = faMessage;
	faFaceDizzy = {
		prefix: "far",
		iconName: "face-dizzy",
		icon: [
			512,
			512,
			["dizzy"],
			"f567",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zM134.1 153.9l25.9 25.9 25.9-25.9c7.8-7.8 20.5-7.8 28.3 0s7.8 20.5 0 28.3l-25.9 25.9 25.9 25.9c7.8 7.8 7.8 20.5 0 28.3s-20.5 7.8-28.3 0l-25.9-25.9-25.9 25.9c-7.8 7.8-20.5 7.8-28.3 0s-7.8-20.5 0-28.3l25.9-25.9-25.9-25.9c-7.8-7.8-7.8-20.5 0-28.3s20.5-7.8 28.3 0zm192 0l25.9 25.9 25.9-25.9c7.8-7.8 20.5-7.8 28.3 0s7.8 20.5 0 28.3l-25.9 25.9 25.9 25.9c7.8 7.8 7.8 20.5 0 28.3s-20.5 7.8-28.3 0l-25.9-25.9-25.9 25.9c-7.8 7.8-20.5 7.8-28.3 0s-7.8-20.5 0-28.3l25.9-25.9-25.9-25.9c-7.8-7.8-7.8-20.5 0-28.3s20.5-7.8 28.3 0zM256 288a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"
		]
	};
	faDizzy = faFaceDizzy;
	faCalendarDays = {
		prefix: "far",
		iconName: "calendar-days",
		icon: [
			448,
			512,
			["calendar-alt"],
			"f073",
			"M120 0c13.3 0 24 10.7 24 24l0 40 160 0 0-40c0-13.3 10.7-24 24-24s24 10.7 24 24l0 40 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-40c0-13.3 10.7-24 24-24zM384 432c8.8 0 16-7.2 16-16l0-64-88 0 0 80 72 0zm16-128l0-80-88 0 0 80 88 0zm-136 0l0-80-80 0 0 80 80 0zm-128 0l0-80-88 0 0 80 88 0zM48 352l0 64c0 8.8 7.2 16 16 16l72 0 0-80-88 0zm136 0l0 80 80 0 0-80-80 0zM120 112l-56 0c-8.8 0-16 7.2-16 16l0 48 352 0 0-48c0-8.8-7.2-16-16-16l-264 0z"
		]
	};
	faCalendarAlt = faCalendarDays;
	faHandPointUp = {
		prefix: "far",
		iconName: "hand-point-up",
		icon: [
			384,
			512,
			[9757],
			"f0a6",
			"M64 64l0 177.6c5.2-1 10.5-1.6 16-1.6l16 0 0-176c0-8.8-7.2-16-16-16S64 55.2 64 64zM80 288c-17.7 0-32 14.3-32 32l0 24c0 66.3 53.7 120 120 120l48 0c52.5 0 97.1-33.7 113.4-80.7-3.1 .5-6.2 .7-9.4 .7-20 0-37.9-9.2-49.7-23.6-9 4.9-19.4 7.6-30.3 7.6-15.1 0-29-5.3-40-14-11 8.8-24.9 14-40 14l-40 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l40 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-80 0zM0 320l0 0c0-18 6-34.6 16-48L16 64C16 28.7 44.7 0 80 0s64 28.7 64 64l0 82c5.1-1.3 10.5-2 16-2 25.3 0 47.2 14.7 57.6 36 7-2.6 14.5-4 22.4-4 20 0 37.9 9.2 49.7 23.6 9-4.9 19.4-7.6 30.3-7.6 35.3 0 64 28.7 64 64l0 88c0 92.8-75.2 168-168 168l-48 0C75.2 512 0 436.8 0 344l0-24zm336-64c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 64c0 8.8 7.2 16 16 16s16-7.2 16-16l0-64zM160 240c5.5 0 10.9 .7 16 2l0-34c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 32 16 0zm64 24l0 40c0 8.8 7.2 16 16 16s16-7.2 16-16l0-64c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 24z"
		]
	};
	faHandLizard = {
		prefix: "far",
		iconName: "hand-lizard",
		icon: [
			512,
			512,
			[],
			"f258",
			"M72 112c-13.3 0-24 10.7-24 24s10.7 24 24 24l168 0c35.3 0 64 28.7 64 64s-28.7 64-64 64l-104 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l152 0c4.5 0 8.9 1.3 12.7 3.6l64 40c7 4.4 11.3 12.1 11.3 20.4l0 24c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-10.7-46.9-29.3-145.1 0c-39.8 0-72-32.2-72-72s32.2-72 72-72l104 0c8.8 0 16-7.2 16-16s-7.2-16-16-16L72 208c-39.8 0-72-32.2-72-72S32.2 64 72 64l209.6 0c46.7 0 90.9 21.5 119.7 58.3l78.4 100.1c20.9 26.7 32.3 59.7 32.3 93.7L512 424c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-107.9c0-23.2-7.8-45.8-22.1-64.1L363.5 151.9c-19.7-25.2-49.9-39.9-81.9-39.9L72 112z"
		]
	};
	faSquareFull = {
		prefix: "far",
		iconName: "square-full",
		icon: [
			512,
			512,
			[
				128997,
				128998,
				128999,
				129e3,
				129001,
				129002,
				129003,
				11035,
				11036
			],
			"f45c",
			"M448 48c8.8 0 16 7.2 16 16l0 384c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16L48 64c0-8.8 7.2-16 16-16l384 0zM64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-384c0-35.3-28.7-64-64-64L64 0z"
		]
	};
	faCirclePause = {
		prefix: "far",
		iconName: "circle-pause",
		icon: [
			512,
			512,
			[62092, "pause-circle"],
			"f28b",
			"M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM224 184c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 144c0 13.3 10.7 24 24 24s24-10.7 24-24l0-144zm112 0c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 144c0 13.3 10.7 24 24 24s24-10.7 24-24l0-144z"
		]
	};
	faPauseCircle = faCirclePause;
	faHardDrive = {
		prefix: "far",
		iconName: "hard-drive",
		icon: [
			448,
			512,
			[128436, "hdd"],
			"f0a0",
			"M64 80c-8.8 0-16 7.2-16 16l0 162c5.1-1.3 10.5-2 16-2l320 0c5.5 0 10.9 .7 16 2l0-162c0-8.8-7.2-16-16-16L64 80zM48 320l0 96c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-96c0-8.8-7.2-16-16-16L64 304c-8.8 0-16 7.2-16 16zM0 320L0 96C0 60.7 28.7 32 64 32l320 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64l0-96zm216 48a24 24 0 1 1 48 0 24 24 0 1 1 -48 0zm120-24a24 24 0 1 1 0 48 24 24 0 1 1 0-48z"
		]
	};
	faHdd = faHardDrive;
	faFileZipper = {
		prefix: "far",
		iconName: "file-zipper",
		icon: [
			384,
			512,
			["file-archive"],
			"f1c6",
			"M64 48l112 0 0 88c0 39.8 32.2 72 72 72l88 0 0 240c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16L48 64c0-8.8 7.2-16 16-16zM224 67.9l92.1 92.1-68.1 0c-13.3 0-24-10.7-24-24l0-68.1zM64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-261.5c0-17-6.7-33.3-18.7-45.3L242.7 18.7C230.7 6.7 214.5 0 197.5 0L64 0zM80 104c0 13.3 10.7 24 24 24l16 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-16 0c-13.3 0-24 10.7-24 24zm0 80c0 13.3 10.7 24 24 24l32 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-32 0c-13.3 0-24 10.7-24 24zm64 56l-32 0c-17.7 0-32 14.3-32 32l0 48c0 26.5 21.5 48 48 48s48-21.5 48-48l0-48c0-17.7-14.3-32-32-32zm-16 64a16 16 0 1 1 0 32 16 16 0 1 1 0-32z"
		]
	};
	faFileArchive = faFileZipper;
	faFloppyDisk = {
		prefix: "far",
		iconName: "floppy-disk",
		icon: [
			448,
			512,
			[
				128190,
				128426,
				"save"
			],
			"f0c7",
			"M64 80c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-242.7c0-4.2-1.7-8.3-4.7-11.3L320 86.6 320 176c0 17.7-14.3 32-32 32l-160 0c-17.7 0-32-14.3-32-32l0-96-32 0zm80 0l0 80 128 0 0-80-128 0zM0 96C0 60.7 28.7 32 64 32l242.7 0c17 0 33.3 6.7 45.3 18.7L429.3 128c12 12 18.7 28.3 18.7 45.3L448 416c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zM160 320a64 64 0 1 1 128 0 64 64 0 1 1 -128 0z"
		]
	};
	faSave = faFloppyDisk;
	faFaceGrinTongueSquint = {
		prefix: "far",
		iconName: "face-grin-tongue-squint",
		icon: [
			512,
			512,
			[128541, "grin-tongue-squint"],
			"f58a",
			"M464 256c0-114.9-93.1-208-208-208S48 141.1 48 256c0 75.9 40.7 142.4 101.5 178.7-3.6-10.9-5.5-22.6-5.5-34.7l0-37.5c-10.2-12.6-18.3-26.9-23.8-42.4-4.1-11.6 7.8-21.4 19.6-17.8 34.7 10.6 74.2 16.5 116.1 16.5 42 0 81.5-6 116.3-16.6 11.8-3.6 23.7 6.1 19.6 17.8-5.5 15.6-13.6 29.9-23.8 42.5l0 37.5c0 12.1-1.9 23.8-5.5 34.7 60.8-36.3 101.5-102.7 101.5-178.7zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm125.8-75.7c-6.2-5.2-7.6-14.3-3.1-21.1s13.3-9.2 20.6-5.5l79.6 40c5.4 2.7 8.8 8.2 8.8 14.3s-3.4 11.6-8.8 14.3l-79.6 40c-7.3 3.6-16.1 1.3-20.6-5.5s-3.1-15.9 3.1-21.1L159 208 125.8 180.3zm263.6-21.1c4.5 6.8 3.1 15.9-3.1 21.1L353 208 386.2 235.7c6.2 5.2 7.6 14.3 3.1 21.1s-13.3 9.2-20.6 5.5l-79.6-40c-5.4-2.7-8.8-8.2-8.8-14.3s3.4-11.6 8.8-14.3l79.6-40c7.3-3.6 16.1-1.3 20.6 5.5zM320 416l0-37.4c0-14.7-11.9-26.6-26.6-26.6l-2 0c-11.3 0-21.1 7.9-23.6 18.9-2.8 12.6-20.8 12.6-23.6 0-2.5-11.1-12.3-18.9-23.6-18.9l-2 0c-14.7 0-26.6 11.9-26.6 26.6l0 37.4c0 35.3 28.7 64 64 64s64-28.7 64-64z"
		]
	};
	faGrinTongueSquint = faFaceGrinTongueSquint;
	faCamera = {
		prefix: "far",
		iconName: "camera",
		icon: [
			512,
			512,
			[62258, "camera-alt"],
			"f030",
			"M193.1 32c-18.7 0-36.2 9.4-46.6 24.9L120.5 96 64 96C28.7 96 0 124.7 0 160L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64l-56.5 0-26-39.1C355.1 41.4 337.6 32 318.9 32L193.1 32zm-6.7 51.6c1.5-2.2 4-3.6 6.7-3.6l125.7 0c2.7 0 5.2 1.3 6.7 3.6l33.2 49.8c4.5 6.7 11.9 10.7 20 10.7l69.3 0c8.8 0 16 7.2 16 16l0 256c0 8.8-7.2 16-16 16L64 432c-8.8 0-16-7.2-16-16l0-256c0-8.8 7.2-16 16-16l69.3 0c8 0 15.5-4 20-10.7l33.2-49.8zM256 384a112 112 0 1 0 0-224 112 112 0 1 0 0 224zM192 272a64 64 0 1 1 128 0 64 64 0 1 1 -128 0z"
		]
	};
	faCameraAlt = faCamera;
	faFaceGrinStars = {
		prefix: "far",
		iconName: "face-grin-stars",
		icon: [
			512,
			512,
			[129321, "grin-stars"],
			"f587",
			"M0 256c0-29.6 5-57.9 14.2-84.4l17.3 16.9-4.6 27c-4.2 24.4 5.6 46.2 22 59.9 9.8 105.8 98.8 188.7 207.1 188.7s197.4-82.8 207.1-188.6c16.4-13.7 26.1-35.4 22-59.9l-4.6-27 17.3-16.9c9.2 26.4 14.2 54.8 14.2 84.4 0 141.4-114.6 256-256 256S0 397.4 0 256zM256 48c-15.2 0-30 1.6-44.3 4.7L201.4 31.8C197 23 191.1 15.8 184.2 10.2 207 3.6 231.1 0 256 0s49 3.6 71.8 10.2C320.9 15.8 315 23 310.6 31.8L300.3 52.7C286 49.6 271.2 48 256 48zM372.2 302.3c11.8-3.6 23.7 6.1 19.6 17.8-19.8 55.9-73.1 96-135.8 96-62.7 0-116-40-135.8-95.9-4.1-11.6 7.8-21.4 19.6-17.8 34.7 10.6 74.2 16.5 116.1 16.5 42 0 81.5-6 116.3-16.6zM353.7 53.1c5.9-11.9 22.8-11.9 28.7 0l23.3 47.2 52 7.6c13.1 1.9 18.4 18 8.9 27.3l-37.7 36.7 8.9 51.8c2.2 13.1-11.5 23-23.2 16.9L368 216 321.5 240.5c-11.7 6.2-25.5-3.8-23.2-16.9l8.9-51.8-37.7-36.7c-9.5-9.3-4.3-25.4 8.9-27.3l52-7.6 23.3-47.2zm-195.3 0l23.3 47.2 52 7.6c13.1 1.9 18.4 18 8.9 27.3l-37.7 36.7 8.9 51.8c2.2 13.1-11.5 23-23.2 16.9L144 216 97.5 240.5c-11.7 6.2-25.5-3.8-23.2-16.9l8.9-51.8-37.7-36.7c-9.5-9.3-4.3-25.4 8.9-27.3l52-7.6 23.3-47.2c5.9-11.9 22.8-11.9 28.7 0z"
		]
	};
	faGrinStars = faFaceGrinStars;
	faEye = {
		prefix: "far",
		iconName: "eye",
		icon: [
			576,
			512,
			[128065],
			"f06e",
			"M288 80C222.8 80 169.2 109.6 128.1 147.7 89.6 183.5 63 226 49.4 256 63 286 89.6 328.5 128.1 364.3 169.2 402.4 222.8 432 288 432s118.8-29.6 159.9-67.7C486.4 328.5 513 286 526.6 256 513 226 486.4 183.5 447.9 147.7 406.8 109.6 353.2 80 288 80zM95.4 112.6C142.5 68.8 207.2 32 288 32s145.5 36.8 192.6 80.6c46.8 43.5 78.1 95.4 93 131.1 3.3 7.9 3.3 16.7 0 24.6-14.9 35.7-46.2 87.7-93 131.1-47.1 43.7-111.8 80.6-192.6 80.6S142.5 443.2 95.4 399.4c-46.8-43.5-78.1-95.4-93-131.1-3.3-7.9-3.3-16.7 0-24.6 14.9-35.7 46.2-87.7 93-131.1zM288 336c44.2 0 80-35.8 80-80 0-29.6-16.1-55.5-40-69.3-1.4 59.7-49.6 107.9-109.3 109.3 13.8 23.9 39.7 40 69.3 40zm-79.6-88.4c2.5 .3 5 .4 7.6 .4 35.3 0 64-28.7 64-64 0-2.6-.2-5.1-.4-7.6-37.4 3.9-67.2 33.7-71.1 71.1zm45.6-115c10.8-3 22.2-4.5 33.9-4.5 8.8 0 17.5 .9 25.8 2.6 .3 .1 .5 .1 .8 .2 57.9 12.2 101.4 63.7 101.4 125.2 0 70.7-57.3 128-128 128-61.6 0-113-43.5-125.2-101.4-1.8-8.6-2.8-17.5-2.8-26.6 0-11 1.4-21.8 4-32 .2-.7 .3-1.3 .5-1.9 11.9-43.4 46.1-77.6 89.5-89.5z"
		]
	};
	faFaceSadTear = {
		prefix: "far",
		iconName: "face-sad-tear",
		icon: [
			512,
			512,
			[128546, "sad-tear"],
			"f5b4",
			"M464 256c0-114.9-93.1-208-208-208S48 141.1 48 256c0 41.8 12.3 80.7 33.6 113.3 8.2 44.7 47.3 78.6 94.3 78.7 24.7 10.3 51.7 16 80.1 16 114.9 0 208-93.1 208-208zM288 352c-5.5 0-10.9 .6-16 1.8 0-.6 0-1.2 0-1.8 0-16.2-4-31.5-11.1-44.9 8.7-2 17.8-3.1 27.1-3.1 40.2 0 75.7 19.8 97.5 50 7.7 10.8 5.3 25.8-5.5 33.5s-25.8 5.3-33.5-5.5c-13.1-18.2-34.4-30-58.5-30zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm176-80a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM185.4 276.8c6.5 7.8 12.6 16.1 18.3 24.6 9 13.4 20.3 30.2 20.3 47.4 0 28.3-21.5 51.2-48 51.2s-48-22.9-48-51.2c0-17.2 11.2-34 20.3-47.4 5.7-8.5 11.9-16.7 18.3-24.6 2.4-2.9 5.7-4.8 9.4-4.8s7 1.9 9.4 4.8z"
		]
	};
	faSadTear = faFaceSadTear;
	faShareFromSquare = {
		prefix: "far",
		iconName: "share-from-square",
		icon: [
			576,
			512,
			[61509, "share-square"],
			"f14d",
			"M425.5 7c-6.9-6.9-17.2-8.9-26.2-5.2S384.5 14.3 384.5 24l0 56-48 0c-88.4 0-160 71.6-160 160 0 46.7 20.7 80.4 43.6 103.4 8.1 8.2 16.5 14.9 24.3 20.4 9.2 6.5 21.7 5.7 30.1-1.9s10.2-20 4.5-29.8c-3.6-6.3-6.5-14.9-6.5-26.7 0-36.2 29.3-65.5 65.5-65.5l46.5 0 0 56c0 9.7 5.8 18.5 14.8 22.2s19.3 1.7 26.2-5.2l136-136c9.4-9.4 9.4-24.6 0-33.9L425.5 7zm7 97l0-22.1 78.1 78.1-78.1 78.1 0-22.1c0-13.3-10.7-24-24-24L338 192c-50.9 0-93.9 33.5-108.3 79.6-3.3-9.4-5.2-19.8-5.2-31.6 0-61.9 50.1-112 112-112l72 0c13.3 0 24-10.7 24-24zm-320-8c-44.2 0-80 35.8-80 80l0 256c0 44.2 35.8 80 80 80l256 0c44.2 0 80-35.8 80-80l0-24c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 24c0 17.7-14.3 32-32 32l-256 0c-17.7 0-32-14.3-32-32l0-256c0-17.7 14.3-32 32-32l24 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-24 0z"
		]
	};
	faShareSquare = faShareFromSquare;
	faNoteSticky = {
		prefix: "far",
		iconName: "note-sticky",
		icon: [
			448,
			512,
			[62026, "sticky-note"],
			"f249",
			"M240 432L64 432c-8.8 0-16-7.2-16-16L48 96c0-8.8 7.2-16 16-16l320 0c8.8 0 16 7.2 16 16l0 176-88 0c-39.8 0-72 32.2-72 72l0 88zM380.1 320L288 412.1 288 344c0-13.3 10.7-24 24-24l68.1 0zM0 416c0 35.3 28.7 64 64 64l197.5 0c17 0 33.3-6.7 45.3-18.7L429.3 338.7c12-12 18.7-28.3 18.7-45.3L448 96c0-35.3-28.7-64-64-64L64 32C28.7 32 0 60.7 0 96L0 416z"
		]
	};
	faStickyNote = faNoteSticky;
	faHandBackFist = {
		prefix: "far",
		iconName: "hand-back-fist",
		icon: [
			384,
			512,
			["hand-rock"],
			"f255",
			"M96 400c-17.7 0-32 14.3-32 32l0 48c0 17.7 14.3 32 32 32l224 0c17.7 0 32-14.3 32-32l0-48c0-17.7-14.3-32-32-32L96 400zM73.2 352l64.6 0-79.5-88.3C51.7 256.3 48 246.8 48 236.9L48 204c0-16.1 11.9-29.5 27.4-31.7 11.8-1.7 20.6-11.8 20.6-23.8L96 72c0-13.3 10.7-24 24-24 7.2 0 13.6 3.1 18 8.1 4.6 5.2 11.1 8.1 18 8.1s13.4-3 18-8.1c4.4-5 10.8-8.1 18-8.1 8.5 0 15.9 4.4 20.2 11.1 6.9 10.7 20.9 14.2 32 8 3.5-1.9 7.4-3.1 11.8-3.1 10.6 0 19.7 6.9 22.8 16.6 3.8 11.7 15.9 18.7 28 16 1.7-.4 3.4-.6 5.2-.6 13.3 0 24 10.7 24 24l0 92.2c0 14.4-3.5 28.5-10.2 41.2l-52.2 98.6 54.3 0 40.3-76.2c10.4-19.6 15.8-41.5 15.8-63.6l0-92.2c0-38.4-30.1-69.8-68.1-71.9-12.9-19.3-34.9-32.1-59.9-32.1-5.7 0-11.2 .7-16.5 1.9-12.7-11.1-29.3-17.9-47.5-17.9-13.1 0-25.4 3.5-36 9.6-10.6-6.1-22.9-9.6-36-9.6-39.8 0-72 32.2-72 72l0 58.7C19.7 143 0 171.2 0 204l0 32.9c0 21.7 8 42.7 22.6 58.9L73.2 352z"
		]
	};
	faHandRock = faHandBackFist;
	faChessQueen = {
		prefix: "far",
		iconName: "chess-queen",
		icon: [
			512,
			512,
			[9819],
			"f445",
			"M325.3 90.8c9.1-4.8 20.6-3.3 28.2 4.3l39.8 39.8 3.7 3.3c9.1 7.1 20.9 10 32.4 7.7l46.4-9.3 3.5-.4c8-.4 15.8 3.2 20.6 9.8 5.5 7.6 6.1 17.6 1.6 25.8l-112.6 202.6 51.5 70.9 1.8 2.7c4 6.6 6.2 14.2 6.2 22 0 23.3-18.9 42.1-42.1 42.1l-299.8 0c-21.8 0-39.8-16.6-41.9-37.8l-.2-4.3 .1-3.3c.6-7.7 3.4-15.1 7.9-21.4l51.5-70.9-112.5-202.6c-4.5-8.2-3.9-18.3 1.6-25.8s14.9-11.2 24.1-9.4l46.4 9.3c13.1 2.6 26.7-1.5 36.1-10.9L159.5 95 163 92.2c8.6-5.8 20.1-5.6 28.5 1.1l40 32 2.8 2.1c14.4 9.6 33.5 8.9 47.2-2.1l40-32 3.8-2.5zM164.7 400l-46.6 64 276.7 0-46.6-64-183.6 0zM311.5 162.8c-30.1 24.1-72.1 25.6-103.8 4.5l-6.2-4.5-23.3-18.6-24.6 24.6c-19.8 19.8-47.7 28.9-75.1 24.8l88.1 158.5 179.8 0 88-158.5c-25.7 3.8-51.7-3.9-71.1-21l-4-3.7-24.6-24.6-23.2 18.6zM256.5 72a40 40 0 1 1 0-80 40 40 0 1 1 0 80z"
		]
	};
	faFaceGrinTears = {
		prefix: "far",
		iconName: "face-grin-tears",
		icon: [
			640,
			512,
			[128514, "grin-tears"],
			"f588",
			"M504.1 353C512.9 367.2 525.3 379 539.8 387.2 495.1 462 413.4 512 320 512S144.9 462 100.2 387.2c14.6-8.2 26.9-20 35.8-34.3 34.9 66 104.2 111 184.1 111s149.2-45 184.1-111zm16.4-152.5C496.2 112.6 415.7 48 320 48S143.8 112.6 119.5 200.5c-10.6-4.8-22.7-6.8-35.4-5l-13.4 1.9C97.2 84.3 198.8 0 320 0S542.8 84.3 569.3 197.4l-13.4-1.9c-12.7-1.8-24.8 .2-35.4 5zM455.8 320c-19.8 55.9-73.1 96-135.8 96-62.7 0-116-40-135.8-95.9-4.1-11.6 7.8-21.4 19.6-17.8 34.7 10.6 74.2 16.5 116.1 16.5 42 0 81.5-6 116.3-16.6 11.8-3.6 23.7 6.1 19.6 17.8zM212 208l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-37.6 30.4-68 68-68s68 30.4 68 68l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-15.5-12.5-28-28-28s-28 12.5-28 28zm188-28c-15.5 0-28 12.5-28 28l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-37.6 30.4-68 68-68s68 30.4 68 68l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-15.5-12.5-28-28-28zM640 300.6c0 28.4-23 51.4-51.4 51.4-25.6 0-47.3-18.8-50.9-44.1L531 261.1c-1.5-10.6 7.5-19.6 18.1-18.1l46.7 6.7c25.3 3.6 44.1 25.3 44.1 50.9zm-640 0c0-25.6 18.8-47.3 44.1-50.9L90.9 243c10.6-1.5 19.6 7.5 18.1 18.1l-6.7 46.7C98.7 333.2 77 352 51.4 352 23 352 0 329 0 300.6z"
		]
	};
	faGrinTears = faFaceGrinTears;
	faPenToSquare = {
		prefix: "far",
		iconName: "pen-to-square",
		icon: [
			512,
			512,
			["edit"],
			"f044",
			"M441 58.9L453.1 71c9.4 9.4 9.4 24.6 0 33.9L424 134.1 377.9 88 407 58.9c9.4-9.4 24.6-9.4 33.9 0zM209.8 256.2L344 121.9 390.1 168 255.8 302.2c-2.9 2.9-6.5 5-10.4 6.1l-58.5 16.7 16.7-58.5c1.1-3.9 3.2-7.5 6.1-10.4zM373.1 25L175.8 222.2c-8.7 8.7-15 19.4-18.3 31.1l-28.6 100c-2.4 8.4-.1 17.4 6.1 23.6s15.2 8.5 23.6 6.1l100-28.6c11.8-3.4 22.5-9.7 31.1-18.3L487 138.9c28.1-28.1 28.1-73.7 0-101.8L474.9 25C446.8-3.1 401.2-3.1 373.1 25zM88 64C39.4 64 0 103.4 0 152L0 424c0 48.6 39.4 88 88 88l272 0c48.6 0 88-39.4 88-88l0-112c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 112c0 22.1-17.9 40-40 40L88 464c-22.1 0-40-17.9-40-40l0-272c0-22.1 17.9-40 40-40l112 0c13.3 0 24-10.7 24-24s-10.7-24-24-24L88 64z"
		]
	};
	faEdit = faPenToSquare;
	faFaceGrinBeamSweat = {
		prefix: "far",
		iconName: "face-grin-beam-sweat",
		icon: [
			576,
			512,
			[128517, "grin-beam-sweat"],
			"f583",
			"M530.2 15.9c-8.8-10.7-18.5-20.9-29-30-3-2.6-7.4-2.6-10.4 0-10.5 9.1-20.1 19.3-29 30-14.7 17.8-29.8 40.1-29.8 64.1 0 36.4 27.6 64 64 64s64-27.6 64-64c0-24-15.2-46.3-29.8-64.1zm-132 8.9C364.8 8.9 327.4 0 288 0 146.6 0 32 114.6 32 256S146.6 512 288 512 544 397.4 544 256c0-24.4-3.4-48-9.8-70.4-11.9 4.2-24.7 6.4-38.2 6.4-3.4 0-6.8-.1-10.2-.4 6.6 20.3 10.2 41.9 10.2 64.4 0 114.9-93.1 208-208 208S80 370.9 80 256 173.1 48 288 48c34.8 0 67.5 8.5 96.3 23.6 1.4-17.4 6.9-33.1 13.8-46.8zM423.8 320c4.1-11.6-7.8-21.4-19.6-17.8-34.8 10.6-74.3 16.6-116.3 16.6-41.9 0-81.4-6-116.1-16.5-11.8-3.6-23.7 6.1-19.6 17.8 19.8 55.9 73.1 95.9 135.8 95.9 62.7 0 116-40.1 135.8-96zM180 208c0-15.5 12.5-28 28-28s28 12.5 28 28l0 8c0 11 9 20 20 20s20-9 20-20l0-8c0-37.6-30.4-68-68-68s-68 30.4-68 68l0 8c0 11 9 20 20 20s20-9 20-20l0-8zm188-28c15.5 0 28 12.5 28 28l0 8c0 11 9 20 20 20s20-9 20-20l0-8c0-37.6-30.4-68-68-68s-68 30.4-68 68l0 8c0 11 9 20 20 20s20-9 20-20l0-8c0-15.5 12.5-28 28-28z"
		]
	};
	faGrinBeamSweat = faFaceGrinBeamSweat;
	faClock = {
		prefix: "far",
		iconName: "clock",
		icon: [
			512,
			512,
			[128339, "clock-four"],
			"f017",
			"M464 256a208 208 0 1 1 -416 0 208 208 0 1 1 416 0zM0 256a256 256 0 1 0 512 0 256 256 0 1 0 -512 0zM232 120l0 136c0 8 4 15.5 10.7 20l96 64c11 7.4 25.9 4.4 33.3-6.7s4.4-25.9-6.7-33.3L280 243.2 280 120c0-13.3-10.7-24-24-24s-24 10.7-24 24z"
		]
	};
	faClockFour = faClock;
	faFaceLaughWink = {
		prefix: "far",
		iconName: "face-laugh-wink",
		icon: [
			512,
			512,
			["laugh-wink"],
			"f59c",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm118.3 58.2c-4.2-13.7 7.1-26.2 21.4-26.2l232.6 0c14.3 0 25.6 12.5 21.4 26.2-18 58.9-72.9 101.8-137.7 101.8S136.3 373.1 118.3 314.2zM144 192a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm164 8c0 11-9 20-20 20s-20-9-20-20c0-33.1 26.9-60 60-60l16 0c33.1 0 60 26.9 60 60 0 11-9 20-20 20s-20-9-20-20-9-20-20-20l-16 0c-11 0-20 9-20 20z"
		]
	};
	faLaughWink = faFaceLaughWink;
	faPaperPlane = {
		prefix: "far",
		iconName: "paper-plane",
		icon: [
			576,
			512,
			[61913],
			"f1d8",
			"M290.5 287.7L491.4 86.9 359 456.3 290.5 287.7zM457.4 53L256.6 253.8 88 185.3 457.4 53zM38.1 216.8l205.8 83.6 83.6 205.8c5.3 13.1 18.1 21.7 32.3 21.7 14.7 0 27.8-9.2 32.8-23.1L570.6 8c3.5-9.8 1-20.6-6.3-28s-18.2-9.8-28-6.3L39.4 151.7c-13.9 5-23.1 18.1-23.1 32.8 0 14.2 8.6 27 21.7 32.3z"
		]
	};
	faHeart = {
		prefix: "far",
		iconName: "heart",
		icon: [
			512,
			512,
			[
				128153,
				128154,
				128155,
				128156,
				128420,
				129293,
				129294,
				129505,
				9829,
				10084,
				61578
			],
			"f004",
			"M378.9 80c-27.3 0-53 13.1-69 35.2l-34.4 47.6c-4.5 6.2-11.7 9.9-19.4 9.9s-14.9-3.7-19.4-9.9l-34.4-47.6c-16-22.1-41.7-35.2-69-35.2-47 0-85.1 38.1-85.1 85.1 0 49.9 32 98.4 68.1 142.3 41.1 50 91.4 94 125.9 120.3 3.2 2.4 7.9 4.2 14 4.2s10.8-1.8 14-4.2c34.5-26.3 84.8-70.4 125.9-120.3 36.2-43.9 68.1-92.4 68.1-142.3 0-47-38.1-85.1-85.1-85.1zM271 87.1c25-34.6 65.2-55.1 107.9-55.1 73.5 0 133.1 59.6 133.1 133.1 0 68.6-42.9 128.9-79.1 172.8-44.1 53.6-97.3 100.1-133.8 127.9-12.3 9.4-27.5 14.1-43.1 14.1s-30.8-4.7-43.1-14.1C176.4 438 123.2 391.5 79.1 338 42.9 294.1 0 233.7 0 165.1 0 91.6 59.6 32 133.1 32 175.8 32 216 52.5 241 87.1l15 20.7 15-20.7z"
		]
	};
	faFontAwesome = {
		prefix: "far",
		iconName: "font-awesome",
		icon: [
			512,
			512,
			[
				62501,
				62694,
				"font-awesome-flag",
				"font-awesome-logo-full"
			],
			"f2b4",
			"M91.7 96C106.3 86.8 116 70.5 116 52 116 23.3 92.7 0 64 0S12 23.3 12 52c0 16.7 7.8 31.5 20 41l0 419 48 0 0-64 389.6 0c14.6 0 26.4-11.8 26.4-26.4 0-3.7-.8-7.3-2.3-10.7L432 272 493.7 133.1c1.5-3.4 2.3-7 2.3-10.7 0-14.6-11.8-26.4-26.4-26.4L91.7 96zM80 400l0-256 356.4 0-48.2 108.5c-5.5 12.4-5.5 26.6 0 39L436.4 400 80 400z"
		]
	};
	faFontAwesomeFlag = faFontAwesome;
	faFontAwesomeLogoFull = faFontAwesome;
	faClone = {
		prefix: "far",
		iconName: "clone",
		icon: [
			512,
			512,
			[],
			"f24d",
			"M288 464L64 464c-8.8 0-16-7.2-16-16l0-224c0-8.8 7.2-16 16-16l48 0 0-48-48 0c-35.3 0-64 28.7-64 64L0 448c0 35.3 28.7 64 64 64l224 0c35.3 0 64-28.7 64-64l0-48-48 0 0 48c0 8.8-7.2 16-16 16zM224 304c-8.8 0-16-7.2-16-16l0-224c0-8.8 7.2-16 16-16l224 0c8.8 0 16 7.2 16 16l0 224c0 8.8-7.2 16-16 16l-224 0zm-64-16c0 35.3 28.7 64 64 64l224 0c35.3 0 64-28.7 64-64l0-224c0-35.3-28.7-64-64-64L224 0c-35.3 0-64 28.7-64 64l0 224z"
		]
	};
	faFolderOpen = {
		prefix: "far",
		iconName: "folder-open",
		icon: [
			576,
			512,
			[
				128194,
				128449,
				61717
			],
			"f07c",
			"M97.5 400l50-160 379.4 0-50 160-379.4 0zm190.7 48L477 448c21 0 39.6-13.6 45.8-33.7l50-160c9.7-30.9-13.4-62.3-45.8-62.3l-379.4 0c-21 0-39.6 13.6-45.8 33.7L80.2 294.4 80.2 96c0-8.8 7.2-16 16-16l138.7 0c3.5 0 6.8 1.1 9.6 3.2L282.9 112c13.8 10.4 30.7 16 48 16l117.3 0c8.8 0 16 7.2 16 16l48 0c0-35.3-28.7-64-64-64L330.9 80c-6.9 0-13.7-2.2-19.2-6.4L273.3 44.8C262.2 36.5 248.8 32 234.9 32L96.2 32c-35.3 0-64 28.7-64 64l0 288c0 35.3 28.7 64 64 64l192 0z"
		]
	};
	faWindowMinimize = {
		prefix: "far",
		iconName: "window-minimize",
		icon: [
			512,
			512,
			[128469],
			"f2d1",
			"M0 424c0-13.3 10.7-24 24-24l464 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L24 448c-13.3 0-24-10.7-24-24z"
		]
	};
	faStarHalf = {
		prefix: "far",
		iconName: "star-half",
		icon: [
			576,
			512,
			[61731],
			"f089",
			"M285.7-15.8c10.8 2.6 18.4 12.2 18.4 23.3l0 387.1c0 9-5.1 17.3-13.1 21.4L143.8 491c-8 4.1-17.7 3.3-25-2s-11-14.2-9.6-23.2L134.4 305.9 20 191.4c-6.4-6.4-8.6-15.8-5.8-24.4s10.1-14.9 19.1-16.3L193.1 125.3 258.8-3.3c5-9.9 16.2-15 27-12.4zM256.1 107.4L230.3 158c-3.5 6.8-10 11.6-17.6 12.8l-125.5 20 89.8 89.9c5.4 5.4 7.9 13.1 6.7 20.7l-19.8 125.5 92.2-46.9 0-272.6z"
		]
	};
	faAlarmClock = {
		prefix: "far",
		iconName: "alarm-clock",
		icon: [
			512,
			512,
			[9200],
			"f34e",
			"M402.6 50.2c-5.4 1.7-11.3 1.8-16.2-.9-5.8-3.2-11.8-6.2-17.8-8.9-10.4-4.7-13.7-18.3-4.1-24.6 15-9.9 33-15.7 52.3-15.7 52.6 0 95.2 42.6 95.2 95.2 0 13.2-2.7 25.8-7.6 37.3-4.5 10.5-18.4 9.8-24.9 .4-3.8-5.5-7.8-10.8-12-16-3.5-4.4-4.5-10.2-3.8-15.8 .2-1.9 .4-3.9 .4-5.9 0-26.1-21.2-47.2-47.2-47.2-4.9 0-9.7 .8-14.2 2.2zM32.5 132.9c-6.5 9.4-20.5 10.1-24.9-.4-4.9-11.5-7.6-24.1-7.6-37.3 0-52.6 42.6-95.2 95.2-95.2 19.3 0 37.3 5.8 52.3 15.7 9.6 6.3 6.3 19.9-4.1 24.6-6.1 2.8-12 5.7-17.8 8.9-4.9 2.7-10.9 2.6-16.2 .9-4.5-1.4-9.2-2.2-14.2-2.2-26.1 0-47.2 21.2-47.2 47.2 0 2 .1 4 .4 5.9 .7 5.6-.3 11.4-3.8 15.8-4.2 5.2-8.2 10.5-12 16zM432 288a176 176 0 1 0 -352 0 176 176 0 1 0 352 0zM396.5 462.5C358.1 493.4 309.2 512 256 512s-102.1-18.6-140.5-49.5L73 505c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l42.5-42.5C50.6 390.1 32 341.2 32 288 32 164.3 132.3 64 256 64S480 164.3 480 288c0 53.2-18.6 102.1-49.5 140.5L473 471c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-42.5-42.5zM280 184l0 94.1 41 41c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-48-48c-4.5-4.5-7-10.6-7-17l0-104c0-13.3 10.7-24 24-24s24 10.7 24 24z"
		]
	};
	faNewspaper = {
		prefix: "far",
		iconName: "newspaper",
		icon: [
			512,
			512,
			[128240],
			"f1ea",
			"M168 80c-13.3 0-24 10.7-24 24l0 304c0 8.4-1.4 16.5-4.1 24L440 432c13.3 0 24-10.7 24-24l0-304c0-13.3-10.7-24-24-24L168 80zM72 480c-39.8 0-72-32.2-72-72L0 112C0 98.7 10.7 88 24 88s24 10.7 24 24l0 296c0 13.3 10.7 24 24 24s24-10.7 24-24l0-304c0-39.8 32.2-72 72-72l272 0c39.8 0 72 32.2 72 72l0 304c0 39.8-32.2 72-72 72L72 480zM192 152c0-13.3 10.7-24 24-24l48 0c13.3 0 24 10.7 24 24l0 48c0 13.3-10.7 24-24 24l-48 0c-13.3 0-24-10.7-24-24l0-48zm152 24l48 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-48 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zM216 256l176 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-176 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm0 80l176 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-176 0c-13.3 0-24-10.7-24-24s10.7-24 24-24z"
		]
	};
	faHospital = {
		prefix: "far",
		iconName: "hospital",
		icon: [
			576,
			512,
			[
				127973,
				62589,
				"hospital-alt",
				"hospital-wide"
			],
			"f0f8",
			"M176 0c-35.3 0-64 28.7-64 64l0 48-48 0c-35.3 0-64 28.7-64 64L0 448c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-272c0-35.3-28.7-64-64-64l-48 0 0-48c0-35.3-28.7-64-64-64L176 0zM160 64c0-8.8 7.2-16 16-16l224 0c8.8 0 16 7.2 16 16l0 72c0 13.3 10.7 24 24 24l72 0c8.8 0 16 7.2 16 16l0 272c0 8.8-7.2 16-16 16l-176 0 0-80c0-17.7-14.3-32-32-32l-32 0c-17.7 0-32 14.3-32 32l0 80-176 0c-8.8 0-16-7.2-16-16l0-272c0-8.8 7.2-16 16-16l72 0c13.3 0 24-10.7 24-24l0-72zM112 224c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zM96 336l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm320 0l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0c-8.8 0-16 7.2-16 16zm16-112c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16l32 0c8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l-32 0zM264 104l0 32-32 0c-8.8 0-16 7.2-16 16l0 16c0 8.8 7.2 16 16 16l32 0 0 32c0 8.8 7.2 16 16 16l16 0c8.8 0 16-7.2 16-16l0-32 32 0c8.8 0 16-7.2 16-16l0-16c0-8.8-7.2-16-16-16l-32 0 0-32c0-8.8-7.2-16-16-16l-16 0c-8.8 0-16 7.2-16 16z"
		]
	};
	faHospitalAlt = faHospital;
	faHospitalWide = faHospital;
	faCircleStop = {
		prefix: "far",
		iconName: "circle-stop",
		icon: [
			512,
			512,
			[62094, "stop-circle"],
			"f28d",
			"M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM160 192l0 128c0 17.7 14.3 32 32 32l128 0c17.7 0 32-14.3 32-32l0-128c0-17.7-14.3-32-32-32l-128 0c-17.7 0-32 14.3-32 32zm48 112l0-96 96 0 0 96-96 0z"
		]
	};
	faStopCircle = faCircleStop;
	faObjectUngroup = {
		prefix: "far",
		iconName: "object-ungroup",
		icon: [
			640,
			512,
			[],
			"f248",
			"M48.2 66.8c-.1-.8-.2-1.7-.2-2.5l0-.2c0-8.8 7.2-16 16-16 .9 0 1.9 .1 2.8 .2 7.5 1.3 13.2 7.9 13.2 15.8 0 8.8-7.2 16-16 16-7.9 0-14.5-5.7-15.8-13.2zM0 64c0 26.9 16.5 49.9 40 59.3l0 105.3c-23.5 9.5-40 32.5-40 59.3 0 35.3 28.7 64 64 64 26.9 0 49.9-16.5 59.3-40l201.3 0c9.5 23.5 32.5 40 59.3 40 35.3 0 64-28.7 64-64 0-26.9-16.5-49.9-40-59.3l0-105.3c23.5-9.5 40-32.5 40-59.3 0-35.3-28.7-64-64-64-26.9 0-49.9 16.5-59.3 40L123.3 40C113.9 16.5 90.9 0 64 0 28.7 0 0 28.7 0 64zm368 0a16 16 0 1 1 32 0 16 16 0 1 1 -32 0zM324.7 88c6.5 16 19.3 28.9 35.3 35.3l0 105.3c-16 6.5-28.9 19.3-35.3 35.3l-201.3 0c-6.5-16-19.3-28.9-35.3-35.3l0-105.3c16-6.5 28.9-19.3 35.3-35.3l201.3 0zM384 272a16 16 0 1 1 0 32 16 16 0 1 1 0-32zM80 288c0 7.9-5.7 14.5-13.2 15.8-.8 .1-1.7 .2-2.5 .2l-.2 0c-8.8 0-16-7.2-16-16 0-.9 .1-1.9 .2-2.8 1.3-7.5 7.9-13.2 15.8-13.2 8.8 0 16 7.2 16 16zm436.7-40c6.5 16 19.3 28.9 35.3 35.3l0 105.3c-16 6.5-28.9 19.3-35.3 35.3l-201.3 0c-6.5-16-19.3-28.9-35.3-35.3l0-20.7-48 0 0 20.7c-23.5 9.5-40 32.5-40 59.3 0 35.3 28.7 64 64 64 26.9 0 49.9-16.5 59.3-40l201.3 0c9.5 23.5 32.5 40 59.3 40 35.3 0 64-28.7 64-64 0-26.9-16.5-49.9-40-59.3l0-105.3c23.5-9.5 40-32.5 40-59.3 0-35.3-28.7-64-64-64-26.9 0-49.9 16.5-59.3 40l-52.7 0 0 9.6c10.7 10.9 19.1 23.9 24.6 38.4l28 0zm59.3-8a16 16 0 1 1 0-32 16 16 0 1 1 0 32zM271.8 450.7a16 16 0 1 1 -31.5-5.5 16 16 0 1 1 31.5 5.5zm301.5 13c-7.5-1.3-13.2-7.9-13.2-15.8 0-8.8 7.2-16 16-16 7.9 0 14.5 5.7 15.8 13.2l0 .1c.1 .9 .2 1.8 .2 2.7 0 8.8-7.2 16-16 16-.9 0-1.9-.1-2.8-.2z"
		]
	};
	faComment = {
		prefix: "far",
		iconName: "comment",
		icon: [
			512,
			512,
			[128489, 61669],
			"f075",
			"M51.9 384.9C19.3 344.6 0 294.4 0 240 0 107.5 114.6 0 256 0S512 107.5 512 240 397.4 480 256 480c-36.5 0-71.2-7.2-102.6-20L37 509.9c-3.7 1.6-7.5 2.1-11.5 2.1-14.1 0-25.5-11.4-25.5-25.5 0-4.3 1.1-8.5 3.1-12.2l48.8-89.4zm37.3-30.2c12.2 15.1 14.1 36.1 4.8 53.2l-18 33.1 58.5-25.1c11.8-5.1 25.2-5.2 37.1-.3 25.7 10.5 54.2 16.4 84.3 16.4 117.8 0 208-88.8 208-192S373.8 48 256 48 48 136.8 48 240c0 42.8 15.1 82.4 41.2 114.7z"
		]
	};
	faChessPawn = {
		prefix: "far",
		iconName: "chess-pawn",
		icon: [
			384,
			512,
			[9823],
			"f443",
			"M192-32c66.3 0 120 53.7 120 120 0 27.6-9.3 52.9-24.9 73.2 9.8 3 16.9 12.1 16.9 22.8 0 13.3-10.7 24-24 24l-.6 0 24.6 160 53.6 67c6.7 8.4 10.4 18.8 10.4 29.6 0 26.2-21.2 47.4-47.4 47.4L63.4 512c-26.2 0-47.4-21.2-47.4-47.4 0-10.8 3.7-21.2 10.4-29.6l53.6-67 24.6-160-.6 0c-13.3 0-24-10.7-24-24 0-10.8 7.1-19.8 16.9-22.8-15.6-20.3-24.9-45.6-24.9-73.2 0-66.3 53.7-120 120-120zM115.9 400l-51.2 64 254.7 0-51.2-64-152.2 0zm36.2-184.7l-21 136.7 121.9 0-21-136.7-1.1-7.3-77.6 0-1.1 7.3zM192 16a72 72 0 1 0 0 144 72 72 0 1 0 0-144z"
		]
	};
	faCalendarPlus = {
		prefix: "far",
		iconName: "calendar-plus",
		icon: [
			448,
			512,
			[],
			"f271",
			"M120 0c13.3 0 24 10.7 24 24l0 40 160 0 0-40c0-13.3 10.7-24 24-24s24 10.7 24 24l0 40 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-40c0-13.3 10.7-24 24-24zm0 112l-56 0c-8.8 0-16 7.2-16 16l0 288c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-288c0-8.8-7.2-16-16-16l-264 0zm104 64c13.3 0 24 10.7 24 24l0 48 48 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-48 0 0 48c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-48-48 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l48 0 0-48c0-13.3 10.7-24 24-24z"
		]
	};
	faClipboard = {
		prefix: "far",
		iconName: "clipboard",
		icon: [
			384,
			512,
			[128203],
			"f328",
			"M232 96l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l80 0c13.3 0 24 10.7 24 24s-10.7 24-24 24zm0 48c37.1 0 67.6-28 71.6-64L320 80c8.8 0 16 7.2 16 16l0 352c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16L48 96c0-8.8 7.2-16 16-16l16.4 0c4 36 34.5 64 71.6 64l80 0zM291.9 32C279 12.7 257 0 232 0L152 0c-25 0-47 12.7-59.9 32L64 32C28.7 32 0 60.7 0 96L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-352c0-35.3-28.7-64-64-64l-28.1 0z"
		]
	};
	faThumbsDown = {
		prefix: "far",
		iconName: "thumbs-down",
		icon: [
			512,
			512,
			[128078, 61576],
			"f165",
			"M360 32l7.4 .4c35 3.6 62.5 32.2 64.4 67.7 17.8 11.8 30.1 31.4 32 53.9l.2 6c0 5.7-.7 11.2-2 16.5 10.2 11.5 16.8 26.3 17.8 42.7l.2 4.8c0 13.2-3.6 25.4-9.8 36 4.9 8.4 8.2 17.9 9.3 28l.4 8c0 37.3-28.3 67.9-64.6 71.6l-7.4 .4-109.7 0 14.1 30 3.1 7.6c12.5 35.7-1.8 75.5-34.2 95l-7.2 3.9c-37.5 17.6-81.7 3.6-102.6-31.2l-.6-.9-2.7-5-.6-1.2-30.1-64c-9.4 17.8-28 29.9-49.5 29.9l-32 0c-30.9 0-56-25.1-56-56L0 152c0-30.9 25.1-56 56-56l32 0c12.4 0 23.9 4.1 33.2 11 13.2-21.4 32-39.4 55-51.6l12.2-6.5 .7-.3 6.6-3.2 .7-.3 7.1-3c16.7-6.6 34.5-9.9 52.6-9.9L360 32zM255.9 80c-12 0-23.9 2.3-35.1 6.6l-4.7 2-5.3 2.6 0 0-12.2 6.5c-29.2 15.5-48.3 44.9-50.7 77.6l-.2 8 0 112.9 .1 4.1c.5 8.2 2.5 16.2 6 23.7l56.8 120.9 2.1 3.8c8.4 13.7 26 19.1 40.8 12.2l2.9-1.6c13-7.8 18.7-23.7 13.7-38l-1.2-3-30.2-64.2c-3.5-7.4-2.9-16.1 1.5-23.1s12-11.1 20.2-11.1l147.5 0 2.4-.1c11.3-1.1 20.3-10.1 21.4-21.4l.1-2.5c0-7.1-3.1-13.5-8.2-18-5.2-4.6-8.2-11.1-8.2-18s3-13.4 8.2-18c4.4-3.9 7.4-9.3 8-15.3l.2-2.7c0-8.4-4.4-15.9-11.2-20.2-10.7-6.9-14.2-20.9-8-32 1.5-2.6 2.5-5.6 2.9-8.6l.2-3.2c0-10.6-6.9-19.6-16.6-22.8-11.7-3.8-18.7-15.9-16-28 .2-.9 .3-1.8 .4-2.6l.2-2.6c0-12.4-9.5-22.6-21.6-23.8L360 80 255.9 80zM56 144c-4.4 0-8 3.6-8 8l0 224c0 4.4 3.6 8 8 8l32 0c4.4 0 8-3.6 8-8l0-224c0-4.4-3.6-8-8-8l-32 0z"
		]
	};
	faIdBadge = {
		prefix: "far",
		iconName: "id-badge",
		icon: [
			384,
			512,
			[],
			"f2c1",
			"M256 48l0 16c0 17.7-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32l0-16-64 0c-8.8 0-16 7.2-16 16l0 384c0 8.8 7.2 16 16 16l256 0c8.8 0 16-7.2 16-16l0-384c0-8.8-7.2-16-16-16l-64 0zM0 64C0 28.7 28.7 0 64 0L320 0c35.3 0 64 28.7 64 64l0 384c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64zM160 320l64 0c44.2 0 80 35.8 80 80 0 8.8-7.2 16-16 16L96 416c-8.8 0-16-7.2-16-16 0-44.2 35.8-80 80-80zm-24-96a56 56 0 1 1 112 0 56 56 0 1 1 -112 0z"
		]
	};
	faSquareCheck = {
		prefix: "far",
		iconName: "square-check",
		icon: [
			448,
			512,
			[
				9745,
				9989,
				61510,
				"check-square"
			],
			"f14a",
			"M384 32c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l320 0zM64 80c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 80zm230.7 89.9c7.8-10.7 22.8-13.1 33.5-5.3 10.7 7.8 13.1 22.8 5.3 33.5L211.4 366.1c-4.1 5.7-10.5 9.3-17.5 9.8-7 .5-13.9-2-18.8-6.9l-55.9-55.9c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l36 36 105.6-145.2z"
		]
	};
	faCheckSquare = faSquareCheck;
	faChessBishop = {
		prefix: "far",
		iconName: "chess-bishop",
		icon: [
			320,
			512,
			[9821],
			"f43a",
			"M216 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-16 0 81.8 98.1c24.7 29.6 38.2 67 38.2 105.6 0 43.7-17.4 85.7-48.3 116.6l-8.6 8.6 46.5 58.2c6.7 8.4 10.4 18.8 10.4 29.6 0 26.2-21.2 47.4-47.4 47.4L47.4 512C21.2 512 0 490.8 0 464.6 0 453.9 3.7 443.4 10.4 435l46.5-58.2-8.6-8.6C17.4 337.4 0 295.4 0 251.7 0 213.1 13.5 175.8 38.2 146.1L120 48 104 48C90.7 48 80 37.3 80 24S90.7 0 104 0L216 0zM94.4 406.8l-45.7 57.2 222.7 0-45.7-57.1-5.5-6.9-120.3 0-5.5 6.8zM156.9 78.7L75.1 176.8c-15.3 18.4-24.6 41-26.7 64.7L48 251.7c0 31 12.3 60.7 34.2 82.7l17.7 17.7 120.2 0c6.2-6.2 12.1-12.1 17.8-17.7 21.9-21.9 34.2-51.6 34.2-82.6l-.4-10.2c-1.5-17-6.7-33.3-15.2-48L209 241c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l51.8-51.8-63.7-76.5-3.1-3.8-3.1 3.8z"
		]
	};
	faEnvelopeOpen = {
		prefix: "far",
		iconName: "envelope-open",
		icon: [
			512,
			512,
			[62135],
			"f2b6",
			"M512 416c0 35.3-28.5 64-63.9 64L64 480c-35.4 0-64-28.7-64-64L0 164c.1-15.5 7.8-30 20.5-38.8L206-2.7c30.1-20.7 69.8-20.7 99.9 0L491.5 125.2c12.8 8.8 20.4 23.3 20.5 38.8l0 252zM64 432l384.1 0c8.8 0 15.9-7.1 15.9-16l0-191.7-154.8 117.4c-31.4 23.9-74.9 23.9-106.4 0L48 224.3 48 416c0 8.9 7.2 16 16 16zM463.6 164.4L278.7 36.8c-13.7-9.4-31.7-9.4-45.4 0L48.4 164.4 231.8 303.5c14.3 10.8 34.1 10.8 48.4 0L463.6 164.4z"
		]
	};
	faCircleXmark = {
		prefix: "far",
		iconName: "circle-xmark",
		icon: [
			512,
			512,
			[
				61532,
				"times-circle",
				"xmark-circle"
			],
			"f057",
			"M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM167 167c-9.4 9.4-9.4 24.6 0 33.9l55 55-55 55c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l55-55 55 55c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-55-55 55-55c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-55 55-55-55c-9.4-9.4-24.6-9.4-33.9 0z"
		]
	};
	faTimesCircle = faCircleXmark;
	faXmarkCircle = faCircleXmark;
	faSquareCaretUp = {
		prefix: "far",
		iconName: "square-caret-up",
		icon: [
			448,
			512,
			["caret-square-up"],
			"f151",
			"M64 80c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 80zM0 96C0 60.7 28.7 32 64 32l320 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zm224 64c6.7 0 13 2.8 17.6 7.7l104 112c6.5 7 8.2 17.2 4.4 25.9S337.5 320 328 320l-208 0c-9.5 0-18.2-5.7-22-14.4s-2.1-18.9 4.4-25.9l104-112c4.5-4.9 10.9-7.7 17.6-7.7z"
		]
	};
	faCaretSquareUp = faSquareCaretUp;
	faFileImage = {
		prefix: "far",
		iconName: "file-image",
		icon: [
			384,
			512,
			[128443],
			"f1c5",
			"M176 48L64 48c-8.8 0-16 7.2-16 16l0 384c0 8.8 7.2 16 16 16l256 0c8.8 0 16-7.2 16-16l0-240-88 0c-39.8 0-72-32.2-72-72l0-88zM316.1 160L224 67.9 224 136c0 13.3 10.7 24 24 24l68.1 0zM0 64C0 28.7 28.7 0 64 0L197.5 0c17 0 33.3 6.7 45.3 18.7L365.3 141.3c12 12 18.7 28.3 18.7 45.3L384 448c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64zM259.4 432l-134.8 0c-15.8 0-28.6-12.8-28.6-28.6 0-6.4 2.1-12.5 6-17.6l67.6-86.9C175 292 183.3 288 192 288s17 4 22.4 10.9L282 385.9c3.9 5 6 11.2 6 17.6 0 15.8-12.8 28.6-28.6 28.6zM112 224a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"
		]
	};
	faSquareCaretRight = {
		prefix: "far",
		iconName: "square-caret-right",
		icon: [
			448,
			512,
			["caret-square-right"],
			"f152",
			"M400 96c0-8.8-7.2-16-16-16L64 80c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-320zM384 32c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l320 0zM320 256c0 6.7-2.8 13-7.7 17.6l-112 104c-7 6.5-17.2 8.2-25.9 4.4S160 369.5 160 360l0-208c0-9.5 5.7-18.2 14.4-22s18.9-2.1 25.9 4.4l112 104c4.9 4.5 7.7 10.9 7.7 17.6z"
		]
	};
	faCaretSquareRight = faSquareCaretRight;
	faSun = {
		prefix: "far",
		iconName: "sun",
		icon: [
			576,
			512,
			[9728],
			"f185",
			"M288-32c8 0 15.4 4 19.9 10.6l58.8 87.4 103.4-20.2c7.8-1.5 15.9 .9 21.6 6.6s8.1 13.8 6.6 21.6L478 177.3 565.4 236.1C572 240.5 576 248 576 256s-4 15.4-10.6 19.9L478 334.7 498.2 438c1.5 7.8-.9 15.9-6.6 21.6s-13.8 8.1-21.6 6.6L366.7 446 307.9 533.4C303.4 540 296 544 288 544s-15.4-4-19.9-10.6L209.3 446 105.9 466.2c-7.8 1.5-15.9-.9-21.6-6.6s-8.1-13.8-6.6-21.6L98 334.7 10.6 275.9C4 271.4 0 264 0 256s4-15.4 10.6-19.9L98 177.3 77.8 73.9c-1.5-7.8 .9-15.9 6.6-21.6s13.8-8.1 21.6-6.6l103.3 20.2 58.8-87.4 1.8-2.3C274.4-29 281-32 288-32zm-47.8 138c-5.4 8-15 12-24.5 10.2l-84-16.4 16.4 84c1.8 9.5-2.2 19.1-10.2 24.5L67 256 138 303.8c8 5.4 12 15 10.2 24.5l-16.4 84 84-16.4 3.5-.4c8.3-.4 16.3 3.6 21 10.6l47.8 71 47.8-71 2.2-2.8c5.6-6.1 14-9 22.3-7.3l84 16.4-16.4-84c-1.8-9.5 2.2-19.1 10.2-24.5l71-47.8-71-47.8c-8-5.4-12-15-10.2-24.5l16.4-84-84 16.4c-9.5 1.8-19.1-2.2-24.5-10.2l-47.8-71-47.8 71zM288 376a120 120 0 1 1 0-240 120 120 0 1 1 0 240zm0-192a72 72 0 1 0 0 144 72 72 0 1 0 0-144z"
		]
	};
	faImage = {
		prefix: "far",
		iconName: "image",
		icon: [
			448,
			512,
			[],
			"f03e",
			"M64 80c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 80zM0 96C0 60.7 28.7 32 64 32l320 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zm128 32a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm136 72c8.5 0 16.4 4.5 20.7 11.8l80 136c4.4 7.4 4.4 16.6 .1 24.1S352.6 384 344 384l-240 0c-8.9 0-17.2-5-21.3-12.9s-3.5-17.5 1.6-24.8l56-80c4.5-6.4 11.8-10.2 19.7-10.2s15.2 3.8 19.7 10.2l17.2 24.6 46.5-79c4.3-7.3 12.2-11.8 20.7-11.8z"
		]
	};
	faLightbulb = {
		prefix: "far",
		iconName: "lightbulb",
		icon: [
			384,
			512,
			[128161],
			"f0eb",
			"M296.5 291.1C321 265.2 336 230.4 336 192 336 112.5 271.5 48 192 48S48 112.5 48 192c0 38.4 15 73.2 39.5 99.1 21.3 22.4 44.9 54 53.3 92.9l102.4 0c8.4-39 32-70.5 53.3-92.9zm34.8 33C307.7 349 288 379.4 288 413.7l0 18.3c0 44.2-35.8 80-80 80l-32 0c-44.2 0-80-35.8-80-80l0-18.3C96 379.4 76.3 349 52.7 324.1 20 289.7 0 243.2 0 192 0 86 86 0 192 0S384 86 384 192c0 51.2-20 97.7-52.7 132.1zM144 184c0 13.3-10.7 24-24 24s-24-10.7-24-24c0-48.6 39.4-88 88-88 13.3 0 24 10.7 24 24s-10.7 24-24 24c-22.1 0-40 17.9-40 40z"
		]
	};
	faAddressCard = {
		prefix: "far",
		iconName: "address-card",
		icon: [
			576,
			512,
			[
				62140,
				"contact-card",
				"vcard"
			],
			"f2bb",
			"M512 80c8.8 0 16 7.2 16 16l0 320c0 8.8-7.2 16-16 16L64 432c-8.8 0-16-7.2-16-16L48 96c0-8.8 7.2-16 16-16l448 0zM64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32zM208 248a56 56 0 1 0 0-112 56 56 0 1 0 0 112zm-32 40c-44.2 0-80 35.8-80 80 0 8.8 7.2 16 16 16l192 0c8.8 0 16-7.2 16-16 0-44.2-35.8-80-80-80l-64 0zM376 144c-13.3 0-24 10.7-24 24s10.7 24 24 24l80 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-80 0zm0 96c-13.3 0-24 10.7-24 24s10.7 24 24 24l80 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-80 0z"
		]
	};
	faContactCard = faAddressCard;
	faVcard = faAddressCard;
	faFaceMeh = {
		prefix: "far",
		iconName: "face-meh",
		icon: [
			512,
			512,
			[128528, "meh"],
			"f11a",
			"M464 256a208 208 0 1 1 -416 0 208 208 0 1 1 416 0zM256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM176 240a32 32 0 1 0 0-64 32 32 0 1 0 0 64zm192-32a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zM184 320c-13.3 0-24 10.7-24 24s10.7 24 24 24l144 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-144 0z"
		]
	};
	faMeh = faFaceMeh;
	faMap = {
		prefix: "far",
		iconName: "map",
		icon: [
			512,
			512,
			[128506, 62072],
			"f279",
			"M512 48c0-8.3-4.3-16-11.3-20.4s-15.9-4.8-23.3-1.1L352.5 88.1 180 29.4c-13.7-4.7-28.7-3.8-41.9 2.3L13.8 90.3C5.4 94.2 0 102.7 0 112L0 464c0 8.2 4.2 15.9 11.1 20.3s15.6 4.9 23.1 1.4l127.3-59.9 170.7 56.9c13.7 4.6 28.5 3.7 41.6-2.5l124.4-58.5c8.4-4 13.8-12.4 13.8-21.7l0-352zM144 82.1l0 299-96 45.2 0-299 96-45.2zm48 303.3l0-301.1 128 43.5 0 300.3-128-42.7zM368 134l96-47.4 0 298.2-96 45.2 0-296z"
		]
	};
	faHandPointDown = {
		prefix: "far",
		iconName: "hand-point-down",
		icon: [
			384,
			512,
			[],
			"f0a7",
			"M64 448l0-177.6c5.2 1 10.5 1.6 16 1.6l16 0 0 176c0 8.8-7.2 16-16 16s-16-7.2-16-16zM80 224c-17.7 0-32-14.3-32-32l0-24c0-66.3 53.7-120 120-120l48 0c52.5 0 97.1 33.7 113.4 80.7-3.1-.5-6.2-.7-9.4-.7-20 0-37.9 9.2-49.7 23.6-9-4.9-19.4-7.6-30.3-7.6-15.1 0-29 5.3-40 14-11-8.8-24.9-14-40-14l-40 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l40 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-80 0zM0 192l0 0c0 18 6 34.6 16 48l0 208c0 35.3 28.7 64 64 64s64-28.7 64-64l0-82c5.1 1.3 10.5 2 16 2 25.3 0 47.2-14.7 57.6-36 7 2.6 14.5 4 22.4 4 20 0 37.9-9.2 49.7-23.6 9 4.9 19.4 7.6 30.3 7.6 35.3 0 64-28.7 64-64l0-88C384 75.2 308.8 0 216 0L168 0C75.2 0 0 75.2 0 168l0 24zm336 64c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-64c0-8.8 7.2-16 16-16s16 7.2 16 16l0 64zM160 272c5.5 0 10.9-.7 16-2l0 34c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-32 16 0zm64-24l0-40c0-8.8 7.2-16 16-16s16 7.2 16 16l0 64c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-24z"
		]
	};
	faFaceMehBlank = {
		prefix: "far",
		iconName: "face-meh-blank",
		icon: [
			512,
			512,
			[128566, "meh-blank"],
			"f5a4",
			"M256 48a208 208 0 1 0 0 416 208 208 0 1 0 0-416zM512 256a256 256 0 1 1 -512 0 256 256 0 1 1 512 0zM144 208a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm192-32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"
		]
	};
	faMehBlank = faFaceMehBlank;
	faFaceGrinTongue = {
		prefix: "far",
		iconName: "face-grin-tongue",
		icon: [
			512,
			512,
			[128539, "grin-tongue"],
			"f589",
			"M464 256c0-114.9-93.1-208-208-208S48 141.1 48 256c0 74.1 38.8 139.2 97.1 176-.7-5.2-1.1-10.6-1.1-16l0-53.5c-10.2-12.6-18.3-26.9-23.8-42.4-4.1-11.6 7.8-21.4 19.6-17.8 34.7 10.6 74.2 16.5 116.1 16.5 42 0 81.5-6 116.3-16.6 11.8-3.6 23.7 6.1 19.6 17.8-5.5 15.6-13.6 29.9-23.8 42.5l0 53.5c0 5.4-.4 10.8-1.1 16 58.4-36.8 97.1-101.9 97.1-176zm48 0c0 116.3-77.6 214.6-183.9 245.7-19.5 16.4-44.6 26.3-72.1 26.3s-52.6-9.9-72.1-26.3C77.6 470.6 0 372.3 0 256 0 114.6 114.6 0 256 0S512 114.6 512 256zM176 176a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm16 208l0-37.4c0-14.7-11.9-26.6-26.6-26.6l-2 0c-11.3 0-21.1 7.9-23.6 18.9-2.8 12.6-20.8 12.6-23.6 0-2.5-11.1-12.3-18.9-23.6-18.9l-2 0c-14.7 0-26.6 11.9-26.6 26.6l0 37.4c0 35.3 28.7 64 64 64s64-28.7 64-64z"
		]
	};
	faGrinTongue = faFaceGrinTongue;
	faFutbol = {
		prefix: "far",
		iconName: "futbol",
		icon: [
			512,
			512,
			[
				9917,
				"futbol-ball",
				"soccer-ball"
			],
			"f1e3",
			"M387 228.3c-4.4-2.8-7.6-7-9.2-11.9s-1.4-10.2 .5-15L411.6 118c-19.9-22.4-44.6-40.5-72.4-52.7l-69.1 57.6c-4 3.3-9 5.1-14.1 5.1s-10.2-1.8-14.1-5.1L172.8 65.3c-27.8 12.2-52.5 30.3-72.4 52.7l33.4 83.4c1.9 4.8 2.1 10.1 .5 15s-4.9 9.1-9.2 11.9L49 276.2c3 30.9 12.7 59.7 27.6 85.2l89.7-6c5.2-.3 10.3 1.1 14.5 4.2s7.2 7.4 8.4 12.5l22 87.2c14.4 3.2 29.4 4.8 44.8 4.8s30.3-1.7 44.8-4.8l22-87.2c1.3-5 4.2-9.4 8.4-12.5s9.3-4.5 14.5-4.2l89.7 6c15-25.4 24.7-54.3 27.6-85.1L387 228.3zM256 0a256 256 0 1 1 0 512 256 256 0 1 1 0-512zm62 221c8.4 6.1 11.9 16.9 8.7 26.8l-18.3 56.3c-3.2 9.9-12.4 16.6-22.8 16.6l-59.2 0c-10.4 0-19.6-6.7-22.8-16.6l-18.3-56.3c-3.2-9.9 .3-20.7 8.7-26.8l47.9-34.8c8.4-6.1 19.8-6.1 28.2 0L318 221z"
		]
	};
	faFutbolBall = faFutbol;
	faSoccerBall = faFutbol;
	faFaceSurprise = {
		prefix: "far",
		iconName: "face-surprise",
		icon: [
			512,
			512,
			[128558, "surprise"],
			"f5c2",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm176-80a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm-48 80a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"
		]
	};
	faSurprise = faFaceSurprise;
	faFolder = {
		prefix: "far",
		iconName: "folder",
		icon: [
			512,
			512,
			[
				128193,
				128447,
				61716,
				"folder-blank"
			],
			"f07b",
			"M64 400l384 0c8.8 0 16-7.2 16-16l0-240c0-8.8-7.2-16-16-16l-149.3 0c-17.3 0-34.2-5.6-48-16L212.3 83.2c-2.8-2.1-6.1-3.2-9.6-3.2L64 80c-8.8 0-16 7.2-16 16l0 288c0 8.8 7.2 16 16 16zm384 48L64 448c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l138.7 0c13.8 0 27.3 4.5 38.4 12.8l38.4 28.8c5.5 4.2 12.3 6.4 19.2 6.4L448 80c35.3 0 64 28.7 64 64l0 240c0 35.3-28.7 64-64 64z"
		]
	};
	faFolderBlank = faFolder;
	faCloud = {
		prefix: "far",
		iconName: "cloud",
		icon: [
			576,
			512,
			[9729],
			"f0c2",
			"M80 192c0-88.4 71.6-160 160-160 47.1 0 89.4 20.4 118.7 52.7 10.6-3.1 21.8-4.7 33.3-4.7 66.3 0 120 53.7 120 120 0 13.2-2.1 25.9-6.1 37.8 41.6 21.1 70.1 64.3 70.1 114.2 0 70.7-57.3 128-128 128l-304 0c-79.5 0-144-64.5-144-144 0-56.8 32.9-105.9 80.7-129.4-.4-4.8-.7-9.7-.7-14.6zM240 80c-61.9 0-112 50.1-112 112 0 8.4 .9 16.6 2.7 24.5 2.7 12.1-4.3 24.3-16.1 28.1-38.7 12.4-66.6 48.7-66.6 91.4 0 53 43 96 96 96l304 0c44.2 0 80-35.8 80-80 0-37.4-25.7-68.9-60.5-77.6-7.5-1.9-13.6-7.2-16.5-14.3s-2.1-15.2 2-21.7c7-11.1 11-24.2 11-38.3 0-39.8-32.2-72-72-72-11.1 0-21.5 2.5-30.8 6.9-10.5 5-23.1 1.7-29.8-7.8-20.3-28.6-53.7-47.1-91.3-47.1z"
		]
	};
	faCircle = {
		prefix: "far",
		iconName: "circle",
		icon: [
			512,
			512,
			[
				128308,
				128309,
				128992,
				128993,
				128994,
				128995,
				128996,
				9679,
				9898,
				9899,
				11044,
				61708,
				61915
			],
			"f111",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0z"
		]
	};
	faFaceGrinSquint = {
		prefix: "far",
		iconName: "face-grin-squint",
		icon: [
			512,
			512,
			[128518, "grin-squint"],
			"f585",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm372.2 46.3c11.8-3.6 23.7 6.1 19.6 17.8-19.8 55.9-73.1 96-135.8 96-62.7 0-116-40-135.8-95.9-4.1-11.6 7.8-21.4 19.6-17.8 34.7 10.6 74.2 16.5 116.1 16.5 42 0 81.5-6 116.3-16.6zm-249.6-143c4.5-6.8 13.3-9.2 20.6-5.5l79.6 40c5.4 2.7 8.8 8.2 8.8 14.3s-3.4 11.6-8.8 14.3l-79.6 40c-7.3 3.6-16.1 1.3-20.6-5.5s-3.1-15.9 3.1-21.1L159 208 125.8 180.3c-6.2-5.2-7.6-14.3-3.1-21.1zm263.6 21.1L353 208 386.2 235.7c6.2 5.2 7.6 14.3 3.1 21.1s-13.3 9.2-20.6 5.5l-79.6-40c-5.4-2.7-8.8-8.2-8.8-14.3s3.4-11.6 8.8-14.3l79.6-40c7.3-3.6 16.1-1.3 20.6 5.5s3.1 15.9-3.1 21.1z"
		]
	};
	faGrinSquint = faFaceGrinSquint;
	faCircleUser = {
		prefix: "far",
		iconName: "circle-user",
		icon: [
			512,
			512,
			[62142, "user-circle"],
			"f2bd",
			"M406.5 399.6C387.4 352.9 341.5 320 288 320l-64 0c-53.5 0-99.4 32.9-118.5 79.6-35.6-37.3-57.5-87.9-57.5-143.6 0-114.9 93.1-208 208-208s208 93.1 208 208c0 55.7-21.9 106.2-57.5 143.6zm-40.1 32.7C334.4 452.4 296.6 464 256 464s-78.4-11.6-110.5-31.7c7.3-36.7 39.7-64.3 78.5-64.3l64 0c38.8 0 71.2 27.6 78.5 64.3zM256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zm0-272a40 40 0 1 1 0-80 40 40 0 1 1 0 80zm-88-40a88 88 0 1 0 176 0 88 88 0 1 0 -176 0z"
		]
	};
	faUserCircle = faCircleUser;
	faRectangleList = {
		prefix: "far",
		iconName: "rectangle-list",
		icon: [
			512,
			512,
			["list-alt"],
			"f022",
			"M64 112c-8.8 0-16 7.2-16 16l0 256c0 8.8 7.2 16 16 16l384 0c8.8 0 16-7.2 16-16l0-256c0-8.8-7.2-16-16-16L64 112zM0 128C0 92.7 28.7 64 64 64l384 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128zM160 320a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm-32-96a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm104-56l160 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-160 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm0 128l160 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-160 0c-13.3 0-24-10.7-24-24s10.7-24 24-24z"
		]
	};
	faListAlt = faRectangleList;
	faHand = {
		prefix: "far",
		iconName: "hand",
		icon: [
			512,
			512,
			[
				129306,
				9995,
				"hand-paper"
			],
			"f256",
			"M256.5 0c-25.3 0-47.2 14.7-57.6 36-7-2.6-14.5-4-22.4-4-35.3 0-64 28.7-64 64l0 165.5-2.7-2.7c-25-25-65.5-25-90.5 0s-25 65.5 0 90.5L107 437c48 48 113.1 75 181 75l16.5 0c1.5 0 3-.1 4.5-.4 91.7-6.2 165-79.4 171.1-171.1 .3-1.5 .4-3 .4-4.5l0-176c0-35.3-28.7-64-64-64-5.5 0-10.9 .7-16 2l0-2c0-35.3-28.7-64-64-64-7.9 0-15.4 1.4-22.4 4-10.4-21.3-32.3-36-57.6-36zm-16 96.1l0-.1 0-32c0-8.8 7.2-16 16-16s16 7.2 16 16l0 168c0 13.3 10.7 24 24 24s24-10.7 24-24l0-136c0-8.8 7.2-16 16-16s16 7.2 16 16l0 136c0 13.3 10.7 24 24 24s24-10.7 24-24l0-72c0-8.8 7.2-16 16-16s16 7.2 16 16l0 172.9c-.1 .6-.1 1.3-.2 1.9-3.4 69.7-59.3 125.6-129 129-.6 0-1.3 .1-1.9 .2L288 464C232.9 464 180 442.1 141 403.1L53.2 315.3c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l43.7 43.7c6.9 6.9 17.2 8.9 26.2 5.2s14.8-12.5 14.8-22.2l0-223.4c0-8.8 7.2-16 16-16 8.8 0 16 7.1 16 15.9l0 136.1c0 13.3 10.7 24 24 24s24-10.7 24-24l0-135.9z"
		]
	};
	faHandPaper = faHand;
	faThumbsUp = {
		prefix: "far",
		iconName: "thumbs-up",
		icon: [
			512,
			512,
			[128077, 61575],
			"f164",
			"M171.5 38.8C192.3 4 236.5-10 274 7.6l7.2 3.8C316 32.3 330 76.5 312.4 114l0 0-14.1 30 109.7 0 7.4 .4c36.3 3.7 64.6 34.4 64.6 71.6 0 13.2-3.6 25.4-9.8 36 6.1 10.6 9.7 22.8 9.8 36 0 18.3-6.9 34.8-18 47.5 1.3 5.3 2 10.8 2 16.5 0 25.1-12.9 47-32.2 59.9-1.9 35.5-29.4 64.2-64.4 67.7l-7.4 .4-104.1 0c-18 0-35.9-3.4-52.6-9.9l-7.1-3-.7-.3-6.6-3.2-.7-.3-12.2-6.5c-12.3-6.5-23.3-14.7-32.9-24.1-4.1 26.9-27.3 47.4-55.3 47.4l-32 0c-30.9 0-56-25.1-56-56L0 200c0-30.9 25.1-56 56-56l32 0c10.8 0 20.9 3.1 29.5 8.5l50.1-106.5 .6-1.2 2.7-5 .6-.9zM56 192c-4.4 0-8 3.6-8 8l0 224c0 4.4 3.6 8 8 8l32 0c4.4 0 8-3.6 8-8l0-224c0-4.4-3.6-8-8-8l-32 0zM253.6 51c-14.8-6.9-32.3-1.6-40.7 12l-2.2 4-56.8 120.9c-3.5 7.5-5.5 15.5-6 23.7l-.1 4.2 0 112.9 .2 7.9c2.4 32.7 21.4 62.1 50.7 77.7l11.5 6.1 6.3 3.1c12.4 5.6 25.8 8.5 39.4 8.5l104.1 0 2.4-.1c12.1-1.2 21.6-11.5 21.6-23.9l-.2-2.6c-.1-.9-.2-1.7-.4-2.6-2.7-12.1 4.3-24.2 16-28 9.7-3.1 16.6-12.2 16.6-22.8 0-4.3-1.1-8.2-3.1-11.8-6.3-11.1-2.8-25.2 8-32 6.8-4.3 11.2-11.8 11.2-20.2 0-7.1-3.1-13.5-8.2-18-5.2-4.6-8.2-11.1-8.2-18s3-13.4 8.2-18c5.1-4.5 8.2-10.9 8.2-18l-.1-2.4c-1.1-11.3-10.1-20.3-21.4-21.4l-2.4-.1-147.5 0c-8.2 0-15.8-4.2-20.2-11.1-4.4-6.9-5-15.7-1.5-23.1L269 93.6c7-15 1.4-32.7-12.5-41L253.6 51z"
		]
	};
	faBuilding = {
		prefix: "far",
		iconName: "building",
		icon: [
			384,
			512,
			[127970, 61687],
			"f1ad",
			"M64 48c-8.8 0-16 7.2-16 16l0 384c0 8.8 7.2 16 16 16l80 0 0-80c0-17.7 14.3-32 32-32l32 0c17.7 0 32 14.3 32 32l0 80 80 0c8.8 0 16-7.2 16-16l0-384c0-8.8-7.2-16-16-16L64 48zM0 64C0 28.7 28.7 0 64 0L320 0c35.3 0 64 28.7 64 64l0 384c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64zm96 48c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32zM240 96l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32c0-8.8 7.2-16 16-16zM96 240c0-8.8 7.2-16 16-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32zm144-16l32 0c8.8 0 16 7.2 16 16l0 32c0 8.8-7.2 16-16 16l-32 0c-8.8 0-16-7.2-16-16l0-32c0-8.8 7.2-16 16-16z"
		]
	};
	faChessRook = {
		prefix: "far",
		iconName: "chess-rook",
		icon: [
			384,
			512,
			[9820],
			"f447",
			"M352 0c17.7 0 32 14.3 32 32l0 138.7c0 13.8-4.5 27.3-12.8 38.4l-35.2 46.9 0 112 40.8 68.1c4.7 7.8 7.2 16.7 7.2 25.8 0 27.7-22.4 50.1-50.1 50.1L50.1 512c-27.7 0-50.1-22.4-50.1-50.1 0-9.1 2.5-18 7.2-25.8L48 368 48 256 12.8 209.1C4.5 198 0 184.5 0 170.7L0 32C0 14.3 14.3 0 32 0L352 0zM48.3 460.8l-.3 1.1c0 1.2 1 2.1 2.1 2.1l283.8 0c1.2 0 2.1-1 2.1-2.1l-.3-1.1-36.5-60.8-214.4 0-36.5 60.8zM48 170.7c0 2.6 .6 5.1 1.8 7.4l1.4 2.2 0 0 35.2 46.9 9.6 12.8 0 112 192 0 0-112 9.6-12.8 35.2-46.9 0 0 1.4-2.2c1.2-2.3 1.8-4.8 1.8-7.4l0-122.7-64 0 0 24c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-24-64 0 0 24c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-24-64 0 0 122.7z"
		]
	};
	faCircleQuestion = {
		prefix: "far",
		iconName: "circle-question",
		icon: [
			512,
			512,
			[62108, "question-circle"],
			"f059",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm256-80c-17.7 0-32 14.3-32 32 0 13.3-10.7 24-24 24s-24-10.7-24-24c0-44.2 35.8-80 80-80s80 35.8 80 80c0 47.2-36 67.2-56 74.5l0 3.8c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-8.1c0-20.5 14.8-35.2 30.1-40.2 6.4-2.1 13.2-5.5 18.2-10.3 4.3-4.2 7.7-10 7.7-19.6 0-17.7-14.3-32-32-32zM224 368a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z"
		]
	};
	faQuestionCircle = faCircleQuestion;
	faFile = {
		prefix: "far",
		iconName: "file",
		icon: [
			384,
			512,
			[
				128196,
				128459,
				61462
			],
			"f15b",
			"M176 48L64 48c-8.8 0-16 7.2-16 16l0 384c0 8.8 7.2 16 16 16l256 0c8.8 0 16-7.2 16-16l0-240-88 0c-39.8 0-72-32.2-72-72l0-88zM316.1 160L224 67.9 224 136c0 13.3 10.7 24 24 24l68.1 0zM0 64C0 28.7 28.7 0 64 0L197.5 0c17 0 33.3 6.7 45.3 18.7L365.3 141.3c12 12 18.7 28.3 18.7 45.3L384 448c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64z"
		]
	};
	faFaceSadCry = {
		prefix: "far",
		iconName: "face-sad-cry",
		icon: [
			512,
			512,
			[128557, "sad-cry"],
			"f5b3",
			"M400 406.1L400 288c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 152.6c-28.7 15-61.4 23.4-96 23.4s-67.3-8.5-96-23.4L160 288c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 118.1C72.6 368.2 48 315 48 256 48 141.1 141.1 48 256 48s208 93.1 208 208c0 59-24.6 112.2-64 150.1zM256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM152 196l16 0c11 0 20 9 20 20s9 20 20 20 20-9 20-20c0-33.1-26.9-60-60-60l-16 0c-33.1 0-60 26.9-60 60 0 11 9 20 20 20s20-9 20-20 9-20 20-20zm172 20c0-11 9-20 20-20l16 0c11 0 20 9 20 20s9 20 20 20 20-9 20-20c0-33.1-26.9-60-60-60l-16 0c-33.1 0-60 26.9-60 60 0 11 9 20 20 20s20-9 20-20zM208 336l0 32c0 26.5 21.5 48 48 48s48-21.5 48-48l0-32c0-26.5-21.5-48-48-48s-48 21.5-48 48z"
		]
	};
	faSadCry = faFaceSadCry;
	faCalendarMinus = {
		prefix: "far",
		iconName: "calendar-minus",
		icon: [
			448,
			512,
			[],
			"f272",
			"M120 0c13.3 0 24 10.7 24 24l0 40 160 0 0-40c0-13.3 10.7-24 24-24s24 10.7 24 24l0 40 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-40c0-13.3 10.7-24 24-24zm0 112l-56 0c-8.8 0-16 7.2-16 16l0 288c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-288c0-8.8-7.2-16-16-16l-264 0zm32 136l144 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-144 0c-13.3 0-24-10.7-24-24s10.7-24 24-24z"
		]
	};
	faFaceTired = {
		prefix: "far",
		iconName: "face-tired",
		icon: [
			512,
			512,
			[128555, "tired"],
			"f5c8",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm176.5 64.3C196.1 302.1 223.8 288 256 288s59.9 14.1 79.5 32.3c19 17.8 32.5 41.7 32.5 63.7 0 5.4-2.7 10.4-7.2 13.4s-10.2 3.4-15.2 1.3l-17.2-7.5c-22.8-10-47.5-15.1-72.4-15.1s-49.6 5.2-72.4 15.1l-17.2 7.5c-4.9 2.2-10.7 1.7-15.2-1.3s-7.2-8-7.2-13.4c0-22 13.5-45.9 32.5-63.7zM122.6 159.2c4.5-6.8 13.3-9.2 20.6-5.5l79.6 40c5.4 2.7 8.8 8.2 8.8 14.3s-3.4 11.6-8.8 14.3l-79.6 40c-7.3 3.6-16.1 1.3-20.6-5.5s-3.1-15.9 3.1-21.1L159 208 125.8 180.3c-6.2-5.2-7.6-14.3-3.1-21.1zm263.6 21.1L353 208 386.2 235.7c6.2 5.2 7.6 14.3 3.1 21.1s-13.3 9.2-20.6 5.5l-79.6-40c-5.4-2.7-8.8-8.2-8.8-14.3s3.4-11.6 8.8-14.3l79.6-40c7.3-3.6 16.1-1.3 20.6 5.5s3.1 15.9-3.1 21.1z"
		]
	};
	faTired = faFaceTired;
	faHandPointRight = {
		prefix: "far",
		iconName: "hand-point-right",
		icon: [
			512,
			512,
			[],
			"f0a4",
			"M448 128l-177.6 0c1 5.2 1.6 10.5 1.6 16l0 16 176 0c8.8 0 16-7.2 16-16s-7.2-16-16-16zM224 144c0-17.7-14.3-32-32-32l-24 0c-66.3 0-120 53.7-120 120l0 48c0 52.5 33.7 97.1 80.7 113.4-.5-3.1-.7-6.2-.7-9.4 0-20 9.2-37.9 23.6-49.7-4.9-9-7.6-19.4-7.6-30.3 0-15.1 5.3-29 14-40-8.8-11-14-24.9-14-40l0-40c0-13.3 10.7-24 24-24s24 10.7 24 24l0 40c0 8.8 7.2 16 16 16s16-7.2 16-16l0-80zM192 64l0 0c18 0 34.6 6 48 16l208 0c35.3 0 64 28.7 64 64s-28.7 64-64 64l-82 0c1.3 5.1 2 10.5 2 16 0 25.3-14.7 47.2-36 57.6 2.6 7 4 14.5 4 22.4 0 20-9.2 37.9-23.6 49.7 4.9 9 7.6 19.4 7.6 30.3 0 35.3-28.7 64-64 64l-88 0C75.2 448 0 372.8 0 280l0-48C0 139.2 75.2 64 168 64l24 0zm64 336c8.8 0 16-7.2 16-16s-7.2-16-16-16l-64 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l64 0zm16-176c0 5.5-.7 10.9-2 16l34 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0 0 16zm-24 64l-40 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l64 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-24 0z"
		]
	};
	faCircleUp = {
		prefix: "far",
		iconName: "circle-up",
		icon: [
			512,
			512,
			[61467, "arrow-alt-circle-up"],
			"f35b",
			"M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464a256 256 0 1 0 0-512 256 256 0 1 0 0 512zm11.3-387.3c-6.2-6.2-16.4-6.2-22.6 0l-104 104c-4.6 4.6-5.9 11.5-3.5 17.4s8.3 9.9 14.8 9.9l72 0 0 104c0 13.3 10.7 24 24 24l16 0c13.3 0 24-10.7 24-24l0-104 72 0c6.5 0 12.3-3.9 14.8-9.9s1.1-12.9-3.5-17.4l-104-104z"
		]
	};
	faArrowAltCircleUp = faCircleUp;
	faHandScissors = {
		prefix: "far",
		iconName: "hand-scissors",
		icon: [
			512,
			512,
			[],
			"f257",
			"M.2 276.3c-1.2-35.3 26.4-65 61.7-66.2l3.3-.1-8.2-1.8C22.5 200.5 .7 166.3 8.3 131.8S50.2 75.5 84.7 83.2l173 38.3c2.3-2.9 4.6-5.7 7.1-8.5l18.4-20.3C299.9 74.5 323.5 64 348.3 64l10.2 0c54.1 0 104.1 28.7 131.3 75.4l1.5 2.6c13.6 23.2 20.7 49.7 20.7 76.6L512 344c0 66.3-53.7 120-120 120l-104 0c-35.3 0-64-28.7-64-64 0-2.8 .2-5.6 .5-8.3-19.4-11-32.5-31.8-32.5-55.7 0-.8 0-1.6 0-2.4L66.4 338c-35.3 1.2-65-26.4-66.2-61.7zm63.4-18.2c-8.8 .3-15.7 7.7-15.4 16.6s7.7 15.7 16.5 15.4l161.5-5.6c9.8-.3 18.7 5.3 22.7 14.2s2.2 19.3-4.5 26.4c-2.8 2.9-4.4 6.7-4.4 11 0 8.8 7.2 16 16 16 9.1 0 17.4 5.1 21.5 13.3s3.2 17.9-2.3 25.1c-2 2.7-3.2 6-3.2 9.6 0 8.8 7.2 16 16 16l104 0c39.8 0 72-32.2 72-72l0-125.4c0-18.4-4.9-36.5-14.2-52.4l-1.5-2.6c-18.6-32-52.8-51.6-89.8-51.6l-10.2 0c-11.3 0-22 4.8-29.6 13.1l0 0-18.4 20.3c-.6 .6-1.1 1.3-1.7 1.9l57 13.2c8.6 2 14 10.6 12 19.2s-10.6 14-19.2 12L262.8 171.8 74.3 130c-8.6-1.9-17.2 3.5-19.1 12.2s3.5 17.2 12.2 19.1l187.5 41.6c10.2 2.3 17.8 10.9 18.7 21.4l.1 1c.6 6.6-1.5 13.1-5.8 18.1s-10.6 7.9-17.2 8.2L63.6 258.1z"
		]
	};
	faGem = {
		prefix: "far",
		iconName: "gem",
		icon: [
			512,
			512,
			[128142],
			"f3a5",
			"M168.5 72l87.5 93 87.5-93-175 0zM383.9 99.1l-72.3 76.9 129 0-56.6-76.9zm50 124.9L78.1 224 256 420.3 433.9 224zM71.5 176l129 0-72.3-76.9-56.6 76.9zm434.3 40.1l-232 256c-4.5 5-11 7.9-17.8 7.9s-13.2-2.9-17.8-7.9l-232-256c-7.7-8.5-8.3-21.2-1.5-30.4l112-152c4.5-6.1 11.7-9.8 19.3-9.8l240 0c7.6 0 14.8 3.6 19.3 9.8l112 152c6.8 9.2 6.1 21.9-1.5 30.4z"
		]
	};
	faRectangleXmark = {
		prefix: "far",
		iconName: "rectangle-xmark",
		icon: [
			512,
			512,
			[
				62164,
				"rectangle-times",
				"times-rectangle",
				"window-close"
			],
			"f410",
			"M64 112c-8.8 0-16 7.2-16 16l0 256c0 8.8 7.2 16 16 16l384 0c8.8 0 16-7.2 16-16l0-256c0-8.8-7.2-16-16-16L64 112zM0 128C0 92.7 28.7 64 64 64l384 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128zm334.1 49.9c9.4 9.4 9.4 24.6 0 33.9l-44.1 44.1 44.1 44.1c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-44.1-44.1-44.1 44.1c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l44.1-44.1-44.1-44.1c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l44.1 44.1 44.1-44.1c9.4-9.4 24.6-9.4 33.9 0z"
		]
	};
	faRectangleTimes = faRectangleXmark;
	faTimesRectangle = faRectangleXmark;
	faWindowClose = faRectangleXmark;
	faTrashCan = {
		prefix: "far",
		iconName: "trash-can",
		icon: [
			448,
			512,
			[61460, "trash-alt"],
			"f2ed",
			"M166.2-16c-13.3 0-25.3 8.3-30 20.8L120 48 24 48C10.7 48 0 58.7 0 72S10.7 96 24 96l400 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-96 0-16.2-43.2C307.1-7.7 295.2-16 281.8-16L166.2-16zM32 144l0 304c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-304-48 0 0 304c0 8.8-7.2 16-16 16L96 464c-8.8 0-16-7.2-16-16l0-304-48 0zm160 72c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 176c0 13.3 10.7 24 24 24s24-10.7 24-24l0-176zm112 0c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 176c0 13.3 10.7 24 24 24s24-10.7 24-24l0-176z"
		]
	};
	faTrashAlt = faTrashCan;
	faLifeRing = {
		prefix: "far",
		iconName: "life-ring",
		icon: [
			512,
			512,
			[],
			"f1cd",
			"M385.1 419.1C349.7 447.2 304.8 464 256 464s-93.7-16.8-129.1-44.9l80.4-80.4c14.3 8.4 31 13.3 48.8 13.3s34.5-4.8 48.8-13.3l80.4 80.4zm68.1 .2C489.9 374.9 512 318.1 512 256S489.9 137.1 453.2 92.7L465 81c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0L419.3 58.8C374.9 22.1 318.1 0 256 0S137.1 22.1 92.7 58.8L81 47c-9.4-9.4-24.6-9.4-33.9 0S37.7 71.6 47 81L58.8 92.7C22.1 137.1 0 193.9 0 256S22.1 374.9 58.8 419.3L47 431c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l11.8-11.8C137.1 489.9 193.9 512 256 512s118.9-22.1 163.3-58.8L431 465c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-11.8-11.8zm-34.1-34.1l-80.4-80.4c8.4-14.3 13.3-31 13.3-48.8s-4.8-34.5-13.3-48.8l80.4-80.4C447.2 162.3 464 207.2 464 256s-16.8 93.7-44.9 129.1zM385.1 92.9l-80.4 80.4c-14.3-8.4-31-13.3-48.8-13.3s-34.5 4.8-48.8 13.3L126.9 92.9C162.3 64.8 207.2 48 256 48s93.7 16.8 129.1 44.9zM173.3 304.8L92.9 385.1C64.8 349.7 48 304.8 48 256s16.8-93.7 44.9-129.1l80.4 80.4c-8.4 14.3-13.3 31-13.3 48.8s4.8 34.5 13.3 48.8zM208 256a48 48 0 1 1 96 0 48 48 0 1 1 -96 0z"
		]
	};
	faCopyright = {
		prefix: "far",
		iconName: "copyright",
		icon: [
			512,
			512,
			[169],
			"f1f9",
			"M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM205.1 306.9c-28.1-28.1-28.1-73.7 0-101.8s73.7-28.1 101.8 0c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9c-46.9-46.9-122.8-46.9-169.7 0s-46.9 122.8 0 169.7 122.8 46.9 169.7 0c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0c-28.1 28.1-73.7 28.1-101.8 0z"
		]
	};
	faCircleLeft = {
		prefix: "far",
		iconName: "circle-left",
		icon: [
			512,
			512,
			[61840, "arrow-alt-circle-left"],
			"f359",
			"M48 256a208 208 0 1 1 416 0 208 208 0 1 1 -416 0zm464 0a256 256 0 1 0 -512 0 256 256 0 1 0 512 0zM124.7 244.7c-6.2 6.2-6.2 16.4 0 22.6l104 104c4.6 4.6 11.5 5.9 17.4 3.5s9.9-8.3 9.9-14.8l0-72 104 0c13.3 0 24-10.7 24-24l0-16c0-13.3-10.7-24-24-24l-104 0 0-72c0-6.5-3.9-12.3-9.9-14.8s-12.9-1.1-17.4 3.5l-104 104z"
		]
	};
	faArrowAltCircleLeft = faCircleLeft;
	faCalendar = {
		prefix: "far",
		iconName: "calendar",
		icon: [
			448,
			512,
			[128197, 128198],
			"f133",
			"M120 0c13.3 0 24 10.7 24 24l0 40 160 0 0-40c0-13.3 10.7-24 24-24s24 10.7 24 24l0 40 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-40c0-13.3 10.7-24 24-24zm0 112l-56 0c-8.8 0-16 7.2-16 16l0 48 352 0 0-48c0-8.8-7.2-16-16-16l-264 0zM48 224l0 192c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-192-352 0z"
		]
	};
	faFaceFrownOpen = {
		prefix: "far",
		iconName: "face-frown-open",
		icon: [
			512,
			512,
			[128550, "frown-open"],
			"f57a",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zM182.4 382.5c-12.4 5.2-26.5-4.1-21.1-16.4 16-36.6 52.4-62.1 94.8-62.1s78.8 25.6 94.8 62.1c5.4 12.3-8.7 21.6-21.1 16.4-22.4-9.5-47.4-14.8-73.7-14.8s-51.3 5.3-73.7 14.8zM144 208a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm192-32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"
		]
	};
	faFrownOpen = faFaceFrownOpen;
	faChartBar = {
		prefix: "far",
		iconName: "chart-bar",
		icon: [
			512,
			512,
			["bar-chart"],
			"f080",
			"M48 56c0-13.3-10.7-24-24-24S0 42.7 0 56L0 400c0 44.2 35.8 80 80 80l408 0c13.3 0 24-10.7 24-24s-10.7-24-24-24L80 432c-17.7 0-32-14.3-32-32L48 56zm104 72l208 0c13.3 0 24-10.7 24-24s-10.7-24-24-24L152 80c-13.3 0-24 10.7-24 24s10.7 24 24 24zm0 64c-13.3 0-24 10.7-24 24s10.7 24 24 24l144 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-144 0zm0 112c-13.3 0-24 10.7-24 24s10.7 24 24 24l272 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-272 0z"
		]
	};
	faBarChart = faChartBar;
	faHouse = {
		prefix: "far",
		iconName: "house",
		icon: [
			512,
			512,
			[
				127968,
				63498,
				63500,
				"home",
				"home-alt",
				"home-lg-alt"
			],
			"f015",
			"M240 6.1c9.1-8.2 22.9-8.2 32 0l232 208c9.9 8.8 10.7 24 1.8 33.9s-24 10.7-33.9 1.8l-8-7.2 0 205.3c0 35.3-28.7 64-64 64l-288 0c-35.3 0-64-28.7-64-64l0-205.3-8 7.2c-9.9 8.8-25 8-33.9-1.8s-8-25 1.8-33.9L240 6.1zm16 50.1L96 199.7 96 448c0 8.8 7.2 16 16 16l48 0 0-104c0-39.8 32.2-72 72-72l48 0c39.8 0 72 32.2 72 72l0 104 48 0c8.8 0 16-7.2 16-16l0-248.3-160-143.4zM208 464l96 0 0-104c0-13.3-10.7-24-24-24l-48 0c-13.3 0-24 10.7-24 24l0 104z"
		]
	};
	faHome = faHouse;
	faHomeAlt = faHouse;
	faHomeLgAlt = faHouse;
	faFaceFrown = {
		prefix: "far",
		iconName: "face-frown",
		icon: [
			512,
			512,
			[9785, "frown"],
			"f119",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zM334.7 384.6C319.7 369 293.6 352 256 352s-63.7 17-78.7 32.6c-9.2 9.6-24.4 9.9-33.9 .7s-9.9-24.4-.7-33.9c22.1-23 60-47.4 113.3-47.4s91.2 24.4 113.3 47.4c9.2 9.6 8.9 24.8-.7 33.9s-24.8 8.9-33.9-.7zM144 208a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm192-32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"
		]
	};
	faFrown = faFaceFrown;
	faUser = {
		prefix: "far",
		iconName: "user",
		icon: [
			448,
			512,
			[
				128100,
				62144,
				62470,
				"user-alt",
				"user-large"
			],
			"f007",
			"M144 128a80 80 0 1 1 160 0 80 80 0 1 1 -160 0zm208 0a128 128 0 1 0 -256 0 128 128 0 1 0 256 0zM48 480c0-70.7 57.3-128 128-128l96 0c70.7 0 128 57.3 128 128l0 8c0 13.3 10.7 24 24 24s24-10.7 24-24l0-8c0-97.2-78.8-176-176-176l-96 0C78.8 304 0 382.8 0 480l0 8c0 13.3 10.7 24 24 24s24-10.7 24-24l0-8z"
		]
	};
	faUserAlt = faUser;
	faUserLarge = faUser;
	faSnowflake = {
		prefix: "far",
		iconName: "snowflake",
		icon: [
			512,
			512,
			[10052, 10054],
			"f2dc",
			"M280.1-8c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 78.1-23-23c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l57 57 0 76.5-66.2-38.2-20.9-77.8c-3.4-12.8-16.6-20.4-29.4-17S95.2 98 98.7 110.8l8.4 31.5-67.6-39C28 96.6 13.3 100.5 6.7 112S4 138.2 15.5 144.8l67.6 39-31.5 8.4c-12.8 3.4-20.4 16.6-17 29.4s16.6 20.4 29.4 17l77.8-20.9 66.2 38.2-66.2 38.2-77.8-20.9c-12.8-3.4-26 4.2-29.4 17s4.2 26 17 29.4l31.5 8.4-67.6 39C4 373.8 .1 388.5 6.7 400s21.3 15.4 32.8 8.8l67.6-39-8.4 31.5c-3.4 12.8 4.2 26 17 29.4s26-4.2 29.4-17l20.9-77.8 66.2-38.2 0 76.5-57 57c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l23-23 0 78.1c0 13.3 10.7 24 24 24s24-10.7 24-24l0-78.1 23 23c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-57-57 0-76.5 66.2 38.2 20.9 77.8c3.4 12.8 16.6 20.4 29.4 17s20.4-16.6 17-29.4l-8.4-31.5 67.6 39c11.5 6.6 26.2 2.7 32.8-8.8s2.7-26.2-8.8-32.8l-67.6-39 31.5-8.4c12.8-3.4 20.4-16.6 17-29.4s-16.6-20.4-29.4-17l-77.8 20.9-66.2-38.2 66.2-38.2 77.8 20.9c12.8 3.4 26-4.2 29.4-17s-4.2-26-17-29.4l-31.5-8.4 67.6-39c11.5-6.6 15.4-21.3 8.8-32.8s-21.3-15.4-32.8-8.8l-67.6 39 8.4-31.5c3.4-12.8-4.2-26-17-29.4s-26 4.2-29.4 17l-20.9 77.8-66.2 38.2 0-76.5 57-57c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-23 23 0-78.1z"
		]
	};
	faBookmark = {
		prefix: "far",
		iconName: "bookmark",
		icon: [
			384,
			512,
			[128278, 61591],
			"f02e",
			"M0 64C0 28.7 28.7 0 64 0L320 0c35.3 0 64 28.7 64 64l0 417.1c0 25.6-28.5 40.8-49.8 26.6L192 412.8 49.8 507.7C28.5 521.9 0 506.6 0 481.1L0 64zM64 48c-8.8 0-16 7.2-16 16l0 387.2 117.4-78.2c16.1-10.7 37.1-10.7 53.2 0L336 451.2 336 64c0-8.8-7.2-16-16-16L64 48z"
		]
	};
	faSquareCaretLeft = {
		prefix: "far",
		iconName: "square-caret-left",
		icon: [
			448,
			512,
			["caret-square-left"],
			"f191",
			"M48 416c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 80c-8.8 0-16 7.2-16 16l0 320zm16 64c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l320 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480zm64-224c0-6.7 2.8-13 7.7-17.6l112-104c7-6.5 17.2-8.2 25.9-4.4S288 142.5 288 152l0 208c0 9.5-5.7 18.2-14.4 22s-18.9 2.1-25.9-4.4l-112-104c-4.9-4.5-7.7-10.9-7.7-17.6z"
		]
	};
	faCaretSquareLeft = faSquareCaretLeft;
	faHandshake = {
		prefix: "far",
		iconName: "handshake",
		icon: [
			640,
			512,
			[
				129309,
				62662,
				"handshake-alt",
				"handshake-simple"
			],
			"f2b5",
			"M598.1 75.4c10.7-7.8 13.1-22.8 5.3-33.5s-22.8-13.1-33.5-5.3l-74.5 54.2-9.9-6.6C465.8 71 442.6 64 418.9 64l-59.2 0-.4 0-143.6 0c-26.7 0-52.5 8.9-73.4 25.1L70.1 36.6c-10.7-7.8-25.7-5.4-33.5 5.3s-5.4 25.7 5.3 33.5l88 64c9.6 6.9 22.7 5.9 31.1-2.4l3.9-3.9c13.5-13.5 31.8-21.1 50.9-21.1l46.3 0-91.7 91.7c-15.6 15.6-15.6 40.9 0 56.6l.8 .8C218 308 294 308 340.9 261.1l27.1-27.1 97.8 97.8c15.6 15.6 15.6 40.9 0 56.6l-9.8 9.8-31-31c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l28 28c-17.5 10.4-37.2 16.7-57.6 18.5L313 399c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l15 15-3.8 0c-36.1 0-70.7-14.3-96.2-39.8L65 279c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9L160.2 442.1c34.5 34.5 81.3 53.9 130.1 53.9l51.8 0 1 1 1-1 5.7 0c48.8 0 95.6-19.4 130.1-53.9l19.9-19.9c1.2-1.2 2.3-2.3 3.4-3.5 .7-.5 1.3-1.1 1.9-1.7L609 313c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-53.8 53.8c-4.2-12.8-11.3-24.9-21.5-35.1L385 183c-9.4-9.4-24.6-9.4-33.9 0l-44.1 44.1c-26.5 26.5-68.5 28-96.7 4.6l98.7-98.7c13.4-13.4 31.6-21 50.6-21.1l8.5 0 .2 0 50.8 0c14.2 0 28.1 4.2 39.9 12.1L482.7 140c8.4 5.6 19.3 5.3 27.4-.6l88-64z"
		]
	};
	faHandshakeAlt = faHandshake;
	faHandshakeSimple = faHandshake;
	faFaceSmileWink = {
		prefix: "far",
		iconName: "face-smile-wink",
		icon: [
			512,
			512,
			[128521, "smile-wink"],
			"f4da",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm177.3 63.4C192.3 335 218.4 352 256 352s63.7-17 78.7-32.6c9.2-9.6 24.4-9.9 33.9-.7s9.9 24.4 .7 33.9c-22.1 23-60 47.4-113.3 47.4s-91.2-24.4-113.3-47.4c-9.2-9.6-8.9-24.8 .7-33.9s24.8-8.9 33.9 .7zM144 208a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm164 8c0 11-9 20-20 20s-20-9-20-20c0-33.1 26.9-60 60-60l16 0c33.1 0 60 26.9 60 60 0 11-9 20-20 20s-20-9-20-20-9-20-20-20l-16 0c-11 0-20 9-20 20z"
		]
	};
	faSmileWink = faFaceSmileWink;
	faFaceGrinSquintTears = {
		prefix: "far",
		iconName: "face-grin-squint-tears",
		icon: [
			512,
			512,
			[129315, "grin-squint-tears"],
			"f586",
			"M403.1 403.1c67.2-67.2 78.8-168.9 34.9-248l36.7-5.2c4.5-.6 8.8-1.6 13.1-2.8 44.6 94.9 27.7 211.5-50.7 290s-195.1 95.3-290 50.7c1.2-4.2 2.1-8.6 2.8-13.1l5.2-36.7c79.1 43.9 180.8 32.3 248-34.9zM75 75c78.4-78.4 195.1-95.3 290-50.7-1.2 4.2-2.1 8.6-2.8 13.1l-5.2 36.7c-79.1-43.9-180.8-32.3-248 34.9s-78.8 168.9-34.9 248l-36.7 5.2c-4.5 .6-8.8 1.6-13.1 2.8-44.6-94.9-27.7-211.5 50.7-290zM370.9 206.5c5.8-10.9 21.1-12.4 26.4-1.3 25.6 53.5 16.2 119.6-28.2 163.9-44.3 44.3-110.3 53.7-163.8 28.2-11.1-5.3-9.6-20.6 1.3-26.4 32-17.1 64.2-40.8 93.8-70.4 29.7-29.7 53.4-61.9 70.5-94zM93.3 281.9c-1.7-8 2.9-15.9 10.6-18.4l84.6-28c5.7-1.9 12.1-.4 16.3 3.9s5.8 10.6 3.9 16.3l-28 84.6c-2.6 7.7-10.5 12.3-18.4 10.6s-13.4-9-12.7-17.1l3.9-43.1-43.1 3.9c-8.1 .7-15.5-4.7-17.1-12.7zM294.6 110.4l-3.9 43.1 43.1-3.9c8.1-.7 15.5 4.7 17.1 12.7s-2.9 15.9-10.6 18.4l-84.6 28c-5.7 1.9-12.1 .4-16.3-3.9s-5.8-10.6-3.9-16.3l28-84.6c2.6-7.7 10.5-12.3 18.4-10.6s13.4 9 12.7 17.1zM512 51.4c0 25.6-18.8 47.3-44.1 50.9L421.1 109c-10.6 1.5-19.6-7.5-18.1-18.1l6.7-46.7C413.3 18.8 435 0 460.6 0 489 0 512 23 512 51.4zM44.1 409.7L90.9 403c10.6-1.5 19.6 7.5 18.1 18.1l-6.7 46.7C98.7 493.2 77 512 51.4 512 23 512 0 489 0 460.6 0 435 18.8 413.3 44.1 409.7z"
		]
	};
	faGrinSquintTears = faFaceGrinSquintTears;
	faFileAudio = {
		prefix: "far",
		iconName: "file-audio",
		icon: [
			384,
			512,
			[],
			"f1c7",
			"M64 48l112 0 0 88c0 39.8 32.2 72 72 72l88 0 0 240c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16L48 64c0-8.8 7.2-16 16-16zM224 67.9l92.1 92.1-68.1 0c-13.3 0-24-10.7-24-24l0-68.1zM64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-261.5c0-17-6.7-33.3-18.7-45.3L242.7 18.7C230.7 6.7 214.5 0 197.5 0L64 0zM221.9 267.6c-4.7 10-.3 21.9 9.7 26.6 19.2 8.9 32.4 28.3 32.4 50.8s-13.2 41.9-32.4 50.8c-10 4.7-14.4 16.6-9.7 26.6s16.6 14.4 26.6 9.7C281.2 416.8 304 383.6 304 345s-22.8-71.9-55.6-87.1c-10-4.7-21.9-.3-26.6 9.7zM104 305c-13.3 0-24 10.7-24 24l0 32c0 13.3 10.7 24 24 24l16 0 27.2 34c3 3.8 7.6 6 12.5 6l.3 0c8.8 0 16-7.2 16-16l0-128c0-8.8-7.2-16-16-16l-.3 0c-4.9 0-9.5 2.2-12.5 6l-27.2 34-16 0zM223.3 373c9.9-5.4 16.7-16 16.7-28.1s-6.7-22.7-16.7-28.1c-7.8-4.2-15.3 3.3-15.3 12.1l0 32c0 8.8 7.6 16.3 15.3 12.1z"
		]
	};
	faCalendarXmark = {
		prefix: "far",
		iconName: "calendar-xmark",
		icon: [
			448,
			512,
			["calendar-times"],
			"f273",
			"M120 0c13.3 0 24 10.7 24 24l0 40 160 0 0-40c0-13.3 10.7-24 24-24s24 10.7 24 24l0 40 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-40c0-13.3 10.7-24 24-24zm0 112l-56 0c-8.8 0-16 7.2-16 16l0 288c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-288c0-8.8-7.2-16-16-16l-264 0zm171.9 92.1c9.4 9.4 9.4 24.6 0 33.9l-33.9 33.9 33.9 33.9c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-33.9-33.9-33.9 33.9c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l33.9-33.9-33.9-33.9c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l33.9 33.9 33.9-33.9c9.4-9.4 24.6-9.4 33.9 0z"
		]
	};
	faCalendarTimes = faCalendarXmark;
	faCircleDown = {
		prefix: "far",
		iconName: "circle-down",
		icon: [
			512,
			512,
			[61466, "arrow-alt-circle-down"],
			"f358",
			"M256 464a208 208 0 1 1 0-416 208 208 0 1 1 0 416zM256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM244.7 387.3c6.2 6.2 16.4 6.2 22.6 0l104-104c4.6-4.6 5.9-11.5 3.5-17.4S366.5 256 360 256l-72 0 0-104c0-13.3-10.7-24-24-24l-16 0c-13.3 0-24 10.7-24 24l0 104-72 0c-6.5 0-12.3 3.9-14.8 9.9s-1.1 12.9 3.5 17.4l104 104z"
		]
	};
	faArrowAltCircleDown = faCircleDown;
	faFileLines = {
		prefix: "far",
		iconName: "file-lines",
		icon: [
			384,
			512,
			[
				128441,
				128462,
				61686,
				"file-alt",
				"file-text"
			],
			"f15c",
			"M64 48l112 0 0 88c0 39.8 32.2 72 72 72l88 0 0 240c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16L48 64c0-8.8 7.2-16 16-16zM224 67.9l92.1 92.1-68.1 0c-13.3 0-24-10.7-24-24l0-68.1zM64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-261.5c0-17-6.7-33.3-18.7-45.3L242.7 18.7C230.7 6.7 214.5 0 197.5 0L64 0zm56 256c-13.3 0-24 10.7-24 24s10.7 24 24 24l144 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-144 0zm0 96c-13.3 0-24 10.7-24 24s10.7 24 24 24l144 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-144 0z"
		]
	};
	faFileAlt = faFileLines;
	faFileText = faFileLines;
	faComments = {
		prefix: "far",
		iconName: "comments",
		icon: [
			576,
			512,
			[128490, 61670],
			"f086",
			"M76.2 258.7c6.1-15.2 4-32.6-5.6-45.9-14.5-20.1-22.6-43.7-22.6-68.8 0-66.8 60.5-128 144-128s144 61.2 144 128-60.5 128-144 128c-15.9 0-31.1-2.3-45.3-6.5-10.3-3.1-21.4-2.5-31.4 1.5l-50.4 20.2 11.4-28.5zM0 144c0 35.8 11.6 69.1 31.7 96.8L1.9 315.2c-1.3 3.2-1.9 6.6-1.9 10 0 14.8 12 26.8 26.8 26.8 3.4 0 6.8-.7 10-1.9l96.3-38.5c18.6 5.5 38.4 8.4 58.9 8.4 106 0 192-78.8 192-176S298-32 192-32 0 46.8 0 144zM384 512c20.6 0 40.3-3 58.9-8.4l96.3 38.5c3.2 1.3 6.6 1.9 10 1.9 14.8 0 26.8-12 26.8-26.8 0-3.4-.7-6.8-1.9-10l-29.7-74.4c20-27.8 31.7-61.1 31.7-96.8 0-82.4-61.7-151.5-145-170.7-1.6 16.3-5.1 31.9-10.1 46.9 63.9 14.8 107.2 67.3 107.2 123.9 0 25.1-8.1 48.7-22.6 68.8-9.6 13.3-11.7 30.6-5.6 45.9l11.4 28.5-50.4-20.2c-10-4-21.1-4.5-31.4-1.5-14.2 4.2-29.4 6.5-45.3 6.5-72.2 0-127.1-45.7-140.7-101.2-15.6 3.2-31.7 5-48.1 5.2 16.4 81.9 94.7 144 188.8 144z"
		]
	};
	faCircleCheck = {
		prefix: "far",
		iconName: "circle-check",
		icon: [
			512,
			512,
			[61533, "check-circle"],
			"f058",
			"M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-464a208 208 0 1 0 0 416 208 208 0 1 0 0-416zm70.7 121.9c7.8-10.7 22.8-13.1 33.5-5.3 10.7 7.8 13.1 22.8 5.3 33.5L243.4 366.1c-4.1 5.7-10.5 9.3-17.5 9.8-7 .5-13.9-2-18.8-6.9l-55.9-55.9c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l36 36 105.6-145.2z"
		]
	};
	faCheckCircle = faCircleCheck;
	faMoon = {
		prefix: "far",
		iconName: "moon",
		icon: [
			512,
			512,
			[127769, 9214],
			"f186",
			"M239.3 48.7c-107.1 8.5-191.3 98.1-191.3 207.3 0 114.9 93.1 208 208 208 33.3 0 64.7-7.8 92.6-21.7-103.4-23.4-180.6-115.8-180.6-226.3 0-65.8 27.4-125.1 71.3-167.3zM0 256c0-141.4 114.6-256 256-256 19.4 0 38.4 2.2 56.7 6.3 9.9 2.2 17.3 10.5 18.5 20.5s-4 19.8-13.1 24.4c-60.6 30.2-102.1 92.7-102.1 164.8 0 101.6 82.4 184 184 184 5 0 9.9-.2 14.8-.6 10.1-.8 19.6 4.8 23.8 14.1s2 20.1-5.3 27.1C387.3 484.8 324.8 512 256 512 114.6 512 0 397.4 0 256z"
		]
	};
	faClosedCaptioning = {
		prefix: "far",
		iconName: "closed-captioning",
		icon: [
			512,
			512,
			[],
			"f20a",
			"M448 112c8.8 0 16 7.2 16 16l0 256c0 8.8-7.2 16-16 16L64 400c-8.8 0-16-7.2-16-16l0-256c0-8.8 7.2-16 16-16l384 0zM64 64C28.7 64 0 92.7 0 128L0 384c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L64 64zm88 144l32 0c4.4 0 8 3.6 8 8 0 13.3 10.7 24 24 24s24-10.7 24-24c0-30.9-25.1-56-56-56l-32 0c-30.9 0-56 25.1-56 56l0 80c0 30.9 25.1 56 56 56l32 0c30.9 0 56-25.1 56-56 0-13.3-10.7-24-24-24s-24 10.7-24 24c0 4.4-3.6 8-8 8l-32 0c-4.4 0-8-3.6-8-8l0-80c0-4.4 3.6-8 8-8zm168 8c0-4.4 3.6-8 8-8l32 0c4.4 0 8 3.6 8 8 0 13.3 10.7 24 24 24s24-10.7 24-24c0-30.9-25.1-56-56-56l-32 0c-30.9 0-56 25.1-56 56l0 80c0 30.9 25.1 56 56 56l32 0c30.9 0 56-25.1 56-56 0-13.3-10.7-24-24-24s-24 10.7-24 24c0 4.4-3.6 8-8 8l-32 0c-4.4 0-8-3.6-8-8l0-80z"
		]
	};
	faImages = {
		prefix: "far",
		iconName: "images",
		icon: [
			576,
			512,
			[],
			"f302",
			"M480 80c8.8 0 16 7.2 16 16l0 256c0 8.8-7.2 16-16 16l-320 0c-8.8 0-16-7.2-16-16l0-256c0-8.8 7.2-16 16-16l320 0zM160 32c-35.3 0-64 28.7-64 64l0 256c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L160 32zm80 112a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm140.7 3.8c-4.3-7.3-12.2-11.8-20.7-11.8s-16.4 4.5-20.7 11.8l-46.5 79-17.2-24.6c-4.5-6.4-11.8-10.2-19.7-10.2s-15.2 3.8-19.7 10.2l-56 80c-5.1 7.3-5.8 16.9-1.6 24.8S191.1 320 200 320l240 0c8.6 0 16.6-4.6 20.8-12.1s4.2-16.7-.1-24.1l-80-136zM48 152c0-13.3-10.7-24-24-24S0 138.7 0 152L0 448c0 35.3 28.7 64 64 64l360 0c13.3 0 24-10.7 24-24s-10.7-24-24-24L64 464c-8.8 0-16-7.2-16-16l0-296z"
		]
	};
	faCircleRight = {
		prefix: "far",
		iconName: "circle-right",
		icon: [
			512,
			512,
			[61838, "arrow-alt-circle-right"],
			"f35a",
			"M464 256a208 208 0 1 1 -416 0 208 208 0 1 1 416 0zM0 256a256 256 0 1 0 512 0 256 256 0 1 0 -512 0zm387.3 11.3c6.2-6.2 6.2-16.4 0-22.6l-104-104c-4.6-4.6-11.5-5.9-17.4-3.5S256 145.5 256 152l0 72-104 0c-13.3 0-24 10.7-24 24l0 16c0 13.3 10.7 24 24 24l104 0 0 72c0 6.5 3.9 12.3 9.9 14.8s12.9 1.1 17.4-3.5l104-104z"
		]
	};
	faArrowAltCircleRight = faCircleRight;
	faIdCard = {
		prefix: "far",
		iconName: "id-card",
		icon: [
			576,
			512,
			[62147, "drivers-license"],
			"f2c2",
			"M48 416l0-256 480 0 0 256c0 8.8-7.2 16-16 16l-192 0c0-44.2-35.8-80-80-80l-64 0c-44.2 0-80 35.8-80 80l-32 0c-8.8 0-16-7.2-16-16zM64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32zM208 312a56 56 0 1 0 0-112 56 56 0 1 0 0 112zM376 208c-13.3 0-24 10.7-24 24s10.7 24 24 24l80 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-80 0zm0 96c-13.3 0-24 10.7-24 24s10.7 24 24 24l80 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-80 0z"
		]
	};
	faDriversLicense = faIdCard;
	faCirclePlay = {
		prefix: "far",
		iconName: "circle-play",
		icon: [
			512,
			512,
			[61469, "play-circle"],
			"f144",
			"M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM212.5 147.5c-7.4-4.5-16.7-4.7-24.3-.5S176 159.3 176 168l0 176c0 8.7 4.7 16.7 12.3 20.9s16.8 4.1 24.3-.5l144-88c7.1-4.4 11.5-12.1 11.5-20.5s-4.4-16.1-11.5-20.5l-144-88zM298 256l-74 45.2 0-90.4 74 45.2z"
		]
	};
	faPlayCircle = faCirclePlay;
	faFaceLaughBeam = {
		prefix: "far",
		iconName: "face-laugh-beam",
		icon: [
			512,
			512,
			[128513, "laugh-beam"],
			"f59a",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm118.3 58.2c-4.2-13.7 7.1-26.2 21.4-26.2l232.6 0c14.3 0 25.6 12.5 21.4 26.2-18 58.9-72.9 101.8-137.7 101.8S136.3 373.1 118.3 314.2zM176 180c-15.5 0-28 12.5-28 28l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-37.6 30.4-68 68-68s68 30.4 68 68l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-15.5-12.5-28-28-28zm132 28l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-37.6 30.4-68 68-68s68 30.4 68 68l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-15.5-12.5-28-28-28s-28 12.5-28 28z"
		]
	};
	faLaughBeam = faFaceLaughBeam;
	faAddressBook = {
		prefix: "far",
		iconName: "address-book",
		icon: [
			512,
			512,
			[62138, "contact-book"],
			"f2b9",
			"M384 48c8.8 0 16 7.2 16 16l0 384c0 8.8-7.2 16-16 16L96 464c-8.8 0-16-7.2-16-16L80 64c0-8.8 7.2-16 16-16l288 0zM96 0C60.7 0 32 28.7 32 64l0 384c0 35.3 28.7 64 64 64l288 0c35.3 0 64-28.7 64-64l0-384c0-35.3-28.7-64-64-64L96 0zM240 248a56 56 0 1 0 0-112 56 56 0 1 0 0 112zm-32 40c-44.2 0-80 35.8-80 80 0 8.8 7.2 16 16 16l192 0c8.8 0 16-7.2 16-16 0-44.2-35.8-80-80-80l-64 0zM512 80c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 64c0 8.8 7.2 16 16 16s16-7.2 16-16l0-64zM496 192c-8.8 0-16 7.2-16 16l0 64c0 8.8 7.2 16 16 16s16-7.2 16-16l0-64c0-8.8-7.2-16-16-16zm16 144c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 64c0 8.8 7.2 16 16 16s16-7.2 16-16l0-64z"
		]
	};
	faContactBook = faAddressBook;
	faHourglass = {
		prefix: "far",
		iconName: "hourglass",
		icon: [
			384,
			512,
			[
				9203,
				62032,
				"hourglass-empty"
			],
			"f254",
			"M24 0C10.7 0 0 10.7 0 24S10.7 48 24 48l8 0 0 19c0 40.3 16 79 44.5 107.5l81.5 81.5-81.5 81.5C48 366 32 404.7 32 445l0 19-8 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l336 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-8 0 0-19c0-40.3-16-79-44.5-107.5l-81.5-81.5 81.5-81.5C336 146 352 107.3 352 67l0-19 8 0c13.3 0 24-10.7 24-24S373.3 0 360 0L24 0zM192 289.9l81.5 81.5C293 391 304 417.4 304 445l0 19-224 0 0-19c0-27.6 11-54 30.5-73.5L192 289.9zm0-67.9l-81.5-81.5C91 121 80 94.6 80 67l0-19 224 0 0 19c0 27.6-11 54-30.5 73.5L192 222.1z"
		]
	};
	faHourglassEmpty = faHourglass;
	faHeadphones = {
		prefix: "far",
		iconName: "headphones",
		icon: [
			448,
			512,
			[
				127911,
				62863,
				"headphones-alt",
				"headphones-simple"
			],
			"f025",
			"M48 224c0-97.2 78.8-176 176-176s176 78.8 176 176l0 44.8c-14.1-8.2-30.5-12.8-48-12.8l-16 0c-26.5 0-48 21.5-48 48l0 128c0 26.5 21.5 48 48 48l16 0c53 0 96-43 96-96l0-160C448 100.3 347.7 0 224 0S0 100.3 0 224L0 384c0 53 43 96 96 96l16 0c26.5 0 48-21.5 48-48l0-128c0-26.5-21.5-48-48-48l-16 0c-17.5 0-33.9 4.7-48 12.8L48 224zm0 128c0-26.5 21.5-48 48-48l16 0 0 128-16 0c-26.5 0-48-21.5-48-48l0-32zm352 0l0 32c0 26.5-21.5 48-48 48l-16 0 0-128 16 0c26.5 0 48 21.5 48 48z"
		]
	};
	faHeadphonesAlt = faHeadphones;
	faHeadphonesSimple = faHeadphones;
	faFilePowerpoint = {
		prefix: "far",
		iconName: "file-powerpoint",
		icon: [
			384,
			512,
			[],
			"f1c4",
			"M64 48l112 0 0 88c0 39.8 32.2 72 72 72l88 0 0 240c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16L48 64c0-8.8 7.2-16 16-16zM224 67.9l92.1 92.1-68.1 0c-13.3 0-24-10.7-24-24l0-68.1zM64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-261.5c0-17-6.7-33.3-18.7-45.3L242.7 18.7C230.7 6.7 214.5 0 197.5 0L64 0zm88 256c-13.3 0-24 10.7-24 24l0 128c0 13.3 10.7 24 24 24s24-10.7 24-24l0-16 28 0c37.6 0 68-30.4 68-68s-30.4-68-68-68l-52 0zm52 88l-28 0 0-40 28 0c11 0 20 9 20 20s-9 20-20 20z"
		]
	};
	faWindowMaximize = {
		prefix: "far",
		iconName: "window-maximize",
		icon: [
			512,
			512,
			[128470],
			"f2d0",
			"M48 224l0 160c0 8.8 7.2 16 16 16l384 0c8.8 0 16-7.2 16-16l0-160-416 0zM0 128C0 92.7 28.7 64 64 64l384 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128z"
		]
	};
	faCommentDots = {
		prefix: "far",
		iconName: "comment-dots",
		icon: [
			512,
			512,
			[
				128172,
				62075,
				"commenting"
			],
			"f4ad",
			"M0 240c0 54.4 19.3 104.6 51.9 144.9L3.1 474.3c-2 3.7-3.1 7.9-3.1 12.2 0 14.1 11.4 25.5 25.5 25.5 4 0 7.8-.6 11.5-2.1L153.4 460c31.4 12.9 66.1 20 102.6 20 141.4 0 256-107.5 256-240S397.4 0 256 0 0 107.5 0 240zM94 407.9c9.3-17.1 7.4-38.1-4.8-53.2-26.1-32.3-41.2-71.9-41.2-114.7 0-103.2 90.2-192 208-192s208 88.8 208 192-90.2 192-208 192c-30.2 0-58.7-5.9-84.3-16.4-11.9-4.9-25.3-4.8-37.1 .3L76 440.9 94 407.9zM144 272a32 32 0 1 0 0-64 32 32 0 1 0 0 64zm144-32a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm80 32a32 32 0 1 0 0-64 32 32 0 1 0 0 64z"
		]
	};
	faCommenting = faCommentDots;
	faFaceGrinTongueWink = {
		prefix: "far",
		iconName: "face-grin-tongue-wink",
		icon: [
			512,
			512,
			[128540, "grin-tongue-wink"],
			"f58b",
			"M366.9 432c.8-5.2 1.1-10.6 1.1-16l0-53.5c10.2-12.6 18.3-26.9 23.8-42.5 4.1-11.6-7.8-21.4-19.6-17.8-34.8 10.6-74.3 16.6-116.3 16.6-41.9 0-81.4-6-116.1-16.5-11.8-3.6-23.7 6.1-19.6 17.8 5.5 15.5 13.6 29.9 23.8 42.4l0 53.5c0 5.4 .4 10.8 1.1 16-58.4-36.8-97.1-101.9-97.1-176 0-114.9 93.1-208 208-208s208 93.1 208 208c0 74.1-38.8 139.2-97.1 176zm-38.8 69.7C434.4 470.6 512 372.3 512 256 512 114.6 397.4 0 256 0S0 114.6 0 256C0 372.3 77.6 470.6 183.9 501.7 203.4 518.1 228.5 528 256 528s52.6-9.9 72.1-26.3zM320 378.6l0 37.4c0 35.3-28.7 64-64 64s-64-28.7-64-64l0-37.4c0-14.7 11.9-26.6 26.6-26.6l2 0c11.3 0 21.1 7.9 23.6 18.9 2.8 12.6 20.8 12.6 23.6 0 2.5-11.1 12.3-18.9 23.6-18.9l2 0c14.7 0 26.6 11.9 26.6 26.6zM132 232c0-11 9-20 20-20l16 0c11 0 20 9 20 20s9 20 20 20 20-9 20-20c0-33.1-26.9-60-60-60l-16 0c-33.1 0-60 26.9-60 60 0 11 9 20 20 20s20-9 20-20zm228.4-24a24 24 0 1 0 -48 0 24 24 0 1 0 48 0zM288 208a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm128 0a80 80 0 1 0 -160 0 80 80 0 1 0 160 0z"
		]
	};
	faGrinTongueWink = faFaceGrinTongueWink;
	faHourglassHalf = {
		prefix: "far",
		iconName: "hourglass-half",
		icon: [
			384,
			512,
			["hourglass-2"],
			"f252",
			"M0 24C0 10.7 10.7 0 24 0L360 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-8 0 0 19c0 40.3-16 79-44.5 107.5l-81.5 81.5 81.5 81.5C336 366 352 404.7 352 445l0 19 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24L24 512c-13.3 0-24-10.7-24-24s10.7-24 24-24l8 0 0-19c0-40.3 16-79 44.5-107.5l81.5-81.5-81.5-81.5C48 146 32 107.3 32 67l0-19-8 0C10.7 48 0 37.3 0 24zM110.5 371.5c-3.9 3.9-7.5 8.1-10.7 12.5l184.4 0c-3.2-4.4-6.8-8.6-10.7-12.5l-81.5-81.5-81.5 81.5zM80.8 432c-.5 4.3-.8 8.6-.8 13l0 19 224 0 0-19c0-4.4-.3-8.7-.8-13L80.8 432zM254.1 160l-124.1 0 62.1 62.1 62.1-62.1zm39.7-48C300.4 98.1 304 82.7 304 67l0-19-224 0 0 19c0 15.7 3.6 31.1 10.2 45l203.5 0z"
		]
	};
	faHourglass2 = faHourglassHalf;
	faCreditCard = {
		prefix: "far",
		iconName: "credit-card",
		icon: [
			512,
			512,
			[
				128179,
				62083,
				"credit-card-alt"
			],
			"f09d",
			"M448 112c8.8 0 16 7.2 16 16l0 32-416 0 0-32c0-8.8 7.2-16 16-16l384 0zm16 112l0 160c0 8.8-7.2 16-16 16L64 400c-8.8 0-16-7.2-16-16l0-160 416 0zM64 64C28.7 64 0 92.7 0 128L0 384c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L64 64zM80 344c0 13.3 10.7 24 24 24l48 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-48 0c-13.3 0-24 10.7-24 24zm144 0c0 13.3 10.7 24 24 24l64 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-64 0c-13.3 0-24 10.7-24 24z"
		]
	};
	faCreditCardAlt = faCreditCard;
	faHandSpock = {
		prefix: "far",
		iconName: "hand-spock",
		icon: [
			512,
			512,
			[128406],
			"f259",
			"M138.3 80.8c-9.2-33.8 10.5-68.8 44.3-78.4 34-9.6 69.4 10.2 79 44.2L291.9 153.7 305.1 84c6.6-34.7 40.1-57.5 74.8-50.9 31.4 6 53 33.9 52 64.9 10-2.6 20.8-2.8 31.5-.1 34.3 8.6 55.1 43.3 46.6 77.6L454.7 397.2C437.8 464.7 377.2 512 307.6 512l-33.7 0c-56.9 0-112.2-19-157.2-53.9l-92-71.6c-27.9-21.7-32.9-61.9-11.2-89.8s61.9-32.9 89.8-11.2l17 13.2-51.8-131.2c-13-32.9 3.2-70.1 36-83 11.1-4.4 22.7-5.4 33.7-3.7zm77.1-21.2c-2.4-8.5-11.2-13.4-19.7-11s-13.4 11.2-11 19.7l54.8 182.4c3.5 12.3-3.3 25.2-15.4 29.3s-25.3-2-30-13.9L142.9 138.1c-3.2-8.2-12.5-12.3-20.8-9s-12.3 12.5-9 20.8l73.3 185.6c12 30.3-23.7 57-49.4 37L73.8 323.4c-7-5.4-17-4.2-22.5 2.8s-4.2 17 2.8 22.5l92 71.6c36.5 28.4 81.4 43.8 127.7 43.8l33.7 0c47.5 0 89-32.4 100.5-78.5l55.4-221.6c2.1-8.6-3.1-17.3-11.6-19.4s-17.3 3.1-19.4 11.6l-26 104c-2.9 11.7-13.4 19.9-25.5 19.9-16.5 0-28.9-15-25.8-31.2L383.7 99c1.7-8.7-4-17.1-12.7-18.7S354 84.3 352.3 93L320.5 260c-2.2 11.6-12.4 20-24.2 20-11 0-20.7-7.3-23.7-17.9L215.4 59.6z"
		]
	};
	faBellSlash = {
		prefix: "far",
		iconName: "bell-slash",
		icon: [
			576,
			512,
			[128277, 61943],
			"f1f6",
			"M41-24.9c-9.4-9.4-24.6-9.4-33.9 0S-2.3-.3 7 9.1l528 528c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-87.8-87.8c17.5-3.3 30.8-18.7 30.8-37.1 0-6.7-1.8-13.3-5.1-19L485 321.7c-19-32.6-29-69.6-29-107.3l0-14.5c0-84.6-62.6-154.7-144-166.3l0-9.7c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 9.7c-42.2 6-79.4 27.8-105.4 59.1L41-24.9zM192.8 126.9C214.7 98.4 249.2 80 288 80 354.3 80 408 133.7 408 200l0 14.5c0 46.2 12.3 91.5 35.5 131.4l12.9 22.1-22.6 0-241.1-241.1zM132.5 345.9c19.5-33.4 31.3-70.7 34.6-109l-46.7-46.7c-.2 3.3-.3 6.6-.3 9.9l0 14.5c0 37.7-10 74.7-29 107.3L69.1 359.2c-3.4 5.8-5.1 12.3-5.1 19 0 20.9 16.9 37.8 37.8 37.8l244.4 0-48-48-178.6 0 12.9-22.1zM220.1 464c9.9 28 36.6 48 67.9 48s58-20 67.9-48l-135.8 0z"
		]
	};
	faStar = {
		prefix: "far",
		iconName: "star",
		icon: [
			576,
			512,
			[11088, 61446],
			"f005",
			"M288.1-32c9 0 17.3 5.1 21.4 13.1L383 125.3 542.9 150.7c8.9 1.4 16.3 7.7 19.1 16.3s.5 18-5.8 24.4L441.7 305.9 467 465.8c1.4 8.9-2.3 17.9-9.6 23.2s-17 6.1-25 2L288.1 417.6 143.8 491c-8 4.1-17.7 3.3-25-2s-11-14.2-9.6-23.2L134.4 305.9 20 191.4c-6.4-6.4-8.6-15.8-5.8-24.4s10.1-14.9 19.1-16.3l159.9-25.4 73.6-144.2c4.1-8 12.4-13.1 21.4-13.1zm0 76.8L230.3 158c-3.5 6.8-10 11.6-17.6 12.8l-125.5 20 89.8 89.9c5.4 5.4 7.9 13.1 6.7 20.7l-19.8 125.5 113.3-57.6c6.8-3.5 14.9-3.5 21.8 0l113.3 57.6-19.8-125.5c-1.2-7.6 1.3-15.3 6.7-20.7l89.8-89.9-125.5-20c-7.6-1.2-14.1-6-17.6-12.8L288.1 44.8z"
		]
	};
	faFlag = {
		prefix: "far",
		iconName: "flag",
		icon: [
			448,
			512,
			[127988, 61725],
			"f024",
			"M48 24C48 10.7 37.3 0 24 0S0 10.7 0 24L0 488c0 13.3 10.7 24 24 24s24-10.7 24-24l0-100 80.3-20.1c41.1-10.3 84.6-5.5 122.5 13.4 44.2 22.1 95.5 24.8 141.7 7.4l34.7-13c12.5-4.7 20.8-16.6 20.8-30l0-279.7c0-23-24.2-38-44.8-27.7l-9.6 4.8c-46.3 23.2-100.8 23.2-147.1 0-35.1-17.6-75.4-22-113.5-12.5L48 52 48 24zm0 77.5l96.6-24.2c27-6.7 55.5-3.6 80.4 8.8 54.9 27.4 118.7 29.7 175 6.8l0 241.8-24.4 9.1c-33.7 12.6-71.2 10.7-103.4-5.4-48.2-24.1-103.3-30.1-155.6-17.1l-68.6 17.2 0-237z"
		]
	};
	faLemon = {
		prefix: "far",
		iconName: "lemon",
		icon: [
			448,
			512,
			[127819],
			"f094",
			"M368 80c-3.2 0-6.2 .4-8.9 1.3-19.1 5.5-46.1 10.7-74.3 3.3-57.4-14.9-124.6 7.4-174.7 57.5S37.7 259.4 52.6 316.8c7.3 28.2 2.2 55.2-3.3 74.3-.8 2.8-1.3 5.8-1.3 8.9 0 17.7 14.3 32 32 32 3.2 0 6.2-.4 8.9-1.3 19.1-5.5 46.1-10.7 74.3-3.3 57.4 14.9 124.6-7.4 174.7-57.5s72.4-117.3 57.5-174.7c-7.3-28.2-2.2-55.2 3.3-74.3 .8-2.8 1.3-5.8 1.3-8.9 0-17.7-14.3-32-32-32zm0-48c44.2 0 80 35.8 80 80 0 7.7-1.1 15.2-3.1 22.3-4.6 15.8-7.1 32.9-3 48.9 20.1 77.6-10.9 161.5-70 220.7s-143.1 90.2-220.7 70c-16-4.1-33-1.6-48.9 3-7.1 2-14.6 3.1-22.3 3.1-44.2 0-80-35.8-80-80 0-7.7 1.1-15.2 3.1-22.3 4.6-15.8 7.1-32.9 3-48.9-20.1-77.6 10.9-161.5 70-220.7S219.3 18 296.8 38.1c16 4.1 33 1.6 48.9-3 7.1-2 14.6-3.1 22.3-3.1zM246.7 167c-52 15.2-96.5 59.7-111.7 111.7-3.7 12.7-17.1 20-29.8 16.3S85.2 278 89 265.3c19.8-67.7 76.6-124.5 144.3-144.3 12.7-3.7 26.1 3.6 29.8 16.3s-3.6 26.1-16.3 29.8z"
		]
	};
	faWindowRestore = {
		prefix: "far",
		iconName: "window-restore",
		icon: [
			576,
			512,
			[],
			"f2d2",
			"M512 80L224 80c-8.8 0-16 7.2-16 16l0 16-48 0 0-16c0-35.3 28.7-64 64-64l288 0c35.3 0 64 28.7 64 64l0 192c0 35.3-28.7 64-64 64l-48 0 0-48 48 0c8.8 0 16-7.2 16-16l0-192c0-8.8-7.2-16-16-16zM368 288l-320 0 0 128c0 8.8 7.2 16 16 16l288 0c8.8 0 16-7.2 16-16l0-128zM64 160l288 0c35.3 0 64 28.7 64 64l0 192c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 224c0-35.3 28.7-64 64-64z"
		]
	};
	faFaceGrinHearts = {
		prefix: "far",
		iconName: "face-grin-hearts",
		icon: [
			512,
			512,
			[128525, "grin-hearts"],
			"f584",
			"M464 256c0 114.9-93.1 208-208 208S48 370.9 48 256c0-3.5 .1-7.1 .3-10.6-14-13.9-29.7-33.1-39.3-56.7-5.8 21.4-8.9 44-8.9 67.3 0 141.4 114.6 256 256 256S512 397.4 512 256c0-23.3-3.1-45.9-8.9-67.3-9.6 23.7-25.4 42.8-39.3 56.7 .2 3.5 .3 7 .3 10.6zM368 58.9c11.7-6 24.5-9.6 37.7-10.6-42.1-30.4-93.8-48.3-149.7-48.3S148.4 17.9 106.3 48.3c13.2 1 26 4.6 37.7 10.6 13.8-7.1 29.3-10.9 45.1-10.9l2.9 0c8.9 0 17.6 1.2 25.8 3.5 12.4-2.3 25.2-3.5 38.2-3.5s25.8 1.2 38.2 3.5c8.2-2.3 16.9-3.5 25.8-3.5l2.9 0c15.8 0 31.3 3.8 45.1 10.9zm4.2 243.4c-34.8 10.6-74.3 16.6-116.3 16.6-41.9 0-81.4-6-116.1-16.5-11.8-3.6-23.7 6.1-19.6 17.8 19.8 55.9 73.1 95.9 135.8 95.9 62.7 0 116-40.1 135.8-96 4.1-11.6-7.8-21.4-19.6-17.8zM322.9 96L320 96c-26.5 0-48 21.5-48 48 0 53.4 66.9 95.7 89 108.2 4.4 2.5 9.6 2.5 14 0 22.1-12.5 89-54.8 89-108.2 0-26.5-21.5-48-48-48l-2.9 0c-13.5 0-26.5 5.4-36 14.9l-9.1 9.1-9.1-9.1c-9.5-9.5-22.5-14.9-36-14.9zm-188 14.9c-9.5-9.5-22.5-14.9-36-14.9L96 96c-26.5 0-48 21.5-48 48 0 53.4 66.9 95.7 89 108.2 4.4 2.5 9.6 2.5 14 0 22.1-12.5 89-54.8 89-108.2 0-26.5-21.5-48-48-48l-2.9 0c-13.5 0-26.5 5.4-36 14.9l-9.1 9.1-9.1-9.1z"
		]
	};
	faGrinHearts = faFaceGrinHearts;
	faFaceKissBeam = {
		prefix: "far",
		iconName: "face-kiss-beam",
		icon: [
			512,
			512,
			[128537, "kiss-beam"],
			"f597",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm240 16l32 0c26.5 0 48 21.5 48 48 0 12.3-4.6 23.5-12.2 32 7.6 8.5 12.2 19.7 12.2 32 0 26.5-21.5 48-48 48l-32 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l16 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-16 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm-64-92c-15.5 0-28 12.5-28 28l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-37.6 30.4-68 68-68s68 30.4 68 68l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-15.5-12.5-28-28-28zm132 28l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-37.6 30.4-68 68-68s68 30.4 68 68l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-15.5-12.5-28-28-28s-28 12.5-28 28z"
		]
	};
	faKissBeam = faFaceKissBeam;
	faFilePdf = {
		prefix: "far",
		iconName: "file-pdf",
		icon: [
			576,
			512,
			[],
			"f1c1",
			"M208 48L96 48c-8.8 0-16 7.2-16 16l0 384c0 8.8 7.2 16 16 16l80 0 0 48-80 0c-35.3 0-64-28.7-64-64L32 64C32 28.7 60.7 0 96 0L229.5 0c17 0 33.3 6.7 45.3 18.7L397.3 141.3c12 12 18.7 28.3 18.7 45.3l0 149.5-48 0 0-128-88 0c-39.8 0-72-32.2-72-72l0-88zM348.1 160L256 67.9 256 136c0 13.3 10.7 24 24 24l68.1 0zM240 380l32 0c33.1 0 60 26.9 60 60s-26.9 60-60 60l-12 0 0 28c0 11-9 20-20 20s-20-9-20-20l0-128c0-11 9-20 20-20zm32 80c11 0 20-9 20-20s-9-20-20-20l-12 0 0 40 12 0zm96-80l32 0c28.7 0 52 23.3 52 52l0 64c0 28.7-23.3 52-52 52l-32 0c-11 0-20-9-20-20l0-128c0-11 9-20 20-20zm32 128c6.6 0 12-5.4 12-12l0-64c0-6.6-5.4-12-12-12l-12 0 0 88 12 0zm76-108c0-11 9-20 20-20l48 0c11 0 20 9 20 20s-9 20-20 20l-28 0 0 24 28 0c11 0 20 9 20 20s-9 20-20 20l-28 0 0 44c0 11-9 20-20 20s-20-9-20-20l0-128z"
		]
	};
	faFaceGrinWide = {
		prefix: "far",
		iconName: "face-grin-wide",
		icon: [
			512,
			512,
			[128515, "grin-alt"],
			"f581",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm372.2 46.3c11.8-3.6 23.7 6.1 19.6 17.8-19.8 55.9-73.1 96-135.8 96-62.7 0-116-40-135.8-95.9-4.1-11.6 7.8-21.4 19.6-17.8 34.7 10.6 74.2 16.5 116.1 16.5 42 0 81.5-6 116.3-16.6zM224 192c0 35.3-14.3 64-32 64s-32-28.7-32-64 14.3-64 32-64 32 28.7 32 64zm96 64c-17.7 0-32-28.7-32-64s14.3-64 32-64 32 28.7 32 64-14.3 64-32 64z"
		]
	};
	faGrinAlt = faFaceGrinWide;
	faFaceLaughSquint = {
		prefix: "far",
		iconName: "face-laugh-squint",
		icon: [
			512,
			512,
			["laugh-squint"],
			"f59b",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm125.2 76.4c-6.5-14 5-28.4 20.4-28.4l220.8 0c15.4 0 26.8 14.4 20.4 28.4-22.8 49.4-72.8 83.6-130.8 83.6s-107.9-34.2-130.8-83.6zm-2.6-173.2c4.5-6.8 13.3-9.2 20.6-5.5l79.6 40c5.4 2.7 8.8 8.2 8.8 14.3s-3.4 11.6-8.8 14.3l-79.6 40c-7.3 3.6-16.1 1.3-20.6-5.5s-3.1-15.9 3.1-21.1L159 208 125.8 180.3c-6.2-5.2-7.6-14.3-3.1-21.1zm263.6 21.1L353 208 386.2 235.7c6.2 5.2 7.6 14.3 3.1 21.1s-13.3 9.2-20.6 5.5l-79.6-40c-5.4-2.7-8.8-8.2-8.8-14.3s3.4-11.6 8.8-14.3l79.6-40c7.3-3.6 16.1-1.3 20.6 5.5s3.1 15.9-3.1 21.1z"
		]
	};
	faLaughSquint = faFaceLaughSquint;
	faFaceKissWinkHeart = {
		prefix: "far",
		iconName: "face-kiss-wink-heart",
		icon: [
			640,
			512,
			[128536, "kiss-wink-heart"],
			"f598",
			"M386 439.5c-29.2 15.6-62.5 24.5-98 24.5-114.9 0-208-93.1-208-208S173.2 48 288 48c113.2 0 205.2 90.4 207.9 202.9 14.3 1.5 28.6 6 41.9 13.7 2 1.2 4 2.4 5.9 3.7 .2-4.1 .3-8.2 .3-12.3 0-141.4-114.6-256-256-256S32 114.6 32 256 146.6 512 288 512c41.4 0 80.5-9.8 115.1-27.3-5.8-12.9-12-28.5-17.2-45.2zM256 288c0 8.8 7.2 16 16 16l16 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-16 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l16 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-16 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c26.5 0 48-21.5 48-48 0-12.3-4.6-23.5-12.2-32 7.6-8.5 12.2-19.7 12.2-32 0-26.5-21.5-48-48-48l-32 0c-8.8 0-16 7.2-16 16zm-48-48a32 32 0 1 0 0-64 32 32 0 1 0 0 64zm152-44l16 0c11 0 20 9 20 20s9 20 20 20 20-9 20-20c0-33.1-26.9-60-60-60l-16 0c-33.1 0-60 26.9-60 60 0 11 9 20 20 20s20-9 20-20 9-20 20-20zM542.8 350c-2.2-18.3-12.9-34.6-28.9-43.8-28.1-16.2-63.9-6.6-80.1 21.5l-2.7 4.6c-24.5 42.5 7.9 117.9 24.4 150.8 5.1 10.1 15.5 16.1 26.8 15.5 36.7-2.2 118.2-11.7 142.8-54.2l2.7-4.6c16.2-28.1 6.6-63.9-21.5-80.1-16-9.2-35.4-10.4-52.4-3.1l-9.8 4.2-1.3-10.6z"
		]
	};
	faKissWinkHeart = faFaceKissWinkHeart;
	faCopy = {
		prefix: "far",
		iconName: "copy",
		icon: [
			448,
			512,
			[],
			"f0c5",
			"M384 336l-192 0c-8.8 0-16-7.2-16-16l0-256c0-8.8 7.2-16 16-16l133.5 0c4.2 0 8.3 1.7 11.3 4.7l58.5 58.5c3 3 4.7 7.1 4.7 11.3L400 320c0 8.8-7.2 16-16 16zM192 384l192 0c35.3 0 64-28.7 64-64l0-197.5c0-17-6.7-33.3-18.7-45.3L370.7 18.7C358.7 6.7 342.5 0 325.5 0L192 0c-35.3 0-64 28.7-64 64l0 256c0 35.3 28.7 64 64 64zM64 128c-35.3 0-64 28.7-64 64L0 448c0 35.3 28.7 64 64 64l192 0c35.3 0 64-28.7 64-64l0-16-48 0 0 16c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16l0-256c0-8.8 7.2-16 16-16l16 0 0-48-16 0z"
		]
	};
	faChessKing = {
		prefix: "far",
		iconName: "chess-king",
		icon: [
			448,
			512,
			[9818],
			"f43f",
			"M224-32c13.3 0 24 10.7 24 24l0 40 48 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-48 0 0 80 161.8 0c21.1 0 38.2 17.1 38.2 38.2 0 6.4-1.6 12.7-4.7 18.3L357.2 374.5 405.6 435c6.7 8.4 10.4 18.8 10.4 29.6 0 26.2-21.2 47.4-47.4 47.4L79.4 512c-26.2 0-47.4-21.2-47.4-47.4 0-10.8 3.7-21.2 10.4-29.6L90.8 374.5 4.7 216.6C1.6 210.9 0 204.6 0 198.2 0 177.1 17.1 160 38.2 160l161.8 0 0-80-48 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l48 0 0-40c0-13.3 10.7-24 24-24zM131.8 400l-3.6 4.4-47.6 59.6 286.6 0-47.6-59.6-3.6-4.4-184.3 0zm1.1-48.5l.3 .5 181.6 0 .3-.5 78.3-143.5-338.7 0 78.3 143.5z"
		]
	};
	faSquarePlus = {
		prefix: "far",
		iconName: "square-plus",
		icon: [
			448,
			512,
			[61846, "plus-square"],
			"f0fe",
			"M64 80c-8.8 0-16 7.2-16 16l0 320c0 8.8 7.2 16 16 16l320 0c8.8 0 16-7.2 16-16l0-320c0-8.8-7.2-16-16-16L64 80zM0 96C0 60.7 28.7 32 64 32l320 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zM200 344l0-64-64 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l64 0 0-64c0-13.3 10.7-24 24-24s24 10.7 24 24l0 64 64 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-64 0 0 64c0 13.3-10.7 24-24 24s-24-10.7-24-24z"
		]
	};
	faPlusSquare = faSquarePlus;
	faFileCode = {
		prefix: "far",
		iconName: "file-code",
		icon: [
			384,
			512,
			[],
			"f1c9",
			"M64 48l112 0 0 88c0 39.8 32.2 72 72 72l88 0 0 240c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16L48 64c0-8.8 7.2-16 16-16zM224 67.9l92.1 92.1-68.1 0c-13.3 0-24-10.7-24-24l0-68.1zM64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-261.5c0-17-6.7-33.3-18.7-45.3L242.7 18.7C230.7 6.7 214.5 0 197.5 0L64 0zM170.2 295.6c8.6-10.1 7.5-25.2-2.6-33.8s-25.2-7.5-33.8 2.6l-48 56c-7.7 9-7.7 22.2 0 31.2l48 56c8.6 10.1 23.8 11.2 33.8 2.6s11.2-23.8 2.6-33.8l-34.6-40.4 34.6-40.4zm80-31.2c-8.6-10.1-23.8-11.2-33.8-2.6s-11.2 23.8-2.6 33.8l34.6 40.4-34.6 40.4c-8.6 10.1-7.5 25.2 2.6 33.8s25.2 7.5 33.8-2.6l48-56c7.7-9 7.7-22.2 0-31.2l-48-56z"
		]
	};
	faFaceGrinWink = {
		prefix: "far",
		iconName: "face-grin-wink",
		icon: [
			512,
			512,
			["grin-wink"],
			"f58c",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm372.2 46.3c11.8-3.6 23.7 6.1 19.6 17.8-19.8 55.9-73.1 96-135.8 96-62.7 0-116-40-135.8-95.9-4.1-11.6 7.8-21.4 19.6-17.8 34.7 10.6 74.2 16.5 116.1 16.5 42 0 81.5-6 116.3-16.6zM144 208a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm164 8c0 11-9 20-20 20s-20-9-20-20c0-33.1 26.9-60 60-60l16 0c33.1 0 60 26.9 60 60 0 11-9 20-20 20s-20-9-20-20-9-20-20-20l-16 0c-11 0-20 9-20 20z"
		]
	};
	faGrinWink = faFaceGrinWink;
	faMoneyBill1 = {
		prefix: "far",
		iconName: "money-bill-1",
		icon: [
			512,
			512,
			["money-bill-alt"],
			"f3d1",
			"M112 112c0 35.3-28.7 64-64 64l0 160c35.3 0 64 28.7 64 64l288 0c0-35.3 28.7-64 64-64l0-160c-35.3 0-64-28.7-64-64l-288 0zM0 128C0 92.7 28.7 64 64 64l384 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128zm256 16a112 112 0 1 1 0 224 112 112 0 1 1 0-224zm-16 44c-11 0-20 9-20 20 0 9.7 6.9 17.7 16 19.6l0 48.4-4 0c-11 0-20 9-20 20s9 20 20 20l48 0c11 0 20-9 20-20s-9-20-20-20l-4 0 0-68c0-11-9-20-20-20l-16 0z"
		]
	};
	faMoneyBillAlt = faMoneyBill1;
	faEyeSlash = {
		prefix: "far",
		iconName: "eye-slash",
		icon: [
			576,
			512,
			[],
			"f070",
			"M41-24.9c-9.4-9.4-24.6-9.4-33.9 0S-2.3-.3 7 9.1l528 528c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-96.4-96.4c2.7-2.4 5.4-4.8 8-7.2 46.8-43.5 78.1-95.4 93-131.1 3.3-7.9 3.3-16.7 0-24.6-14.9-35.7-46.2-87.7-93-131.1-47.1-43.7-111.8-80.6-192.6-80.6-56.8 0-105.6 18.2-146 44.2L41-24.9zM176.9 111.1c32.1-18.9 69.2-31.1 111.1-31.1 65.2 0 118.8 29.6 159.9 67.7 38.5 35.7 65.1 78.3 78.6 108.3-13.6 30-40.2 72.5-78.6 108.3-3.1 2.8-6.2 5.6-9.4 8.4L393.8 328c14-20.5 22.2-45.3 22.2-72 0-70.7-57.3-128-128-128-26.7 0-51.5 8.2-72 22.2l-39.1-39.1zm182 182l-108-108c11.1-5.8 23.7-9.1 37.1-9.1 44.2 0 80 35.8 80 80 0 13.4-3.3 26-9.1 37.1zM103.4 173.2l-34-34c-32.6 36.8-55 75.8-66.9 104.5-3.3 7.9-3.3 16.7 0 24.6 14.9 35.7 46.2 87.7 93 131.1 47.1 43.7 111.8 80.6 192.6 80.6 37.3 0 71.2-7.9 101.5-20.6L352.2 422c-20 6.4-41.4 10-64.2 10-65.2 0-118.8-29.6-159.9-67.7-38.5-35.7-65.1-78.3-78.6-108.3 10.4-23.1 28.6-53.6 54-82.8z"
		]
	};
	faFileWord = {
		prefix: "far",
		iconName: "file-word",
		icon: [
			384,
			512,
			[],
			"f1c2",
			"M64 48l112 0 0 88c0 39.8 32.2 72 72 72l88 0 0 240c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16L48 64c0-8.8 7.2-16 16-16zM224 67.9l92.1 92.1-68.1 0c-13.3 0-24-10.7-24-24l0-68.1zM64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-261.5c0-17-6.7-33.3-18.7-45.3L242.7 18.7C230.7 6.7 214.5 0 197.5 0L64 0zm71.3 274.2c-3.2-12.9-16.2-20.7-29.1-17.5S85.5 273 88.7 285.8l32 128c2.5 10.2 11.4 17.5 21.9 18.1s20.1-5.7 23.8-15.5l25.5-68.1 25.5 68.1c3.7 9.8 13.3 16.1 23.8 15.5s19.4-7.9 21.9-18.1l32-128c3.2-12.9-4.6-25.9-17.5-29.1s-25.9 4.6-29.1 17.5l-13.3 53.2-20.9-55.8C211 262.2 202 256 192 256s-19 6.2-22.5 15.6l-20.9 55.8-13.3-53.2z"
		]
	};
	faFaceAngry = {
		prefix: "far",
		iconName: "face-angry",
		icon: [
			512,
			512,
			[128544, "angry"],
			"f556",
			"M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464a256 256 0 1 0 0-512 256 256 0 1 0 0 512zm0-144c24.1 0 45.4 11.8 58.5 30 7.7 10.8 22.7 13.2 33.5 5.5s13.2-22.7 5.5-33.5c-21.7-30.2-57.3-50-97.5-50s-75.7 19.8-97.5 50c-7.7 10.8-5.3 25.8 5.5 33.5s25.8 5.3 33.5-5.5c13.1-18.2 34.4-30 58.5-30zm-80-96c17.7 0 32-14.3 32-32l0-.3 9.7 3.2c10.5 3.5 21.8-2.2 25.3-12.6s-2.2-21.8-12.6-25.3l-96-32c-10.5-3.5-21.8 2.2-25.3 12.6s2.2 21.8 12.6 25.3l28.9 9.6c-4.1 5.4-6.6 12.1-6.6 19.4 0 17.7 14.3 32 32 32zm192-32c0-7.3-2.4-14-6.6-19.4l28.9-9.6c10.5-3.5 16.1-14.8 12.6-25.3s-14.8-16.1-25.3-12.6l-96 32c-10.5 3.5-16.1 14.8-12.6 25.3s14.8 16.1 25.3 12.6l9.7-3.2 0 .3c0 17.7 14.3 32 32 32s32-14.3 32-32z"
		]
	};
	faAngry = faFaceAngry;
	faChessKnight = {
		prefix: "far",
		iconName: "chess-knight",
		icon: [
			448,
			512,
			[9822],
			"f441",
			"M232-32c110.5 0 200 89.5 200 200l0 127.7c0 18.9-6.1 37.1-17.2 52.2l-5.1 6.2-36.3 40.7 32.1 40.2c6.7 8.4 10.4 18.8 10.4 29.6l-.2 4.8c-2.4 23.9-22.6 42.5-47.1 42.5l-289.2 0-4.8-.2c-23.9-2.4-42.5-22.6-42.5-47.1 0-10.8 3.7-21.2 10.4-29.6l37.6-47 0-24.3c0-24.3 10.1-47.6 27.8-64.2l63.5-59.5-17.4 0-.2 .2c-20.3 20.3-49.6 28.2-77.1 21.1l-5.5-1.6c-30.9-10.3-52.3-38-54.9-70.1l-.2-6.4 0-1.4c0-19.7 7.1-38.8 19.9-53.8l76.1-88.8 0-47.1 .1-2.5C113.4-22.6 123.6-32 136-32l96 0zM80.7 464l286.6 0-38.4-48-209.9 0-38.4 48zM160 48c0 5.7-2.1 11.3-5.8 15.6L72.3 159.1C67 165.4 64 173.4 64 181.7l0 1.4 .4 5.2c1.9 11.9 10.3 21.9 21.9 25.8l4.5 1.1c10.5 1.9 21.3-1.4 29-9l7.2-7.2 3.7-3c3.9-2.6 8.5-4 13.3-4l88 0c9.8 0 18.7 6 22.3 15.2s1.3 19.6-5.9 26.3l-107.8 101c-8.1 7.6-12.7 18.1-12.7 29.2l0 4.3 205.2 0 40.7-45.8 2.3-2.8c5.1-6.8 7.8-15.2 7.8-23.7L384 168c0-83.9-68.1-152-152-152l-72 0 0 32zm32 72a24 24 0 1 1 0-48 24 24 0 1 1 0 48z"
		]
	};
	faFaceGrinBeam = {
		prefix: "far",
		iconName: "face-grin-beam",
		icon: [
			512,
			512,
			[128516, "grin-beam"],
			"f582",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm372.2 46.3c11.8-3.6 23.7 6.1 19.6 17.8-19.8 55.9-73.1 96-135.8 96-62.7 0-116-40-135.8-95.9-4.1-11.6 7.8-21.4 19.6-17.8 34.7 10.6 74.2 16.5 116.1 16.5 42 0 81.5-6 116.3-16.6zM176 180c-15.5 0-28 12.5-28 28l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-37.6 30.4-68 68-68s68 30.4 68 68l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-15.5-12.5-28-28-28zm132 28l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-37.6 30.4-68 68-68s68 30.4 68 68l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-15.5-12.5-28-28-28s-28 12.5-28 28z"
		]
	};
	faGrinBeam = faFaceGrinBeam;
	faHandPeace = {
		prefix: "far",
		iconName: "hand-peace",
		icon: [
			448,
			512,
			[9996],
			"f25b",
			"M219 1.4c-35.2-3.7-66.6 21.8-70.3 57l-6.4 60.6-17.4-49.4C113.2 36.3 76.6 18.8 43.3 30.5S-7.6 78.8 4.1 112.1L56.9 262.2C41.7 276.7 32.2 297.3 32.2 320l0 24c0 92.8 75.2 168 168 168l48 0c92.8 0 168-75.2 168-168l0-120c0-35.3-28.7-64-64-64-7.9 0-15.4 1.4-22.4 4-10.4-21.3-32.3-36-57.6-36-.7 0-1.5 0-2.2 0l5.9-56.3c3.7-35.2-21.8-66.6-57-70.3zm-.2 155.4c-6.6 10.1-10.5 22.2-10.5 35.2l0 48c0 .7 0 1.4 0 2-5.1-1.3-10.5-2-16-2l-7.4 0-5.4-15.3 17-161.3c.9-8.8 8.8-15.2 17.6-14.2s15.2 8.8 14.2 17.6l-9.5 90.1zM79.6 85.6l54.3 154.4-21.7 0c-4 0-8 .3-11.9 .9L49.4 96.2c-2.9-8.3 1.5-17.5 9.8-20.4s17.5 1.5 20.4 9.8zM256.2 192c0-8.8 7.2-16 16-16s16 7.2 16 16l0 48c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-48zm38.4 108c10.4 21.3 32.3 36 57.6 36 5.5 0 10.9-.7 16-2l0 10c0 66.3-53.7 120-120 120l-48 0c-66.3 0-120-53.7-120-120l0-24c0-17.7 14.3-32 32-32l80 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-40 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l40 0c35.3 0 64-28.7 64-64 0-.7 0-1.4 0-2 5.1 1.3 10.5 2 16 2 7.9 0 15.4-1.4 22.4-4zm73.6-28c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-48c0-8.8 7.2-16 16-16s16 7.2 16 16l0 48z"
		]
	};
	faCompass = {
		prefix: "far",
		iconName: "compass",
		icon: [
			512,
			512,
			[129517],
			"f14e",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm306.7 69.1L162.4 380.6c-19.4 7.5-38.5-11.6-31-31l55.5-144.3c3.3-8.5 9.9-15.1 18.4-18.4l144.3-55.5c19.4-7.5 38.5 11.6 31 31L325.1 306.7c-3.3 8.5-9.9 15.1-18.4 18.4zM288 256a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z"
		]
	};
	faSquare = {
		prefix: "far",
		iconName: "square",
		icon: [
			448,
			512,
			[
				9632,
				9723,
				9724,
				61590
			],
			"f0c8",
			"M384 80c8.8 0 16 7.2 16 16l0 320c0 8.8-7.2 16-16 16L64 432c-8.8 0-16-7.2-16-16L48 96c0-8.8 7.2-16 16-16l320 0zM64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32z"
		]
	};
	faFaceGrin = {
		prefix: "far",
		iconName: "face-grin",
		icon: [
			512,
			512,
			[128512, "grin"],
			"f580",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm372.2 46.3c11.8-3.6 23.7 6.1 19.6 17.8-19.8 55.9-73.1 96-135.8 96-62.7 0-116-40-135.8-95.9-4.1-11.6 7.8-21.4 19.6-17.8 34.7 10.6 74.2 16.5 116.1 16.5 42 0 81.5-6 116.3-16.6zM144 208a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm192-32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"
		]
	};
	faGrin = faFaceGrin;
	faFaceSmile = {
		prefix: "far",
		iconName: "face-smile",
		icon: [
			512,
			512,
			[128578, "smile"],
			"f118",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm177.3 63.4C192.3 335 218.4 352 256 352s63.7-17 78.7-32.6c9.2-9.6 24.4-9.9 33.9-.7s9.9 24.4 .7 33.9c-22.1 23-60 47.4-113.3 47.4s-91.2-24.4-113.3-47.4c-9.2-9.6-8.9-24.8 .7-33.9s24.8-8.9 33.9 .7zM144 208a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm192-32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"
		]
	};
	faSmile = faFaceSmile;
	faFaceSmileBeam = {
		prefix: "far",
		iconName: "face-smile-beam",
		icon: [
			512,
			512,
			[128522, "smile-beam"],
			"f5b8",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm177.3 63.4C192.3 335 218.4 352 256 352s63.7-17 78.7-32.6c9.2-9.6 24.4-9.9 33.9-.7s9.9 24.4 .7 33.9c-22.1 23-60 47.4-113.3 47.4s-91.2-24.4-113.3-47.4c-9.2-9.6-8.9-24.8 .7-33.9s24.8-8.9 33.9 .7zM176 180c-15.5 0-28 12.5-28 28l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-37.6 30.4-68 68-68s68 30.4 68 68l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-15.5-12.5-28-28-28zm132 28l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-37.6 30.4-68 68-68s68 30.4 68 68l0 8c0 11-9 20-20 20s-20-9-20-20l0-8c0-15.5-12.5-28-28-28s-28 12.5-28 28z"
		]
	};
	faSmileBeam = faFaceSmileBeam;
	faFolderClosed = {
		prefix: "far",
		iconName: "folder-closed",
		icon: [
			512,
			512,
			[],
			"e185",
			"M448 400L64 400c-8.8 0-16-7.2-16-16l0-144 416 0 0 144c0 8.8-7.2 16-16 16zm16-208l-416 0 0-96c0-8.8 7.2-16 16-16l138.7 0c3.5 0 6.8 1.1 9.6 3.2L250.7 112c13.8 10.4 30.7 16 48 16L448 128c8.8 0 16 7.2 16 16l0 48zM64 448l384 0c35.3 0 64-28.7 64-64l0-240c0-35.3-28.7-64-64-64L298.7 80c-6.9 0-13.7-2.2-19.2-6.4L241.1 44.8C230 36.5 216.5 32 202.7 32L64 32C28.7 32 0 60.7 0 96L0 384c0 35.3 28.7 64 64 64z"
		]
	};
	faKeyboard = {
		prefix: "far",
		iconName: "keyboard",
		icon: [
			576,
			512,
			[9e3],
			"f11c",
			"M64 112c-8.8 0-16 7.2-16 16l0 256c0 8.8 7.2 16 16 16l448 0c8.8 0 16-7.2 16-16l0-256c0-8.8-7.2-16-16-16L64 112zM0 128C0 92.7 28.7 64 64 64l448 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128zM176 320l224 0c8.8 0 16 7.2 16 16l0 16c0 8.8-7.2 16-16 16l-224 0c-8.8 0-16-7.2-16-16l0-16c0-8.8 7.2-16 16-16zm-72-72c0-8.8 7.2-16 16-16l16 0c8.8 0 16 7.2 16 16l0 16c0 8.8-7.2 16-16 16l-16 0c-8.8 0-16-7.2-16-16l0-16zm16-96l16 0c8.8 0 16 7.2 16 16l0 16c0 8.8-7.2 16-16 16l-16 0c-8.8 0-16-7.2-16-16l0-16c0-8.8 7.2-16 16-16zm64 96c0-8.8 7.2-16 16-16l16 0c8.8 0 16 7.2 16 16l0 16c0 8.8-7.2 16-16 16l-16 0c-8.8 0-16-7.2-16-16l0-16zm16-96l16 0c8.8 0 16 7.2 16 16l0 16c0 8.8-7.2 16-16 16l-16 0c-8.8 0-16-7.2-16-16l0-16c0-8.8 7.2-16 16-16zm64 96c0-8.8 7.2-16 16-16l16 0c8.8 0 16 7.2 16 16l0 16c0 8.8-7.2 16-16 16l-16 0c-8.8 0-16-7.2-16-16l0-16zm16-96l16 0c8.8 0 16 7.2 16 16l0 16c0 8.8-7.2 16-16 16l-16 0c-8.8 0-16-7.2-16-16l0-16c0-8.8 7.2-16 16-16zm64 96c0-8.8 7.2-16 16-16l16 0c8.8 0 16 7.2 16 16l0 16c0 8.8-7.2 16-16 16l-16 0c-8.8 0-16-7.2-16-16l0-16zm16-96l16 0c8.8 0 16 7.2 16 16l0 16c0 8.8-7.2 16-16 16l-16 0c-8.8 0-16-7.2-16-16l0-16c0-8.8 7.2-16 16-16zm64 96c0-8.8 7.2-16 16-16l16 0c8.8 0 16 7.2 16 16l0 16c0 8.8-7.2 16-16 16l-16 0c-8.8 0-16-7.2-16-16l0-16zm16-96l16 0c8.8 0 16 7.2 16 16l0 16c0 8.8-7.2 16-16 16l-16 0c-8.8 0-16-7.2-16-16l0-16c0-8.8 7.2-16 16-16z"
		]
	};
	faFaceRollingEyes = {
		prefix: "far",
		iconName: "face-rolling-eyes",
		icon: [
			512,
			512,
			[128580, "meh-rolling-eyes"],
			"f5a5",
			"M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM176 376c0 13.3 10.7 24 24 24l112 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-112 0c-13.3 0-24 10.7-24 24zM160 264c-22.1 0-40-17.9-40-40 0-9.5 3.3-18.1 8.8-25 3.2 14.3 16 25 31.2 25s28-10.7 31.2-25c5.5 6.8 8.8 15.5 8.8 25 0 22.1-17.9 40-40 40zm0 40a80 80 0 1 0 0-160 80 80 0 1 0 0 160zm192-40c-22.1 0-40-17.9-40-40 0-9.5 3.3-18.1 8.8-25 3.2 14.3 16 25 31.2 25s28-10.7 31.2-25c5.5 6.8 8.8 15.5 8.8 25 0 22.1-17.9 40-40 40zm0 40a80 80 0 1 0 0-160 80 80 0 1 0 0 160z"
		]
	};
	faMehRollingEyes = faFaceRollingEyes;
	faFaceGrimace = {
		prefix: "far",
		iconName: "face-grimace",
		icon: [
			512,
			512,
			[128556, "grimace"],
			"f57f",
			"M256 48a208 208 0 1 0 0 416 208 208 0 1 0 0-416zM512 256a256 256 0 1 1 -512 0 256 256 0 1 1 512 0zM152 352c0 11.9 8.6 21.8 20 23.7l0-47.3c-11.4 1.9-20 11.8-20 23.7zm84 24l0-48-24 0 0 48 24 0zm64 0l0-48-24 0 0 48 24 0zm40-.3c11.4-1.9 20-11.8 20-23.7s-8.6-21.8-20-23.7l0 47.3zM176 288l160 0c35.3 0 64 28.7 64 64s-28.7 64-64 64l-160 0c-35.3 0-64-28.7-64-64s28.7-64 64-64zm0-112a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z"
		]
	};
	faGrimace = faFaceGrimace;
	faCircleDot = {
		prefix: "far",
		iconName: "circle-dot",
		icon: [
			512,
			512,
			[128280, "dot-circle"],
			"f192",
			"M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-464a208 208 0 1 0 0 416 208 208 0 1 0 0-416zm0 304a96 96 0 1 1 0-192 96 96 0 1 1 0 192z"
		]
	};
	faDotCircle = faCircleDot;
	faObjectGroup = {
		prefix: "far",
		iconName: "object-group",
		icon: [
			576,
			512,
			[],
			"f247",
			"M40 64a24 24 0 1 1 48 0 24 24 0 1 1 -48 0zm48 59.3c16-6.5 28.9-19.3 35.3-35.3l329.3 0c6.5 16 19.3 28.9 35.3 35.3l0 265.3c-16 6.5-28.9 19.3-35.3 35.3l-329.3 0c-6.5-16-19.3-28.9-35.3-35.3l0-265.3zM512 0c-26.9 0-49.9 16.5-59.3 40L123.3 40C113.9 16.5 90.9 0 64 0 28.7 0 0 28.7 0 64 0 90.9 16.5 113.9 40 123.3l0 265.3c-23.5 9.5-40 32.5-40 59.3 0 35.3 28.7 64 64 64 26.9 0 49.9-16.5 59.3-40l329.3 0c9.5 23.5 32.5 40 59.3 40 35.3 0 64-28.7 64-64 0-26.9-16.5-49.9-40-59.3l0-265.3c23.5-9.5 40-32.5 40-59.3 0-35.3-28.7-64-64-64zM488 64a24 24 0 1 1 48 0 24 24 0 1 1 -48 0zM64 424a24 24 0 1 1 0 48 24 24 0 1 1 0-48zm424 24a24 24 0 1 1 48 0 24 24 0 1 1 -48 0zM192 176l88 0 0 56-88 0 0-56zm-8-40c-17.7 0-32 14.3-32 32l0 72c0 17.7 14.3 32 32 32l104 0c17.7 0 32-14.3 32-32l0-72c0-17.7-14.3-32-32-32l-104 0zm72 184l0 24c0 17.7 14.3 32 32 32l104 0c17.7 0 32-14.3 32-32l0-72c0-17.7-14.3-32-32-32l-24 0c0 14.6-3.9 28.2-10.7 40l26.7 0 0 56-88 0 0-16.4c-2.6 .3-5.3 .4-8 .4l-32 0z"
		]
	};
	faFaceFlushed = {
		prefix: "far",
		iconName: "face-flushed",
		icon: [
			512,
			512,
			[128563, "flushed"],
			"f579",
			"M464 256a208 208 0 1 1 -416 0 208 208 0 1 1 416 0zM256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM160 248a24 24 0 1 0 0-48 24 24 0 1 0 0 48zm216-24a24 24 0 1 0 -48 0 24 24 0 1 0 48 0zM192 352c-13.3 0-24 10.7-24 24s10.7 24 24 24l128 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-128 0zM160 176a48 48 0 1 1 0 96 48 48 0 1 1 0-96zm0 128a80 80 0 1 0 0-160 80 80 0 1 0 0 160zm144-80a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm128 0a80 80 0 1 0 -160 0 80 80 0 1 0 160 0z"
		]
	};
	faFlushed = faFaceFlushed;
	faStarHalfStroke = {
		prefix: "far",
		iconName: "star-half-stroke",
		icon: [
			576,
			512,
			["star-half-alt"],
			"f5c0",
			"M309.5-18.9c-4.1-8-12.4-13.1-21.4-13.1s-17.3 5.1-21.4 13.1L193.1 125.3 33.2 150.7c-8.9 1.4-16.3 7.7-19.1 16.3s-.5 18 5.8 24.4l114.4 114.5-25.2 159.9c-1.4 8.9 2.3 17.9 9.6 23.2s16.9 6.1 25 2L288.1 417.6 432.4 491c8 4.1 17.7 3.3 25-2s11-14.2 9.6-23.2L441.7 305.9 556.1 191.4c6.4-6.4 8.6-15.8 5.8-24.4s-10.1-14.9-19.1-16.3L383 125.3 309.5-18.9zM264.1 91.8l0 284.1-100.1 50.9 19.8-125.5c1.2-7.6-1.3-15.3-6.7-20.7l-89.8-89.9 125.5-20c7.6-1.2 14.1-6 17.6-12.8l33.8-66.2zm48 284.1l0-284.1 33.8 66.2c3.5 6.8 10 11.6 17.6 12.8l125.5 20-89.8 89.9c-5.4 5.4-7.9 13.1-6.7 20.7l19.8 125.5-100.1-50.9z"
		]
	};
	faStarHalfAlt = faStarHalfStroke;
	faFileVideo = {
		prefix: "far",
		iconName: "file-video",
		icon: [
			384,
			512,
			[],
			"f1c8",
			"M64 48l112 0 0 88c0 39.8 32.2 72 72 72l88 0 0 240c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16L48 64c0-8.8 7.2-16 16-16zM224 67.9l92.1 92.1-68.1 0c-13.3 0-24-10.7-24-24l0-68.1zM64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-261.5c0-17-6.7-33.3-18.7-45.3L242.7 18.7C230.7 6.7 214.5 0 197.5 0L64 0zM80 288l0 96c0 17.7 14.3 32 32 32l96 0c17.7 0 32-14.3 32-32l0-24 35 35c3.2 3.2 7.5 5 12 5 9.4 0 17-7.6 17-17l0-94.1c0-9.4-7.6-17-17-17-4.5 0-8.8 1.8-12 5l-35 35 0-24c0-17.7-14.3-32-32-32l-96 0c-17.7 0-32 14.3-32 32z"
		]
	};
	faFaceLaugh = {
		prefix: "far",
		iconName: "face-laugh",
		icon: [
			512,
			512,
			["laugh"],
			"f599",
			"M464 256a208 208 0 1 0 -416 0 208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm118.3 58.2c-4.2-13.7 7.1-26.2 21.4-26.2l232.6 0c14.3 0 25.6 12.5 21.4 26.2-18 58.9-72.9 101.8-137.7 101.8S136.3 373.1 118.3 314.2zM144 192a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm192-32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"
		]
	};
	icons = {
		faSquareMinus,
		faMinusSquare,
		faCalendarCheck,
		faFaceKiss,
		faKiss,
		faPaste,
		faFileClipboard,
		faHandPointLeft,
		faFileExcel,
		faEnvelope,
		faSquareCaretDown,
		faCaretSquareDown,
		faTruck,
		faBell,
		faMessage,
		faCommentAlt,
		faFaceDizzy,
		faDizzy,
		faCalendarDays,
		faCalendarAlt,
		faHandPointUp,
		faHandLizard,
		faSquareFull,
		faCirclePause,
		faPauseCircle,
		faHardDrive,
		faHdd,
		faFileZipper,
		faFileArchive,
		faFloppyDisk,
		faSave,
		faFaceGrinTongueSquint,
		faGrinTongueSquint,
		faCamera,
		faCameraAlt,
		faFaceGrinStars,
		faGrinStars,
		faEye,
		faFaceSadTear,
		faSadTear,
		faShareFromSquare,
		faShareSquare,
		faNoteSticky,
		faStickyNote,
		faHandBackFist,
		faHandRock,
		faChessQueen,
		faFaceGrinTears,
		faGrinTears,
		faPenToSquare,
		faEdit,
		faFaceGrinBeamSweat,
		faGrinBeamSweat,
		faClock,
		faClockFour,
		faFaceLaughWink,
		faLaughWink,
		faPaperPlane,
		faHeart,
		faFontAwesome,
		faFontAwesomeFlag,
		faFontAwesomeLogoFull,
		faClone,
		faFolderOpen,
		faWindowMinimize,
		faStarHalf,
		faAlarmClock,
		faNewspaper,
		faHospital,
		faHospitalAlt,
		faHospitalWide,
		faCircleStop,
		faStopCircle,
		faObjectUngroup,
		faComment,
		faChessPawn,
		faCalendarPlus,
		faClipboard,
		faThumbsDown,
		faIdBadge,
		faSquareCheck,
		faCheckSquare,
		faChessBishop,
		faEnvelopeOpen,
		faCircleXmark,
		faTimesCircle,
		faXmarkCircle,
		faSquareCaretUp,
		faCaretSquareUp,
		faFileImage,
		faSquareCaretRight,
		faCaretSquareRight,
		faSun,
		faImage,
		faLightbulb,
		faAddressCard,
		faContactCard,
		faVcard,
		faFaceMeh,
		faMeh,
		faMap,
		faHandPointDown,
		faFaceMehBlank,
		faMehBlank,
		faFaceGrinTongue,
		faGrinTongue,
		faFutbol,
		faFutbolBall,
		faSoccerBall,
		faFaceSurprise,
		faSurprise,
		faFolder,
		faFolderBlank,
		faCloud,
		faCircle,
		faFaceGrinSquint,
		faGrinSquint,
		faCircleUser,
		faUserCircle,
		faRectangleList,
		faListAlt,
		faHand,
		faHandPaper,
		faThumbsUp,
		faBuilding,
		faChessRook,
		faCircleQuestion,
		faQuestionCircle,
		faFile,
		faFaceSadCry,
		faSadCry,
		faCalendarMinus,
		faFaceTired,
		faTired,
		faHandPointRight,
		faCircleUp,
		faArrowAltCircleUp,
		faHandScissors,
		faGem,
		faRectangleXmark,
		faRectangleTimes,
		faTimesRectangle,
		faWindowClose,
		faTrashCan,
		faTrashAlt,
		faLifeRing,
		faCopyright,
		faCircleLeft,
		faArrowAltCircleLeft,
		faCalendar,
		faFaceFrownOpen,
		faFrownOpen,
		faChartBar,
		faBarChart,
		faHouse,
		faHome,
		faHomeAlt,
		faHomeLgAlt,
		faFaceFrown,
		faFrown,
		faUser,
		faUserAlt,
		faUserLarge,
		faSnowflake,
		faBookmark,
		faSquareCaretLeft,
		faCaretSquareLeft,
		faHandshake,
		faHandshakeAlt,
		faHandshakeSimple,
		faFaceSmileWink,
		faSmileWink,
		faFaceGrinSquintTears,
		faGrinSquintTears,
		faFileAudio,
		faCalendarXmark,
		faCalendarTimes,
		faCircleDown,
		faArrowAltCircleDown,
		faFileLines,
		faFileAlt,
		faFileText,
		faComments,
		faCircleCheck,
		faCheckCircle,
		faMoon,
		faClosedCaptioning,
		faImages,
		faCircleRight,
		faArrowAltCircleRight,
		faIdCard,
		faDriversLicense,
		faCirclePlay,
		faPlayCircle,
		faFaceLaughBeam,
		faLaughBeam,
		faAddressBook,
		faContactBook,
		faHourglass,
		faHourglassEmpty,
		faHeadphones,
		faHeadphonesAlt,
		faHeadphonesSimple,
		faFilePowerpoint,
		faWindowMaximize,
		faCommentDots,
		faCommenting,
		faFaceGrinTongueWink,
		faGrinTongueWink,
		faHourglassHalf,
		faHourglass2,
		faCreditCard,
		faCreditCardAlt,
		faHandSpock,
		faBellSlash,
		faStar,
		faFlag,
		faLemon,
		faWindowRestore,
		faFaceGrinHearts,
		faGrinHearts,
		faFaceKissBeam,
		faKissBeam,
		faFilePdf,
		faFaceGrinWide,
		faGrinAlt,
		faFaceLaughSquint,
		faLaughSquint,
		faFaceKissWinkHeart,
		faKissWinkHeart,
		faCopy,
		faChessKing,
		faSquarePlus,
		faPlusSquare,
		faFileCode,
		faFaceGrinWink,
		faGrinWink,
		faMoneyBill1,
		faMoneyBillAlt,
		faEyeSlash,
		faFileWord,
		faFaceAngry,
		faAngry,
		faChessKnight,
		faFaceGrinBeam,
		faGrinBeam,
		faHandPeace,
		faCompass,
		faSquare,
		faFaceGrin,
		faGrin,
		faFaceSmile,
		faSmile,
		faFaceSmileBeam,
		faSmileBeam,
		faFolderClosed,
		faKeyboard,
		faFaceRollingEyes,
		faMehRollingEyes,
		faFaceGrimace,
		faGrimace,
		faCircleDot,
		faDotCircle,
		faObjectGroup,
		faFaceFlushed,
		faFlushed,
		faStarHalfStroke,
		faStarHalfAlt,
		faFileVideo,
		faFaceLaugh,
		faLaugh: faFaceLaugh,
		faHandPointer: {
			prefix: "far",
			iconName: "hand-pointer",
			icon: [
				448,
				512,
				[],
				"f25a",
				"M160 64c0-8.8 7.2-16 16-16s16 7.2 16 16l0 136c0 10.3 6.6 19.5 16.4 22.8s20.6-.1 26.8-8.3c3-3.9 7.6-6.4 12.8-6.4 8.8 0 16 7.2 16 16 0 10.3 6.6 19.5 16.4 22.8s20.6-.1 26.8-8.3c3-3.9 7.6-6.4 12.8-6.4 7.8 0 14.3 5.6 15.7 13 1.6 8.2 7.3 15.1 15.1 18s16.7 1.6 23.3-3.6c2.7-2.1 6.1-3.4 9.9-3.4 8.8 0 16 7.2 16 16l0 120c0 39.8-32.2 72-72 72l-116.6 0c-37.4 0-72.4-18.7-93.2-49.9L50.7 312.9c-4.9-7.4-2.9-17.3 4.4-22.2s17.3-2.9 22.2 4.4L116 353.2c5.9 8.8 16.8 12.7 26.9 9.7s17-12.4 17-23L160 64zM176 0c-35.3 0-64 28.7-64 64l0 197.7C91.2 238 55.5 232.8 28.5 250.7-.9 270.4-8.9 310.1 10.8 339.5L78.3 440.8c29.7 44.5 79.6 71.2 133.1 71.2L328 512c66.3 0 120-53.7 120-120l0-120c0-35.3-28.7-64-64-64-4.5 0-8.8 .5-13 1.3-11.7-15.4-30.2-25.3-51-25.3-6.9 0-13.5 1.1-19.7 3.1-11.6-16.4-30.7-27.1-52.3-27.1-2.7 0-5.4 .2-8 .5L240 64c0-35.3-28.7-64-64-64zm48 304c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16s16-7.2 16-16l0-96zm48-16c-8.8 0-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16s16-7.2 16-16l0-96c0-8.8-7.2-16-16-16zm80 16c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 96c0 8.8 7.2 16 16 16s16-7.2 16-16l0-96z"
			]
		},
		faRegistered: {
			prefix: "far",
			iconName: "registered",
			icon: [
				512,
				512,
				[174],
				"f25d",
				"M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM200 144c-13.3 0-24 10.7-24 24l0 176c0 13.3 10.7 24 24 24s24-10.7 24-24l0-56 34.4 0 41 68.3c6.8 11.4 21.6 15 32.9 8.2s15-21.6 8.2-32.9l-30.2-50.3c24.6-11.5 41.6-36.4 41.6-65.3 0-39.8-32.2-72-72-72l-80 0zm72 96l-48 0 0-48 56 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-8 0z"
			]
		}
	};
	noop = function noop() {};
	_WINDOW = {};
	_DOCUMENT = {};
	_MUTATION_OBSERVER = null;
	_PERFORMANCE = {
		mark: noop,
		measure: noop
	};
	try {
		if (typeof window !== "undefined") _WINDOW = window;
		if (typeof document !== "undefined") _DOCUMENT = document;
		if (typeof MutationObserver !== "undefined") _MUTATION_OBSERVER = MutationObserver;
		if (typeof performance !== "undefined") _PERFORMANCE = performance;
	} catch (e) {}
	_ref$userAgent = (_WINDOW.navigator || {}).userAgent, userAgent = _ref$userAgent === void 0 ? "" : _ref$userAgent;
	WINDOW = _WINDOW;
	DOCUMENT = _DOCUMENT;
	MUTATION_OBSERVER = _MUTATION_OBSERVER;
	PERFORMANCE = _PERFORMANCE;
	WINDOW.document;
	IS_DOM = !!DOCUMENT.documentElement && !!DOCUMENT.head && typeof DOCUMENT.addEventListener === "function" && typeof DOCUMENT.createElement === "function";
	IS_IE = ~userAgent.indexOf("MSIE") || ~userAgent.indexOf("Trident/");
	G = /fa(k|kd|s|r|l|t|d|dr|dl|dt|b|slr|slpr|wsb|tl|ns|nds|es|gt|jr|jfr|jdr|usb|ufsb|udsb|cr|ss|sr|sl|st|sds|sdr|sdl|sdt)?[\-\ ]/, M = /Font ?Awesome ?([567 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp Duotone|Sharp|Kit|Notdog Duo|Notdog|Chisel|Etch|Graphite|Thumbprint|Jelly Fill|Jelly Duo|Jelly|Utility|Utility Fill|Utility Duo|Slab Press|Slab|Whiteboard)?.*/i;
	Q = {
		classic: {
			fa: "solid",
			fas: "solid",
			"fa-solid": "solid",
			far: "regular",
			"fa-regular": "regular",
			fal: "light",
			"fa-light": "light",
			fat: "thin",
			"fa-thin": "thin",
			fab: "brands",
			"fa-brands": "brands"
		},
		duotone: {
			fa: "solid",
			fad: "solid",
			"fa-solid": "solid",
			"fa-duotone": "solid",
			fadr: "regular",
			"fa-regular": "regular",
			fadl: "light",
			"fa-light": "light",
			fadt: "thin",
			"fa-thin": "thin"
		},
		sharp: {
			fa: "solid",
			fass: "solid",
			"fa-solid": "solid",
			fasr: "regular",
			"fa-regular": "regular",
			fasl: "light",
			"fa-light": "light",
			fast: "thin",
			"fa-thin": "thin"
		},
		"sharp-duotone": {
			fa: "solid",
			fasds: "solid",
			"fa-solid": "solid",
			fasdr: "regular",
			"fa-regular": "regular",
			fasdl: "light",
			"fa-light": "light",
			fasdt: "thin",
			"fa-thin": "thin"
		},
		slab: {
			"fa-regular": "regular",
			faslr: "regular"
		},
		"slab-press": {
			"fa-regular": "regular",
			faslpr: "regular"
		},
		thumbprint: {
			"fa-light": "light",
			fatl: "light"
		},
		whiteboard: {
			"fa-semibold": "semibold",
			fawsb: "semibold"
		},
		notdog: {
			"fa-solid": "solid",
			fans: "solid"
		},
		"notdog-duo": {
			"fa-solid": "solid",
			fands: "solid"
		},
		etch: {
			"fa-solid": "solid",
			faes: "solid"
		},
		graphite: {
			"fa-thin": "thin",
			fagt: "thin"
		},
		jelly: {
			"fa-regular": "regular",
			fajr: "regular"
		},
		"jelly-fill": {
			"fa-regular": "regular",
			fajfr: "regular"
		},
		"jelly-duo": {
			"fa-regular": "regular",
			fajdr: "regular"
		},
		chisel: {
			"fa-regular": "regular",
			facr: "regular"
		},
		utility: {
			"fa-semibold": "semibold",
			fausb: "semibold"
		},
		"utility-duo": {
			"fa-semibold": "semibold",
			faudsb: "semibold"
		},
		"utility-fill": {
			"fa-semibold": "semibold",
			faufsb: "semibold"
		}
	}, X = {
		GROUP: "duotone-group",
		SWAP_OPACITY: "swap-opacity",
		PRIMARY: "primary",
		SECONDARY: "secondary"
	}, Z = [
		"fa-classic",
		"fa-duotone",
		"fa-sharp",
		"fa-sharp-duotone",
		"fa-thumbprint",
		"fa-whiteboard",
		"fa-notdog",
		"fa-notdog-duo",
		"fa-chisel",
		"fa-etch",
		"fa-graphite",
		"fa-jelly",
		"fa-jelly-fill",
		"fa-jelly-duo",
		"fa-slab",
		"fa-slab-press",
		"fa-utility",
		"fa-utility-duo",
		"fa-utility-fill"
	], i = "classic", t = "duotone", d = "sharp", l = "sharp-duotone", f = "chisel", h = "etch", n = "graphite", g = "jelly", o = "jelly-duo", u = "jelly-fill", m = "notdog", e = "notdog-duo", y = "slab", p = "slab-press", s = "thumbprint", w = "utility", a = "utility-duo", x = "utility-fill", b = "whiteboard", c = "Classic", I = "Duotone", F = "Sharp", v = "Sharp Duotone", S = "Chisel", A = "Etch", P = "Graphite", j = "Jelly", B = "Jelly Duo", N = "Jelly Fill", k = "Notdog", D = "Notdog Duo", T = "Slab", C = "Slab Press", W = "Thumbprint", K = "Utility", R = "Utility Duo", L = "Utility Fill", U = "Whiteboard", dt = [
		i,
		t,
		d,
		l,
		f,
		h,
		n,
		g,
		o,
		u,
		m,
		e,
		y,
		p,
		s,
		w,
		a,
		x,
		b
	];
	_ht = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_ht, i, c), t, I), d, F), l, v), f, S), h, A), n, P), g, j), o, B), u, N), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_ht, m, k), e, D), y, T), p, C), s, W), w, K), a, R), x, L), b, U);
	yt = {
		classic: {
			900: "fas",
			400: "far",
			normal: "far",
			300: "fal",
			100: "fat"
		},
		duotone: {
			900: "fad",
			400: "fadr",
			300: "fadl",
			100: "fadt"
		},
		sharp: {
			900: "fass",
			400: "fasr",
			300: "fasl",
			100: "fast"
		},
		"sharp-duotone": {
			900: "fasds",
			400: "fasdr",
			300: "fasdl",
			100: "fasdt"
		},
		slab: { 400: "faslr" },
		"slab-press": { 400: "faslpr" },
		whiteboard: { 600: "fawsb" },
		thumbprint: { 300: "fatl" },
		notdog: { 900: "fans" },
		"notdog-duo": { 900: "fands" },
		etch: { 900: "faes" },
		graphite: { 100: "fagt" },
		chisel: { 400: "facr" },
		jelly: { 400: "fajr" },
		"jelly-fill": { 400: "fajfr" },
		"jelly-duo": { 400: "fajdr" },
		utility: { 600: "fausb" },
		"utility-duo": { 600: "faudsb" },
		"utility-fill": { 600: "faufsb" }
	};
	Kt = {
		"Font Awesome 7 Free": {
			900: "fas",
			400: "far"
		},
		"Font Awesome 7 Pro": {
			900: "fas",
			400: "far",
			normal: "far",
			300: "fal",
			100: "fat"
		},
		"Font Awesome 7 Brands": {
			400: "fab",
			normal: "fab"
		},
		"Font Awesome 7 Duotone": {
			900: "fad",
			400: "fadr",
			normal: "fadr",
			300: "fadl",
			100: "fadt"
		},
		"Font Awesome 7 Sharp": {
			900: "fass",
			400: "fasr",
			normal: "fasr",
			300: "fasl",
			100: "fast"
		},
		"Font Awesome 7 Sharp Duotone": {
			900: "fasds",
			400: "fasdr",
			normal: "fasdr",
			300: "fasdl",
			100: "fasdt"
		},
		"Font Awesome 7 Jelly": {
			400: "fajr",
			normal: "fajr"
		},
		"Font Awesome 7 Jelly Fill": {
			400: "fajfr",
			normal: "fajfr"
		},
		"Font Awesome 7 Jelly Duo": {
			400: "fajdr",
			normal: "fajdr"
		},
		"Font Awesome 7 Slab": {
			400: "faslr",
			normal: "faslr"
		},
		"Font Awesome 7 Slab Press": {
			400: "faslpr",
			normal: "faslpr"
		},
		"Font Awesome 7 Thumbprint": {
			300: "fatl",
			normal: "fatl"
		},
		"Font Awesome 7 Notdog": {
			900: "fans",
			normal: "fans"
		},
		"Font Awesome 7 Notdog Duo": {
			900: "fands",
			normal: "fands"
		},
		"Font Awesome 7 Etch": {
			900: "faes",
			normal: "faes"
		},
		"Font Awesome 7 Graphite": {
			100: "fagt",
			normal: "fagt"
		},
		"Font Awesome 7 Chisel": {
			400: "facr",
			normal: "facr"
		},
		"Font Awesome 7 Whiteboard": {
			600: "fawsb",
			normal: "fawsb"
		},
		"Font Awesome 7 Utility": {
			600: "fausb",
			normal: "fausb"
		},
		"Font Awesome 7 Utility Duo": {
			600: "faudsb",
			normal: "faudsb"
		},
		"Font Awesome 7 Utility Fill": {
			600: "faufsb",
			normal: "faufsb"
		}
	};
	Et = new Map([
		["classic", {
			defaultShortPrefixId: "fas",
			defaultStyleId: "solid",
			styleIds: [
				"solid",
				"regular",
				"light",
				"thin",
				"brands"
			],
			futureStyleIds: [],
			defaultFontWeight: 900
		}],
		["duotone", {
			defaultShortPrefixId: "fad",
			defaultStyleId: "solid",
			styleIds: [
				"solid",
				"regular",
				"light",
				"thin"
			],
			futureStyleIds: [],
			defaultFontWeight: 900
		}],
		["sharp", {
			defaultShortPrefixId: "fass",
			defaultStyleId: "solid",
			styleIds: [
				"solid",
				"regular",
				"light",
				"thin"
			],
			futureStyleIds: [],
			defaultFontWeight: 900
		}],
		["sharp-duotone", {
			defaultShortPrefixId: "fasds",
			defaultStyleId: "solid",
			styleIds: [
				"solid",
				"regular",
				"light",
				"thin"
			],
			futureStyleIds: [],
			defaultFontWeight: 900
		}],
		["chisel", {
			defaultShortPrefixId: "facr",
			defaultStyleId: "regular",
			styleIds: ["regular"],
			futureStyleIds: [],
			defaultFontWeight: 400
		}],
		["etch", {
			defaultShortPrefixId: "faes",
			defaultStyleId: "solid",
			styleIds: ["solid"],
			futureStyleIds: [],
			defaultFontWeight: 900
		}],
		["graphite", {
			defaultShortPrefixId: "fagt",
			defaultStyleId: "thin",
			styleIds: ["thin"],
			futureStyleIds: [],
			defaultFontWeight: 100
		}],
		["jelly", {
			defaultShortPrefixId: "fajr",
			defaultStyleId: "regular",
			styleIds: ["regular"],
			futureStyleIds: [],
			defaultFontWeight: 400
		}],
		["jelly-duo", {
			defaultShortPrefixId: "fajdr",
			defaultStyleId: "regular",
			styleIds: ["regular"],
			futureStyleIds: [],
			defaultFontWeight: 400
		}],
		["jelly-fill", {
			defaultShortPrefixId: "fajfr",
			defaultStyleId: "regular",
			styleIds: ["regular"],
			futureStyleIds: [],
			defaultFontWeight: 400
		}],
		["notdog", {
			defaultShortPrefixId: "fans",
			defaultStyleId: "solid",
			styleIds: ["solid"],
			futureStyleIds: [],
			defaultFontWeight: 900
		}],
		["notdog-duo", {
			defaultShortPrefixId: "fands",
			defaultStyleId: "solid",
			styleIds: ["solid"],
			futureStyleIds: [],
			defaultFontWeight: 900
		}],
		["slab", {
			defaultShortPrefixId: "faslr",
			defaultStyleId: "regular",
			styleIds: ["regular"],
			futureStyleIds: [],
			defaultFontWeight: 400
		}],
		["slab-press", {
			defaultShortPrefixId: "faslpr",
			defaultStyleId: "regular",
			styleIds: ["regular"],
			futureStyleIds: [],
			defaultFontWeight: 400
		}],
		["thumbprint", {
			defaultShortPrefixId: "fatl",
			defaultStyleId: "light",
			styleIds: ["light"],
			futureStyleIds: [],
			defaultFontWeight: 300
		}],
		["utility", {
			defaultShortPrefixId: "fausb",
			defaultStyleId: "semibold",
			styleIds: ["semibold"],
			futureStyleIds: [],
			defaultFontWeight: 600
		}],
		["utility-duo", {
			defaultShortPrefixId: "faudsb",
			defaultStyleId: "semibold",
			styleIds: ["semibold"],
			futureStyleIds: [],
			defaultFontWeight: 600
		}],
		["utility-fill", {
			defaultShortPrefixId: "faufsb",
			defaultStyleId: "semibold",
			styleIds: ["semibold"],
			futureStyleIds: [],
			defaultFontWeight: 600
		}],
		["whiteboard", {
			defaultShortPrefixId: "fawsb",
			defaultStyleId: "semibold",
			styleIds: ["semibold"],
			futureStyleIds: [],
			defaultFontWeight: 600
		}]
	]), Mt = {
		chisel: { regular: "facr" },
		classic: {
			brands: "fab",
			light: "fal",
			regular: "far",
			solid: "fas",
			thin: "fat"
		},
		duotone: {
			light: "fadl",
			regular: "fadr",
			solid: "fad",
			thin: "fadt"
		},
		etch: { solid: "faes" },
		graphite: { thin: "fagt" },
		jelly: { regular: "fajr" },
		"jelly-duo": { regular: "fajdr" },
		"jelly-fill": { regular: "fajfr" },
		notdog: { solid: "fans" },
		"notdog-duo": { solid: "fands" },
		sharp: {
			light: "fasl",
			regular: "fasr",
			solid: "fass",
			thin: "fast"
		},
		"sharp-duotone": {
			light: "fasdl",
			regular: "fasdr",
			solid: "fasds",
			thin: "fasdt"
		},
		slab: { regular: "faslr" },
		"slab-press": { regular: "faslpr" },
		thumbprint: { light: "fatl" },
		utility: { semibold: "fausb" },
		"utility-duo": { semibold: "faudsb" },
		"utility-fill": { semibold: "faufsb" },
		whiteboard: { semibold: "fawsb" }
	};
	Ht = [
		"fak",
		"fa-kit",
		"fakd",
		"fa-kit-duotone"
	], Qt = {
		kit: {
			fak: "kit",
			"fa-kit": "kit"
		},
		"kit-duotone": {
			fakd: "kit-duotone",
			"fa-kit-duotone": "kit-duotone"
		}
	}, Xt = ["kit"];
	_defineProperty(_defineProperty({}, "kit", "Kit"), "kit-duotone", "Kit Duotone");
	sl = {
		kit: { "fa-kit": "fak" },
		"kit-duotone": { "fa-kit-duotone": "fakd" }
	};
	hl = {
		"Font Awesome Kit": {
			400: "fak",
			normal: "fak"
		},
		"Font Awesome Kit Duotone": {
			400: "fakd",
			normal: "fakd"
		}
	}, nl = {
		kit: { fak: "fa-kit" },
		"kit-duotone": { fakd: "fa-kit-duotone" }
	};
	ml = {
		kit: { kit: "fak" },
		"kit-duotone": { "kit-duotone": "fakd" }
	};
	t$1 = {
		GROUP: "duotone-group",
		SWAP_OPACITY: "swap-opacity",
		PRIMARY: "primary",
		SECONDARY: "secondary"
	}, f$1 = [
		"fa-classic",
		"fa-duotone",
		"fa-sharp",
		"fa-sharp-duotone",
		"fa-thumbprint",
		"fa-whiteboard",
		"fa-notdog",
		"fa-notdog-duo",
		"fa-chisel",
		"fa-etch",
		"fa-graphite",
		"fa-jelly",
		"fa-jelly-fill",
		"fa-jelly-duo",
		"fa-slab",
		"fa-slab-press",
		"fa-utility",
		"fa-utility-duo",
		"fa-utility-fill"
	];
	_wt = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_wt, "classic", "Classic"), "duotone", "Duotone"), "sharp", "Sharp"), "sharp-duotone", "Sharp Duotone"), "chisel", "Chisel"), "etch", "Etch"), "graphite", "Graphite"), "jelly", "Jelly"), "jelly-duo", "Jelly Duo"), "jelly-fill", "Jelly Fill"), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_wt, "notdog", "Notdog"), "notdog-duo", "Notdog Duo"), "slab", "Slab"), "slab-press", "Slab Press"), "thumbprint", "Thumbprint"), "utility", "Utility"), "utility-duo", "Utility Duo"), "utility-fill", "Utility Fill"), "whiteboard", "Whiteboard");
	_defineProperty(_defineProperty({}, "kit", "Kit"), "kit-duotone", "Kit Duotone");
	Hl = {
		classic: {
			"fa-brands": "fab",
			"fa-duotone": "fad",
			"fa-light": "fal",
			"fa-regular": "far",
			"fa-solid": "fas",
			"fa-thin": "fat"
		},
		duotone: {
			"fa-regular": "fadr",
			"fa-light": "fadl",
			"fa-thin": "fadt"
		},
		sharp: {
			"fa-solid": "fass",
			"fa-regular": "fasr",
			"fa-light": "fasl",
			"fa-thin": "fast"
		},
		"sharp-duotone": {
			"fa-solid": "fasds",
			"fa-regular": "fasdr",
			"fa-light": "fasdl",
			"fa-thin": "fasdt"
		},
		slab: { "fa-regular": "faslr" },
		"slab-press": { "fa-regular": "faslpr" },
		whiteboard: { "fa-semibold": "fawsb" },
		thumbprint: { "fa-light": "fatl" },
		notdog: { "fa-solid": "fans" },
		"notdog-duo": { "fa-solid": "fands" },
		etch: { "fa-solid": "faes" },
		graphite: { "fa-thin": "fagt" },
		jelly: { "fa-regular": "fajr" },
		"jelly-fill": { "fa-regular": "fajfr" },
		"jelly-duo": { "fa-regular": "fajdr" },
		chisel: { "fa-regular": "facr" },
		utility: { "fa-semibold": "fausb" },
		"utility-duo": { "fa-semibold": "faudsb" },
		"utility-fill": { "fa-semibold": "faufsb" }
	}, Y$1 = {
		classic: [
			"fas",
			"far",
			"fal",
			"fat",
			"fad"
		],
		duotone: [
			"fadr",
			"fadl",
			"fadt"
		],
		sharp: [
			"fass",
			"fasr",
			"fasl",
			"fast"
		],
		"sharp-duotone": [
			"fasds",
			"fasdr",
			"fasdl",
			"fasdt"
		],
		slab: ["faslr"],
		"slab-press": ["faslpr"],
		whiteboard: ["fawsb"],
		thumbprint: ["fatl"],
		notdog: ["fans"],
		"notdog-duo": ["fands"],
		etch: ["faes"],
		graphite: ["fagt"],
		jelly: ["fajr"],
		"jelly-fill": ["fajfr"],
		"jelly-duo": ["fajdr"],
		chisel: ["facr"],
		utility: ["fausb"],
		"utility-duo": ["faudsb"],
		"utility-fill": ["faufsb"]
	}, Xl = {
		classic: {
			fab: "fa-brands",
			fad: "fa-duotone",
			fal: "fa-light",
			far: "fa-regular",
			fas: "fa-solid",
			fat: "fa-thin"
		},
		duotone: {
			fadr: "fa-regular",
			fadl: "fa-light",
			fadt: "fa-thin"
		},
		sharp: {
			fass: "fa-solid",
			fasr: "fa-regular",
			fasl: "fa-light",
			fast: "fa-thin"
		},
		"sharp-duotone": {
			fasds: "fa-solid",
			fasdr: "fa-regular",
			fasdl: "fa-light",
			fasdt: "fa-thin"
		},
		slab: { faslr: "fa-regular" },
		"slab-press": { faslpr: "fa-regular" },
		whiteboard: { fawsb: "fa-semibold" },
		thumbprint: { fatl: "fa-light" },
		notdog: { fans: "fa-solid" },
		"notdog-duo": { fands: "fa-solid" },
		etch: { faes: "fa-solid" },
		graphite: { fagt: "fa-thin" },
		jelly: { fajr: "fa-regular" },
		"jelly-fill": { fajfr: "fa-regular" },
		"jelly-duo": { fajdr: "fa-regular" },
		chisel: { facr: "fa-regular" },
		utility: { fausb: "fa-semibold" },
		"utility-duo": { faudsb: "fa-semibold" },
		"utility-fill": { faufsb: "fa-semibold" }
	}, lo = [
		"fa",
		"fas",
		"far",
		"fal",
		"fat",
		"fad",
		"fadr",
		"fadl",
		"fadt",
		"fab",
		"fass",
		"fasr",
		"fasl",
		"fast",
		"fasds",
		"fasdr",
		"fasdl",
		"fasdt",
		"faslr",
		"faslpr",
		"fawsb",
		"fatl",
		"fans",
		"fands",
		"faes",
		"fagt",
		"fajr",
		"fajfr",
		"fajdr",
		"facr",
		"fausb",
		"faudsb",
		"faufsb"
	].concat(f$1, [
		"fa-solid",
		"fa-regular",
		"fa-light",
		"fa-thin",
		"fa-duotone",
		"fa-brands",
		"fa-semibold"
	]), $ = [
		"solid",
		"regular",
		"light",
		"thin",
		"duotone",
		"brands",
		"semibold"
	], z$1 = [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10
	], q$1 = z$1.concat([
		11,
		12,
		13,
		14,
		15,
		16,
		17,
		18,
		19,
		20
	]), so = [].concat(_toConsumableArray(Object.keys(Y$1)), $, [
		"aw",
		"fw",
		"pull-left",
		"pull-right"
	], [
		"2xs",
		"xs",
		"sm",
		"lg",
		"xl",
		"2xl",
		"beat",
		"border",
		"fade",
		"beat-fade",
		"bounce",
		"flip-both",
		"flip-horizontal",
		"flip-vertical",
		"flip",
		"inverse",
		"layers",
		"layers-bottom-left",
		"layers-bottom-right",
		"layers-counter",
		"layers-text",
		"layers-top-left",
		"layers-top-right",
		"li",
		"pull-end",
		"pull-start",
		"pulse",
		"rotate-180",
		"rotate-270",
		"rotate-90",
		"rotate-by",
		"shake",
		"spin-pulse",
		"spin-reverse",
		"spin",
		"stack-1x",
		"stack-2x",
		"stack",
		"ul",
		"width-auto",
		"width-fixed",
		t$1.GROUP,
		t$1.SWAP_OPACITY,
		t$1.PRIMARY,
		t$1.SECONDARY
	]).concat(z$1.map(function(l) {
		return "".concat(l, "x");
	})).concat(q$1.map(function(l) {
		return "w-".concat(l);
	}));
	fo = {
		"Font Awesome 5 Free": {
			900: "fas",
			400: "far"
		},
		"Font Awesome 5 Pro": {
			900: "fas",
			400: "far",
			normal: "far",
			300: "fal"
		},
		"Font Awesome 5 Brands": {
			400: "fab",
			normal: "fab"
		},
		"Font Awesome 5 Duotone": { 900: "fad" }
	};
	NAMESPACE_IDENTIFIER = "___FONT_AWESOME___";
	UNITS_IN_GRID = 16;
	DEFAULT_CSS_PREFIX = "fa";
	DEFAULT_REPLACEMENT_CLASS = "svg-inline--fa";
	DATA_FA_I2SVG = "data-fa-i2svg";
	DATA_FA_PSEUDO_ELEMENT = "data-fa-pseudo-element";
	DATA_FA_PSEUDO_ELEMENT_PENDING = "data-fa-pseudo-element-pending";
	DATA_PREFIX = "data-prefix";
	DATA_ICON = "data-icon";
	HTML_CLASS_I2SVG_BASE_CLASS = "fontawesome-i2svg";
	MUTATION_APPROACH_ASYNC = "async";
	TAGNAMES_TO_SKIP_FOR_PSEUDOELEMENTS = [
		"HTML",
		"HEAD",
		"STYLE",
		"SCRIPT"
	];
	PSEUDO_ELEMENTS = [
		"::before",
		"::after",
		":before",
		":after"
	];
	PRODUCTION = function() {
		try {
			return true;
		} catch (e$$1) {
			return false;
		}
	}();
	_PREFIX_TO_STYLE = _objectSpread2({}, Q);
	_PREFIX_TO_STYLE[i] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, { "fa-duotone": "duotone" }), Q[i]), Qt["kit"]), Qt["kit-duotone"]);
	PREFIX_TO_STYLE = familyProxy(_PREFIX_TO_STYLE);
	_STYLE_TO_PREFIX = _objectSpread2({}, Mt);
	_STYLE_TO_PREFIX[i] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, { duotone: "fad" }), _STYLE_TO_PREFIX[i]), ml["kit"]), ml["kit-duotone"]);
	STYLE_TO_PREFIX = familyProxy(_STYLE_TO_PREFIX);
	_PREFIX_TO_LONG_STYLE = _objectSpread2({}, Xl);
	_PREFIX_TO_LONG_STYLE[i] = _objectSpread2(_objectSpread2({}, _PREFIX_TO_LONG_STYLE[i]), nl["kit"]);
	PREFIX_TO_LONG_STYLE = familyProxy(_PREFIX_TO_LONG_STYLE);
	_LONG_STYLE_TO_PREFIX = _objectSpread2({}, Hl);
	_LONG_STYLE_TO_PREFIX[i] = _objectSpread2(_objectSpread2({}, _LONG_STYLE_TO_PREFIX[i]), sl["kit"]);
	familyProxy(_LONG_STYLE_TO_PREFIX);
	ICON_SELECTION_SYNTAX_PATTERN = G;
	LAYERS_TEXT_CLASSNAME = "fa-layers-text";
	FONT_FAMILY_PATTERN = M;
	familyProxy(_objectSpread2({}, yt));
	ATTRIBUTES_WATCHED_FOR_MUTATION = [
		"class",
		"data-prefix",
		"data-icon",
		"data-fa-transform",
		"data-fa-mask"
	];
	DUOTONE_CLASSES = X;
	RESERVED_CLASSES = [].concat(_toConsumableArray(Xt), _toConsumableArray(so));
	initial = WINDOW.FontAwesomeConfig || {};
	if (DOCUMENT && typeof DOCUMENT.querySelector === "function") [
		["data-family-prefix", "familyPrefix"],
		["data-css-prefix", "cssPrefix"],
		["data-family-default", "familyDefault"],
		["data-style-default", "styleDefault"],
		["data-replacement-class", "replacementClass"],
		["data-auto-replace-svg", "autoReplaceSvg"],
		["data-auto-add-css", "autoAddCss"],
		["data-search-pseudo-elements", "searchPseudoElements"],
		["data-search-pseudo-elements-warnings", "searchPseudoElementsWarnings"],
		["data-search-pseudo-elements-full-scan", "searchPseudoElementsFullScan"],
		["data-observe-mutations", "observeMutations"],
		["data-mutate-approach", "mutateApproach"],
		["data-keep-original-source", "keepOriginalSource"],
		["data-measure-performance", "measurePerformance"],
		["data-show-missing-icons", "showMissingIcons"]
	].forEach(function(_ref) {
		var _ref2 = _slicedToArray(_ref, 2), attr = _ref2[0], key = _ref2[1];
		var val = coerce(getAttrConfig(attr));
		if (val !== void 0 && val !== null) initial[key] = val;
	});
	_default = {
		styleDefault: "solid",
		familyDefault: i,
		cssPrefix: DEFAULT_CSS_PREFIX,
		replacementClass: DEFAULT_REPLACEMENT_CLASS,
		autoReplaceSvg: true,
		autoAddCss: true,
		searchPseudoElements: false,
		searchPseudoElementsWarnings: true,
		searchPseudoElementsFullScan: false,
		observeMutations: true,
		mutateApproach: "async",
		keepOriginalSource: true,
		measurePerformance: false,
		showMissingIcons: true
	};
	if (initial.familyPrefix) initial.cssPrefix = initial.familyPrefix;
	_config = _objectSpread2(_objectSpread2({}, _default), initial);
	if (!_config.autoReplaceSvg) _config.observeMutations = false;
	config = {};
	Object.keys(_default).forEach(function(key) {
		Object.defineProperty(config, key, {
			enumerable: true,
			set: function set(val) {
				_config[key] = val;
				_onChangeCb.forEach(function(cb) {
					return cb(config);
				});
			},
			get: function get() {
				return _config[key];
			}
		});
	});
	Object.defineProperty(config, "familyPrefix", {
		enumerable: true,
		set: function set(val) {
			_config.cssPrefix = val;
			_onChangeCb.forEach(function(cb) {
				return cb(config);
			});
		},
		get: function get() {
			return _config.cssPrefix;
		}
	});
	WINDOW.FontAwesomeConfig = config;
	_onChangeCb = [];
	d$2 = UNITS_IN_GRID;
	meaninglessTransform = {
		size: 16,
		x: 0,
		y: 0,
		rotate: 0,
		flipX: false,
		flipY: false
	};
	idPool = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	baseStyles = ":root, :host {\n  --fa-font-solid: normal 900 1em/1 'Font Awesome 7 Free';\n  --fa-font-regular: normal 400 1em/1 'Font Awesome 7 Free';\n  --fa-font-light: normal 300 1em/1 'Font Awesome 7 Pro';\n  --fa-font-thin: normal 100 1em/1 'Font Awesome 7 Pro';\n  --fa-font-duotone: normal 900 1em/1 'Font Awesome 7 Duotone';\n  --fa-font-duotone-regular: normal 400 1em/1 'Font Awesome 7 Duotone';\n  --fa-font-duotone-light: normal 300 1em/1 'Font Awesome 7 Duotone';\n  --fa-font-duotone-thin: normal 100 1em/1 'Font Awesome 7 Duotone';\n  --fa-font-brands: normal 400 1em/1 'Font Awesome 7 Brands';\n  --fa-font-sharp-solid: normal 900 1em/1 'Font Awesome 7 Sharp';\n  --fa-font-sharp-regular: normal 400 1em/1 'Font Awesome 7 Sharp';\n  --fa-font-sharp-light: normal 300 1em/1 'Font Awesome 7 Sharp';\n  --fa-font-sharp-thin: normal 100 1em/1 'Font Awesome 7 Sharp';\n  --fa-font-sharp-duotone-solid: normal 900 1em/1 'Font Awesome 7 Sharp Duotone';\n  --fa-font-sharp-duotone-regular: normal 400 1em/1 'Font Awesome 7 Sharp Duotone';\n  --fa-font-sharp-duotone-light: normal 300 1em/1 'Font Awesome 7 Sharp Duotone';\n  --fa-font-sharp-duotone-thin: normal 100 1em/1 'Font Awesome 7 Sharp Duotone';\n  --fa-font-slab-regular: normal 400 1em/1 'Font Awesome 7 Slab';\n  --fa-font-slab-press-regular: normal 400 1em/1 'Font Awesome 7 Slab Press';\n  --fa-font-whiteboard-semibold: normal 600 1em/1 'Font Awesome 7 Whiteboard';\n  --fa-font-thumbprint-light: normal 300 1em/1 'Font Awesome 7 Thumbprint';\n  --fa-font-notdog-solid: normal 900 1em/1 'Font Awesome 7 Notdog';\n  --fa-font-notdog-duo-solid: normal 900 1em/1 'Font Awesome 7 Notdog Duo';\n  --fa-font-etch-solid: normal 900 1em/1 'Font Awesome 7 Etch';\n  --fa-font-graphite-thin: normal 100 1em/1 'Font Awesome 7 Graphite';\n  --fa-font-jelly-regular: normal 400 1em/1 'Font Awesome 7 Jelly';\n  --fa-font-jelly-fill-regular: normal 400 1em/1 'Font Awesome 7 Jelly Fill';\n  --fa-font-jelly-duo-regular: normal 400 1em/1 'Font Awesome 7 Jelly Duo';\n  --fa-font-chisel-regular: normal 400 1em/1 'Font Awesome 7 Chisel';\n  --fa-font-utility-semibold: normal 600 1em/1 'Font Awesome 7 Utility';\n  --fa-font-utility-duo-semibold: normal 600 1em/1 'Font Awesome 7 Utility Duo';\n  --fa-font-utility-fill-semibold: normal 600 1em/1 'Font Awesome 7 Utility Fill';\n}\n\n.svg-inline--fa {\n  box-sizing: content-box;\n  display: var(--fa-display, inline-block);\n  height: 1em;\n  overflow: visible;\n  vertical-align: -0.125em;\n  width: var(--fa-width, 1.25em);\n}\n.svg-inline--fa.fa-2xs {\n  vertical-align: 0.1em;\n}\n.svg-inline--fa.fa-xs {\n  vertical-align: 0em;\n}\n.svg-inline--fa.fa-sm {\n  vertical-align: -0.0714285714em;\n}\n.svg-inline--fa.fa-lg {\n  vertical-align: -0.2em;\n}\n.svg-inline--fa.fa-xl {\n  vertical-align: -0.25em;\n}\n.svg-inline--fa.fa-2xl {\n  vertical-align: -0.3125em;\n}\n.svg-inline--fa.fa-pull-left,\n.svg-inline--fa .fa-pull-start {\n  float: inline-start;\n  margin-inline-end: var(--fa-pull-margin, 0.3em);\n}\n.svg-inline--fa.fa-pull-right,\n.svg-inline--fa .fa-pull-end {\n  float: inline-end;\n  margin-inline-start: var(--fa-pull-margin, 0.3em);\n}\n.svg-inline--fa.fa-li {\n  width: var(--fa-li-width, 2em);\n  inset-inline-start: calc(-1 * var(--fa-li-width, 2em));\n  inset-block-start: 0.25em; /* syncing vertical alignment with Web Font rendering */\n}\n\n.fa-layers-counter, .fa-layers-text {\n  display: inline-block;\n  position: absolute;\n  text-align: center;\n}\n\n.fa-layers {\n  display: inline-block;\n  height: 1em;\n  position: relative;\n  text-align: center;\n  vertical-align: -0.125em;\n  width: var(--fa-width, 1.25em);\n}\n.fa-layers .svg-inline--fa {\n  inset: 0;\n  margin: auto;\n  position: absolute;\n  transform-origin: center center;\n}\n\n.fa-layers-text {\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n  transform-origin: center center;\n}\n\n.fa-layers-counter {\n  background-color: var(--fa-counter-background-color, #ff253a);\n  border-radius: var(--fa-counter-border-radius, 1em);\n  box-sizing: border-box;\n  color: var(--fa-inverse, #fff);\n  line-height: var(--fa-counter-line-height, 1);\n  max-width: var(--fa-counter-max-width, 5em);\n  min-width: var(--fa-counter-min-width, 1.5em);\n  overflow: hidden;\n  padding: var(--fa-counter-padding, 0.25em 0.5em);\n  right: var(--fa-right, 0);\n  text-overflow: ellipsis;\n  top: var(--fa-top, 0);\n  transform: scale(var(--fa-counter-scale, 0.25));\n  transform-origin: top right;\n}\n\n.fa-layers-bottom-right {\n  bottom: var(--fa-bottom, 0);\n  right: var(--fa-right, 0);\n  top: auto;\n  transform: scale(var(--fa-layers-scale, 0.25));\n  transform-origin: bottom right;\n}\n\n.fa-layers-bottom-left {\n  bottom: var(--fa-bottom, 0);\n  left: var(--fa-left, 0);\n  right: auto;\n  top: auto;\n  transform: scale(var(--fa-layers-scale, 0.25));\n  transform-origin: bottom left;\n}\n\n.fa-layers-top-right {\n  top: var(--fa-top, 0);\n  right: var(--fa-right, 0);\n  transform: scale(var(--fa-layers-scale, 0.25));\n  transform-origin: top right;\n}\n\n.fa-layers-top-left {\n  left: var(--fa-left, 0);\n  right: auto;\n  top: var(--fa-top, 0);\n  transform: scale(var(--fa-layers-scale, 0.25));\n  transform-origin: top left;\n}\n\n.fa-1x {\n  font-size: 1em;\n}\n\n.fa-2x {\n  font-size: 2em;\n}\n\n.fa-3x {\n  font-size: 3em;\n}\n\n.fa-4x {\n  font-size: 4em;\n}\n\n.fa-5x {\n  font-size: 5em;\n}\n\n.fa-6x {\n  font-size: 6em;\n}\n\n.fa-7x {\n  font-size: 7em;\n}\n\n.fa-8x {\n  font-size: 8em;\n}\n\n.fa-9x {\n  font-size: 9em;\n}\n\n.fa-10x {\n  font-size: 10em;\n}\n\n.fa-2xs {\n  font-size: calc(10 / 16 * 1em); /* converts a 10px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 10 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 10 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-xs {\n  font-size: calc(12 / 16 * 1em); /* converts a 12px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 12 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 12 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-sm {\n  font-size: calc(14 / 16 * 1em); /* converts a 14px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 14 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 14 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-lg {\n  font-size: calc(20 / 16 * 1em); /* converts a 20px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 20 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 20 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-xl {\n  font-size: calc(24 / 16 * 1em); /* converts a 24px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 24 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 24 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-2xl {\n  font-size: calc(32 / 16 * 1em); /* converts a 32px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 32 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 32 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-width-auto {\n  --fa-width: auto;\n}\n\n.fa-fw,\n.fa-width-fixed {\n  --fa-width: 1.25em;\n}\n\n.fa-ul {\n  list-style-type: none;\n  margin-inline-start: var(--fa-li-margin, 2.5em);\n  padding-inline-start: 0;\n}\n.fa-ul > li {\n  position: relative;\n}\n\n.fa-li {\n  inset-inline-start: calc(-1 * var(--fa-li-width, 2em));\n  position: absolute;\n  text-align: center;\n  width: var(--fa-li-width, 2em);\n  line-height: inherit;\n}\n\n/* Heads Up: Bordered Icons will not be supported in the future!\n  - This feature will be deprecated in the next major release of Font Awesome (v8)!\n  - You may continue to use it in this version *v7), but it will not be supported in Font Awesome v8.\n*/\n/* Notes:\n* --@{v.$css-prefix}-border-width = 1/16 by default (to render as ~1px based on a 16px default font-size)\n* --@{v.$css-prefix}-border-padding =\n  ** 3/16 for vertical padding (to give ~2px of vertical whitespace around an icon considering it's vertical alignment)\n  ** 4/16 for horizontal padding (to give ~4px of horizontal whitespace around an icon)\n*/\n.fa-border {\n  border-color: var(--fa-border-color, #eee);\n  border-radius: var(--fa-border-radius, 0.1em);\n  border-style: var(--fa-border-style, solid);\n  border-width: var(--fa-border-width, 0.0625em);\n  box-sizing: var(--fa-border-box-sizing, content-box);\n  padding: var(--fa-border-padding, 0.1875em 0.25em);\n}\n\n.fa-pull-left,\n.fa-pull-start {\n  float: inline-start;\n  margin-inline-end: var(--fa-pull-margin, 0.3em);\n}\n\n.fa-pull-right,\n.fa-pull-end {\n  float: inline-end;\n  margin-inline-start: var(--fa-pull-margin, 0.3em);\n}\n\n.fa-beat {\n  animation-name: fa-beat;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, ease-in-out);\n}\n\n.fa-bounce {\n  animation-name: fa-bounce;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));\n}\n\n.fa-fade {\n  animation-name: fa-fade;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));\n}\n\n.fa-beat-fade {\n  animation-name: fa-beat-fade;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));\n}\n\n.fa-flip {\n  animation-name: fa-flip;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, ease-in-out);\n}\n\n.fa-shake {\n  animation-name: fa-shake;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, linear);\n}\n\n.fa-spin {\n  animation-name: fa-spin;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 2s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, linear);\n}\n\n.fa-spin-reverse {\n  --fa-animation-direction: reverse;\n}\n\n.fa-pulse,\n.fa-spin-pulse {\n  animation-name: fa-spin;\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, steps(8));\n}\n\n@media (prefers-reduced-motion: reduce) {\n  .fa-beat,\n  .fa-bounce,\n  .fa-fade,\n  .fa-beat-fade,\n  .fa-flip,\n  .fa-pulse,\n  .fa-shake,\n  .fa-spin,\n  .fa-spin-pulse {\n    animation: none !important;\n    transition: none !important;\n  }\n}\n@keyframes fa-beat {\n  0%, 90% {\n    transform: scale(1);\n  }\n  45% {\n    transform: scale(var(--fa-beat-scale, 1.25));\n  }\n}\n@keyframes fa-bounce {\n  0% {\n    transform: scale(1, 1) translateY(0);\n  }\n  10% {\n    transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);\n  }\n  30% {\n    transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));\n  }\n  50% {\n    transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);\n  }\n  57% {\n    transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));\n  }\n  64% {\n    transform: scale(1, 1) translateY(0);\n  }\n  100% {\n    transform: scale(1, 1) translateY(0);\n  }\n}\n@keyframes fa-fade {\n  50% {\n    opacity: var(--fa-fade-opacity, 0.4);\n  }\n}\n@keyframes fa-beat-fade {\n  0%, 100% {\n    opacity: var(--fa-beat-fade-opacity, 0.4);\n    transform: scale(1);\n  }\n  50% {\n    opacity: 1;\n    transform: scale(var(--fa-beat-fade-scale, 1.125));\n  }\n}\n@keyframes fa-flip {\n  50% {\n    transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));\n  }\n}\n@keyframes fa-shake {\n  0% {\n    transform: rotate(-15deg);\n  }\n  4% {\n    transform: rotate(15deg);\n  }\n  8%, 24% {\n    transform: rotate(-18deg);\n  }\n  12%, 28% {\n    transform: rotate(18deg);\n  }\n  16% {\n    transform: rotate(-22deg);\n  }\n  20% {\n    transform: rotate(22deg);\n  }\n  32% {\n    transform: rotate(-12deg);\n  }\n  36% {\n    transform: rotate(12deg);\n  }\n  40%, 100% {\n    transform: rotate(0deg);\n  }\n}\n@keyframes fa-spin {\n  0% {\n    transform: rotate(0deg);\n  }\n  100% {\n    transform: rotate(360deg);\n  }\n}\n.fa-rotate-90 {\n  transform: rotate(90deg);\n}\n\n.fa-rotate-180 {\n  transform: rotate(180deg);\n}\n\n.fa-rotate-270 {\n  transform: rotate(270deg);\n}\n\n.fa-flip-horizontal {\n  transform: scale(-1, 1);\n}\n\n.fa-flip-vertical {\n  transform: scale(1, -1);\n}\n\n.fa-flip-both,\n.fa-flip-horizontal.fa-flip-vertical {\n  transform: scale(-1, -1);\n}\n\n.fa-rotate-by {\n  transform: rotate(var(--fa-rotate-angle, 0));\n}\n\n.svg-inline--fa .fa-primary {\n  fill: var(--fa-primary-color, currentColor);\n  opacity: var(--fa-primary-opacity, 1);\n}\n\n.svg-inline--fa .fa-secondary {\n  fill: var(--fa-secondary-color, currentColor);\n  opacity: var(--fa-secondary-opacity, 0.4);\n}\n\n.svg-inline--fa.fa-swap-opacity .fa-primary {\n  opacity: var(--fa-secondary-opacity, 0.4);\n}\n\n.svg-inline--fa.fa-swap-opacity .fa-secondary {\n  opacity: var(--fa-primary-opacity, 1);\n}\n\n.svg-inline--fa mask .fa-primary,\n.svg-inline--fa mask .fa-secondary {\n  fill: black;\n}\n\n.svg-inline--fa.fa-inverse {\n  fill: var(--fa-inverse, #fff);\n}\n\n.fa-stack {\n  display: inline-block;\n  height: 2em;\n  line-height: 2em;\n  position: relative;\n  vertical-align: middle;\n  width: 2.5em;\n}\n\n.fa-inverse {\n  color: var(--fa-inverse, #fff);\n}\n\n.svg-inline--fa.fa-stack-1x {\n  --fa-width: 1.25em;\n  height: 1em;\n  width: var(--fa-width);\n}\n.svg-inline--fa.fa-stack-2x {\n  --fa-width: 2.5em;\n  height: 2em;\n  width: var(--fa-width);\n}\n\n.fa-stack-1x,\n.fa-stack-2x {\n  inset: 0;\n  margin: auto;\n  position: absolute;\n  z-index: var(--fa-stack-z-index, auto);\n}";
	_cssInserted = false;
	InjectCSS = {
		mixout: function mixout() {
			return { dom: {
				css,
				insertCss: ensureCss
			} };
		},
		hooks: function hooks() {
			return {
				beforeDOMElementCreation: function beforeDOMElementCreation() {
					ensureCss();
				},
				beforeI2svg: function beforeI2svg() {
					ensureCss();
				}
			};
		}
	};
	w$2 = WINDOW || {};
	if (!w$2[NAMESPACE_IDENTIFIER]) w$2[NAMESPACE_IDENTIFIER] = {};
	if (!w$2[NAMESPACE_IDENTIFIER].styles) w$2[NAMESPACE_IDENTIFIER].styles = {};
	if (!w$2[NAMESPACE_IDENTIFIER].hooks) w$2[NAMESPACE_IDENTIFIER].hooks = {};
	if (!w$2[NAMESPACE_IDENTIFIER].shims) w$2[NAMESPACE_IDENTIFIER].shims = [];
	namespace = w$2[NAMESPACE_IDENTIFIER];
	functions = [];
	_listener = function listener() {
		DOCUMENT.removeEventListener("DOMContentLoaded", _listener);
		loaded = 1;
		functions.map(function(fn) {
			return fn();
		});
	};
	loaded = false;
	if (IS_DOM) {
		loaded = (DOCUMENT.documentElement.doScroll ? /^loaded|^c/ : /^loaded|^i|^c/).test(DOCUMENT.readyState);
		if (!loaded) DOCUMENT.addEventListener("DOMContentLoaded", _listener);
	}
	bindInternal4 = function bindInternal4(func, thisContext) {
		return function(a, b, c, d) {
			return func.call(thisContext, a, b, c, d);
		};
	};
	reduce = function fastReduceObject(subject, fn, initialValue, thisContext) {
		var keys = Object.keys(subject), length = keys.length, iterator = thisContext !== void 0 ? bindInternal4(fn, thisContext) : fn, i, key, result;
		if (initialValue === void 0) {
			i = 1;
			result = subject[keys[0]];
		} else {
			i = 0;
			result = initialValue;
		}
		for (; i < length; i++) {
			key = keys[i];
			result = iterator(result, subject[key], key, subject);
		}
		return result;
	};
	styles = namespace.styles, shims = namespace.shims;
	FAMILY_NAMES = Object.keys(PREFIX_TO_LONG_STYLE);
	PREFIXES_FOR_FAMILY = FAMILY_NAMES.reduce(function(acc, familyId) {
		acc[familyId] = Object.keys(PREFIX_TO_LONG_STYLE[familyId]);
		return acc;
	}, {});
	_defaultUsablePrefix = null;
	_byUnicode = {};
	_byLigature = {};
	_byOldName = {};
	_byOldUnicode = {};
	_byAlias = {};
	build = function build() {
		var lookup = function lookup(reducer) {
			return reduce(styles, function(o$$1, style, prefix) {
				o$$1[prefix] = reduce(style, reducer, {});
				return o$$1;
			}, {});
		};
		_byUnicode = lookup(function(acc, icon, iconName) {
			if (icon[3]) acc[icon[3]] = iconName;
			if (icon[2]) icon[2].filter(function(a$$1) {
				return typeof a$$1 === "number";
			}).forEach(function(alias) {
				acc[alias.toString(16)] = iconName;
			});
			return acc;
		});
		_byLigature = lookup(function(acc, icon, iconName) {
			acc[iconName] = iconName;
			if (icon[2]) icon[2].filter(function(a$$1) {
				return typeof a$$1 === "string";
			}).forEach(function(alias) {
				acc[alias] = iconName;
			});
			return acc;
		});
		_byAlias = lookup(function(acc, icon, iconName) {
			var aliases = icon[2];
			acc[iconName] = iconName;
			aliases.forEach(function(alias) {
				acc[alias] = iconName;
			});
			return acc;
		});
		var hasRegular = "far" in styles || config.autoFetchSvg;
		var shimLookups = reduce(shims, function(acc, shim) {
			var maybeNameMaybeUnicode = shim[0];
			var prefix = shim[1];
			var iconName = shim[2];
			if (prefix === "far" && !hasRegular) prefix = "fas";
			if (typeof maybeNameMaybeUnicode === "string") acc.names[maybeNameMaybeUnicode] = {
				prefix,
				iconName
			};
			if (typeof maybeNameMaybeUnicode === "number") acc.unicodes[maybeNameMaybeUnicode.toString(16)] = {
				prefix,
				iconName
			};
			return acc;
		}, {
			names: {},
			unicodes: {}
		});
		_byOldName = shimLookups.names;
		_byOldUnicode = shimLookups.unicodes;
		_defaultUsablePrefix = getCanonicalPrefix(config.styleDefault, { family: config.familyDefault });
	};
	onChange(function(c$$1) {
		_defaultUsablePrefix = getCanonicalPrefix(c$$1.styleDefault, { family: config.familyDefault });
	});
	build();
	emptyCanonicalIcon = function emptyCanonicalIcon() {
		return {
			prefix: null,
			iconName: null,
			rest: []
		};
	};
	_faCombinedClasses = lo.concat(Ht);
	newCanonicalFamilies = dt.filter(function(familyId) {
		return familyId !== i || familyId !== t;
	});
	newCanonicalStyles = Object.keys(Xl).filter(function(key) {
		return key !== i;
	}).map(function(key) {
		return Object.keys(Xl[key]);
	}).flat();
	Library = /* @__PURE__ */ function() {
		function Library() {
			_classCallCheck(this, Library);
			this.definitions = {};
		}
		return _createClass(Library, [
			{
				key: "add",
				value: function add() {
					var _this = this;
					for (var _len = arguments.length, definitions = new Array(_len), _key = 0; _key < _len; _key++) definitions[_key] = arguments[_key];
					var additions = definitions.reduce(this._pullDefinitions, {});
					Object.keys(additions).forEach(function(key) {
						_this.definitions[key] = _objectSpread2(_objectSpread2({}, _this.definitions[key] || {}), additions[key]);
						defineIcons(key, additions[key]);
						var longPrefix = PREFIX_TO_LONG_STYLE[i][key];
						if (longPrefix) defineIcons(longPrefix, additions[key]);
						build();
					});
				}
			},
			{
				key: "reset",
				value: function reset() {
					this.definitions = {};
				}
			},
			{
				key: "_pullDefinitions",
				value: function _pullDefinitions(additions, definition) {
					var normalized = definition.prefix && definition.iconName && definition.icon ? { 0: definition } : definition;
					Object.keys(normalized).map(function(key) {
						var _normalized$key = normalized[key], prefix = _normalized$key.prefix, iconName = _normalized$key.iconName, icon = _normalized$key.icon;
						var aliases = icon[2];
						if (!additions[prefix]) additions[prefix] = {};
						if (aliases.length > 0) aliases.forEach(function(alias) {
							if (typeof alias === "string") additions[prefix][alias] = icon;
						});
						additions[prefix][iconName] = icon;
					});
					return additions;
				}
			}
		]);
	}();
	_plugins = [];
	_hooks = {};
	providers = {};
	defaultProviderKeys = Object.keys(providers);
	library = new Library();
	api = {
		noAuto: function noAuto() {
			config.autoReplaceSvg = false;
			config.observeMutations = false;
			callHooks("noAuto");
		},
		config,
		dom: {
			i2svg: function i2svg() {
				var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
				if (IS_DOM) {
					callHooks("beforeI2svg", params);
					callProvided("pseudoElements2svg", params);
					return callProvided("i2svg", params);
				} else return Promise.reject(/* @__PURE__ */ new Error("Operation requires a DOM of some kind."));
			},
			watch: function watch() {
				var params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
				var autoReplaceSvgRoot = params.autoReplaceSvgRoot;
				if (config.autoReplaceSvg === false) config.autoReplaceSvg = true;
				config.observeMutations = true;
				domready(function() {
					autoReplace({ autoReplaceSvgRoot });
					callHooks("watch", params);
				});
			}
		},
		parse: { icon: function icon(_icon) {
			if (_icon === null) return null;
			if (_typeof(_icon) === "object" && _icon.prefix && _icon.iconName) return {
				prefix: _icon.prefix,
				iconName: byAlias(_icon.prefix, _icon.iconName) || _icon.iconName
			};
			if (Array.isArray(_icon) && _icon.length === 2) {
				var iconName = _icon[1].indexOf("fa-") === 0 ? _icon[1].slice(3) : _icon[1];
				var prefix = getCanonicalPrefix(_icon[0]);
				return {
					prefix,
					iconName: byAlias(prefix, iconName) || iconName
				};
			}
			if (typeof _icon === "string" && (_icon.indexOf("".concat(config.cssPrefix, "-")) > -1 || _icon.match(ICON_SELECTION_SYNTAX_PATTERN))) {
				var canonicalIcon = getCanonicalIcon(_icon.split(" "), { skipLookups: true });
				return {
					prefix: canonicalIcon.prefix || getDefaultUsablePrefix(),
					iconName: byAlias(canonicalIcon.prefix, canonicalIcon.iconName) || canonicalIcon.iconName
				};
			}
			if (typeof _icon === "string") {
				var _prefix = getDefaultUsablePrefix();
				return {
					prefix: _prefix,
					iconName: byAlias(_prefix, _icon) || _icon
				};
			}
		} },
		library,
		findIconDefinition,
		toHtml
	};
	autoReplace = function autoReplace() {
		var _params$autoReplaceSv = (arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}).autoReplaceSvgRoot, autoReplaceSvgRoot = _params$autoReplaceSv === void 0 ? DOCUMENT : _params$autoReplaceSv;
		if ((Object.keys(namespace.styles).length > 0 || config.autoFetchSvg) && IS_DOM && config.autoReplaceSvg) api.dom.i2svg({ node: autoReplaceSvgRoot });
	};
	styles$1 = namespace.styles;
	missingIconResolutionMixin = {
		found: false,
		width: 512,
		height: 512
	};
	noop$1 = function noop() {};
	p$2 = config.measurePerformance && PERFORMANCE && PERFORMANCE.mark && PERFORMANCE.measure ? PERFORMANCE : {
		mark: noop$1,
		measure: noop$1
	};
	preamble = "FA \"7.2.0\"";
	begin = function begin(name) {
		p$2.mark("".concat(preamble, " ").concat(name, " begins"));
		return function() {
			return end(name);
		};
	};
	end = function end(name) {
		p$2.mark("".concat(preamble, " ").concat(name, " ends"));
		p$2.measure("".concat(preamble, " ").concat(name), "".concat(preamble, " ").concat(name, " begins"), "".concat(preamble, " ").concat(name, " ends"));
	};
	perf = {
		begin,
		end
	};
	noop$2 = function noop() {};
	mutators = {
		replace: function replace(mutation) {
			var node = mutation[0];
			if (node.parentNode) {
				mutation[1].forEach(function(abstract) {
					node.parentNode.insertBefore(convertSVG(abstract), node);
				});
				if (node.getAttribute(DATA_FA_I2SVG) === null && config.keepOriginalSource) {
					var comment = DOCUMENT.createComment(nodeAsComment(node));
					node.parentNode.replaceChild(comment, node);
				} else node.remove();
			}
		},
		nest: function nest(mutation) {
			var node = mutation[0];
			var abstract = mutation[1];
			if (~classArray(node).indexOf(config.replacementClass)) return mutators.replace(mutation);
			var forSvg = new RegExp("".concat(config.cssPrefix, "-.*"));
			delete abstract[0].attributes.id;
			if (abstract[0].attributes.class) {
				var splitClasses = abstract[0].attributes.class.split(" ").reduce(function(acc, cls) {
					if (cls === config.replacementClass || cls.match(forSvg)) acc.toSvg.push(cls);
					else acc.toNode.push(cls);
					return acc;
				}, {
					toNode: [],
					toSvg: []
				});
				abstract[0].attributes.class = splitClasses.toSvg.join(" ");
				if (splitClasses.toNode.length === 0) node.removeAttribute("class");
				else node.setAttribute("class", splitClasses.toNode.join(" "));
			}
			var newInnerHTML = abstract.map(function(a) {
				return toHtml(a);
			}).join("\n");
			node.setAttribute(DATA_FA_I2SVG, "");
			node.innerHTML = newInnerHTML;
		}
	};
	disabled = false;
	mo = null;
	styles$2 = namespace.styles;
	render = function render(iconDefinition) {
		var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		var _params$transform = params.transform, transform = _params$transform === void 0 ? meaninglessTransform : _params$transform, _params$symbol = params.symbol, symbol = _params$symbol === void 0 ? false : _params$symbol, _params$mask = params.mask, mask = _params$mask === void 0 ? null : _params$mask, _params$maskId = params.maskId, maskId = _params$maskId === void 0 ? null : _params$maskId, _params$classes = params.classes, classes = _params$classes === void 0 ? [] : _params$classes, _params$attributes = params.attributes, attributes = _params$attributes === void 0 ? {} : _params$attributes, _params$styles = params.styles, styles = _params$styles === void 0 ? {} : _params$styles;
		if (!iconDefinition) return;
		var prefix = iconDefinition.prefix, iconName = iconDefinition.iconName, icon = iconDefinition.icon;
		return domVariants(_objectSpread2({ type: "icon" }, iconDefinition), function() {
			callHooks("beforeDOMElementCreation", {
				iconDefinition,
				params
			});
			return makeInlineSvgAbstract({
				icons: {
					main: asFoundIcon(icon),
					mask: mask ? asFoundIcon(mask.icon) : {
						found: false,
						width: null,
						height: null,
						icon: {}
					}
				},
				prefix,
				iconName,
				transform: _objectSpread2(_objectSpread2({}, meaninglessTransform), transform),
				symbol,
				maskId,
				extra: {
					attributes,
					styles,
					classes
				}
			});
		});
	};
	ReplaceElements = {
		mixout: function mixout() {
			return { icon: resolveIcons(render) };
		},
		hooks: function hooks() {
			return { mutationObserverCallbacks: function mutationObserverCallbacks(accumulator) {
				accumulator.treeCallback = onTree;
				accumulator.nodeCallback = onNode;
				return accumulator;
			} };
		},
		provides: function provides(providers$$1) {
			providers$$1.i2svg = function(params) {
				var _params$node = params.node, node = _params$node === void 0 ? DOCUMENT : _params$node, _params$callback = params.callback;
				return onTree(node, _params$callback === void 0 ? function() {} : _params$callback);
			};
			providers$$1.generateSvgReplacementMutation = function(node, nodeMeta) {
				var iconName = nodeMeta.iconName, prefix = nodeMeta.prefix, transform = nodeMeta.transform, symbol = nodeMeta.symbol, mask = nodeMeta.mask, maskId = nodeMeta.maskId, extra = nodeMeta.extra;
				return new Promise(function(resolve, reject) {
					Promise.all([findIcon(iconName, prefix), mask.iconName ? findIcon(mask.iconName, mask.prefix) : Promise.resolve({
						found: false,
						width: 512,
						height: 512,
						icon: {}
					})]).then(function(_ref) {
						var _ref2 = _slicedToArray(_ref, 2), main = _ref2[0], mask = _ref2[1];
						resolve([node, makeInlineSvgAbstract({
							icons: {
								main,
								mask
							},
							prefix,
							iconName,
							transform,
							symbol,
							maskId,
							extra,
							watchable: true
						})]);
					}).catch(reject);
				});
			};
			providers$$1.generateAbstractIcon = function(_ref3) {
				var children = _ref3.children, attributes = _ref3.attributes, main = _ref3.main, transform = _ref3.transform, styles = _ref3.styles;
				var styleString = joinStyles(styles);
				if (styleString.length > 0) attributes["style"] = styleString;
				var nextChild;
				if (transformIsMeaningful(transform)) nextChild = callProvided("generateAbstractTransformGrouping", {
					main,
					transform,
					containerWidth: main.width,
					iconWidth: main.width
				});
				children.push(nextChild || main.icon);
				return {
					children,
					attributes
				};
			};
		}
	};
	Layers = { mixout: function mixout() {
		return { layer: function layer(assembler) {
			var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
			var _params$classes = params.classes, classes = _params$classes === void 0 ? [] : _params$classes;
			return domVariants({ type: "layer" }, function() {
				callHooks("beforeDOMElementCreation", {
					assembler,
					params
				});
				var children = [];
				assembler(function(args) {
					Array.isArray(args) ? args.map(function(a) {
						children = children.concat(a.abstract);
					}) : children = children.concat(args.abstract);
				});
				return [{
					tag: "span",
					attributes: { class: ["".concat(config.cssPrefix, "-layers")].concat(_toConsumableArray(classes)).join(" ") },
					children
				}];
			});
		} };
	} };
	LayersCounter = { mixout: function mixout() {
		return { counter: function counter(content) {
			var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
			var _params$title = params.title, title = _params$title === void 0 ? null : _params$title, _params$classes = params.classes, classes = _params$classes === void 0 ? [] : _params$classes, _params$attributes = params.attributes, attributes = _params$attributes === void 0 ? {} : _params$attributes, _params$styles = params.styles, styles = _params$styles === void 0 ? {} : _params$styles;
			return domVariants({
				type: "counter",
				content
			}, function() {
				callHooks("beforeDOMElementCreation", {
					content,
					params
				});
				return makeLayersCounterAbstract({
					content: content.toString(),
					title,
					extra: {
						attributes,
						styles,
						classes: ["".concat(config.cssPrefix, "-layers-counter")].concat(_toConsumableArray(classes))
					}
				});
			});
		} };
	} };
	LayersText = {
		mixout: function mixout() {
			return { text: function text(content) {
				var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
				var _params$transform = params.transform, transform = _params$transform === void 0 ? meaninglessTransform : _params$transform, _params$classes = params.classes, classes = _params$classes === void 0 ? [] : _params$classes, _params$attributes = params.attributes, attributes = _params$attributes === void 0 ? {} : _params$attributes, _params$styles = params.styles, styles = _params$styles === void 0 ? {} : _params$styles;
				return domVariants({
					type: "text",
					content
				}, function() {
					callHooks("beforeDOMElementCreation", {
						content,
						params
					});
					return makeLayersTextAbstract({
						content,
						transform: _objectSpread2(_objectSpread2({}, meaninglessTransform), transform),
						extra: {
							attributes,
							styles,
							classes: ["".concat(config.cssPrefix, "-layers-text")].concat(_toConsumableArray(classes))
						}
					});
				});
			} };
		},
		provides: function provides(providers$$1) {
			providers$$1.generateLayersText = function(node, nodeMeta) {
				var transform = nodeMeta.transform, extra = nodeMeta.extra;
				var width = null;
				var height = null;
				if (IS_IE) {
					var computedFontSize = parseInt(getComputedStyle(node).fontSize, 10);
					var boundingClientRect = node.getBoundingClientRect();
					width = boundingClientRect.width / computedFontSize;
					height = boundingClientRect.height / computedFontSize;
				}
				return Promise.resolve([node, makeLayersTextAbstract({
					content: node.innerHTML,
					width,
					height,
					transform,
					extra,
					watchable: true
				})]);
			};
		}
	};
	CLEAN_CONTENT_PATTERN = /* @__PURE__ */ new RegExp("\"", "ug");
	SECONDARY_UNICODE_RANGE = [1105920, 1112319];
	_FONT_FAMILY_WEIGHT_TO_PREFIX = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, { FontAwesome: {
		normal: "fas",
		400: "fas"
	} }), Kt), fo), hl);
	FONT_FAMILY_WEIGHT_TO_PREFIX = Object.keys(_FONT_FAMILY_WEIGHT_TO_PREFIX).reduce(function(acc, key) {
		acc[key.toLowerCase()] = _FONT_FAMILY_WEIGHT_TO_PREFIX[key];
		return acc;
	}, {});
	FONT_FAMILY_WEIGHT_FALLBACK = Object.keys(FONT_FAMILY_WEIGHT_TO_PREFIX).reduce(function(acc, fontFamily) {
		var weights = FONT_FAMILY_WEIGHT_TO_PREFIX[fontFamily];
		acc[fontFamily] = weights[900] || _toConsumableArray(Object.entries(weights))[0][1];
		return acc;
	}, {});
	hasPseudoElement = function hasPseudoElement(selector) {
		return !!selector && PSEUDO_ELEMENTS.some(function(pseudoSelector) {
			return selector.includes(pseudoSelector);
		});
	};
	parseCSSRuleForPseudos = function parseCSSRuleForPseudos(selectorText) {
		if (!selectorText) return [];
		var selectorSet = /* @__PURE__ */ new Set();
		var selectors = selectorText.split(/,(?![^()]*\))/).map(function(s$$1) {
			return s$$1.trim();
		});
		selectors = selectors.flatMap(function(selector) {
			return selector.includes("(") ? selector : selector.split(",").map(function(s$$1) {
				return s$$1.trim();
			});
		});
		var _iterator = _createForOfIteratorHelper(selectors), _step;
		try {
			for (_iterator.s(); !(_step = _iterator.n()).done;) {
				var selector = _step.value;
				if (hasPseudoElement(selector)) {
					var selectorWithoutPseudo = PSEUDO_ELEMENTS.reduce(function(acc, pseudoSelector) {
						return acc.replace(pseudoSelector, "");
					}, selector);
					if (selectorWithoutPseudo !== "" && selectorWithoutPseudo !== "*") selectorSet.add(selectorWithoutPseudo);
				}
			}
		} catch (err) {
			_iterator.e(err);
		} finally {
			_iterator.f();
		}
		return selectorSet;
	};
	PseudoElements = {
		hooks: function hooks() {
			return { mutationObserverCallbacks: function mutationObserverCallbacks(accumulator) {
				accumulator.pseudoElementsCallback = searchPseudoElements;
				return accumulator;
			} };
		},
		provides: function provides(providers) {
			providers.pseudoElements2svg = function(params) {
				var _params$node = params.node, node = _params$node === void 0 ? DOCUMENT : _params$node;
				if (config.searchPseudoElements) searchPseudoElements(node);
			};
		}
	};
	_unwatched = false;
	MutationObserver$1 = {
		mixout: function mixout() {
			return { dom: { unwatch: function unwatch() {
				disableObservation();
				_unwatched = true;
			} } };
		},
		hooks: function hooks() {
			return {
				bootstrap: function bootstrap() {
					observe(chainHooks("mutationObserverCallbacks", {}));
				},
				noAuto: function noAuto() {
					disconnect();
				},
				watch: function watch(params) {
					var observeMutationsRoot = params.observeMutationsRoot;
					if (_unwatched) enableObservation();
					else observe(chainHooks("mutationObserverCallbacks", { observeMutationsRoot }));
				}
			};
		}
	};
	parseTransformString = function parseTransformString(transformString) {
		return transformString.toLowerCase().split(" ").reduce(function(acc, n) {
			var parts = n.toLowerCase().split("-");
			var first = parts[0];
			var rest = parts.slice(1).join("-");
			if (first && rest === "h") {
				acc.flipX = true;
				return acc;
			}
			if (first && rest === "v") {
				acc.flipY = true;
				return acc;
			}
			rest = parseFloat(rest);
			if (isNaN(rest)) return acc;
			switch (first) {
				case "grow":
					acc.size = acc.size + rest;
					break;
				case "shrink":
					acc.size = acc.size - rest;
					break;
				case "left":
					acc.x = acc.x - rest;
					break;
				case "right":
					acc.x = acc.x + rest;
					break;
				case "up":
					acc.y = acc.y - rest;
					break;
				case "down":
					acc.y = acc.y + rest;
					break;
				case "rotate":
					acc.rotate = acc.rotate + rest;
					break;
			}
			return acc;
		}, {
			size: 16,
			x: 0,
			y: 0,
			flipX: false,
			flipY: false,
			rotate: 0
		});
	};
	PowerTransforms = {
		mixout: function mixout() {
			return { parse: { transform: function transform(transformString) {
				return parseTransformString(transformString);
			} } };
		},
		hooks: function hooks() {
			return { parseNodeAttributes: function parseNodeAttributes(accumulator, node) {
				var transformString = node.getAttribute("data-fa-transform");
				if (transformString) accumulator.transform = parseTransformString(transformString);
				return accumulator;
			} };
		},
		provides: function provides(providers) {
			providers.generateAbstractTransformGrouping = function(_ref) {
				var main = _ref.main, transform = _ref.transform, containerWidth = _ref.containerWidth, iconWidth = _ref.iconWidth;
				var outer = { transform: "translate(".concat(containerWidth / 2, " 256)") };
				var innerTranslate = "translate(".concat(transform.x * 32, ", ").concat(transform.y * 32, ") ");
				var innerScale = "scale(".concat(transform.size / 16 * (transform.flipX ? -1 : 1), ", ").concat(transform.size / 16 * (transform.flipY ? -1 : 1), ") ");
				var innerRotate = "rotate(".concat(transform.rotate, " 0 0)");
				var operations = {
					outer,
					inner: { transform: "".concat(innerTranslate, " ").concat(innerScale, " ").concat(innerRotate) },
					path: { transform: "translate(".concat(iconWidth / 2 * -1, " -256)") }
				};
				return {
					tag: "g",
					attributes: _objectSpread2({}, operations.outer),
					children: [{
						tag: "g",
						attributes: _objectSpread2({}, operations.inner),
						children: [{
							tag: main.icon.tag,
							children: main.icon.children,
							attributes: _objectSpread2(_objectSpread2({}, main.icon.attributes), operations.path)
						}]
					}]
				};
			};
		}
	};
	ALL_SPACE = {
		x: 0,
		y: 0,
		width: "100%",
		height: "100%"
	};
	registerPlugins([
		InjectCSS,
		ReplaceElements,
		Layers,
		LayersCounter,
		LayersText,
		PseudoElements,
		MutationObserver$1,
		PowerTransforms,
		{
			hooks: function hooks() {
				return { parseNodeAttributes: function parseNodeAttributes(accumulator, node) {
					var maskData = node.getAttribute("data-fa-mask");
					var mask = !maskData ? emptyCanonicalIcon() : getCanonicalIcon(maskData.split(" ").map(function(i) {
						return i.trim();
					}));
					if (!mask.prefix) mask.prefix = getDefaultUsablePrefix();
					accumulator.mask = mask;
					accumulator.maskId = node.getAttribute("data-fa-mask-id");
					return accumulator;
				} };
			},
			provides: function provides(providers) {
				providers.generateAbstractMask = function(_ref) {
					var children = _ref.children, attributes = _ref.attributes, main = _ref.main, mask = _ref.mask, explicitMaskId = _ref.maskId, transform = _ref.transform;
					var mainWidth = main.width, mainPath = main.icon;
					var maskWidth = mask.width, maskPath = mask.icon;
					var trans = transformForSvg({
						transform,
						containerWidth: maskWidth,
						iconWidth: mainWidth
					});
					var maskRect = {
						tag: "rect",
						attributes: _objectSpread2(_objectSpread2({}, ALL_SPACE), {}, { fill: "white" })
					};
					var maskInnerGroupChildrenMixin = mainPath.children ? { children: mainPath.children.map(fillBlack) } : {};
					var maskInnerGroup = {
						tag: "g",
						attributes: _objectSpread2({}, trans.inner),
						children: [fillBlack(_objectSpread2({
							tag: mainPath.tag,
							attributes: _objectSpread2(_objectSpread2({}, mainPath.attributes), trans.path)
						}, maskInnerGroupChildrenMixin))]
					};
					var maskOuterGroup = {
						tag: "g",
						attributes: _objectSpread2({}, trans.outer),
						children: [maskInnerGroup]
					};
					var maskId = "mask-".concat(explicitMaskId || nextUniqueId());
					var clipId = "clip-".concat(explicitMaskId || nextUniqueId());
					var maskTag = {
						tag: "mask",
						attributes: _objectSpread2(_objectSpread2({}, ALL_SPACE), {}, {
							id: maskId,
							maskUnits: "userSpaceOnUse",
							maskContentUnits: "userSpaceOnUse"
						}),
						children: [maskRect, maskOuterGroup]
					};
					var defs = {
						tag: "defs",
						children: [{
							tag: "clipPath",
							attributes: { id: clipId },
							children: deGroup(maskPath)
						}, maskTag]
					};
					children.push(defs, {
						tag: "rect",
						attributes: _objectSpread2({
							"fill": "currentColor",
							"clip-path": "url(#".concat(clipId, ")"),
							"mask": "url(#".concat(maskId, ")")
						}, ALL_SPACE)
					});
					return {
						children,
						attributes
					};
				};
			}
		},
		{ provides: function provides(providers) {
			var reduceMotion = false;
			if (WINDOW.matchMedia) reduceMotion = WINDOW.matchMedia("(prefers-reduced-motion: reduce)").matches;
			providers.missingIconAbstract = function() {
				var gChildren = [];
				var FILL = { fill: "currentColor" };
				var ANIMATION_BASE = {
					attributeType: "XML",
					repeatCount: "indefinite",
					dur: "2s"
				};
				gChildren.push({
					tag: "path",
					attributes: _objectSpread2(_objectSpread2({}, FILL), {}, { d: "M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z" })
				});
				var OPACITY_ANIMATE = _objectSpread2(_objectSpread2({}, ANIMATION_BASE), {}, { attributeName: "opacity" });
				var dot = {
					tag: "circle",
					attributes: _objectSpread2(_objectSpread2({}, FILL), {}, {
						cx: "256",
						cy: "364",
						r: "28"
					}),
					children: []
				};
				if (!reduceMotion) dot.children.push({
					tag: "animate",
					attributes: _objectSpread2(_objectSpread2({}, ANIMATION_BASE), {}, {
						attributeName: "r",
						values: "28;14;28;28;14;28;"
					})
				}, {
					tag: "animate",
					attributes: _objectSpread2(_objectSpread2({}, OPACITY_ANIMATE), {}, { values: "1;0;1;1;0;1;" })
				});
				gChildren.push(dot);
				gChildren.push({
					tag: "path",
					attributes: _objectSpread2(_objectSpread2({}, FILL), {}, {
						opacity: "1",
						d: "M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z"
					}),
					children: reduceMotion ? [] : [{
						tag: "animate",
						attributes: _objectSpread2(_objectSpread2({}, OPACITY_ANIMATE), {}, { values: "1;0;0;0;0;1;" })
					}]
				});
				if (!reduceMotion) gChildren.push({
					tag: "path",
					attributes: _objectSpread2(_objectSpread2({}, FILL), {}, {
						opacity: "0",
						d: "M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z"
					}),
					children: [{
						tag: "animate",
						attributes: _objectSpread2(_objectSpread2({}, OPACITY_ANIMATE), {}, { values: "0;0;1;1;0;0;" })
					}]
				});
				return {
					tag: "g",
					attributes: { class: "missing" },
					children: gChildren
				};
			};
		} },
		{ hooks: function hooks() {
			return { parseNodeAttributes: function parseNodeAttributes(accumulator, node) {
				var symbolData = node.getAttribute("data-fa-symbol");
				accumulator["symbol"] = symbolData === null ? false : symbolData === "" ? true : symbolData;
				return accumulator;
			} };
		} }
	], { mixoutsTo: api });
	api.noAuto;
	config$1 = api.config;
	api.library;
	api.dom;
	parse$1 = api.parse;
	api.findIconDefinition;
	api.toHtml;
	icon = api.icon;
	api.layer;
	api.text;
	api.counter;
	createGradientStops = (stop, index) => import_react$1.createElement("stop", {
		key: `${index}-${stop.offset}`,
		offset: stop.offset,
		stopColor: stop.color,
		...stop.opacity !== void 0 && { stopOpacity: stop.opacity }
	});
	styleCache = /* @__PURE__ */ new Map();
	STYLE_CACHE_LIMIT = 1e3;
	makeReactConverter = convert.bind(null, import_react$1.createElement);
	useAccessibilityId = (id, hasAccessibleProps) => {
		const generatedId = (0, import_react$1.useId)();
		return id || (hasAccessibleProps ? generatedId : void 0);
	};
	Logger = class {
		constructor(scope = "react-fontawesome") {
			this.enabled = false;
			let IS_DEV = false;
			try {
				IS_DEV = typeof process !== "undefined" && false;
			} catch {}
			this.scope = scope;
			this.enabled = IS_DEV;
		}
		/**
		* Logs messages to the console if not in production.
		* @param args - The message and/or data to log.
		*/
		log(...args) {
			if (!this.enabled) return;
			console.log(`[${this.scope}]`, ...args);
		}
		/**
		* Logs warnings to the console if not in production.
		* @param args - The warning message and/or data to log.
		*/
		warn(...args) {
			if (!this.enabled) return;
			console.warn(`[${this.scope}]`, ...args);
		}
		/**
		* Logs errors to the console if not in production.
		* @param args - The error message and/or data to log.
		*/
		error(...args) {
			if (!this.enabled) return;
			console.error(`[${this.scope}]`, ...args);
		}
	};
	typeof process !== "undefined" && {}.FA_VERSION;
	SVG_CORE_VERSION = "searchPseudoElementsFullScan" in config$1 && typeof config$1.searchPseudoElementsFullScan === "boolean" ? "7.0.0" : "6.0.0";
	IS_VERSION_7_OR_LATER = Number.parseInt(SVG_CORE_VERSION) >= 7;
	getIsVersion7OrLater = () => IS_VERSION_7_OR_LATER;
	DEFAULT_CLASSNAME_PREFIX = "fa";
	ANIMATION_CLASSES = {
		beat: "fa-beat",
		fade: "fa-fade",
		beatFade: "fa-beat-fade",
		bounce: "fa-bounce",
		shake: "fa-shake",
		spin: "fa-spin",
		spinPulse: "fa-spin-pulse",
		spinReverse: "fa-spin-reverse",
		pulse: "fa-pulse"
	};
	PULL_CLASSES = {
		left: "fa-pull-left",
		right: "fa-pull-right"
	};
	ROTATE_CLASSES = {
		"90": "fa-rotate-90",
		"180": "fa-rotate-180",
		"270": "fa-rotate-270"
	};
	SIZE_CLASSES = {
		"2xs": "fa-2xs",
		xs: "fa-xs",
		sm: "fa-sm",
		lg: "fa-lg",
		xl: "fa-xl",
		"2xl": "fa-2xl",
		"1x": "fa-1x",
		"2x": "fa-2x",
		"3x": "fa-3x",
		"4x": "fa-4x",
		"5x": "fa-5x",
		"6x": "fa-6x",
		"7x": "fa-7x",
		"8x": "fa-8x",
		"9x": "fa-9x",
		"10x": "fa-10x"
	};
	STYLE_CLASSES = {
		border: "fa-border",
		/** @deprecated */
		fixedWidth: "fa-fw",
		flip: "fa-flip",
		flipHorizontal: "fa-flip-horizontal",
		flipVertical: "fa-flip-vertical",
		inverse: "fa-inverse",
		rotateBy: "fa-rotate-by",
		swapOpacity: "fa-swap-opacity",
		widthAuto: "fa-width-auto"
	};
	LAYER_CLASSES = { default: "fa-layers" };
	isIconDefinition = (icon) => typeof icon === "object" && "icon" in icon && !!icon.icon;
	logger = new Logger("FontAwesomeIcon");
	DEFAULT_PROPS = {
		border: false,
		className: "",
		mask: void 0,
		maskId: void 0,
		fixedWidth: false,
		inverse: false,
		flip: false,
		icon: void 0,
		listItem: false,
		pull: void 0,
		pulse: false,
		rotation: void 0,
		rotateBy: false,
		size: void 0,
		spin: false,
		spinPulse: false,
		spinReverse: false,
		beat: false,
		fade: false,
		beatFade: false,
		bounce: false,
		shake: false,
		symbol: false,
		title: "",
		titleId: void 0,
		transform: void 0,
		swapOpacity: false,
		widthAuto: false
	};
	DEFAULT_PROP_KEYS = new Set(Object.keys(DEFAULT_PROPS));
	FontAwesomeIcon = import_react$1.forwardRef((props, ref) => {
		const allProps = {
			...DEFAULT_PROPS,
			...props
		};
		const { icon: iconArgs, mask: maskArgs, symbol, title, titleId: titleIdFromProps, maskId: maskIdFromProps, transform } = allProps;
		const maskId = useAccessibilityId(maskIdFromProps, Boolean(maskArgs));
		const titleId = useAccessibilityId(titleIdFromProps, Boolean(title));
		const iconLookup = normalizeIconArgs(iconArgs);
		if (!iconLookup) {
			logger.error("Icon lookup is undefined", iconArgs);
			return null;
		}
		const classList = getClassListFromProps(allProps);
		const transformProps = typeof transform === "string" ? parse$1.transform(transform) : transform;
		const normalizedMaskArgs = normalizeIconArgs(maskArgs);
		const renderedIcon = icon(iconLookup, {
			...classList.length > 0 && { classes: classList },
			...transformProps && { transform: transformProps },
			...normalizedMaskArgs && { mask: normalizedMaskArgs },
			symbol,
			title,
			titleId,
			maskId
		});
		if (!renderedIcon) {
			logger.error("Could not find icon", iconLookup);
			return null;
		}
		const { abstract } = renderedIcon;
		const extraProps = { ref };
		for (const key of typedObjectKeys(allProps)) {
			if (DEFAULT_PROP_KEYS.has(key)) continue;
			extraProps[key] = allProps[key];
		}
		return makeReactConverter(abstract[0], extraProps);
	});
	FontAwesomeIcon.displayName = "FontAwesomeIcon";
	`${LAYER_CLASSES.default}${STYLE_CLASSES.fixedWidth}`;
	toLookup = (pack) => {
		const lookup = {};
		Object.values(pack).forEach((item) => {
			if (item && typeof item === "object" && "iconName" in item) {
				const icon = item;
				lookup[icon.iconName] = icon;
			}
		});
		return lookup;
	};
	regularIcons = toLookup(icons);
	toAliasLookup = (icons) => {
		const lookup = {};
		Object.values(icons).forEach((icon) => {
			const aliases = icon.icon?.[2];
			if (!Array.isArray(aliases)) return;
			aliases.forEach((alias) => {
				if (typeof alias === "string") lookup[alias] = icon;
			});
		});
		return lookup;
	};
	regularAliases = toAliasLookup(regularIcons);
	legacyAliases = {
		circleCheck: "circle-check",
		circleQuestion: "circle-question",
		circleInfo: "circle-info"
	};
	toKebabCase = (value) => {
		return value.replace(/[A-Z]/g, (char) => `-${char.toLowerCase()}`);
	};
	normalizeName = (name) => {
		return legacyAliases[name] ?? toKebabCase(name);
	};
	getAvailableIconNames = () => {
		return [...new Set([...Object.keys(regularIcons), ...Object.keys(regularAliases)])].sort();
	};
	resolveIcon = (name) => {
		const normalizedName = normalizeName(name);
		return regularIcons[normalizedName] ?? regularAliases[normalizedName];
	};
	variantIcon$1 = {
		info: "circle-question",
		success: "circle-check",
		warning: "circle-question",
		danger: "circle-xmark"
	};
	getInitials = (name) => {
		if (!name) return "?";
		const parts = name.trim().split(/\s+/).filter(Boolean).slice(0, 2);
		if (parts.length === 0) return "?";
		return parts.map((part) => part.charAt(0).toUpperCase()).join("");
	};
	Avatar = (0, import_react$1.forwardRef)(({ src, alt, name, size = "md", status, className, children, ...props }, ref) => {
		const initials = children ?? getInitials(name);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			ref,
			className: cx("pf-avatar", `pf-avatar--${size}`, className),
			"aria-label": name,
			...props,
			children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				className: "pf-avatar__image",
				src,
				alt: alt ?? name ?? "Avatar"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-avatar__fallback",
				"aria-hidden": true,
				children: initials
			}), status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cx("pf-avatar__status", `pf-avatar__status--${status}`),
				"aria-hidden": true
			}) : null]
		});
	});
	Avatar.displayName = "Avatar";
	Button = (0, import_react$1.forwardRef)(({ className, variant = "primary", size = "md", fullWidth = false, type = "button", ...props }, ref) => {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			ref,
			type,
			className: cx("pf-button", `pf-button--${variant}`, `pf-button--${size}`, fullWidth && "pf-button--full", className),
			...props
		});
	});
	Button.displayName = "Button";
	BadgeGroup = (0, import_react$1.forwardRef)(({ label, message, color = "gray", appearance = "pill", badgePosition = "leading", className, ...props }, ref) => {
		const badge = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cx("pf-badge-group__badge", `pf-badge-group__badge--${color}`),
			children: label
		});
		const text = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cx("pf-badge-group__text", `pf-badge-group__text--${appearance}`, `pf-badge-group__text--${color}`),
			children: message
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref,
			className: cx("pf-badge-group", `pf-badge-group--${appearance}`, `pf-badge-group--${badgePosition}`, className),
			...props,
			children: badgePosition === "leading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [badge, text] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [text, badge] })
		});
	});
	BadgeGroup.displayName = "BadgeGroup";
	isSelected = (currentValue, itemValue, multiple) => {
		if (multiple) return Array.isArray(currentValue) ? currentValue.includes(itemValue) : false;
		return currentValue === itemValue;
	};
	ButtonGroup = (0, import_react$1.forwardRef)(({ items, value, defaultValue, multiple = false, onValueChange, disabled = false, className, ...props }, ref) => {
		const isControlled = value !== void 0;
		const [internalValue, setInternalValue] = (0, import_react$1.useState)(defaultValue);
		const selectedValue = isControlled ? value : internalValue;
		const selectedSet = (0, import_react$1.useMemo)(() => {
			if (!multiple) return new Set(typeof selectedValue === "string" ? [selectedValue] : []);
			return new Set(Array.isArray(selectedValue) ? selectedValue : []);
		}, [multiple, selectedValue]);
		const handleSelect = (itemValue) => {
			if (disabled) return;
			if (multiple) {
				const nextValue = selectedSet.has(itemValue) ? [...selectedSet].filter((currentItem) => currentItem !== itemValue) : [...selectedSet, itemValue];
				if (!isControlled) setInternalValue(nextValue);
				onValueChange?.(nextValue);
				return;
			}
			if (!isControlled) setInternalValue(itemValue);
			onValueChange?.(itemValue);
		};
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref,
			className: cx("pf-button-group", className),
			role: "group",
			...props,
			children: items.map((item) => {
				const selected = isSelected(selectedValue, item.value, multiple);
				const isDisabled = disabled || item.disabled;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: cx("pf-button-group__button", selected && "pf-button-group__button--selected"),
					"aria-pressed": selected,
					disabled: isDisabled,
					onClick: () => handleSelect(item.value),
					children: [
						item.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							className: "pf-button-group__icon",
							children: item.icon
						}) : null,
						item.dot ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							className: "pf-button-group__dot"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pf-button-group__label",
							children: item.label
						})
					]
				}, item.value);
			})
		});
	});
	ButtonGroup.displayName = "ButtonGroup";
	Input = (0, import_react$1.forwardRef)(({ id, label, description, error, className, "aria-describedby": ariaDescribedBy, ...props }, ref) => {
		const generatedId = (0, import_react$1.useId)();
		const inputId = id ?? generatedId;
		const descriptionId = description ? `${inputId}-description` : void 0;
		const errorId = error ? `${inputId}-error` : void 0;
		const describedBy = [
			ariaDescribedBy,
			descriptionId,
			errorId
		].filter(Boolean).join(" ") || void 0;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-field",
			children: [
				label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "pf-field__label",
					htmlFor: inputId,
					children: label
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref,
					id: inputId,
					className: cx("pf-input", error && "pf-input--invalid", className),
					"aria-invalid": error ? true : void 0,
					"aria-describedby": describedBy,
					...props
				}),
				description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__description",
					id: descriptionId,
					children: description
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__error",
					id: errorId,
					children: error
				}) : null
			]
		});
	});
	Input.displayName = "Input";
	maskCardNumber = (value) => {
		const digits = value.replace(/\D+/g, "");
		if (digits.length <= 4) return digits;
		const visible = digits.slice(-4);
		const hiddenLength = digits.length - 4;
		return `${"*".repeat(hiddenLength)}${visible}`.replace(/(.{4})/g, "$1 ").trim();
	};
	formatCardNumber = (value) => {
		return value.replace(/\D+/g, "").replace(/(.{4})/g, "$1 ").trim();
	};
	CreditCard = (0, import_react$1.forwardRef)(({ brand = "generic", cardNumber, cardholderName, expiry, cvc, masked = true, className, ...props }, ref) => {
		const displayNumber = masked ? maskCardNumber(cardNumber) : formatCardNumber(cardNumber);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref,
			className: cx("pf-credit-card", `pf-credit-card--${brand}`, className),
			...props,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pf-credit-card__top-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-credit-card__chip",
						"aria-hidden": true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-credit-card__brand",
						children: brand.toUpperCase()
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-credit-card__number",
					children: displayNumber
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pf-credit-card__meta",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pf-credit-card__label",
							children: "Card holder"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pf-credit-card__value",
							children: cardholderName
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pf-credit-card__label",
							children: "Expires"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pf-credit-card__value",
							children: expiry
						})] }),
						cvc ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pf-credit-card__label",
							children: "CVC"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pf-credit-card__value",
							children: masked ? "***" : cvc
						})] }) : null
					]
				})
			]
		});
	});
	CreditCard.displayName = "CreditCard";
	Checkbox = (0, import_react$1.forwardRef)(({ id, label, className, ...props }, ref) => {
		const generatedId = (0, import_react$1.useId)();
		const checkboxId = id ?? generatedId;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-checkbox-field",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref,
				id: checkboxId,
				type: "checkbox",
				className: cx("pf-checkbox", className),
				...props
			}), label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: checkboxId,
				children: label
			}) : null]
		});
	});
	Checkbox.displayName = "Checkbox";
	WEEKDAY_LABELS = [
		"Su",
		"Mo",
		"Tu",
		"We",
		"Th",
		"Fr",
		"Sa"
	];
	MONTH_OPTIONS = Array.from({ length: 12 }, (_, month) => {
		const date = new Date(2024, month, 1);
		return {
			value: month,
			label: new Intl.DateTimeFormat("en-US", { month: "long" }).format(date)
		};
	});
	toMidday$1 = (date) => {
		const next = new Date(date);
		next.setHours(12, 0, 0, 0);
		return next;
	};
	isSameDay = (a, b) => {
		return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
	};
	startOfMonth = (date) => {
		return new Date(date.getFullYear(), date.getMonth(), 1, 12);
	};
	addMonths = (date, amount) => {
		return new Date(date.getFullYear(), date.getMonth() + amount, 1, 12);
	};
	buildCalendarDays = (monthDate) => {
		const monthStart = startOfMonth(monthDate);
		const firstWeekday = monthStart.getDay();
		const gridStart = new Date(monthStart.getFullYear(), monthStart.getMonth(), monthStart.getDate() - firstWeekday, 12);
		return Array.from({ length: 42 }, (_, index) => {
			const date = new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + index, 12);
			return {
				date,
				inCurrentMonth: date.getMonth() === monthDate.getMonth()
			};
		});
	};
	clamp$1 = (value, min, max) => {
		return Math.min(Math.max(value, min), max);
	};
	splitLines = (value) => {
		if (!value.length) return [""];
		return value.replace(/\n$/, "").split("\n");
	};
	toMidday = (date) => {
		const next = new Date(date);
		next.setHours(12, 0, 0, 0);
		return next;
	};
	findNextEnabledIndex$2 = (items, startIndex, direction) => {
		if (items.length === 0) return -1;
		let index = startIndex;
		for (let step = 0; step < items.length; step += 1) {
			index = (index + direction + items.length) % items.length;
			if (!items[index]?.disabled) return index;
		}
		return -1;
	};
	findFirstEnabledIndex$2 = (items) => {
		return items.findIndex((item) => !item.disabled);
	};
	Dropdown = (0, import_react$1.forwardRef)(({ label = "Actions", items, align = "start", disabled, className, ...props }, ref) => {
		const menuId = (0, import_react$1.useId)();
		const rootRef = (0, import_react$1.useRef)(null);
		const triggerRef = (0, import_react$1.useRef)(null);
		const menuRef = (0, import_react$1.useRef)(null);
		const [isOpen, setIsOpen] = (0, import_react$1.useState)(false);
		const [activeIndex, setActiveIndex] = (0, import_react$1.useState)(() => findFirstEnabledIndex$2(items));
		const [menuStyle, setMenuStyle] = (0, import_react$1.useState)({});
		(0, import_react$1.useEffect)(() => {
			if (!isOpen) return;
			setActiveIndex(findFirstEnabledIndex$2(items));
		}, [isOpen, items]);
		(0, import_react$1.useEffect)(() => {
			const handlePointerDown = (event) => {
				const target = event.target;
				if (!rootRef.current?.contains(target) && !menuRef.current?.contains(target)) setIsOpen(false);
			};
			const handleEscape = (event) => {
				if (event.key === "Escape") {
					setIsOpen(false);
					triggerRef.current?.focus();
				}
			};
			document.addEventListener("pointerdown", handlePointerDown);
			document.addEventListener("keydown", handleEscape);
			return () => {
				document.removeEventListener("pointerdown", handlePointerDown);
				document.removeEventListener("keydown", handleEscape);
			};
		}, []);
		(0, import_react$1.useEffect)(() => {
			if (!isOpen) return;
			const updateMenuPosition = () => {
				const trigger = triggerRef.current;
				if (!trigger) return;
				const rect = trigger.getBoundingClientRect();
				const width = Math.max(rect.width, 200);
				setMenuStyle({
					left: align === "end" ? Math.max(8, rect.right - width) : Math.min(rect.left, window.innerWidth - width - 8),
					top: rect.bottom + 8,
					width
				});
			};
			updateMenuPosition();
			window.addEventListener("resize", updateMenuPosition);
			window.addEventListener("scroll", updateMenuPosition, true);
			return () => {
				window.removeEventListener("resize", updateMenuPosition);
				window.removeEventListener("scroll", updateMenuPosition, true);
			};
		}, [align, isOpen]);
		const onTriggerKeyDown = (event) => {
			if (disabled) return;
			if (event.key === "ArrowDown" || event.key === "ArrowUp") {
				event.preventDefault();
				if (!isOpen) {
					setIsOpen(true);
					return;
				}
				const direction = event.key === "ArrowDown" ? 1 : -1;
				const nextIndex = findNextEnabledIndex$2(items, activeIndex >= 0 ? activeIndex : 0, direction);
				if (nextIndex >= 0) setActiveIndex(nextIndex);
			}
			if (event.key === "Enter" || event.key === " ") {
				event.preventDefault();
				setIsOpen((value) => !value);
			}
		};
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: rootRef,
			className: cx("pf-dropdown", className),
			...props,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				ref: (node) => {
					triggerRef.current = node;
					if (typeof ref === "function") ref(node);
					else if (ref) ref.current = node;
				},
				type: "button",
				className: "pf-dropdown__trigger",
				"aria-haspopup": "menu",
				"aria-expanded": isOpen,
				"aria-controls": isOpen ? menuId : void 0,
				onClick: () => {
					if (!disabled) setIsOpen((value) => !value);
				},
				onKeyDown: onTriggerKeyDown,
				disabled,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cx("pf-dropdown__chevron", isOpen && "pf-dropdown__chevron--open"),
					"aria-hidden": true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						name: "square-caret-down",
						"aria-hidden": true
					})
				})]
			}), isOpen && typeof document !== "undefined" ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: menuId,
				ref: menuRef,
				className: "pf-dropdown__menu",
				role: "menu",
				style: menuStyle,
				children: items.map((item, index) => {
					const isActive = index === activeIndex;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						role: "menuitem",
						disabled: item.disabled,
						className: cx("pf-dropdown__item", isActive && "pf-dropdown__item--active", item.destructive && "pf-dropdown__item--destructive"),
						onMouseEnter: () => {
							if (!item.disabled) setActiveIndex(index);
						},
						onClick: () => {
							if (item.disabled) return;
							item.onSelect?.();
							setIsOpen(false);
							triggerRef.current?.focus();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "pf-dropdown__item-left",
							children: [item.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pf-dropdown__item-icon",
								"aria-hidden": true,
								children: item.icon
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
						}), item.shortcut ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pf-dropdown__item-shortcut",
							children: item.shortcut
						}) : null]
					}, item.id ?? `${item.label}-${index}`);
				})
			}), document.body) : null]
		});
	});
	Dropdown.displayName = "Dropdown";
	bytesToSize = (bytes) => {
		if (bytes < 1024) return `${bytes} B`;
		if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
		return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
	};
	trendSymbol = {
		positive: "+",
		negative: "-",
		neutral: "="
	};
	getFocusableElements = (container) => {
		const selector = [
			"a[href]",
			"button:not([disabled])",
			"input:not([disabled])",
			"select:not([disabled])",
			"textarea:not([disabled])",
			"[tabindex]:not([tabindex=\"-1\"])"
		].join(",");
		return Array.from(container.querySelectorAll(selector)).filter((element) => {
			if (element.hasAttribute("disabled")) return false;
			return element.offsetParent !== null;
		});
	};
	findNextEnabledIndex$1 = (options, startIndex, direction) => {
		if (options.length === 0) return -1;
		let index = startIndex;
		for (let step = 0; step < options.length; step += 1) {
			index = (index + direction + options.length) % options.length;
			if (!options[index]?.disabled) return index;
		}
		return -1;
	};
	findFirstEnabledIndex$1 = (options) => {
		return options.findIndex((option) => !option.disabled);
	};
	MultiSelect = (0, import_react$1.forwardRef)(({ id, options, value, defaultValue, onValueChange, placeholder = "Select options", name, label, description, error, className, disabled, "aria-describedby": ariaDescribedBy, ...props }, ref) => {
		const generatedId = (0, import_react$1.useId)();
		const selectId = id ?? generatedId;
		const descriptionId = description ? `${selectId}-description` : void 0;
		const errorId = error ? `${selectId}-error` : void 0;
		const listboxId = `${selectId}-listbox`;
		const describedBy = [
			ariaDescribedBy,
			descriptionId,
			errorId
		].filter(Boolean).join(" ") || void 0;
		const isControlled = value !== void 0;
		const [internalValue, setInternalValue] = (0, import_react$1.useState)(defaultValue ?? []);
		const selectedValues = isControlled ? value ?? [] : internalValue;
		const selectedSet = (0, import_react$1.useMemo)(() => new Set(selectedValues), [selectedValues]);
		const selectedOptions = (0, import_react$1.useMemo)(() => options.filter((option) => selectedSet.has(option.value)), [options, selectedSet]);
		const [isOpen, setIsOpen] = (0, import_react$1.useState)(false);
		const [activeIndex, setActiveIndex] = (0, import_react$1.useState)(() => {
			const selectedIndex = options.findIndex((option) => selectedSet.has(option.value) && !option.disabled);
			if (selectedIndex >= 0) return selectedIndex;
			return findFirstEnabledIndex$1(options);
		});
		const rootRef = (0, import_react$1.useRef)(null);
		const triggerRef = (0, import_react$1.useRef)(null);
		const menuRef = (0, import_react$1.useRef)(null);
		const [menuStyle, setMenuStyle] = (0, import_react$1.useState)({});
		(0, import_react$1.useEffect)(() => {
			if (!isOpen) return;
			const selectedIndex = options.findIndex((option) => selectedSet.has(option.value) && !option.disabled);
			setActiveIndex(selectedIndex >= 0 ? selectedIndex : findFirstEnabledIndex$1(options));
		}, [
			isOpen,
			options,
			selectedSet
		]);
		(0, import_react$1.useEffect)(() => {
			const handlePointerDown = (event) => {
				const target = event.target;
				if (!rootRef.current?.contains(target) && !menuRef.current?.contains(target)) setIsOpen(false);
			};
			document.addEventListener("pointerdown", handlePointerDown);
			return () => {
				document.removeEventListener("pointerdown", handlePointerDown);
			};
		}, []);
		(0, import_react$1.useEffect)(() => {
			if (!isOpen) return;
			const updateMenuPosition = () => {
				const trigger = triggerRef.current;
				if (!trigger) return;
				const rect = trigger.getBoundingClientRect();
				setMenuStyle({
					left: rect.left,
					top: rect.bottom + 8,
					width: rect.width
				});
			};
			updateMenuPosition();
			window.addEventListener("resize", updateMenuPosition);
			window.addEventListener("scroll", updateMenuPosition, true);
			return () => {
				window.removeEventListener("resize", updateMenuPosition);
				window.removeEventListener("scroll", updateMenuPosition, true);
			};
		}, [isOpen]);
		const updateValue = (nextValue) => {
			if (!isControlled) setInternalValue(nextValue);
			onValueChange?.(nextValue);
		};
		const toggleValue = (nextValue) => {
			if (selectedSet.has(nextValue)) {
				updateValue(selectedValues.filter((valueItem) => valueItem !== nextValue));
				return;
			}
			updateValue([...selectedValues, nextValue]);
		};
		const openMenu = () => {
			if (disabled) return;
			setIsOpen(true);
		};
		const onTriggerKeyDown = (event) => {
			if (disabled) return;
			if (event.key === "ArrowDown" || event.key === "ArrowUp") {
				event.preventDefault();
				if (!isOpen) {
					openMenu();
					return;
				}
				const direction = event.key === "ArrowDown" ? 1 : -1;
				const nextIndex = findNextEnabledIndex$1(options, activeIndex >= 0 ? activeIndex : 0, direction);
				if (nextIndex >= 0) setActiveIndex(nextIndex);
				return;
			}
			if (event.key === "Home") {
				event.preventDefault();
				const firstEnabled = findFirstEnabledIndex$1(options);
				if (firstEnabled >= 0) setActiveIndex(firstEnabled);
				return;
			}
			if (event.key === "End") {
				event.preventDefault();
				const lastEnabled = [...options].reverse().findIndex((option) => !option.disabled);
				if (lastEnabled >= 0) setActiveIndex(options.length - 1 - lastEnabled);
				return;
			}
			if (event.key === "Enter" || event.key === " ") {
				event.preventDefault();
				if (!isOpen) {
					openMenu();
					return;
				}
				const activeOption = options[activeIndex];
				if (activeOption && !activeOption.disabled) toggleValue(activeOption.value);
				return;
			}
			if (event.key === "Escape") setIsOpen(false);
		};
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-field",
			children: [
				label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "pf-field__label",
					htmlFor: selectId,
					children: label
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pf-multi-select",
					ref: rootRef,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							...props,
							id: selectId,
							ref: (node) => {
								triggerRef.current = node;
								if (typeof ref === "function") ref(node);
								else if (ref) ref.current = node;
							},
							type: "button",
							className: cx("pf-multi-select__trigger", isOpen && "pf-multi-select__trigger--open", error && "pf-multi-select__trigger--invalid", className),
							disabled,
							"aria-haspopup": "listbox",
							"aria-expanded": isOpen,
							"aria-controls": isOpen ? listboxId : void 0,
							"aria-describedby": describedBy,
							onClick: () => {
								if (disabled) return;
								setIsOpen((current) => !current);
							},
							onKeyDown: onTriggerKeyDown,
							children: [selectedOptions.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pf-multi-select__chips",
								children: selectedOptions.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pf-multi-select__chip",
									children: option.label
								}, option.value))
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pf-multi-select__placeholder",
								children: placeholder
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								className: cx("pf-multi-select__icon", isOpen && "pf-multi-select__icon--open"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									name: "square-caret-down",
									"aria-hidden": true
								})
							})]
						}),
						name ? selectedValues.map((selectedValue) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "hidden",
							name,
							value: selectedValue
						}, selectedValue)) : null,
						isOpen && typeof document !== "undefined" ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							id: listboxId,
							ref: menuRef,
							className: "pf-multi-select__menu",
							style: menuStyle,
							role: "listbox",
							"aria-multiselectable": "true",
							"aria-labelledby": label ? selectId : void 0,
							children: options.map((option, index) => {
								const isSelected = selectedSet.has(option.value);
								const isActive = index === activeIndex;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									role: "option",
									"aria-selected": isSelected,
									"aria-disabled": option.disabled ? true : void 0,
									className: cx("pf-multi-select__option", isSelected && "pf-multi-select__option--selected", isActive && "pf-multi-select__option--active", option.disabled && "pf-multi-select__option--disabled"),
									onMouseEnter: () => {
										if (!option.disabled) setActiveIndex(index);
									},
									onMouseDown: (event) => {
										event.preventDefault();
									},
									onClick: () => {
										if (option.disabled) return;
										toggleValue(option.value);
										triggerRef.current?.focus();
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: option.label }), isSelected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "pf-multi-select__check",
										"aria-hidden": true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											name: "square-check",
											"aria-hidden": true
										})
									}) : null]
								}, option.value);
							})
						}), document.body) : null
					]
				}),
				description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__description",
					id: descriptionId,
					children: description
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__error",
					id: errorId,
					children: error
				}) : null
			]
		});
	});
	MultiSelect.displayName = "MultiSelect";
	variantIcon = {
		info: "circle-question",
		success: "circle-check",
		warning: "triangle-exclamation",
		danger: "circle-xmark"
	};
	PageHeaderMeta.displayName = "PageHeaderMeta";
	PageHeader.displayName = "PageHeader";
	Pagination.displayName = "Pagination";
	fallbackColors = [
		"var(--color-brand-600)",
		"var(--color-brand-500)",
		"var(--color-gray-500)",
		"#06b6d4",
		"#22c55e",
		"var(--color-gray-500)"
	];
	PieChart.displayName = "PieChart";
	clampPercent = (value, max) => {
		if (max <= 0) return 0;
		return Math.max(0, Math.min(100, value / max * 100));
	};
	ProgressSteps.displayName = "ProgressSteps";
	RadarChart.displayName = "RadarChart";
	RadioButton = (0, import_react$1.forwardRef)(({ id, label, className, ...props }, ref) => {
		const generatedId = (0, import_react$1.useId)();
		const radioId = id ?? generatedId;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-radio-field",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref,
				id: radioId,
				type: "radio",
				className: cx("pf-radio", className),
				...props
			}), label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: radioId,
				children: label
			}) : null]
		});
	});
	RadioButton.displayName = "RadioButton";
	RadioGroup = (0, import_react$1.forwardRef)(({ name, legend, options, value, defaultValue, onValueChange, disabled = false, orientation = "vertical", className, ...props }, ref) => {
		const generatedName = (0, import_react$1.useId)();
		const groupName = name ?? generatedName;
		const isControlled = value !== void 0;
		const [internalValue, setInternalValue] = (0, import_react$1.useState)(defaultValue);
		const selectedValue = isControlled ? value : internalValue;
		const handleChange = (nextValue) => {
			if (!isControlled) setInternalValue(nextValue);
			onValueChange?.(nextValue);
		};
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
			ref,
			className: cx("pf-radio-group", orientation === "horizontal" && "pf-radio-group--horizontal", className),
			disabled,
			...props,
			children: [legend ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "pf-radio-group__legend",
				children: legend
			}) : null, options.map((option) => {
				const optionId = `${groupName}-${option.value}`;
				const checked = selectedValue === option.value;
				const optionDisabled = disabled || option.disabled;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pf-radio-group__item",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: optionId,
						className: "pf-radio-group__input",
						type: "radio",
						name: groupName,
						value: option.value,
						checked,
						disabled: optionDisabled,
						onChange: () => handleChange(option.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						htmlFor: optionId,
						className: "pf-radio-group__label",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pf-radio-group__label-text",
							children: option.label
						}), option.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pf-radio-group__description",
							children: option.description
						}) : null]
					})]
				}, option.value);
			})]
		});
	});
	RadioGroup.displayName = "RadioGroup";
	clampRating = (value, max) => Math.min(Math.max(value, 0), max);
	getStarFillPercent = (value, index) => {
		if (value >= index + 1) return 100;
		if (value > index) return Math.round((value - index) * 100);
		return 0;
	};
	normalizeHtml = (value) => value ?? "";
	getTextLength = (element) => element.textContent?.length ?? 0;
	RichTextEditor = (0, import_react$1.forwardRef)(({ id, label, description, error, value, defaultValue, onChange, placeholder = "Start typing...", minHeight = 140, characterMax, disabled = false, className, "aria-describedby": ariaDescribedBy, ...props }, ref) => {
		const generatedId = (0, import_react$1.useId)();
		const editorId = id ?? generatedId;
		const descriptionId = description ? `${editorId}-description` : void 0;
		const errorId = error ? `${editorId}-error` : void 0;
		const countId = typeof characterMax === "number" ? `${editorId}-count` : void 0;
		const describedBy = [
			ariaDescribedBy,
			descriptionId,
			errorId,
			countId
		].filter(Boolean).join(" ") || void 0;
		const editorRef = (0, import_react$1.useRef)(null);
		const lastValidHtmlRef = (0, import_react$1.useRef)("");
		const [characterCount, setCharacterCount] = (0, import_react$1.useState)(0);
		const isControlled = value !== void 0;
		(0, import_react$1.useImperativeHandle)(ref, () => editorRef.current, []);
		(0, import_react$1.useEffect)(() => {
			if (!editorRef.current) return;
			const nextValue = normalizeHtml(isControlled ? value : defaultValue);
			if (editorRef.current.innerHTML !== nextValue) editorRef.current.innerHTML = nextValue;
			lastValidHtmlRef.current = nextValue;
			setCharacterCount(getTextLength(editorRef.current));
		}, [
			defaultValue,
			isControlled,
			value
		]);
		const emitChange = () => {
			if (!editorRef.current) return;
			onChange?.(editorRef.current.innerHTML);
		};
		const enforceLimitAndEmit = () => {
			if (!editorRef.current) return;
			const nextLength = getTextLength(editorRef.current);
			if (typeof characterMax === "number" && nextLength > characterMax) {
				editorRef.current.innerHTML = lastValidHtmlRef.current;
				setCharacterCount(getTextLength(editorRef.current));
				return;
			}
			lastValidHtmlRef.current = editorRef.current.innerHTML;
			setCharacterCount(nextLength);
			emitChange();
		};
		const handleCommand = (command) => {
			if (!editorRef.current || disabled) return;
			editorRef.current.focus();
			document.execCommand(command);
			enforceLimitAndEmit();
		};
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-field",
			children: [
				label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "pf-field__label",
					htmlFor: editorId,
					children: label
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cx("pf-rte", error && "pf-rte--invalid", disabled && "pf-rte--disabled", className),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pf-rte__toolbar",
						role: "toolbar",
						"aria-label": "Formatting options",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "pf-rte__tool",
								onMouseDown: (event) => event.preventDefault(),
								onClick: () => handleCommand("bold"),
								disabled,
								children: "B"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "pf-rte__tool",
								onMouseDown: (event) => event.preventDefault(),
								onClick: () => handleCommand("italic"),
								disabled,
								children: "I"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "pf-rte__tool",
								onMouseDown: (event) => event.preventDefault(),
								onClick: () => handleCommand("underline"),
								disabled,
								children: "U"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pf-rte__divider",
								"aria-hidden": true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "pf-rte__tool",
								onMouseDown: (event) => event.preventDefault(),
								onClick: () => handleCommand("insertUnorderedList"),
								disabled,
								children: "• List"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "pf-rte__tool",
								onMouseDown: (event) => event.preventDefault(),
								onClick: () => handleCommand("insertOrderedList"),
								disabled,
								children: "1. List"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "pf-rte__tool",
								onMouseDown: (event) => event.preventDefault(),
								onClick: () => handleCommand("removeFormat"),
								disabled,
								children: "Clear"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						id: editorId,
						ref: editorRef,
						className: "pf-rte__editor",
						contentEditable: !disabled,
						role: "textbox",
						"aria-multiline": "true",
						"aria-invalid": error ? true : void 0,
						"aria-describedby": describedBy,
						"data-placeholder": placeholder,
						suppressContentEditableWarning: true,
						onInput: enforceLimitAndEmit,
						style: { minHeight },
						...props
					})]
				}),
				typeof characterMax === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "pf-rte__count",
					id: countId,
					"aria-live": "polite",
					children: [
						characterCount,
						"/",
						characterMax
					]
				}) : null,
				description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__description",
					id: descriptionId,
					children: description
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__error",
					id: errorId,
					children: error
				}) : null
			]
		});
	});
	RichTextEditor.displayName = "RichTextEditor";
	SectionFooter.displayName = "SectionFooter";
	SectionHeader.displayName = "SectionHeader";
	SidebarNavigation.displayName = "SidebarNavigation";
	FOCUSABLE_SELECTOR = "a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex=\"-1\"])";
	SlideoutMenu.displayName = "SlideoutMenu";
	Switch = (0, import_react$1.forwardRef)(({ id, label, className, ...props }, ref) => {
		const generatedId = (0, import_react$1.useId)();
		const switchId = id ?? generatedId;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-switch-field",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref,
				id: switchId,
				type: "checkbox",
				role: "switch",
				className: cx("pf-switch", className),
				...props
			}), label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: switchId,
				children: label
			}) : null]
		});
	});
	Switch.displayName = "Switch";
	findNextEnabledIndex = (options, startIndex, direction) => {
		if (options.length === 0) return -1;
		let index = startIndex;
		for (let step = 0; step < options.length; step += 1) {
			index = (index + direction + options.length) % options.length;
			if (!options[index]?.disabled) return index;
		}
		return -1;
	};
	findFirstEnabledIndex = (options) => {
		return options.findIndex((option) => !option.disabled);
	};
	Select = (0, import_react$1.forwardRef)(({ id, options, value, defaultValue, onValueChange, placeholder = "Select an option", name, label, description, error, className, disabled, "aria-describedby": ariaDescribedBy, ...props }, ref) => {
		const generatedId = (0, import_react$1.useId)();
		const selectId = id ?? generatedId;
		const descriptionId = description ? `${selectId}-description` : void 0;
		const errorId = error ? `${selectId}-error` : void 0;
		const listboxId = `${selectId}-listbox`;
		const describedBy = [
			ariaDescribedBy,
			descriptionId,
			errorId
		].filter(Boolean).join(" ") || void 0;
		const isControlled = value !== void 0;
		const [internalValue, setInternalValue] = (0, import_react$1.useState)(defaultValue);
		const selectedValue = isControlled ? value : internalValue;
		const selectedIndex = (0, import_react$1.useMemo)(() => options.findIndex((option) => option.value === selectedValue), [options, selectedValue]);
		const selectedOption = selectedIndex >= 0 ? options[selectedIndex] : void 0;
		const [isOpen, setIsOpen] = (0, import_react$1.useState)(false);
		const [activeIndex, setActiveIndex] = (0, import_react$1.useState)(() => {
			if (selectedIndex >= 0 && !options[selectedIndex]?.disabled) return selectedIndex;
			return findFirstEnabledIndex(options);
		});
		const rootRef = (0, import_react$1.useRef)(null);
		const triggerRef = (0, import_react$1.useRef)(null);
		const menuRef = (0, import_react$1.useRef)(null);
		const [menuStyle, setMenuStyle] = (0, import_react$1.useState)({});
		(0, import_react$1.useEffect)(() => {
			if (!isOpen) return;
			setActiveIndex(selectedIndex >= 0 && !options[selectedIndex]?.disabled ? selectedIndex : findFirstEnabledIndex(options));
		}, [
			isOpen,
			options,
			selectedIndex
		]);
		(0, import_react$1.useEffect)(() => {
			const handlePointerDown = (event) => {
				const target = event.target;
				if (!rootRef.current?.contains(target) && !menuRef.current?.contains(target)) setIsOpen(false);
			};
			document.addEventListener("pointerdown", handlePointerDown);
			return () => {
				document.removeEventListener("pointerdown", handlePointerDown);
			};
		}, []);
		(0, import_react$1.useEffect)(() => {
			if (!isOpen) return;
			const updateMenuPosition = () => {
				const trigger = triggerRef.current;
				if (!trigger) return;
				const rect = trigger.getBoundingClientRect();
				setMenuStyle({
					left: rect.left,
					top: rect.bottom + 8,
					width: rect.width
				});
			};
			updateMenuPosition();
			window.addEventListener("resize", updateMenuPosition);
			window.addEventListener("scroll", updateMenuPosition, true);
			return () => {
				window.removeEventListener("resize", updateMenuPosition);
				window.removeEventListener("scroll", updateMenuPosition, true);
			};
		}, [isOpen]);
		const selectValue = (nextValue) => {
			if (!isControlled) setInternalValue(nextValue);
			onValueChange?.(nextValue);
		};
		const openMenu = () => {
			if (disabled) return;
			setIsOpen(true);
		};
		const closeMenu = () => {
			setIsOpen(false);
		};
		const onTriggerKeyDown = (event) => {
			if (disabled) return;
			if (event.key === "ArrowDown" || event.key === "ArrowUp") {
				event.preventDefault();
				if (!isOpen) {
					openMenu();
					return;
				}
				const direction = event.key === "ArrowDown" ? 1 : -1;
				const nextIndex = findNextEnabledIndex(options, activeIndex >= 0 ? activeIndex : selectedIndex, direction);
				if (nextIndex >= 0) setActiveIndex(nextIndex);
				return;
			}
			if (event.key === "Home") {
				event.preventDefault();
				const firstEnabled = findFirstEnabledIndex(options);
				if (firstEnabled >= 0) setActiveIndex(firstEnabled);
				return;
			}
			if (event.key === "End") {
				event.preventDefault();
				const lastEnabled = [...options].reverse().findIndex((option) => !option.disabled);
				if (lastEnabled >= 0) setActiveIndex(options.length - 1 - lastEnabled);
				return;
			}
			if (event.key === "Enter" || event.key === " ") {
				event.preventDefault();
				if (!isOpen) {
					openMenu();
					return;
				}
				const activeOption = options[activeIndex];
				if (activeOption && !activeOption.disabled) {
					selectValue(activeOption.value);
					closeMenu();
				}
				return;
			}
			if (event.key === "Escape") closeMenu();
		};
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-field",
			children: [
				label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "pf-field__label",
					htmlFor: selectId,
					children: label
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pf-select",
					ref: rootRef,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							...props,
							id: selectId,
							ref: (node) => {
								triggerRef.current = node;
								if (typeof ref === "function") ref(node);
								else if (ref) ref.current = node;
							},
							type: "button",
							className: cx("pf-select__trigger", isOpen && "pf-select__trigger--open", error && "pf-select__trigger--invalid", className),
							disabled,
							"aria-haspopup": "listbox",
							"aria-expanded": isOpen,
							"aria-controls": isOpen ? listboxId : void 0,
							"aria-describedby": describedBy,
							onClick: () => {
								if (disabled) return;
								setIsOpen((current) => !current);
							},
							onKeyDown: onTriggerKeyDown,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cx("pf-select__value", !selectedOption && "pf-select__placeholder"),
								children: selectedOption?.label ?? placeholder
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								className: cx("pf-select__icon", isOpen && "pf-select__icon--open"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									name: "square-caret-down",
									"aria-hidden": true
								})
							})]
						}),
						name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "hidden",
							name,
							value: selectedOption?.value ?? ""
						}) : null,
						isOpen && typeof document !== "undefined" ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							id: listboxId,
							ref: menuRef,
							className: "pf-select__menu",
							style: menuStyle,
							role: "listbox",
							"aria-labelledby": label ? selectId : void 0,
							children: options.map((option, index) => {
								const isSelected = option.value === selectedOption?.value;
								const isActive = index === activeIndex;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									role: "option",
									"aria-selected": isSelected,
									"aria-disabled": option.disabled ? true : void 0,
									className: cx("pf-select__option", isSelected && "pf-select__option--selected", isActive && "pf-select__option--active", option.disabled && "pf-select__option--disabled"),
									onMouseEnter: () => {
										if (!option.disabled) setActiveIndex(index);
									},
									onMouseDown: (event) => {
										event.preventDefault();
									},
									onClick: () => {
										if (option.disabled) return;
										selectValue(option.value);
										closeMenu();
										triggerRef.current?.focus();
									},
									children: option.label
								}, option.value);
							})
						}), document.body) : null
					]
				}),
				description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__description",
					id: descriptionId,
					children: description
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__error",
					id: errorId,
					children: error
				}) : null
			]
		});
	});
	Select.displayName = "Select";
	clamp = (value, min, max) => {
		return Math.min(Math.max(value, min), max);
	};
	Slider = (0, import_react$1.forwardRef)(({ id, value, defaultValue, onValueChange, min = 0, max = 100, step = 1, label, description, error, showValue = true, className, disabled, "aria-describedby": ariaDescribedBy, ...props }, ref) => {
		const generatedId = (0, import_react$1.useId)();
		const sliderId = id ?? generatedId;
		const descriptionId = description ? `${sliderId}-description` : void 0;
		const errorId = error ? `${sliderId}-error` : void 0;
		const describedBy = [
			ariaDescribedBy,
			descriptionId,
			errorId
		].filter(Boolean).join(" ") || void 0;
		const minNumber = Number(min);
		const maxNumber = Number(max);
		const stepNumber = Number(step);
		const safeMin = Number.isFinite(minNumber) ? minNumber : 0;
		const safeMax = Number.isFinite(maxNumber) ? maxNumber : safeMin + 100;
		const normalizedMax = safeMax >= safeMin ? safeMax : safeMin;
		const normalizedStep = Number.isFinite(stepNumber) && stepNumber > 0 ? stepNumber : 1;
		const isControlled = value !== void 0;
		const [internalValue, setInternalValue] = (0, import_react$1.useState)(clamp(defaultValue ?? safeMin, safeMin, normalizedMax));
		const currentValue = clamp(isControlled ? value ?? safeMin : internalValue, safeMin, normalizedMax);
		const progressPercent = (0, import_react$1.useMemo)(() => {
			const range = normalizedMax - safeMin;
			if (range <= 0) return 0;
			return (currentValue - safeMin) / range * 100;
		}, [
			currentValue,
			normalizedMax,
			safeMin
		]);
		const handleChange = (event) => {
			const nextValue = Number(event.target.value);
			if (!isControlled) setInternalValue(nextValue);
			onValueChange?.(nextValue);
		};
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-field",
			children: [
				label || showValue ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pf-slider__header",
					children: [label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "pf-field__label",
						htmlFor: sliderId,
						children: label
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), showValue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pf-slider__value",
						"aria-hidden": true,
						children: Math.round(currentValue)
					}) : null]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					...props,
					ref,
					id: sliderId,
					type: "range",
					value: currentValue,
					min: safeMin,
					max: normalizedMax,
					step: normalizedStep,
					disabled,
					className: cx("pf-slider", error && "pf-slider--invalid", className),
					"aria-invalid": error ? true : void 0,
					"aria-describedby": describedBy,
					onChange: handleChange,
					style: { "--pf-slider-progress": `${progressPercent}%` }
				}),
				description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__description",
					id: descriptionId,
					children: description
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__error",
					id: errorId,
					children: error
				}) : null
			]
		});
	});
	Slider.displayName = "Slider";
	Table.displayName = "Table";
	Tabs.displayName = "Tabs";
	Textarea = (0, import_react$1.forwardRef)(({ id, label, description, error, className, "aria-describedby": ariaDescribedBy, rows = 4, ...props }, ref) => {
		const generatedId = (0, import_react$1.useId)();
		const textareaId = id ?? generatedId;
		const descriptionId = description ? `${textareaId}-description` : void 0;
		const errorId = error ? `${textareaId}-error` : void 0;
		const describedBy = [
			ariaDescribedBy,
			descriptionId,
			errorId
		].filter(Boolean).join(" ") || void 0;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-field",
			children: [
				label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "pf-field__label",
					htmlFor: textareaId,
					children: label
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					ref,
					id: textareaId,
					rows,
					className: cx("pf-textarea", error && "pf-textarea--invalid", className),
					"aria-invalid": error ? true : void 0,
					"aria-describedby": describedBy,
					...props
				}),
				description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__description",
					id: descriptionId,
					children: description
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__error",
					id: errorId,
					children: error
				}) : null
			]
		});
	});
	Textarea.displayName = "Textarea";
	GAP = 10;
	getTooltipStyle = (triggerRect, tooltipRect, placement) => {
		const centerX = triggerRect.left + triggerRect.width / 2;
		const centerY = triggerRect.top + triggerRect.height / 2;
		if (placement === "bottom") return {
			left: centerX - tooltipRect.width / 2,
			top: triggerRect.bottom + GAP
		};
		if (placement === "left") return {
			left: triggerRect.left - tooltipRect.width - GAP,
			top: centerY - tooltipRect.height / 2
		};
		if (placement === "right") return {
			left: triggerRect.right + GAP,
			top: centerY - tooltipRect.height / 2
		};
		return {
			left: centerX - tooltipRect.width / 2,
			top: triggerRect.top - tooltipRect.height - GAP
		};
	};
	TreeView = (0, import_react$1.forwardRef)(function TreeView({ className, nodes, selectedValue, defaultSelectedValue, onSelectedValueChange, expandedValues, defaultExpandedValues = [], onExpandedValuesChange, ...props }, ref) {
		const isSelectedControlled = selectedValue !== void 0;
		const isExpandedControlled = expandedValues !== void 0;
		const [internalSelectedValue, setInternalSelectedValue] = (0, import_react$1.useState)(defaultSelectedValue ?? findFirstEnabledValue(nodes));
		const [internalExpandedValues, setInternalExpandedValues] = (0, import_react$1.useState)(defaultExpandedValues);
		const resolvedSelectedValue = isSelectedControlled ? selectedValue : internalSelectedValue;
		const resolvedExpandedValues = isExpandedControlled ? expandedValues : internalExpandedValues;
		const expandedSet = (0, import_react$1.useMemo)(() => new Set(resolvedExpandedValues), [resolvedExpandedValues]);
		const flattenedNodes = (0, import_react$1.useMemo)(() => flattenVisibleNodes(nodes, expandedSet), [expandedSet, nodes]);
		const itemRefs = (0, import_react$1.useRef)({});
		const updateExpandedValues = (0, import_react$1.useCallback)((nextValues) => {
			if (!isExpandedControlled) setInternalExpandedValues(nextValues);
			onExpandedValuesChange?.(nextValues);
		}, [isExpandedControlled, onExpandedValuesChange]);
		const expandAll = (0, import_react$1.useCallback)(() => {
			updateExpandedValues(collectExpandableNodeValues(nodes));
		}, [nodes, updateExpandedValues]);
		const collapseAll = (0, import_react$1.useCallback)(() => {
			updateExpandedValues([]);
		}, [updateExpandedValues]);
		(0, import_react$1.useImperativeHandle)(ref, () => ({
			expandAll,
			collapseAll
		}), [collapseAll, expandAll]);
		const setExpandedState = (value, expanded) => {
			const nextSet = new Set(resolvedExpandedValues);
			if (expanded) nextSet.add(value);
			else nextSet.delete(value);
			updateExpandedValues(Array.from(nextSet));
		};
		const toggleExpanded = (value) => {
			setExpandedState(value, !expandedSet.has(value));
		};
		const setSelectedValue = (value) => {
			if (!isSelectedControlled) setInternalSelectedValue(value);
			onSelectedValueChange?.(value);
		};
		const focusNodeByValue = (value) => {
			if (!value) return;
			itemRefs.current[value]?.focus();
		};
		const onItemKeyDown = (current, event) => {
			const currentIndex = flattenedNodes.findIndex((item) => item.node.value === current.node.value);
			if (currentIndex === -1) return;
			const hasChildren = !!(current.node.children && current.node.children.length > 0);
			const isExpanded = expandedSet.has(current.node.value);
			if (event.key === "ArrowDown") {
				event.preventDefault();
				focusNodeByValue(flattenedNodes[currentIndex + 1]?.node.value);
				return;
			}
			if (event.key === "ArrowUp") {
				event.preventDefault();
				focusNodeByValue(flattenedNodes[currentIndex - 1]?.node.value);
				return;
			}
			if (event.key === "ArrowRight") {
				event.preventDefault();
				if (hasChildren && !isExpanded) {
					setExpandedState(current.node.value, true);
					return;
				}
				if (hasChildren && isExpanded) {
					const nextNode = flattenedNodes[currentIndex + 1];
					if (nextNode && nextNode.parentValue === current.node.value) focusNodeByValue(nextNode.node.value);
				}
				return;
			}
			if (event.key === "ArrowLeft") {
				event.preventDefault();
				if (hasChildren && isExpanded) {
					setExpandedState(current.node.value, false);
					return;
				}
				focusNodeByValue(current.parentValue);
				return;
			}
			if (event.key === "Home") {
				event.preventDefault();
				focusNodeByValue(flattenedNodes[0]?.node.value);
				return;
			}
			if (event.key === "End") {
				event.preventDefault();
				focusNodeByValue(flattenedNodes[flattenedNodes.length - 1]?.node.value);
				return;
			}
			if (event.key === "Enter" || event.key === " ") {
				event.preventDefault();
				if (!current.node.disabled) setSelectedValue(current.node.value);
				if (hasChildren) toggleExpanded(current.node.value);
			}
		};
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cx("pf-tree-view", className),
			role: "tree",
			...props,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "pf-tree-view__list",
				role: "presentation",
				children: flattenedNodes.map((item) => {
					const hasChildren = !!(item.node.children && item.node.children.length > 0);
					const isExpanded = expandedSet.has(item.node.value);
					const isSelected = resolvedSelectedValue === item.node.value;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "pf-tree-view__item",
						role: "presentation",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cx("pf-tree-view__row", isSelected && "pf-tree-view__row--selected", item.node.disabled && "pf-tree-view__row--disabled"),
							style: { "--pf-tree-level": String(item.level - 1) },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pf-tree-view__toggle-wrap",
								"aria-hidden": true,
								children: hasChildren ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "pf-tree-view__toggle",
									onClick: () => toggleExpanded(item.node.value),
									tabIndex: -1,
									children: isExpanded ? "▾" : "▸"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pf-tree-view__spacer" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								ref: (element) => {
									itemRefs.current[item.node.value] = element;
								},
								type: "button",
								role: "treeitem",
								className: "pf-tree-view__node",
								"aria-level": item.level,
								"aria-expanded": hasChildren ? isExpanded : void 0,
								"aria-selected": isSelected,
								disabled: item.node.disabled,
								onClick: () => {
									if (!item.node.disabled) setSelectedValue(item.node.value);
								},
								onKeyDown: (event) => onItemKeyDown(item, event),
								children: [
									item.node.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "pf-tree-view__icon",
										children: item.node.icon
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "pf-tree-view__label",
										children: item.node.label
									}),
									item.node.badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "pf-tree-view__badge",
										children: item.node.badge
									}) : null
								]
							})]
						})
					}, item.node.value);
				})
			})
		});
	});
	TreeView.displayName = "TreeView";
	UtilityButton = (0, import_react$1.forwardRef)(({ className, variant = "neutral", size = "md", type = "button", icon, children, ...props }, ref) => {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			ref,
			type,
			className: cx("pf-utility-button", `pf-utility-button--${variant}`, `pf-utility-button--${size}`, className),
			...props,
			children: [icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-utility-button__icon",
				children: icon
			}) : null, children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pf-utility-button__label",
				children
			}) : null]
		});
	});
	UtilityButton.displayName = "UtilityButton";
	VideoPlayer = (0, import_react$1.forwardRef)(({ id, label, description, error, aspectRatio = "16/9", sources, tracks, className, src, controls = true, preload = "metadata", "aria-describedby": ariaDescribedBy, ...props }, ref) => {
		const generatedId = (0, import_react$1.useId)();
		const videoId = id ?? generatedId;
		const descriptionId = description ? `${videoId}-description` : void 0;
		const errorId = error ? `${videoId}-error` : void 0;
		const describedBy = [
			ariaDescribedBy,
			descriptionId,
			errorId
		].filter(Boolean).join(" ") || void 0;
		const hasSource = Boolean(src) || Boolean(sources?.length);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pf-field",
			children: [
				label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "pf-field__label",
					htmlFor: videoId,
					children: label
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cx("pf-video-player", `pf-video-player--ratio-${aspectRatio.replace("/", "-")}`, error && "pf-video-player--invalid", className),
					children: hasSource ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("video", {
						...props,
						ref,
						id: videoId,
						className: "pf-video-player__video",
						controls,
						preload,
						src,
						"aria-invalid": error ? true : void 0,
						"aria-describedby": describedBy,
						children: [sources?.map((source) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
							src: source.src,
							type: source.type
						}, `${source.src}-${source.type ?? "default"}`)), tracks?.map((track) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("track", {
							src: track.src,
							kind: track.kind,
							srcLang: track.srcLang,
							label: track.label,
							default: track.default
						}, `${track.src}-${track.kind}-${track.srcLang}`))]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pf-video-player__empty",
						role: "note",
						id: videoId,
						children: "Add a video src to display playback."
					})
				}),
				description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__description",
					id: descriptionId,
					children: description
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pf-field__error",
					id: errorId,
					children: error
				}) : null
			]
		});
	});
	VideoPlayer.displayName = "VideoPlayer";
	Avatar.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "Avatar",
		"props": { "size": {
			"defaultValue": {
				"value": "\"md\"",
				"computed": false
			},
			"required": false
		} }
	};
	BadgeGroup.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "BadgeGroup",
		"props": {
			"color": {
				"defaultValue": {
					"value": "\"gray\"",
					"computed": false
				},
				"required": false
			},
			"appearance": {
				"defaultValue": {
					"value": "\"pill\"",
					"computed": false
				},
				"required": false
			},
			"badgePosition": {
				"defaultValue": {
					"value": "\"leading\"",
					"computed": false
				},
				"required": false
			}
		}
	};
	Button.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "Button",
		"props": {
			"variant": {
				"defaultValue": {
					"value": "\"primary\"",
					"computed": false
				},
				"required": false
			},
			"size": {
				"defaultValue": {
					"value": "\"md\"",
					"computed": false
				},
				"required": false
			},
			"fullWidth": {
				"defaultValue": {
					"value": "false",
					"computed": false
				},
				"required": false
			},
			"type": {
				"defaultValue": {
					"value": "\"button\"",
					"computed": false
				},
				"required": false
			}
		}
	};
	ButtonGroup.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "ButtonGroup",
		"props": {
			"multiple": {
				"defaultValue": {
					"value": "false",
					"computed": false
				},
				"required": false
			},
			"disabled": {
				"defaultValue": {
					"value": "false",
					"computed": false
				},
				"required": false
			}
		}
	};
	Checkbox.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "Checkbox"
	};
	CreditCard.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "CreditCard",
		"props": {
			"brand": {
				"defaultValue": {
					"value": "\"generic\"",
					"computed": false
				},
				"required": false
			},
			"masked": {
				"defaultValue": {
					"value": "true",
					"computed": false
				},
				"required": false
			}
		}
	};
	Dropdown.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "Dropdown",
		"props": {
			"label": {
				"defaultValue": {
					"value": "\"Actions\"",
					"computed": false
				},
				"required": false
			},
			"align": {
				"defaultValue": {
					"value": "\"start\"",
					"computed": false
				},
				"required": false
			}
		}
	};
	Input.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "Input"
	};
	MultiSelect.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "MultiSelect",
		"props": { "placeholder": {
			"defaultValue": {
				"value": "\"Select options\"",
				"computed": false
			},
			"required": false
		} }
	};
	RadioButton.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "RadioButton"
	};
	RadioGroup.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "RadioGroup",
		"props": {
			"disabled": {
				"defaultValue": {
					"value": "false",
					"computed": false
				},
				"required": false
			},
			"orientation": {
				"defaultValue": {
					"value": "\"vertical\"",
					"computed": false
				},
				"required": false
			}
		}
	};
	RichTextEditor.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "RichTextEditor",
		"props": {
			"placeholder": {
				"defaultValue": {
					"value": "\"Start typing...\"",
					"computed": false
				},
				"required": false
			},
			"minHeight": {
				"defaultValue": {
					"value": "140",
					"computed": false
				},
				"required": false
			},
			"disabled": {
				"defaultValue": {
					"value": "false",
					"computed": false
				},
				"required": false
			}
		}
	};
	Select.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "Select",
		"props": { "placeholder": {
			"defaultValue": {
				"value": "\"Select an option\"",
				"computed": false
			},
			"required": false
		} }
	};
	Slider.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "Slider",
		"props": {
			"min": {
				"defaultValue": {
					"value": "0",
					"computed": false
				},
				"required": false
			},
			"max": {
				"defaultValue": {
					"value": "100",
					"computed": false
				},
				"required": false
			},
			"step": {
				"defaultValue": {
					"value": "1",
					"computed": false
				},
				"required": false
			},
			"showValue": {
				"defaultValue": {
					"value": "true",
					"computed": false
				},
				"required": false
			}
		}
	};
	Switch.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "Switch"
	};
	Textarea.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "Textarea",
		"props": { "rows": {
			"defaultValue": {
				"value": "4",
				"computed": false
			},
			"required": false
		} }
	};
	TreeView.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "TreeView",
		"props": { "defaultExpandedValues": {
			"defaultValue": {
				"value": "[]",
				"computed": false
			},
			"required": false
		} }
	};
	UtilityButton.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "UtilityButton",
		"props": {
			"variant": {
				"defaultValue": {
					"value": "\"neutral\"",
					"computed": false
				},
				"required": false
			},
			"size": {
				"defaultValue": {
					"value": "\"md\"",
					"computed": false
				},
				"required": false
			},
			"type": {
				"defaultValue": {
					"value": "\"button\"",
					"computed": false
				},
				"required": false
			}
		}
	};
	VideoPlayer.__docgenInfo = {
		"description": "",
		"methods": [],
		"displayName": "VideoPlayer",
		"props": {
			"aspectRatio": {
				"defaultValue": {
					"value": "\"16/9\"",
					"computed": false
				},
				"required": false
			},
			"controls": {
				"defaultValue": {
					"value": "true",
					"computed": false
				},
				"required": false
			},
			"preload": {
				"defaultValue": {
					"value": "\"metadata\"",
					"computed": false
				},
				"required": false
			}
		}
	};
}));
//#endregion
export { Slider as $, Modal as A, ProgressCircle as B, InlineCTA as C, LoadingSpinner as D, LoadingSkeleton as E, NotificationStack as F, RatingBadge as G, RadarChart as H, PageHeader as I, SectionFooter as J, RatingStars as K, Pagination as L, ModalFooter as M, MultiSelect as N, MetricCard as O, Notification as P, SlideoutMenu as Q, PieChart as R, Icon as S, LoadingDots as T, RadioButton as U, ProgressSteps as V, RadioGroup as W, Select as X, SectionHeader as Y, SidebarNavigation as Z, CreditCard as _, Breadcrumbs as a, Tooltip as at, FileUploader as b, Calendar as c, VideoPlayer as ct, CardFooter as d, Switch as et, CardHeader as f, ContentDivider as g, CodeSnippet as h, BadgeGroup as i, Textarea as it, ModalBody as j, MetricGrid as k, Card as l, getAvailableIconNames as lt, Checkbox as m, Avatar as n, Tabs as nt, Button as o, TreeView as ot, Carousel as p, RichTextEditor as q, Badge as r, Tag as rt, ButtonGroup as s, UtilityButton as st, Alert as t, Table as tt, CardContent as u, init_dist as ut, DatePicker as v, Input as w, HeaderNavigation as x, Dropdown as y, ProgressBar as z };

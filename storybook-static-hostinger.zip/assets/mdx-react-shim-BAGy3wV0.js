import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { P as init_react } from "./blocks-OZ7n4nQC.js";
//#region ../../node_modules/@storybook/addon-docs/dist/mdx-react-shim.js
var init_mdx_react_shim = __esmMin((() => {
	init_react();
}));
//#endregion
export { init_mdx_react_shim as t };

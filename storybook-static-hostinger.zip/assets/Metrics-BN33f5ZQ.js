import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { CompactGrid, OverviewGrid, WithAction, n as init_Metrics_examples_stories, t as Metrics_examples_stories_exports } from "./Metrics.examples.stories-CscjFIIU.js";
import { n as init_Metrics_stories, t as Metrics_stories_exports } from "./Metrics.stories-CRemW3L7.js";
//#region src/Metrics.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Metrics_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "metrics",
			children: "Metrics"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "MetricCard and MetricGrid surface key numbers with optional trend context, supporting both standalone and dashboard-style layouts." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "overview-grid",
			children: "Overview grid"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: OverviewGrid,
			meta: Metrics_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-action",
			children: "With action"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithAction,
			meta: Metrics_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "compact-grid",
			children: "Compact grid"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: CompactGrid,
			meta: Metrics_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Metrics_stories();
	init_Metrics_examples_stories();
}))();
export { MDXContent as default };

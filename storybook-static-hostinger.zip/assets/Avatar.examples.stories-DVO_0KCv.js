import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { n as Avatar, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Avatar.examples.stories.tsx
var Avatar_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Initials: () => Initials,
	PresenceStatus: () => PresenceStatus,
	Sizes: () => Sizes,
	WithImage: () => WithImage,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Initials, WithImage, Sizes, PresenceStatus, __namedExportsOrder;
var init_Avatar_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Avatar",
		component: Avatar,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { name: "Leland Rangel" }
	};
	Initials = {};
	WithImage = { args: {
		src: "avatar.jpeg",
		alt: "Profile image",
		name: "Pitchfork User"
	} };
	Sizes = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "flex",
			gap: 12,
			alignItems: "center"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
				name: "Leland Rangel",
				size: "sm"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
				name: "Leland Rangel",
				size: "md"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
				name: "Leland Rangel",
				size: "lg"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
				name: "Leland Rangel",
				size: "xl"
			})
		]
	}) };
	PresenceStatus = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "flex",
			gap: 12,
			alignItems: "center"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
				name: "Online User",
				status: "online"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
				name: "Away User",
				status: "away"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
				name: "Busy User",
				status: "busy"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
				name: "Offline User",
				status: "offline"
			})
		]
	}) };
	Initials.parameters = {
		...Initials.parameters,
		docs: {
			...Initials.parameters?.docs,
			source: {
				originalSource: "{}",
				...Initials.parameters?.docs?.source
			}
		}
	};
	WithImage.parameters = {
		...WithImage.parameters,
		docs: {
			...WithImage.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    src: 'avatar.jpeg',\n    alt: 'Profile image',\n    name: 'Pitchfork User'\n  }\n}",
				...WithImage.parameters?.docs?.source
			}
		}
	};
	Sizes.parameters = {
		...Sizes.parameters,
		docs: {
			...Sizes.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <div style={{\n    display: 'flex',\n    gap: 12,\n    alignItems: 'center'\n  }}>\n      <Avatar name=\"Leland Rangel\" size=\"sm\" />\n      <Avatar name=\"Leland Rangel\" size=\"md\" />\n      <Avatar name=\"Leland Rangel\" size=\"lg\" />\n      <Avatar name=\"Leland Rangel\" size=\"xl\" />\n    </div>\n}",
				...Sizes.parameters?.docs?.source
			}
		}
	};
	PresenceStatus.parameters = {
		...PresenceStatus.parameters,
		docs: {
			...PresenceStatus.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <div style={{\n    display: 'flex',\n    gap: 12,\n    alignItems: 'center'\n  }}>\n      <Avatar name=\"Online User\" status=\"online\" />\n      <Avatar name=\"Away User\" status=\"away\" />\n      <Avatar name=\"Busy User\" status=\"busy\" />\n      <Avatar name=\"Offline User\" status=\"offline\" />\n    </div>\n}",
				...PresenceStatus.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Initials",
		"WithImage",
		"Sizes",
		"PresenceStatus"
	];
}));
//#endregion
init_Avatar_examples_stories();
export { Initials, PresenceStatus, Sizes, WithImage, __namedExportsOrder, meta as default, init_Avatar_examples_stories as n, Avatar_examples_stories_exports as t };

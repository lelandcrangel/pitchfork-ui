import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Disabled, Ghost, Primary, Secondary, n as init_Button_examples_stories, t as Button_examples_stories_exports } from "./Button.examples.stories-C3VdjZct.js";
import { n as init_Button_stories, t as Button_stories_exports } from "./Button.stories-k1oTpA3r.js";
//#region src/Button.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Button_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "button",
			children: "Button"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Buttons trigger key user actions and support clear visual hierarchy through variants and size." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "primary",
			children: "Primary"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Primary,
			meta: Button_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "secondary",
			children: "Secondary"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Secondary,
			meta: Button_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "ghost",
			children: "Ghost"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Ghost,
			meta: Button_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled",
			children: "Disabled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Disabled,
			meta: Button_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Button_stories();
	init_Button_examples_stories();
}))();
export { MDXContent as default };

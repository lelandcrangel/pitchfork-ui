import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { R as PieChart, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/PieChart.stories.tsx
var PieChart_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_PieChart_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Pie Charts",
		component: PieChart,
		tags: ["ai-generated", "test"],
		args: {
			size: 192,
			cutout: .58,
			showLegend: true,
			centerLabel: "12.4k",
			data: [
				{
					label: "Product",
					value: 48
				},
				{
					label: "Enterprise",
					value: 32
				},
				{
					label: "Services",
					value: 20
				}
			]
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieChart, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <PieChart {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_PieChart_stories();
export { Interactive, __namedExportsOrder, meta as default, init_PieChart_stories as n, PieChart_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { nt as Tabs, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Tabs.stories.tsx
var Tabs_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_Tabs_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Tabs",
		component: Tabs,
		tags: ["ai-generated", "test"],
		args: {
			items: [
				{
					value: "overview",
					label: "Overview",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						style: { margin: 0 },
						children: "Track team health, delivery status, and KPIs from one place."
					})
				},
				{
					value: "activity",
					label: "Activity",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						style: { margin: 0 },
						children: "Recent events include PR merges, deployments, and incident updates."
					})
				},
				{
					value: "settings",
					label: "Settings",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						style: { margin: 0 },
						children: "Configure alerts, notification channels, and role permissions."
					})
				},
				{
					value: "billing",
					label: "Billing",
					disabled: true,
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						style: { margin: 0 },
						children: "Billing details are currently unavailable."
					})
				}
			],
			variant: "underline",
			size: "md",
			fullWidth: false,
			defaultValue: "overview"
		},
		argTypes: {
			items: { control: false },
			variant: {
				control: "select",
				options: ["underline", "pills"]
			},
			size: {
				control: "select",
				options: ["sm", "md"]
			}
		}
	};
	Interactive = {};
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Tabs_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Tabs_stories as n, Tabs_stories_exports as t };

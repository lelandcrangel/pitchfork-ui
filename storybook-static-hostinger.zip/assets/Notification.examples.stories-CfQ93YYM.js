import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { F as NotificationStack, P as Notification, o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Notification.examples.stories.tsx
var Notification_examples_stories_exports = /* @__PURE__ */ __exportAll({
	BottomLeftPlacement: () => BottomLeftPlacement,
	DestructiveNotice: () => DestructiveNotice,
	StackedToasts: () => StackedToasts,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, StackedToasts, DestructiveNotice, BottomLeftPlacement, __namedExportsOrder;
var init_Notification_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Notifications",
		component: Notification,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		]
	};
	StackedToasts = {
		args: { heading: "Example" },
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NotificationStack, {
			style: { maxWidth: 420 },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notification, {
					variant: "success",
					heading: "Changes published",
					description: "Your homepage updates are now live.",
					dismissible: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notification, {
					variant: "info",
					heading: "Background sync in progress",
					description: "We are refreshing the latest analytics for your dashboard."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notification, {
					variant: "warning",
					heading: "Storage nearing limit",
					description: "You have 12% of your storage remaining.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						children: "Upgrade plan"
					})
				})
			]
		})
	};
	DestructiveNotice = {
		args: { heading: "Delete warning" },
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notification, {
			variant: "danger",
			heading: "Project archived",
			description: "The project was archived and can be restored from settings within 30 days.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "secondary",
				children: "View details"
			}),
			dismissible: true,
			style: { maxWidth: 420 }
		})
	};
	BottomLeftPlacement = {
		args: { heading: "Placement" },
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationStack, {
			placement: "bottom-left",
			style: { maxWidth: 420 },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notification, {
				heading: "Invite sent",
				description: "Jordan will receive an invitation email shortly."
			})
		})
	};
	StackedToasts.parameters = {
		...StackedToasts.parameters,
		docs: {
			...StackedToasts.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    heading: 'Example'\n  },\n  render: () => <NotificationStack style={{\n    maxWidth: 420\n  }}>\n      <Notification variant=\"success\" heading=\"Changes published\" description=\"Your homepage updates are now live.\" dismissible />\n      <Notification variant=\"info\" heading=\"Background sync in progress\" description=\"We are refreshing the latest analytics for your dashboard.\" />\n      <Notification variant=\"warning\" heading=\"Storage nearing limit\" description=\"You have 12% of your storage remaining.\" action={<Button size=\"sm\">Upgrade plan</Button>} />\n    </NotificationStack>\n}",
				...StackedToasts.parameters?.docs?.source
			}
		}
	};
	DestructiveNotice.parameters = {
		...DestructiveNotice.parameters,
		docs: {
			...DestructiveNotice.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    heading: 'Delete warning'\n  },\n  render: () => <Notification variant=\"danger\" heading=\"Project archived\" description=\"The project was archived and can be restored from settings within 30 days.\" action={<Button size=\"sm\" variant=\"secondary\">\n          View details\n        </Button>} dismissible style={{\n    maxWidth: 420\n  }} />\n}",
				...DestructiveNotice.parameters?.docs?.source
			}
		}
	};
	BottomLeftPlacement.parameters = {
		...BottomLeftPlacement.parameters,
		docs: {
			...BottomLeftPlacement.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    heading: 'Placement'\n  },\n  render: () => <NotificationStack placement=\"bottom-left\" style={{\n    maxWidth: 420\n  }}>\n      <Notification heading=\"Invite sent\" description=\"Jordan will receive an invitation email shortly.\" />\n    </NotificationStack>\n}",
				...BottomLeftPlacement.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"StackedToasts",
		"DestructiveNotice",
		"BottomLeftPlacement"
	];
}));
//#endregion
init_Notification_examples_stories();
export { BottomLeftPlacement, DestructiveNotice, StackedToasts, __namedExportsOrder, meta as default, init_Notification_examples_stories as n, Notification_examples_stories_exports as t };

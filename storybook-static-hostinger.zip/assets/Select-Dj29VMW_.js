import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Default, Disabled, WithDefaultValue, WithError, n as init_Select_examples_stories, t as Select_examples_stories_exports } from "./Select.examples.stories-Bvdfl4M6.js";
import { n as init_Select_stories, t as Select_stories_exports } from "./Select.stories-BatWjres.js";
//#region src/Select.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Select_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "select",
			children: "Select"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Select presents a custom dropdown for choosing a single option from a list." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: Select_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-default-value",
			children: "With Default Value"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithDefaultValue,
			meta: Select_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-error",
			children: "With Error"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithError,
			meta: Select_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled",
			children: "Disabled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Disabled,
			meta: Select_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Select_stories();
	init_Select_examples_stories();
}))();
export { MDXContent as default };

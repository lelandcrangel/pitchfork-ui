import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as Pagination, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Pagination.stories.tsx
var Pagination_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_Pagination_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Paginations",
		component: Pagination,
		tags: ["ai-generated", "test"],
		args: {
			defaultPage: 8,
			totalPages: 20,
			siblingCount: 1,
			boundaryCount: 1,
			showPrevNext: true,
			disabled: false,
			prevLabel: "Previous",
			nextLabel: "Next"
		},
		argTypes: { onPageChange: { action: "page changed" } }
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <Pagination {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Pagination_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Pagination_stories as n, Pagination_stories_exports as t };

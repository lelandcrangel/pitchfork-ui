import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { L as Pagination, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Pagination.examples.stories.tsx
var Pagination_examples_stories_exports = /* @__PURE__ */ __exportAll({
	CompactNumbers: () => CompactNumbers,
	Default: () => Default,
	Disabled: () => Disabled,
	NumbersOnly: () => NumbersOnly,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Default, CompactNumbers, NumbersOnly, Disabled, __namedExportsOrder;
var init_Pagination_examples_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Examples/Pagination",
		component: Pagination,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			totalPages: 15,
			defaultPage: 1
		},
		argTypes: { onPageChange: { action: "page changed" } }
	};
	Default = { args: { defaultPage: 8 } };
	CompactNumbers = { args: {
		defaultPage: 12,
		totalPages: 24,
		siblingCount: 0
	} };
	NumbersOnly = { args: {
		defaultPage: 4,
		totalPages: 9,
		showPrevNext: false
	} };
	Disabled = { args: {
		defaultPage: 3,
		totalPages: 10,
		disabled: true
	} };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultPage: 8\n  }\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	CompactNumbers.parameters = {
		...CompactNumbers.parameters,
		docs: {
			...CompactNumbers.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultPage: 12,\n    totalPages: 24,\n    siblingCount: 0\n  }\n}",
				...CompactNumbers.parameters?.docs?.source
			}
		}
	};
	NumbersOnly.parameters = {
		...NumbersOnly.parameters,
		docs: {
			...NumbersOnly.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultPage: 4,\n    totalPages: 9,\n    showPrevNext: false\n  }\n}",
				...NumbersOnly.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultPage: 3,\n    totalPages: 10,\n    disabled: true\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"CompactNumbers",
		"NumbersOnly",
		"Disabled"
	];
}));
//#endregion
init_Pagination_examples_stories();
export { CompactNumbers, Default, Disabled, NumbersOnly, __namedExportsOrder, meta as default, init_Pagination_examples_stories as n, Pagination_examples_stories_exports as t };

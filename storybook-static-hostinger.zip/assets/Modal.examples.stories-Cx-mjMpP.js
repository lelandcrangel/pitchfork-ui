import { a as __exportAll, i as __esmMin, s as __toESM } from "./preload-helper-UB4_TMNL.js";
import { k as require_react } from "./iframe-DMCHwO1W.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { A as Modal, M as ModalFooter, j as ModalBody, o as Button, ut as init_dist, w as Input } from "./dist-D1zMThSa.js";
//#region src/Modal.examples.stories.tsx
var Modal_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Confirmation: () => Confirmation,
	FormModal: () => FormModal,
	LargeContent: () => LargeContent,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_react, import_jsx_runtime, meta, Confirmation, FormModal, LargeContent, __namedExportsOrder;
var init_Modal_examples_stories = __esmMin((() => {
	import_react = /* @__PURE__ */ __toESM(require_react(), 1);
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Modals",
		component: Modal,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { open: false },
		argTypes: {
			onOpenChange: { control: false },
			footer: { control: false },
			children: { control: false }
		}
	};
	Confirmation = { render: () => {
		const [open, setOpen] = (0, import_react.useState)(false);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => setOpen(true),
			children: "Delete project"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open,
			onOpenChange: setOpen,
			size: "sm",
			title: "Delete project",
			description: "This action cannot be undone. All analytics and exports will be removed.",
			footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: () => setOpen(false),
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen(false),
				children: "Delete"
			})] }),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { margin: 0 },
				children: "Review the impact before confirming."
			})
		})] });
	} };
	FormModal = { render: () => {
		const [open, setOpen] = (0, import_react.useState)(false);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => setOpen(true),
			children: "Invite teammate"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open,
			onOpenChange: setOpen,
			title: "Invite teammate",
			description: "Add a collaborator and assign their starting role.",
			footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ModalFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: () => setOpen(false),
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen(false),
				children: "Send invite"
			})] }),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ModalBody, {
				style: {
					display: "grid",
					gap: 12,
					padding: 0
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					label: "Email address",
					placeholder: "teammate@company.com"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					label: "Role",
					placeholder: "Designer"
				})]
			})
		})] });
	} };
	LargeContent = { render: () => {
		const [open, setOpen] = (0, import_react.useState)(false);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => setOpen(true),
			children: "Open release notes"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open,
			onOpenChange: setOpen,
			size: "lg",
			title: "Release notes",
			description: "A larger modal for longer-form content.",
			footer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: () => setOpen(false),
				children: "Close"
			}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "grid",
					gap: 12
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						style: { margin: 0 },
						children: "This release improves search relevance, upload reliability, and dashboard performance."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						style: { margin: 0 },
						children: "Teams can now manage permissions more granularly and review audit activity from one place."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						style: { margin: 0 },
						children: "Use a larger modal when the content requires more reading space but should stay in context."
					})
				]
			})
		})] });
	} };
	Confirmation.parameters = {
		...Confirmation.parameters,
		docs: {
			...Confirmation.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => {\n    const [open, setOpen] = useState(false);\n    return <>\n        <Button onClick={() => setOpen(true)}>Delete project</Button>\n        <Modal open={open} onOpenChange={setOpen} size=\"sm\" title=\"Delete project\" description=\"This action cannot be undone. All analytics and exports will be removed.\" footer={<>\n              <Button variant=\"secondary\" onClick={() => setOpen(false)}>\n                Cancel\n              </Button>\n              <Button onClick={() => setOpen(false)}>Delete</Button>\n            </>}>\n          <p style={{\n          margin: 0\n        }}>Review the impact before confirming.</p>\n        </Modal>\n      </>;\n  }\n}",
				...Confirmation.parameters?.docs?.source
			}
		}
	};
	FormModal.parameters = {
		...FormModal.parameters,
		docs: {
			...FormModal.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => {\n    const [open, setOpen] = useState(false);\n    return <>\n        <Button onClick={() => setOpen(true)}>Invite teammate</Button>\n        <Modal open={open} onOpenChange={setOpen} title=\"Invite teammate\" description=\"Add a collaborator and assign their starting role.\" footer={<ModalFooter>\n              <Button variant=\"secondary\" onClick={() => setOpen(false)}>\n                Cancel\n              </Button>\n              <Button onClick={() => setOpen(false)}>Send invite</Button>\n            </ModalFooter>}>\n          <ModalBody style={{\n          display: 'grid',\n          gap: 12,\n          padding: 0\n        }}>\n            <Input label=\"Email address\" placeholder=\"teammate@company.com\" />\n            <Input label=\"Role\" placeholder=\"Designer\" />\n          </ModalBody>\n        </Modal>\n      </>;\n  }\n}",
				...FormModal.parameters?.docs?.source
			}
		}
	};
	LargeContent.parameters = {
		...LargeContent.parameters,
		docs: {
			...LargeContent.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => {\n    const [open, setOpen] = useState(false);\n    return <>\n        <Button onClick={() => setOpen(true)}>Open release notes</Button>\n        <Modal open={open} onOpenChange={setOpen} size=\"lg\" title=\"Release notes\" description=\"A larger modal for longer-form content.\" footer={<Button variant=\"secondary\" onClick={() => setOpen(false)}>\n              Close\n            </Button>}>\n          <div style={{\n          display: 'grid',\n          gap: 12\n        }}>\n            <p style={{\n            margin: 0\n          }}>\n              This release improves search relevance, upload reliability, and\n              dashboard performance.\n            </p>\n            <p style={{\n            margin: 0\n          }}>\n              Teams can now manage permissions more granularly and review audit\n              activity from one place.\n            </p>\n            <p style={{\n            margin: 0\n          }}>\n              Use a larger modal when the content requires more reading space\n              but should stay in context.\n            </p>\n          </div>\n        </Modal>\n      </>;\n  }\n}",
				...LargeContent.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Confirmation",
		"FormModal",
		"LargeContent"
	];
}));
//#endregion
init_Modal_examples_stories();
export { Confirmation, FormModal, LargeContent, __namedExportsOrder, meta as default, init_Modal_examples_stories as n, Modal_examples_stories_exports as t };

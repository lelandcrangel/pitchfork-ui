import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { BottomLeftPlacement, DestructiveNotice, StackedToasts, n as init_Notification_examples_stories, t as Notification_examples_stories_exports } from "./Notification.examples.stories-CfQ93YYM.js";
import { n as init_Notification_stories, t as Notification_stories_exports } from "./Notification.stories-l0F3gdeG.js";
//#region src/Notification.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Notification_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "notifications",
			children: "Notifications"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Notification and NotificationStack provide toast-style status messages with optional actions and dismiss controls." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "stacked-toasts",
			children: "Stacked toasts"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: StackedToasts,
			meta: Notification_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "destructive-notice",
			children: "Destructive notice"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: DestructiveNotice,
			meta: Notification_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "bottom-left-placement",
			children: "Bottom-left placement"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: BottomLeftPlacement,
			meta: Notification_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Notification_stories();
	init_Notification_examples_stories();
}))();
export { MDXContent as default };

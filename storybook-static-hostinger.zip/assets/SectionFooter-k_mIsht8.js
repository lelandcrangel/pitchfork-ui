import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Default, EndAlignedActions, NoDivider, n as init_SectionFooter_examples_stories, t as SectionFooter_examples_stories_exports } from "./SectionFooter.examples.stories-TuFOqfng.js";
import { n as init_SectionFooter_stories, t as SectionFooter_stories_exports } from "./SectionFooter.stories-CRTLnWE3.js";
//#region src/SectionFooter.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: SectionFooter_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "section-footers",
			children: "Section Footers"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "SectionFooter provides a consistent bottom area for section-level messaging and actions." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: SectionFooter_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "no-divider",
			children: "No divider"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: NoDivider,
			meta: SectionFooter_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "end-aligned-actions",
			children: "End-aligned actions"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: EndAlignedActions,
			meta: SectionFooter_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_SectionFooter_stories();
	init_SectionFooter_examples_stories();
}))();
export { MDXContent as default };

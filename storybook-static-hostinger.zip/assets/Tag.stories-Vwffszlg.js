import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { rt as Tag, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Tag.stories.tsx
var Tag_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, fn, meta, Interactive, __namedExportsOrder;
var init_Tag_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	({fn} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Components/Tag",
		component: Tag,
		tags: ["ai-generated", "test"],
		args: {
			children: "Design",
			variant: "neutral",
			dismissible: false,
			onDismiss: fn()
		},
		argTypes: {
			variant: {
				control: "select",
				options: [
					"neutral",
					"brand",
					"success",
					"warning"
				]
			},
			dismissible: { control: "boolean" }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <Tag {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Tag_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Tag_stories as n, Tag_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { S as Icon, o as Button, st as UtilityButton, ut as init_dist, x as HeaderNavigation } from "./dist-D1zMThSa.js";
//#region src/HeaderNavigation.examples.stories.tsx
var HeaderNavigation_examples_stories_exports = /* @__PURE__ */ __exportAll({
	ActionGroup: () => ActionGroup,
	Default: () => Default,
	NoActions: () => NoActions,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Default, NoActions, ActionGroup, __namedExportsOrder;
var init_HeaderNavigation_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/HeaderNavigation",
		component: HeaderNavigation,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		]
	};
	Default = { args: {
		brand: "Pitchfork UI",
		items: [
			{
				label: "Overview",
				href: "#",
				active: true
			},
			{
				label: "Projects",
				href: "#"
			},
			{
				label: "Team",
				href: "#"
			},
			{
				label: "Settings",
				href: "#"
			}
		],
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			children: "New"
		})
	} };
	NoActions = { args: {
		brand: "Workspace",
		items: [
			{
				label: "Home",
				href: "#",
				active: true
			},
			{
				label: "Activity",
				href: "#"
			},
			{
				label: "Files",
				href: "#"
			}
		]
	} };
	ActionGroup = { args: {
		brand: "Dashboard",
		items: [
			{
				label: "Overview",
				href: "#",
				active: true
			},
			{
				label: "Analytics",
				href: "#"
			},
			{
				label: "Billing",
				href: "#"
			}
		],
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtilityButton, {
			"aria-label": "Search",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				name: "magnifying-glass",
				"aria-hidden": true
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "secondary",
			children: "Invite"
		})] })
	} };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    brand: 'Pitchfork UI',\n    items: [{\n      label: 'Overview',\n      href: '#',\n      active: true\n    }, {\n      label: 'Projects',\n      href: '#'\n    }, {\n      label: 'Team',\n      href: '#'\n    }, {\n      label: 'Settings',\n      href: '#'\n    }],\n    actions: <Button size=\"sm\">New</Button>\n  }\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	NoActions.parameters = {
		...NoActions.parameters,
		docs: {
			...NoActions.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    brand: 'Workspace',\n    items: [{\n      label: 'Home',\n      href: '#',\n      active: true\n    }, {\n      label: 'Activity',\n      href: '#'\n    }, {\n      label: 'Files',\n      href: '#'\n    }]\n  }\n}",
				...NoActions.parameters?.docs?.source
			}
		}
	};
	ActionGroup.parameters = {
		...ActionGroup.parameters,
		docs: {
			...ActionGroup.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    brand: 'Dashboard',\n    items: [{\n      label: 'Overview',\n      href: '#',\n      active: true\n    }, {\n      label: 'Analytics',\n      href: '#'\n    }, {\n      label: 'Billing',\n      href: '#'\n    }],\n    actions: <>\n        <UtilityButton aria-label=\"Search\">\n          <Icon name=\"magnifying-glass\" aria-hidden />\n        </UtilityButton>\n        <Button size=\"sm\" variant=\"secondary\">\n          Invite\n        </Button>\n      </>\n  }\n}",
				...ActionGroup.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"NoActions",
		"ActionGroup"
	];
}));
//#endregion
init_HeaderNavigation_examples_stories();
export { ActionGroup, Default, NoActions, __namedExportsOrder, meta as default, init_HeaderNavigation_examples_stories as n, HeaderNavigation_examples_stories_exports as t };

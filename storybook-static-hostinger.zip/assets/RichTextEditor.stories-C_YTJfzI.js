import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { q as RichTextEditor, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/RichTextEditor.stories.tsx
var RichTextEditor_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_RichTextEditor_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Rich Text Editor",
		component: RichTextEditor,
		tags: ["ai-generated", "test"],
		args: {
			label: "Description",
			description: "Use formatting controls to style your text.",
			placeholder: "Write product details...",
			minHeight: 160,
			characterMax: 220,
			defaultValue: "<p><strong>Pitchfork UI</strong> helps teams ship faster.</p>",
			disabled: false
		},
		argTypes: {
			minHeight: { control: {
				type: "number",
				min: 100,
				max: 400,
				step: 10
			} },
			characterMax: { control: {
				type: "number",
				min: 40,
				max: 500,
				step: 10
			} },
			disabled: { control: "boolean" }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RichTextEditor, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <RichTextEditor {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_RichTextEditor_stories();
export { Interactive, __namedExportsOrder, meta as default, init_RichTextEditor_stories as n, RichTextEditor_stories_exports as t };

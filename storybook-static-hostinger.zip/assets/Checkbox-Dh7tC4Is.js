import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Checked, Disabled, Unchecked, n as init_Checkbox_examples_stories, t as Checkbox_examples_stories_exports } from "./Checkbox.examples.stories-D7CnFDF1.js";
import { n as init_Checkbox_stories, t as Checkbox_stories_exports } from "./Checkbox.stories-DXMLDpBW.js";
//#region src/Checkbox.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Checkbox_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "checkbox",
			children: "Checkbox"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Checkboxes let users opt in to one or more independent settings." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "unchecked",
			children: "Unchecked"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Unchecked,
			meta: Checkbox_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "checked",
			children: "Checked"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Checked,
			meta: Checkbox_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled",
			children: "Disabled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Disabled,
			meta: Checkbox_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Checkbox_stories();
	init_Checkbox_examples_stories();
}))();
export { MDXContent as default };

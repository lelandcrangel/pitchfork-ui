import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Disabled, Off, On, n as init_Switch_examples_stories, t as Switch_examples_stories_exports } from "./Switch.examples.stories-CP_1mloC.js";
import { n as init_Switch_stories, t as Switch_stories_exports } from "./Switch.stories-DVPGXgcB.js";
//#region src/Switch.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Switch_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "switch",
			children: "Switch"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Switches toggle binary settings on and off with immediate visual feedback." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "off",
			children: "Off"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Off,
			meta: Switch_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "on",
			children: "On"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: On,
			meta: Switch_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled",
			children: "Disabled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Disabled,
			meta: Switch_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Switch_stories();
	init_Switch_examples_stories();
}))();
export { MDXContent as default };

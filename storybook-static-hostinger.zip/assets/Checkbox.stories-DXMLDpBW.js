import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { m as Checkbox, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Checkbox.stories.tsx
var Checkbox_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Interactive, __namedExportsOrder;
var init_Checkbox_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Components/Checkbox",
		component: Checkbox,
		tags: ["ai-generated", "test"],
		args: { label: "Enable notifications" }
	};
	Interactive = { args: { label: "Interactive checkbox" } };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Interactive checkbox'\n  }\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Checkbox_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Checkbox_stories as n, Checkbox_stories_exports as t };

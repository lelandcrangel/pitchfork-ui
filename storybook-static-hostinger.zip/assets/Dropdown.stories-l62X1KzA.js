import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { S as Icon, ut as init_dist, y as Dropdown } from "./dist-D1zMThSa.js";
//#region src/Dropdown.stories.tsx
var Dropdown_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_Dropdown_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Dropdown",
		component: Dropdown,
		tags: ["ai-generated", "test"],
		args: {
			label: "Actions",
			align: "start",
			items: [
				{
					label: "Edit profile",
					shortcut: "E",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						name: "pen-to-square",
						"aria-hidden": true
					})
				},
				{
					label: "Archive",
					shortcut: "A"
				},
				{
					label: "Delete",
					destructive: true,
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						name: "trash-can",
						"aria-hidden": true
					})
				}
			]
		},
		argTypes: { align: {
			control: "select",
			options: ["start", "end"]
		} }
	};
	Interactive = {};
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Dropdown_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Dropdown_stories as n, Dropdown_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { C as InlineCTA, S as Icon, o as Button, st as UtilityButton, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/InlineCTA.examples.stories.tsx
var InlineCTA_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	Info: () => Info,
	Success: () => Success,
	WarningWithActionGroup: () => WarningWithActionGroup,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Default, Info, Success, WarningWithActionGroup, __namedExportsOrder;
var init_InlineCTA_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/InlineCTA",
		component: InlineCTA,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		]
	};
	Default = { args: {
		heading: "Complete your profile",
		description: "Add your details to personalize your workspace.",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			children: "Complete"
		})
	} };
	Info = { args: {
		tone: "info",
		heading: "New release notes",
		description: "Version 2.4 is live with improved editing tools.",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "secondary",
			children: "Read notes"
		})
	} };
	Success = { args: {
		tone: "success",
		iconName: "circle-check",
		heading: "Payment method verified",
		description: "You are all set for the next billing cycle."
	} };
	WarningWithActionGroup = { args: {
		tone: "warning",
		iconName: "triangle-exclamation",
		heading: "Storage is almost full",
		description: "You have less than 10% storage remaining.",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			children: "Upgrade storage"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtilityButton, {
			"aria-label": "Dismiss notice",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				name: "circle-xmark",
				"aria-hidden": true
			})
		})] })
	} };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    heading: 'Complete your profile',\n    description: 'Add your details to personalize your workspace.',\n    action: <Button size=\"sm\">Complete</Button>\n  }\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	Info.parameters = {
		...Info.parameters,
		docs: {
			...Info.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    tone: 'info',\n    heading: 'New release notes',\n    description: 'Version 2.4 is live with improved editing tools.',\n    action: <Button size=\"sm\" variant=\"secondary\">\n        Read notes\n      </Button>\n  }\n}",
				...Info.parameters?.docs?.source
			}
		}
	};
	Success.parameters = {
		...Success.parameters,
		docs: {
			...Success.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    tone: 'success',\n    iconName: 'circle-check',\n    heading: 'Payment method verified',\n    description: 'You are all set for the next billing cycle.'\n  }\n}",
				...Success.parameters?.docs?.source
			}
		}
	};
	WarningWithActionGroup.parameters = {
		...WarningWithActionGroup.parameters,
		docs: {
			...WarningWithActionGroup.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    tone: 'warning',\n    iconName: 'triangle-exclamation',\n    heading: 'Storage is almost full',\n    description: 'You have less than 10% storage remaining.',\n    action: <>\n        <Button size=\"sm\">Upgrade storage</Button>\n        <UtilityButton aria-label=\"Dismiss notice\">\n          <Icon name=\"circle-xmark\" aria-hidden />\n        </UtilityButton>\n      </>\n  }\n}",
				...WarningWithActionGroup.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"Info",
		"Success",
		"WarningWithActionGroup"
	];
}));
//#endregion
init_InlineCTA_examples_stories();
export { Default, Info, Success, WarningWithActionGroup, __namedExportsOrder, meta as default, init_InlineCTA_examples_stories as n, InlineCTA_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { O as MetricCard, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Metrics.stories.tsx
var Metrics_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_Metrics_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Metrics",
		component: MetricCard,
		tags: ["ai-generated", "test"],
		args: {
			heading: "Monthly recurring revenue",
			value: "$128k",
			trend: "positive",
			trendLabel: "12.4%",
			description: "Compared with the previous month.",
			iconName: "chart-bar"
		},
		argTypes: {
			icon: { control: false },
			action: { control: false }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <MetricCard {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Metrics_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Metrics_stories as n, Metrics_stories_exports as t };

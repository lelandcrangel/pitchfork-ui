import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { b as FileUploader, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/FileUploader.examples.stories.tsx
var FileUploader_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	Disabled: () => Disabled,
	LimitedCount: () => LimitedCount,
	SingleFile: () => SingleFile,
	WithError: () => WithError,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Default, SingleFile, LimitedCount, Disabled, WithError, __namedExportsOrder;
var init_FileUploader_examples_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Examples/FileUploader",
		component: FileUploader,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { label: "Upload files" }
	};
	Default = {};
	SingleFile = { args: {
		multiple: false,
		label: "Upload avatar",
		description: "Choose a single image file.",
		accept: ".png,.jpg,.jpeg",
		maxFiles: 1,
		maxFileSize: 1024 * 1024
	} };
	LimitedCount = { args: {
		description: "Upload up to two documents.",
		accept: ".pdf,.doc,.docx",
		maxFiles: 2
	} };
	Disabled = { args: {
		disabled: true,
		description: "Uploads are temporarily disabled."
	} };
	WithError = { args: { error: "Please upload at least one document before continuing." } };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{}",
				...Default.parameters?.docs?.source
			}
		}
	};
	SingleFile.parameters = {
		...SingleFile.parameters,
		docs: {
			...SingleFile.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    multiple: false,\n    label: 'Upload avatar',\n    description: 'Choose a single image file.',\n    accept: '.png,.jpg,.jpeg',\n    maxFiles: 1,\n    maxFileSize: 1024 * 1024\n  }\n}",
				...SingleFile.parameters?.docs?.source
			}
		}
	};
	LimitedCount.parameters = {
		...LimitedCount.parameters,
		docs: {
			...LimitedCount.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    description: 'Upload up to two documents.',\n    accept: '.pdf,.doc,.docx',\n    maxFiles: 2\n  }\n}",
				...LimitedCount.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    disabled: true,\n    description: 'Uploads are temporarily disabled.'\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	WithError.parameters = {
		...WithError.parameters,
		docs: {
			...WithError.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    error: 'Please upload at least one document before continuing.'\n  }\n}",
				...WithError.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"SingleFile",
		"LimitedCount",
		"Disabled",
		"WithError"
	];
}));
//#endregion
init_FileUploader_examples_stories();
export { Default, Disabled, LimitedCount, SingleFile, WithError, __namedExportsOrder, meta as default, init_FileUploader_examples_stories as n, FileUploader_examples_stories_exports as t };

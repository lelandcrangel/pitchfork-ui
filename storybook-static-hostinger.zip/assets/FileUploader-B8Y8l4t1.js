import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Default, Disabled, LimitedCount, SingleFile, WithError, n as init_FileUploader_examples_stories, t as FileUploader_examples_stories_exports } from "./FileUploader.examples.stories-DGjU9qKP.js";
import { n as init_FileUploader_stories, t as FileUploader_stories_exports } from "./FileUploader.stories-ybRK4iph.js";
//#region src/FileUploader.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: FileUploader_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "file-uploader",
			children: "File Uploader"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "FileUploader supports clicking or dragging files into a dropzone with optional limits." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: FileUploader_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "single-file",
			children: "Single file"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: SingleFile,
			meta: FileUploader_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "limited-count",
			children: "Limited count"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: LimitedCount,
			meta: FileUploader_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled",
			children: "Disabled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Disabled,
			meta: FileUploader_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-error",
			children: "With error"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithError,
			meta: FileUploader_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_FileUploader_stories();
	init_FileUploader_examples_stories();
}))();
export { MDXContent as default };

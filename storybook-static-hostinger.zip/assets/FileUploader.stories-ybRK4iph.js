import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { b as FileUploader, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/FileUploader.stories.tsx
var FileUploader_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_FileUploader_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/FileUploader",
		component: FileUploader,
		tags: ["ai-generated", "test"],
		args: {
			label: "Attachments",
			description: "Upload one or more files to include with this request.",
			multiple: true,
			accept: ".png,.jpg,.pdf",
			maxFiles: 3,
			maxFileSize: 2 * 1024 * 1024
		},
		argTypes: {
			multiple: { control: "boolean" },
			maxFiles: { control: {
				type: "number",
				min: 1,
				max: 10,
				step: 1
			} },
			maxFileSize: { control: {
				type: "number",
				min: 1e5,
				max: 1e7,
				step: 1e5
			} },
			onFilesChange: { control: false },
			value: { control: false },
			defaultValue: { control: false }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUploader, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <FileUploader {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_FileUploader_stories();
export { Interactive, __namedExportsOrder, meta as default, init_FileUploader_stories as n, FileUploader_stories_exports as t };

import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Default, Minimal, WithDisabledItems, n as init_SidebarNavigation_examples_stories, t as SidebarNavigation_examples_stories_exports } from "./SidebarNavigation.examples.stories-CEQcsjd6.js";
import { n as init_SidebarNavigation_stories, t as SidebarNavigation_stories_exports } from "./SidebarNavigation.stories-B0ihR0tU.js";
//#region src/SidebarNavigation.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: SidebarNavigation_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "sidebar-navigations",
			children: "Sidebar Navigations"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "SidebarNavigation provides a structured vertical navigation with optional section labels, badges, and header/footer slots." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: SidebarNavigation_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-disabled-items",
			children: "With disabled items"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithDisabledItems,
			meta: SidebarNavigation_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "minimal",
			children: "Minimal"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Minimal,
			meta: SidebarNavigation_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_SidebarNavigation_stories();
	init_SidebarNavigation_examples_stories();
}))();
export { MDXContent as default };

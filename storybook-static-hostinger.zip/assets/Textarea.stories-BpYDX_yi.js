import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { it as Textarea, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Textarea.stories.tsx
var Textarea_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Interactive, __namedExportsOrder;
var init_Textarea_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Components/Textarea",
		component: Textarea,
		tags: ["ai-generated", "test"],
		args: {
			label: "Description",
			placeholder: "Write a short project description...",
			description: "Keep it concise and specific.",
			rows: 4
		}
	};
	Interactive = { args: {
		label: "Interactive textarea",
		placeholder: "Type details here",
		description: "Edit this field with controls."
	} };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Interactive textarea',\n    placeholder: 'Type details here',\n    description: 'Edit this field with controls.'\n  }\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Textarea_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Textarea_stories as n, Textarea_stories_exports as t };

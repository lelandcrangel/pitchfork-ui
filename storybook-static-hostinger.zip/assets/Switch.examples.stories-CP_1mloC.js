import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { et as Switch, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Switch.examples.stories.tsx
var Switch_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Disabled: () => Disabled,
	Off: () => Off,
	On: () => On,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var expect, meta, Off, On, Disabled, __namedExportsOrder;
var init_Switch_examples_stories = __esmMin((() => {
	init_dist();
	({expect} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Switch",
		component: Switch,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { label: "Enable notifications" }
	};
	Off = {};
	On = {
		args: {
			defaultChecked: true,
			label: "Notify me"
		},
		play: async ({ canvas }) => {
			await expect(canvas.getByRole("switch", { name: /notify me/i })).toBeChecked();
		}
	};
	Disabled = { args: {
		disabled: true,
		label: "Disabled switch"
	} };
	Off.parameters = {
		...Off.parameters,
		docs: {
			...Off.parameters?.docs,
			source: {
				originalSource: "{}",
				...Off.parameters?.docs?.source
			}
		}
	};
	On.parameters = {
		...On.parameters,
		docs: {
			...On.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultChecked: true,\n    label: 'Notify me'\n  },\n  play: async ({\n    canvas\n  }) => {\n    await expect(canvas.getByRole('switch', {\n      name: /notify me/i\n    })).toBeChecked();\n  }\n}",
				...On.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    disabled: true,\n    label: 'Disabled switch'\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Off",
		"On",
		"Disabled"
	];
}));
//#endregion
init_Switch_examples_stories();
export { Disabled, Off, On, __namedExportsOrder, meta as default, init_Switch_examples_stories as n, Switch_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { Y as SectionHeader, o as Button, r as Badge, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/SectionHeader.examples.stories.tsx
var SectionHeader_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	EndAligned: () => EndAligned,
	WithActionsAndMeta: () => WithActionsAndMeta,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Default, WithActionsAndMeta, EndAligned, __namedExportsOrder;
var init_SectionHeader_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Section Header",
		component: SectionHeader,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { heading: "Section title" }
	};
	Default = { args: {
		heading: "Billing settings",
		description: "Manage invoices, payment methods, and usage tiers."
	} };
	WithActionsAndMeta = { args: {
		eyebrow: "Workspace",
		heading: "Deployment settings",
		description: "Control releases and environment-specific overrides.",
		metadata: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "success",
			children: "Healthy"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Updated 10m ago" })] }),
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "secondary",
			children: "View logs"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			children: "Deploy"
		})] }),
		divider: true
	} };
	EndAligned = { args: {
		align: "end",
		heading: "Filters",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			variant: "secondary",
			children: "Reset"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "sm",
			children: "Apply"
		})] })
	} };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    heading: 'Billing settings',\n    description: 'Manage invoices, payment methods, and usage tiers.'\n  }\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	WithActionsAndMeta.parameters = {
		...WithActionsAndMeta.parameters,
		docs: {
			...WithActionsAndMeta.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    eyebrow: 'Workspace',\n    heading: 'Deployment settings',\n    description: 'Control releases and environment-specific overrides.',\n    metadata: <>\n        <Badge variant=\"success\">Healthy</Badge>\n        <span>Updated 10m ago</span>\n      </>,\n    actions: <>\n        <Button size=\"sm\" variant=\"secondary\">\n          View logs\n        </Button>\n        <Button size=\"sm\">Deploy</Button>\n      </>,\n    divider: true\n  }\n}",
				...WithActionsAndMeta.parameters?.docs?.source
			}
		}
	};
	EndAligned.parameters = {
		...EndAligned.parameters,
		docs: {
			...EndAligned.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    align: 'end',\n    heading: 'Filters',\n    actions: <>\n        <Button size=\"sm\" variant=\"secondary\">\n          Reset\n        </Button>\n        <Button size=\"sm\">Apply</Button>\n      </>\n  }\n}",
				...EndAligned.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"WithActionsAndMeta",
		"EndAligned"
	];
}));
//#endregion
init_SectionHeader_examples_stories();
export { Default, EndAligned, WithActionsAndMeta, __namedExportsOrder, meta as default, init_SectionHeader_examples_stories as n, SectionHeader_examples_stories_exports as t };

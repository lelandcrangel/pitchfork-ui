import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Confirmation, FormModal, LargeContent, n as init_Modal_examples_stories, t as Modal_examples_stories_exports } from "./Modal.examples.stories-Cx-mjMpP.js";
import { n as init_Modal_stories, t as Modal_stories_exports } from "./Modal.stories-DpUi5HTs.js";
//#region src/Modal.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Modal_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "modals",
			children: "Modals"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Modal provides an overlay dialog for focused tasks, confirmations, and longer in-context workflows." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "confirmation",
			children: "Confirmation"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Confirmation,
			meta: Modal_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "form-modal",
			children: "Form modal"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: FormModal,
			meta: Modal_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "large-content",
			children: "Large content"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: LargeContent,
			meta: Modal_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Modal_stories();
	init_Modal_examples_stories();
}))();
export { MDXContent as default };

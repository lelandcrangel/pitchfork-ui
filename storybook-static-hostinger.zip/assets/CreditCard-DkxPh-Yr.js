import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Mastercard, UnmaskedAmex, Visa, n as init_CreditCard_examples_stories, t as CreditCard_examples_stories_exports } from "./CreditCard.examples.stories-pCz9RTfY.js";
import { n as init_CreditCard_stories, t as CreditCard_stories_exports } from "./CreditCard.stories-OVcxCfwH.js";
//#region src/CreditCard.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: CreditCard_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "credit-card",
			children: "Credit Card"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Credit card component for payment method previews with brand styles and masked card details." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "visa",
			children: "Visa"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Visa,
			meta: CreditCard_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "mastercard",
			children: "Mastercard"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Mastercard,
			meta: CreditCard_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "unmasked-amex",
			children: "Unmasked Amex"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: UnmaskedAmex,
			meta: CreditCard_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_CreditCard_stories();
	init_CreditCard_examples_stories();
}))();
export { MDXContent as default };

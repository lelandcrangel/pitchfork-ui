import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { O as MetricCard, k as MetricGrid, o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Metrics.examples.stories.tsx
var Metrics_examples_stories_exports = /* @__PURE__ */ __exportAll({
	CompactGrid: () => CompactGrid,
	OverviewGrid: () => OverviewGrid,
	WithAction: () => WithAction,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, OverviewGrid, WithAction, CompactGrid, __namedExportsOrder;
var init_Metrics_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Metrics",
		component: MetricCard,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		]
	};
	OverviewGrid = {
		args: {
			heading: "Revenue",
			value: "$128k"
		},
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(MetricGrid, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
				heading: "Monthly recurring revenue",
				value: "$128k",
				trend: "positive",
				trendLabel: "12.4%",
				description: "Compared with the previous month.",
				iconName: "chart-bar"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
				heading: "Net retention",
				value: "94.8%",
				trend: "neutral",
				trendLabel: "0.3%",
				description: "Stable over the last 30 days.",
				iconName: "circle-check"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
				heading: "Churned accounts",
				value: "18",
				trend: "negative",
				trendLabel: "4.1%",
				description: "Higher than the previous billing cycle.",
				iconName: "circle-xmark"
			})
		] })
	};
	WithAction = {
		args: {
			heading: "Active users",
			value: "24.2k"
		},
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
			heading: "Active users",
			value: "24.2k",
			trend: "positive",
			trendLabel: "8.1%",
			description: "Weekly active users across all workspaces.",
			iconName: "user",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "secondary",
				children: "View report"
			}),
			style: { maxWidth: 320 }
		})
	};
	CompactGrid = {
		args: {
			heading: "Metric",
			value: "0"
		},
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(MetricGrid, {
			style: { gridTemplateColumns: "repeat(2, minmax(0, 1fr))" },
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
				heading: "Conversion rate",
				value: "6.8%",
				trend: "positive",
				trendLabel: "1.2%"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricCard, {
				heading: "Avg. response time",
				value: "184ms",
				trend: "negative",
				trendLabel: "11ms"
			})]
		})
	};
	OverviewGrid.parameters = {
		...OverviewGrid.parameters,
		docs: {
			...OverviewGrid.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    heading: 'Revenue',\n    value: '$128k'\n  },\n  render: () => <MetricGrid>\n      <MetricCard heading=\"Monthly recurring revenue\" value=\"$128k\" trend=\"positive\" trendLabel=\"12.4%\" description=\"Compared with the previous month.\" iconName=\"chart-bar\" />\n      <MetricCard heading=\"Net retention\" value=\"94.8%\" trend=\"neutral\" trendLabel=\"0.3%\" description=\"Stable over the last 30 days.\" iconName=\"circle-check\" />\n      <MetricCard heading=\"Churned accounts\" value=\"18\" trend=\"negative\" trendLabel=\"4.1%\" description=\"Higher than the previous billing cycle.\" iconName=\"circle-xmark\" />\n    </MetricGrid>\n}",
				...OverviewGrid.parameters?.docs?.source
			}
		}
	};
	WithAction.parameters = {
		...WithAction.parameters,
		docs: {
			...WithAction.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    heading: 'Active users',\n    value: '24.2k'\n  },\n  render: () => <MetricCard heading=\"Active users\" value=\"24.2k\" trend=\"positive\" trendLabel=\"8.1%\" description=\"Weekly active users across all workspaces.\" iconName=\"user\" action={<Button size=\"sm\" variant=\"secondary\">\n          View report\n        </Button>} style={{\n    maxWidth: 320\n  }} />\n}",
				...WithAction.parameters?.docs?.source
			}
		}
	};
	CompactGrid.parameters = {
		...CompactGrid.parameters,
		docs: {
			...CompactGrid.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    heading: 'Metric',\n    value: '0'\n  },\n  render: () => <MetricGrid style={{\n    gridTemplateColumns: 'repeat(2, minmax(0, 1fr))'\n  }}>\n      <MetricCard heading=\"Conversion rate\" value=\"6.8%\" trend=\"positive\" trendLabel=\"1.2%\" />\n      <MetricCard heading=\"Avg. response time\" value=\"184ms\" trend=\"negative\" trendLabel=\"11ms\" />\n    </MetricGrid>\n}",
				...CompactGrid.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"OverviewGrid",
		"WithAction",
		"CompactGrid"
	];
}));
//#endregion
init_Metrics_examples_stories();
export { CompactGrid, OverviewGrid, WithAction, __namedExportsOrder, meta as default, init_Metrics_examples_stories as n, Metrics_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { et as Switch, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Switch.stories.tsx
var Switch_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Interactive, __namedExportsOrder;
var init_Switch_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Components/Switch",
		component: Switch,
		tags: ["ai-generated", "test"],
		args: { label: "Enable notifications" }
	};
	Interactive = { args: { label: "Interactive switch" } };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Interactive switch'\n  }\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Switch_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Switch_stories as n, Switch_stories_exports as t };

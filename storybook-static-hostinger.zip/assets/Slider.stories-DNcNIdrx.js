import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { $ as Slider, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Slider.stories.tsx
var Slider_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_Slider_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Slider",
		component: Slider,
		tags: ["ai-generated", "test"],
		args: {
			label: "Satisfaction score",
			description: "Choose a score between 0 and 100.",
			min: 0,
			max: 100,
			step: 1,
			defaultValue: 64,
			showValue: true
		},
		argTypes: {
			min: { control: {
				type: "number",
				step: 1
			} },
			max: { control: {
				type: "number",
				step: 1
			} },
			step: { control: {
				type: "number",
				step: 1,
				min: 1
			} },
			showValue: { control: "boolean" }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <Slider {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Slider_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Slider_stories as n, Slider_stories_exports as t };

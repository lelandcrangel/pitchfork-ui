import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { ct as VideoPlayer, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/VideoPlayer.examples.stories.tsx
var VideoPlayer_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	MultipleSources: () => MultipleSources,
	MutedLoop: () => MutedLoop,
	WithError: () => WithError,
	WithPoster: () => WithPoster,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var DEMO_VIDEO, meta, Default, WithPoster, MutedLoop, MultipleSources, WithError, __namedExportsOrder;
var init_VideoPlayer_examples_stories = __esmMin((() => {
	init_dist();
	DEMO_VIDEO = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
	meta = {
		title: "Examples/Video Player",
		component: VideoPlayer,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			label: "Intro video",
			description: "Watch the short introduction clip.",
			src: DEMO_VIDEO,
			controls: true,
			aspectRatio: "16/9"
		}
	};
	Default = {};
	WithPoster = { args: {
		label: "Product walkthrough",
		poster: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80"
	} };
	MutedLoop = { args: {
		label: "Background loop",
		description: "Muted looping preview for ambient demos.",
		muted: true,
		loop: true,
		autoPlay: true,
		playsInline: true
	} };
	MultipleSources = { args: {
		label: "Multi-source video",
		src: void 0,
		sources: [{
			src: DEMO_VIDEO,
			type: "video/mp4"
		}, {
			src: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm",
			type: "video/webm"
		}]
	} };
	WithError = { args: {
		src: "",
		error: "Please provide a valid video source before publishing."
	} };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{}",
				...Default.parameters?.docs?.source
			}
		}
	};
	WithPoster.parameters = {
		...WithPoster.parameters,
		docs: {
			...WithPoster.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Product walkthrough',\n    poster: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80'\n  }\n}",
				...WithPoster.parameters?.docs?.source
			}
		}
	};
	MutedLoop.parameters = {
		...MutedLoop.parameters,
		docs: {
			...MutedLoop.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Background loop',\n    description: 'Muted looping preview for ambient demos.',\n    muted: true,\n    loop: true,\n    autoPlay: true,\n    playsInline: true\n  }\n}",
				...MutedLoop.parameters?.docs?.source
			}
		}
	};
	MultipleSources.parameters = {
		...MultipleSources.parameters,
		docs: {
			...MultipleSources.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Multi-source video',\n    src: undefined,\n    sources: [{\n      src: DEMO_VIDEO,\n      type: 'video/mp4'\n    }, {\n      src: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm',\n      type: 'video/webm'\n    }]\n  }\n}",
				...MultipleSources.parameters?.docs?.source
			}
		}
	};
	WithError.parameters = {
		...WithError.parameters,
		docs: {
			...WithError.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    src: '',\n    error: 'Please provide a valid video source before publishing.'\n  }\n}",
				...WithError.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"WithPoster",
		"MutedLoop",
		"MultipleSources",
		"WithError"
	];
}));
//#endregion
init_VideoPlayer_examples_stories();
export { Default, MultipleSources, MutedLoop, WithError, WithPoster, __namedExportsOrder, meta as default, init_VideoPlayer_examples_stories as n, VideoPlayer_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { d as CardFooter, f as CardHeader, l as Card, o as Button, u as CardContent, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Card.stories.tsx
var Card_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_Card_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Card",
		component: Card,
		tags: ["ai-generated", "test"],
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			style: { maxWidth: 480 },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Project summary" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: "This card composes header, content, and footer slots." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardFooter, {
					style: {
						display: "flex",
						gap: 8
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Save" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						children: "Cancel"
					})]
				})
			]
		})
	};
	Interactive = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		style: { maxWidth: 480 },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Interactive card" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: "Use this story with the docs controls panel." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardFooter, {
				style: {
					display: "flex",
					gap: 8
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Save" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					children: "Cancel"
				})]
			})
		]
	}) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <Card style={{\n    maxWidth: 480\n  }}>\n      <CardHeader>\n        <strong>Interactive card</strong>\n      </CardHeader>\n      <CardContent>Use this story with the docs controls panel.</CardContent>\n      <CardFooter style={{\n      display: 'flex',\n      gap: 8\n    }}>\n        <Button>Save</Button>\n        <Button variant=\"secondary\">Cancel</Button>\n      </CardFooter>\n    </Card>\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Card_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Card_stories as n, Card_stories_exports as t };

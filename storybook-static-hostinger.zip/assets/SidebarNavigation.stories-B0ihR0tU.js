import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { Z as SidebarNavigation, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/SidebarNavigation.stories.tsx
var SidebarNavigation_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_SidebarNavigation_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Sidebar Navigations",
		component: SidebarNavigation,
		tags: ["ai-generated", "test"],
		args: {
			header: "Workspace",
			sections: [{
				title: "Main",
				items: [
					{
						label: "Overview",
						active: true
					},
					{ label: "Projects" },
					{
						label: "Billing",
						badge: "2"
					}
				]
			}, {
				title: "Settings",
				items: [
					{ label: "Users" },
					{ label: "Roles" },
					{ label: "API keys" }
				]
			}],
			footer: "Signed in as team-admin"
		},
		argTypes: { sections: { control: "object" } }
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarNavigation, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <SidebarNavigation {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_SidebarNavigation_stories();
export { Interactive, __namedExportsOrder, meta as default, init_SidebarNavigation_stories as n, SidebarNavigation_stories_exports as t };

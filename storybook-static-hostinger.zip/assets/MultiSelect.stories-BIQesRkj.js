import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { N as MultiSelect, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/MultiSelect.stories.tsx
var MultiSelect_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Interactive, __namedExportsOrder;
var init_MultiSelect_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Components/Multi Select",
		component: MultiSelect,
		tags: ["ai-generated", "test"],
		args: {
			label: "Tech stack",
			description: "Select all tools your team uses daily.",
			placeholder: "Choose one or more",
			options: [
				{
					value: "react",
					label: "React"
				},
				{
					value: "typescript",
					label: "TypeScript"
				},
				{
					value: "storybook",
					label: "Storybook"
				},
				{
					value: "figma",
					label: "Figma",
					disabled: true
				}
			]
		}
	};
	Interactive = { args: {
		label: "Interactive multi select",
		description: "Toggle multiple options from the menu."
	} };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Interactive multi select',\n    description: 'Toggle multiple options from the menu.'\n  }\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_MultiSelect_stories();
export { Interactive, __namedExportsOrder, meta as default, init_MultiSelect_stories as n, MultiSelect_stories_exports as t };

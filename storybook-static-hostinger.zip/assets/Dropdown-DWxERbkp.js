import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Basic, EndAligned, WithDisabledItem, n as init_Dropdown_examples_stories, t as Dropdown_examples_stories_exports } from "./Dropdown.examples.stories-BXa57ZZ2.js";
import { n as init_Dropdown_stories, t as Dropdown_stories_exports } from "./Dropdown.stories-l62X1KzA.js";
//#region src/Dropdown.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Dropdown_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "dropdown",
			children: "Dropdown"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Dropdown menus let users choose an action from a compact menu anchored to a trigger button." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "basic",
			children: "Basic"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Basic,
			meta: Dropdown_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "end-aligned",
			children: "End aligned"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: EndAligned,
			meta: Dropdown_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-disabled-item",
			children: "With disabled item"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithDisabledItem,
			meta: Dropdown_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Dropdown_stories();
	init_Dropdown_examples_stories();
}))();
export { MDXContent as default };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Button.examples.stories.tsx
var Button_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Disabled: () => Disabled,
	Ghost: () => Ghost,
	Primary: () => Primary,
	Secondary: () => Secondary,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var expect, meta, Primary, Secondary, Ghost, Disabled, __namedExportsOrder;
var init_Button_examples_stories = __esmMin((() => {
	init_dist();
	({expect} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Button",
		component: Button,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			children: "Button",
			variant: "primary",
			size: "md"
		},
		argTypes: {
			variant: {
				control: "select",
				options: [
					"primary",
					"secondary",
					"ghost"
				]
			},
			size: {
				control: "select",
				options: [
					"sm",
					"md",
					"lg"
				]
			}
		}
	};
	Primary = {
		args: { children: "Order now" },
		play: async ({ canvas }) => {
			await expect(canvas.getByRole("button", { name: /order now/i })).toHaveAttribute("type", "button");
		}
	};
	Secondary = { args: { variant: "secondary" } };
	Ghost = { args: { variant: "ghost" } };
	Disabled = { args: { disabled: true } };
	Primary.parameters = {
		...Primary.parameters,
		docs: {
			...Primary.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    children: 'Order now'\n  },\n  play: async ({\n    canvas\n  }) => {\n    const button = canvas.getByRole('button', {\n      name: /order now/i\n    });\n    await expect(button).toHaveAttribute('type', 'button');\n  }\n}",
				...Primary.parameters?.docs?.source
			}
		}
	};
	Secondary.parameters = {
		...Secondary.parameters,
		docs: {
			...Secondary.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    variant: 'secondary'\n  }\n}",
				...Secondary.parameters?.docs?.source
			}
		}
	};
	Ghost.parameters = {
		...Ghost.parameters,
		docs: {
			...Ghost.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    variant: 'ghost'\n  }\n}",
				...Ghost.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    disabled: true\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Primary",
		"Secondary",
		"Ghost",
		"Disabled"
	];
}));
//#endregion
init_Button_examples_stories();
export { Disabled, Ghost, Primary, Secondary, __namedExportsOrder, meta as default, init_Button_examples_stories as n, Button_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { H as RadarChart, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/RadarChart.examples.stories.tsx
var RadarChart_examples_stories_exports = /* @__PURE__ */ __exportAll({
	MinimalNoLegend: () => MinimalNoLegend,
	ProductHealth: () => ProductHealth,
	TeamComparisonStyle: () => TeamComparisonStyle,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, ProductHealth, TeamComparisonStyle, MinimalNoLegend, __namedExportsOrder;
var init_RadarChart_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Radar Chart",
		component: RadarChart,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { data: [
			{
				label: "A",
				value: 1
			},
			{
				label: "B",
				value: 1
			},
			{
				label: "C",
				value: 1
			}
		] }
	};
	ProductHealth = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadarChart, {
		max: 100,
		data: [
			{
				label: "Adoption",
				value: 84
			},
			{
				label: "Retention",
				value: 72
			},
			{
				label: "Reliability",
				value: 88
			},
			{
				label: "Support",
				value: 66
			},
			{
				label: "Velocity",
				value: 79
			}
		]
	}) };
	TeamComparisonStyle = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadarChart, {
		max: 10,
		levels: 5,
		strokeColor: "#0ea5e9",
		fillColor: "rgb(14 165 233 / 0.2)",
		data: [
			{
				label: "Frontend",
				value: 8
			},
			{
				label: "Backend",
				value: 7
			},
			{
				label: "DevOps",
				value: 6
			},
			{
				label: "QA",
				value: 9
			},
			{
				label: "UX",
				value: 8
			},
			{
				label: "Docs",
				value: 5
			}
		]
	}) };
	MinimalNoLegend = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadarChart, {
		size: 220,
		showLegend: false,
		showAxes: false,
		data: [
			{
				label: "A",
				value: 56
			},
			{
				label: "B",
				value: 71
			},
			{
				label: "C",
				value: 63
			},
			{
				label: "D",
				value: 48
			},
			{
				label: "E",
				value: 74
			}
		]
	}) };
	ProductHealth.parameters = {
		...ProductHealth.parameters,
		docs: {
			...ProductHealth.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <RadarChart max={100} data={[{\n    label: 'Adoption',\n    value: 84\n  }, {\n    label: 'Retention',\n    value: 72\n  }, {\n    label: 'Reliability',\n    value: 88\n  }, {\n    label: 'Support',\n    value: 66\n  }, {\n    label: 'Velocity',\n    value: 79\n  }]} />\n}",
				...ProductHealth.parameters?.docs?.source
			}
		}
	};
	TeamComparisonStyle.parameters = {
		...TeamComparisonStyle.parameters,
		docs: {
			...TeamComparisonStyle.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <RadarChart max={10} levels={5} strokeColor=\"#0ea5e9\" fillColor=\"rgb(14 165 233 / 0.2)\" data={[{\n    label: 'Frontend',\n    value: 8\n  }, {\n    label: 'Backend',\n    value: 7\n  }, {\n    label: 'DevOps',\n    value: 6\n  }, {\n    label: 'QA',\n    value: 9\n  }, {\n    label: 'UX',\n    value: 8\n  }, {\n    label: 'Docs',\n    value: 5\n  }]} />\n}",
				...TeamComparisonStyle.parameters?.docs?.source
			}
		}
	};
	MinimalNoLegend.parameters = {
		...MinimalNoLegend.parameters,
		docs: {
			...MinimalNoLegend.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <RadarChart size={220} showLegend={false} showAxes={false} data={[{\n    label: 'A',\n    value: 56\n  }, {\n    label: 'B',\n    value: 71\n  }, {\n    label: 'C',\n    value: 63\n  }, {\n    label: 'D',\n    value: 48\n  }, {\n    label: 'E',\n    value: 74\n  }]} />\n}",
				...MinimalNoLegend.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"ProductHealth",
		"TeamComparisonStyle",
		"MinimalNoLegend"
	];
}));
//#endregion
init_RadarChart_examples_stories();
export { MinimalNoLegend, ProductHealth, TeamComparisonStyle, __namedExportsOrder, meta as default, init_RadarChart_examples_stories as n, RadarChart_examples_stories_exports as t };

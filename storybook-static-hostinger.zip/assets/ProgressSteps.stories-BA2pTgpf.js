import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { V as ProgressSteps, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/ProgressSteps.stories.tsx
var ProgressSteps_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_ProgressSteps_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Progress Steps",
		component: ProgressSteps,
		tags: ["ai-generated", "test"],
		args: {
			orientation: "horizontal",
			steps: [
				{
					title: "Account",
					description: "Create your workspace",
					status: "complete"
				},
				{
					title: "Profile",
					description: "Set your personal details",
					status: "current"
				},
				{
					title: "Invite",
					description: "Add your team members",
					status: "upcoming"
				},
				{
					title: "Finish",
					description: "Review and launch",
					status: "upcoming"
				}
			]
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressSteps, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <ProgressSteps {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_ProgressSteps_stories();
export { Interactive, __namedExportsOrder, meta as default, init_ProgressSteps_stories as n, ProgressSteps_stories_exports as t };

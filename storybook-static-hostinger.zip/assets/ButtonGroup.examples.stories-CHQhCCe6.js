import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { S as Icon, s as ButtonGroup, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/ButtonGroup.examples.stories.tsx
var ButtonGroup_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	Disabled: () => Disabled,
	DisabledItem: () => DisabledItem,
	LeadingIcon: () => LeadingIcon,
	MultipleSelection: () => MultipleSelection,
	WithDot: () => WithDot,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Default, LeadingIcon, WithDot, Disabled, DisabledItem, MultipleSelection, __namedExportsOrder;
var init_ButtonGroup_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Button Group",
		component: ButtonGroup,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			"aria-label": "Time range",
			items: [
				{
					value: "today",
					label: "Today"
				},
				{
					value: "tomorrow",
					label: "Tomorrow"
				},
				{
					value: "week",
					label: "This week"
				}
			],
			defaultValue: "today"
		},
		argTypes: {
			multiple: { control: "boolean" },
			disabled: { control: "boolean" }
		}
	};
	Default = { args: { defaultValue: "today" } };
	LeadingIcon = { args: {
		"aria-label": "Calendar range",
		items: [
			{
				value: "today",
				label: "Today",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "calendar-days",
					"aria-hidden": true
				})
			},
			{
				value: "tomorrow",
				label: "Tomorrow",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "calendar-days",
					"aria-hidden": true
				})
			},
			{
				value: "week",
				label: "This week",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					name: "calendar-days",
					"aria-hidden": true
				})
			}
		],
		defaultValue: "today"
	} };
	WithDot = { args: {
		"aria-label": "Status filters",
		items: [
			{
				value: "draft",
				label: "Draft",
				dot: true
			},
			{
				value: "in-review",
				label: "In review",
				dot: true
			},
			{
				value: "published",
				label: "Published",
				dot: true
			}
		],
		defaultValue: "in-review"
	} };
	Disabled = { args: {
		disabled: true,
		defaultValue: "today"
	} };
	DisabledItem = { args: {
		items: [
			{
				value: "today",
				label: "Today"
			},
			{
				value: "tomorrow",
				label: "Tomorrow",
				disabled: true
			},
			{
				value: "week",
				label: "This week"
			}
		],
		defaultValue: "today"
	} };
	MultipleSelection = { args: {
		"aria-label": "Visible sections",
		multiple: true,
		items: [
			{
				value: "overview",
				label: "Overview"
			},
			{
				value: "details",
				label: "Details"
			},
			{
				value: "activity",
				label: "Activity"
			}
		],
		defaultValue: ["overview", "activity"]
	} };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultValue: 'today'\n  }\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	LeadingIcon.parameters = {
		...LeadingIcon.parameters,
		docs: {
			...LeadingIcon.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    'aria-label': 'Calendar range',\n    items: [{\n      value: 'today',\n      label: 'Today',\n      icon: <Icon name=\"calendar-days\" aria-hidden />\n    }, {\n      value: 'tomorrow',\n      label: 'Tomorrow',\n      icon: <Icon name=\"calendar-days\" aria-hidden />\n    }, {\n      value: 'week',\n      label: 'This week',\n      icon: <Icon name=\"calendar-days\" aria-hidden />\n    }],\n    defaultValue: 'today'\n  }\n}",
				...LeadingIcon.parameters?.docs?.source
			}
		}
	};
	WithDot.parameters = {
		...WithDot.parameters,
		docs: {
			...WithDot.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    'aria-label': 'Status filters',\n    items: [{\n      value: 'draft',\n      label: 'Draft',\n      dot: true\n    }, {\n      value: 'in-review',\n      label: 'In review',\n      dot: true\n    }, {\n      value: 'published',\n      label: 'Published',\n      dot: true\n    }],\n    defaultValue: 'in-review'\n  }\n}",
				...WithDot.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    disabled: true,\n    defaultValue: 'today'\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	DisabledItem.parameters = {
		...DisabledItem.parameters,
		docs: {
			...DisabledItem.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    items: [{\n      value: 'today',\n      label: 'Today'\n    }, {\n      value: 'tomorrow',\n      label: 'Tomorrow',\n      disabled: true\n    }, {\n      value: 'week',\n      label: 'This week'\n    }],\n    defaultValue: 'today'\n  }\n}",
				...DisabledItem.parameters?.docs?.source
			}
		}
	};
	MultipleSelection.parameters = {
		...MultipleSelection.parameters,
		docs: {
			...MultipleSelection.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    'aria-label': 'Visible sections',\n    multiple: true,\n    items: [{\n      value: 'overview',\n      label: 'Overview'\n    }, {\n      value: 'details',\n      label: 'Details'\n    }, {\n      value: 'activity',\n      label: 'Activity'\n    }],\n    defaultValue: ['overview', 'activity']\n  }\n}",
				...MultipleSelection.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"LeadingIcon",
		"WithDot",
		"Disabled",
		"DisabledItem",
		"MultipleSelection"
	];
}));
//#endregion
init_ButtonGroup_examples_stories();
export { Default, Disabled, DisabledItem, LeadingIcon, MultipleSelection, WithDot, __namedExportsOrder, meta as default, init_ButtonGroup_examples_stories as n, ButtonGroup_examples_stories_exports as t };

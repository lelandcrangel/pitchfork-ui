import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Default, DenseStriped, EmptyState, StickyHeader, WithCaption, n as init_Table_examples_stories, t as Table_examples_stories_exports } from "./Table.examples.stories-Bt12AZ-N.js";
import { n as init_Table_stories, t as Table_stories_exports } from "./Table.stories-BEU4ga6-.js";
//#region src/Table.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Table_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "tables",
			children: "Tables"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Table is a structured data surface with support for density, striping, hover states, sticky headers, and empty states." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "A baseline tabular layout with sortable headers for quick scan-and-order workflows." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: Table_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "dense-and-striped",
			children: "Dense and striped"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "A compact view with zebra striping to improve row legibility in information-dense tables." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: DenseStriped,
			meta: Table_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-caption",
			children: "With caption"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Use a caption when the table needs lightweight context or summary text." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithCaption,
			meta: Table_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "sticky-header",
			children: "Sticky header"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Header cells remain visible while scrolling long result sets." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: StickyHeader,
			meta: Table_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "empty-state",
			children: "Empty state"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Use a clear message when the current filters return no rows." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: EmptyState,
			meta: Table_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Table_stories();
	init_Table_examples_stories();
}))();
export { MDXContent as default };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { $ as Slider, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Slider.examples.stories.tsx
var Slider_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	Disabled: () => Disabled,
	PercentageRange: () => PercentageRange,
	Stepped: () => Stepped,
	WithError: () => WithError,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var expect, meta, Default, PercentageRange, Stepped, WithError, Disabled, __namedExportsOrder;
var init_Slider_examples_stories = __esmMin((() => {
	init_dist();
	({expect} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Slider",
		component: Slider,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			label: "Satisfaction score",
			description: "Choose a score between 0 and 100.",
			min: 0,
			max: 100,
			step: 1,
			defaultValue: 64,
			showValue: true
		}
	};
	Default = { play: async ({ canvas }) => {
		await expect(canvas.getByRole("slider", { name: /satisfaction score/i })).toHaveValue("64");
	} };
	PercentageRange = { args: {
		label: "Completion",
		min: 0,
		max: 100,
		defaultValue: 28
	} };
	Stepped = { args: {
		label: "Seats",
		min: 1,
		max: 20,
		step: 1,
		defaultValue: 8
	} };
	WithError = { args: { error: "Choose at least 40 before continuing." } };
	Disabled = { args: { disabled: true } };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  play: async ({\n    canvas\n  }) => {\n    const input = canvas.getByRole('slider', {\n      name: /satisfaction score/i\n    });\n    await expect(input).toHaveValue('64');\n  }\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	PercentageRange.parameters = {
		...PercentageRange.parameters,
		docs: {
			...PercentageRange.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Completion',\n    min: 0,\n    max: 100,\n    defaultValue: 28\n  }\n}",
				...PercentageRange.parameters?.docs?.source
			}
		}
	};
	Stepped.parameters = {
		...Stepped.parameters,
		docs: {
			...Stepped.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Seats',\n    min: 1,\n    max: 20,\n    step: 1,\n    defaultValue: 8\n  }\n}",
				...Stepped.parameters?.docs?.source
			}
		}
	};
	WithError.parameters = {
		...WithError.parameters,
		docs: {
			...WithError.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    error: 'Choose at least 40 before continuing.'\n  }\n}",
				...WithError.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    disabled: true\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"PercentageRange",
		"Stepped",
		"WithError",
		"Disabled"
	];
}));
//#endregion
init_Slider_examples_stories();
export { Default, Disabled, PercentageRange, Stepped, WithError, __namedExportsOrder, meta as default, init_Slider_examples_stories as n, Slider_examples_stories_exports as t };

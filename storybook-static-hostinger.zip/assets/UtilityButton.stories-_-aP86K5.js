import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { S as Icon, st as UtilityButton, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/UtilityButton.stories.tsx
var UtilityButton_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_UtilityButton_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Utility Button",
		component: UtilityButton,
		tags: ["ai-generated", "test"],
		args: {
			children: "Quick action",
			variant: "neutral",
			size: "md",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				name: "circle-dot",
				"aria-hidden": true
			})
		},
		argTypes: {
			variant: {
				control: "select",
				options: [
					"neutral",
					"brand",
					"danger"
				]
			},
			size: {
				control: "inline-radio",
				options: ["sm", "md"]
			}
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtilityButton, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <UtilityButton {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_UtilityButton_stories();
export { Interactive, __namedExportsOrder, meta as default, init_UtilityButton_stories as n, UtilityButton_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { V as ProgressSteps, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/ProgressSteps.examples.stories.tsx
var ProgressSteps_examples_stories_exports = /* @__PURE__ */ __exportAll({
	AutoStatusFromCurrent: () => AutoStatusFromCurrent,
	CheckoutFlow: () => CheckoutFlow,
	VerticalOnboarding: () => VerticalOnboarding,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, CheckoutFlow, VerticalOnboarding, AutoStatusFromCurrent, __namedExportsOrder;
var init_ProgressSteps_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Progress Steps",
		component: ProgressSteps,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { steps: [{
			title: "Step",
			description: "Description"
		}] }
	};
	CheckoutFlow = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressSteps, { steps: [
		{
			title: "Cart",
			description: "Review items",
			status: "complete"
		},
		{
			title: "Shipping",
			description: "Delivery address",
			status: "complete"
		},
		{
			title: "Payment",
			description: "Choose payment method",
			status: "current"
		},
		{
			title: "Confirm",
			description: "Place your order",
			status: "upcoming"
		}
	] }) };
	VerticalOnboarding = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressSteps, {
		orientation: "vertical",
		steps: [
			{
				title: "Workspace details",
				description: "Name and region",
				status: "complete"
			},
			{
				title: "Security settings",
				description: "Enable MFA",
				status: "current"
			},
			{
				title: "Team permissions",
				description: "Set access levels",
				status: "upcoming"
			},
			{
				title: "Integrations",
				description: "Connect third-party apps",
				status: "upcoming"
			}
		]
	}) };
	AutoStatusFromCurrent = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressSteps, { steps: [
		{ title: "Draft" },
		{
			title: "Review",
			status: "current"
		},
		{ title: "Approve" },
		{ title: "Publish" }
	] }) };
	CheckoutFlow.parameters = {
		...CheckoutFlow.parameters,
		docs: {
			...CheckoutFlow.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <ProgressSteps steps={[{\n    title: 'Cart',\n    description: 'Review items',\n    status: 'complete'\n  }, {\n    title: 'Shipping',\n    description: 'Delivery address',\n    status: 'complete'\n  }, {\n    title: 'Payment',\n    description: 'Choose payment method',\n    status: 'current'\n  }, {\n    title: 'Confirm',\n    description: 'Place your order',\n    status: 'upcoming'\n  }]} />\n}",
				...CheckoutFlow.parameters?.docs?.source
			}
		}
	};
	VerticalOnboarding.parameters = {
		...VerticalOnboarding.parameters,
		docs: {
			...VerticalOnboarding.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <ProgressSteps orientation=\"vertical\" steps={[{\n    title: 'Workspace details',\n    description: 'Name and region',\n    status: 'complete'\n  }, {\n    title: 'Security settings',\n    description: 'Enable MFA',\n    status: 'current'\n  }, {\n    title: 'Team permissions',\n    description: 'Set access levels',\n    status: 'upcoming'\n  }, {\n    title: 'Integrations',\n    description: 'Connect third-party apps',\n    status: 'upcoming'\n  }]} />\n}",
				...VerticalOnboarding.parameters?.docs?.source
			}
		}
	};
	AutoStatusFromCurrent.parameters = {
		...AutoStatusFromCurrent.parameters,
		docs: {
			...AutoStatusFromCurrent.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <ProgressSteps steps={[{\n    title: 'Draft'\n  }, {\n    title: 'Review',\n    status: 'current'\n  }, {\n    title: 'Approve'\n  }, {\n    title: 'Publish'\n  }]} />\n}",
				...AutoStatusFromCurrent.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"CheckoutFlow",
		"VerticalOnboarding",
		"AutoStatusFromCurrent"
	];
}));
//#endregion
init_ProgressSteps_examples_stories();
export { AutoStatusFromCurrent, CheckoutFlow, VerticalOnboarding, __namedExportsOrder, meta as default, init_ProgressSteps_examples_stories as n, ProgressSteps_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { ut as init_dist, v as DatePicker } from "./dist-D1zMThSa.js";
//#region src/DatePicker.examples.stories.tsx
var DatePicker_examples_stories_exports = /* @__PURE__ */ __exportAll({
	BoundedYearRange: () => BoundedYearRange,
	Default: () => Default,
	DisabledWeekends: () => DisabledWeekends,
	NoOutsideDays: () => NoOutsideDays,
	WithError: () => WithError,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var disableWeekends, meta, Default, NoOutsideDays, DisabledWeekends, BoundedYearRange, WithError, __namedExportsOrder;
var init_DatePicker_examples_stories = __esmMin((() => {
	init_dist();
	disableWeekends = (date) => {
		const day = date.getDay();
		return day === 0 || day === 6;
	};
	meta = {
		title: "Examples/DatePicker",
		component: DatePicker,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			label: "Event date",
			defaultValue: new Date(2026, 4, 22)
		}
	};
	Default = {};
	NoOutsideDays = { args: { showOutsideDays: false } };
	DisabledWeekends = { args: {
		description: "Weekends are disabled.",
		disabledDates: disableWeekends
	} };
	BoundedYearRange = { args: {
		startYear: 2020,
		endYear: 2030,
		allowClear: true
	} };
	WithError = { args: { error: "Please choose a valid date." } };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{}",
				...Default.parameters?.docs?.source
			}
		}
	};
	NoOutsideDays.parameters = {
		...NoOutsideDays.parameters,
		docs: {
			...NoOutsideDays.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    showOutsideDays: false\n  }\n}",
				...NoOutsideDays.parameters?.docs?.source
			}
		}
	};
	DisabledWeekends.parameters = {
		...DisabledWeekends.parameters,
		docs: {
			...DisabledWeekends.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    description: 'Weekends are disabled.',\n    disabledDates: disableWeekends\n  }\n}",
				...DisabledWeekends.parameters?.docs?.source
			}
		}
	};
	BoundedYearRange.parameters = {
		...BoundedYearRange.parameters,
		docs: {
			...BoundedYearRange.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    startYear: 2020,\n    endYear: 2030,\n    allowClear: true\n  }\n}",
				...BoundedYearRange.parameters?.docs?.source
			}
		}
	};
	WithError.parameters = {
		...WithError.parameters,
		docs: {
			...WithError.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    error: 'Please choose a valid date.'\n  }\n}",
				...WithError.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"NoOutsideDays",
		"DisabledWeekends",
		"BoundedYearRange",
		"WithError"
	];
}));
//#endregion
init_DatePicker_examples_stories();
export { BoundedYearRange, Default, DisabledWeekends, NoOutsideDays, WithError, __namedExportsOrder, meta as default, init_DatePicker_examples_stories as n, DatePicker_examples_stories_exports as t };

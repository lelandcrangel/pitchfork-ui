import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Basic, Disabled, Horizontal, WithDescriptions, n as init_RadioGroup_examples_stories, t as RadioGroup_examples_stories_exports } from "./RadioGroup.examples.stories-CoOcJq4p.js";
import { n as init_RadioGroup_stories, t as RadioGroup_stories_exports } from "./RadioGroup.stories-CYlsrvNf.js";
//#region src/RadioGroup.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: RadioGroup_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "radio-groups",
			children: "Radio Groups"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Radio groups are used for choosing exactly one option from a set, with optional helper text for each option." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "basic",
			children: "Basic"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Basic,
			meta: RadioGroup_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "horizontal-layout",
			children: "Horizontal layout"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Horizontal,
			meta: RadioGroup_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-descriptions",
			children: "With descriptions"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithDescriptions,
			meta: RadioGroup_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled",
			children: "Disabled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Disabled,
			meta: RadioGroup_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_RadioGroup_stories();
	init_RadioGroup_examples_stories();
}))();
export { MDXContent as default };

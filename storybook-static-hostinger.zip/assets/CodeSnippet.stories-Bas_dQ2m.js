import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { h as CodeSnippet, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/CodeSnippet.stories.tsx
var CodeSnippet_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_CodeSnippet_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/CodeSnippet",
		component: CodeSnippet,
		tags: ["ai-generated", "test"],
		args: {
			title: "SaveAction.tsx",
			language: "tsx",
			code: `import { Button } from '@pitchfork-ui/react';

export function SaveAction() {
  return (
    <Button variant="primary" onClick={() => console.log('saved')}>
      Save changes
    </Button>
  );
}`,
			showLineNumbers: false,
			maxHeight: 240,
			copyLabel: "Copy",
			copiedLabel: "Copied"
		},
		argTypes: {
			showLineNumbers: { control: "boolean" },
			maxHeight: { control: {
				type: "number",
				min: 120,
				max: 600,
				step: 20
			} },
			code: { control: "text" },
			onCodeCopy: { control: false }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeSnippet, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <CodeSnippet {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_CodeSnippet_stories();
export { Interactive, __namedExportsOrder, meta as default, init_CodeSnippet_stories as n, CodeSnippet_stories_exports as t };

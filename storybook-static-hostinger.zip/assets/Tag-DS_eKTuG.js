import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Brand, Dismissible, Neutral, Success, Warning, n as init_Tag_examples_stories, t as Tag_examples_stories_exports } from "./Tag.examples.stories-DDiDq0aQ.js";
import { n as init_Tag_stories, t as Tag_stories_exports } from "./Tag.stories-Vwffszlg.js";
//#region src/Tag.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Tag_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "tag",
			children: "Tag"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Tags communicate compact categorical metadata and can optionally be removable." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "neutral",
			children: "Neutral"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Neutral,
			meta: Tag_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "brand",
			children: "Brand"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Brand,
			meta: Tag_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "success",
			children: "Success"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Success,
			meta: Tag_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "warning",
			children: "Warning"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Warning,
			meta: Tag_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "dismissible",
			children: "Dismissible"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Dismissible,
			meta: Tag_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Tag_stories();
	init_Tag_examples_stories();
}))();
export { MDXContent as default };

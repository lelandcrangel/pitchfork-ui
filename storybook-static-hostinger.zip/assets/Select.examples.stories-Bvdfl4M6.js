import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { X as Select, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Select.examples.stories.tsx
var Select_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	Disabled: () => Disabled,
	WithDefaultValue: () => WithDefaultValue,
	WithError: () => WithError,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var expect, meta, Default, WithDefaultValue, WithError, Disabled, __namedExportsOrder;
var init_Select_examples_stories = __esmMin((() => {
	init_dist();
	({expect} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Select",
		component: Select,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			label: "Pricing tier",
			description: "Choose the plan that fits your team.",
			placeholder: "Choose a plan",
			options: [
				{
					value: "starter",
					label: "Starter plan"
				},
				{
					value: "pro",
					label: "Pro plan"
				},
				{
					value: "enterprise",
					label: "Enterprise plan",
					disabled: true
				}
			]
		}
	};
	Default = { play: async ({ canvas, userEvent }) => {
		const trigger = canvas.getByRole("button", { name: /pricing tier/i });
		await userEvent.click(trigger);
		await userEvent.click(canvas.getByRole("option", { name: /pro plan/i }));
		await expect(trigger).toHaveTextContent(/pro plan/i);
	} };
	WithDefaultValue = { args: { defaultValue: "starter" } };
	WithError = {
		args: { error: "Please select a plan before continuing." },
		play: async ({ canvas }) => {
			await expect(canvas.getByRole("button", { name: /pricing tier/i })).toHaveAttribute("aria-describedby", expect.stringContaining("error"));
		}
	};
	Disabled = { args: { disabled: true } };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  play: async ({\n    canvas,\n    userEvent\n  }) => {\n    const trigger = canvas.getByRole('button', {\n      name: /pricing tier/i\n    });\n    await userEvent.click(trigger);\n    await userEvent.click(canvas.getByRole('option', {\n      name: /pro plan/i\n    }));\n    await expect(trigger).toHaveTextContent(/pro plan/i);\n  }\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	WithDefaultValue.parameters = {
		...WithDefaultValue.parameters,
		docs: {
			...WithDefaultValue.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultValue: 'starter'\n  }\n}",
				...WithDefaultValue.parameters?.docs?.source
			}
		}
	};
	WithError.parameters = {
		...WithError.parameters,
		docs: {
			...WithError.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    error: 'Please select a plan before continuing.'\n  },\n  play: async ({\n    canvas\n  }) => {\n    const trigger = canvas.getByRole('button', {\n      name: /pricing tier/i\n    });\n    await expect(trigger).toHaveAttribute('aria-describedby', expect.stringContaining('error'));\n  }\n}",
				...WithError.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    disabled: true\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"WithDefaultValue",
		"WithError",
		"Disabled"
	];
}));
//#endregion
init_Select_examples_stories();
export { Default, Disabled, WithDefaultValue, WithError, __namedExportsOrder, meta as default, init_Select_examples_stories as n, Select_examples_stories_exports as t };

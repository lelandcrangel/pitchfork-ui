import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
//#region src/Introduction.mdx
function _createMdxContent(props) {
	const _components = {
		h2: "h2",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { title: "Foundations/Introduction" }),
		"\n",
		(0, import_jsx_runtime.jsxs)("div", {
			style: {
				background: "radial-gradient(circle at 8% 10%, #dbeafe 0%, #bfdbfe 28%, #eff6ff 58%, #ffffff 100%)",
				border: "1px solid #93c5fd",
				borderRadius: 20,
				padding: "2rem",
				marginBottom: "1.5rem",
				boxShadow: "0 18px 44px rgba(37, 99, 235, 0.16)"
			},
			children: [
				(0, import_jsx_runtime.jsx)("div", {
					style: {
						display: "inline-block",
						fontFamily: "Space Grotesk, Avenir Next, Helvetica Neue, sans-serif",
						fontWeight: 700,
						letterSpacing: "0.06em",
						fontSize: "0.75rem",
						textTransform: "uppercase",
						color: "#1e40af",
						background: "#bfdbfe",
						border: "1px solid #60a5fa",
						borderRadius: 999,
						padding: "0.25rem 0.75rem",
						marginBottom: "1rem"
					},
					children: (0, import_jsx_runtime.jsx)(_components.p, { children: "Product UI System" })
				}),
				(0, import_jsx_runtime.jsx)("h1", {
					style: {
						margin: 0,
						fontFamily: "Sora, Space Grotesk, Avenir Next, Helvetica Neue, sans-serif",
						fontSize: "clamp(2rem, 4vw, 3rem)",
						lineHeight: 1.1,
						letterSpacing: "-0.02em",
						color: "#1e3a8a"
					},
					children: (0, import_jsx_runtime.jsx)(_components.p, { children: "PitchforkUI" })
				}),
				(0, import_jsx_runtime.jsx)("p", {
					style: {
						marginTop: "1rem",
						marginBottom: "1.25rem",
						maxWidth: 760,
						fontFamily: "Avenir Next, Nunito Sans, Helvetica Neue, sans-serif",
						fontSize: "1.1rem",
						lineHeight: 1.7,
						color: "#1d4ed8"
					},
					children: (0, import_jsx_runtime.jsx)(_components.p, { children: "A premium component system designed to help product teams launch faster,\nmaintain consistency at scale, and deliver interfaces that feel intentional\nfrom first click to final conversion." })
				}),
				(0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "grid",
						gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))",
						gap: "0.75rem",
						marginTop: "1rem"
					},
					children: [
						(0, import_jsx_runtime.jsxs)("div", {
							style: {
								background: "#dbeafe",
								border: "1px solid #93c5fd",
								borderRadius: 12,
								padding: "0.75rem 0.9rem"
							},
							children: [(0, import_jsx_runtime.jsx)("strong", {
								style: { color: "#1e40af" },
								children: "Faster Releases"
							}), (0, import_jsx_runtime.jsx)("div", {
								style: {
									color: "#1d4ed8",
									fontSize: "0.92rem"
								},
								children: "Reusable patterns that cut build time."
							})]
						}),
						(0, import_jsx_runtime.jsxs)("div", {
							style: {
								background: "#dbeafe",
								border: "1px solid #93c5fd",
								borderRadius: 12,
								padding: "0.75rem 0.9rem"
							},
							children: [(0, import_jsx_runtime.jsx)("strong", {
								style: { color: "#1e40af" },
								children: "Higher Quality"
							}), (0, import_jsx_runtime.jsx)("div", {
								style: {
									color: "#1d4ed8",
									fontSize: "0.92rem"
								},
								children: "Accessibility and UX consistency by default."
							})]
						}),
						(0, import_jsx_runtime.jsxs)("div", {
							style: {
								background: "#dbeafe",
								border: "1px solid #93c5fd",
								borderRadius: 12,
								padding: "0.75rem 0.9rem"
							},
							children: [(0, import_jsx_runtime.jsx)("strong", {
								style: { color: "#1e40af" },
								children: "Lower Cost"
							}), (0, import_jsx_runtime.jsx)("div", {
								style: {
									color: "#1d4ed8",
									fontSize: "0.92rem"
								},
								children: "Fewer rewrites and less UI drift over time."
							})]
						})
					]
				})
			]
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "why-teams-pick-pitchforkui",
			children: "Why teams pick PitchforkUI"
		}),
		"\n",
		(0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "grid",
				gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))",
				gap: "0.9rem",
				marginBottom: "1.5rem"
			},
			children: [
				(0, import_jsx_runtime.jsxs)("div", {
					style: {
						border: "1px solid #93c5fd",
						borderRadius: 14,
						padding: "1rem",
						background: "#eff6ff"
					},
					children: [(0, import_jsx_runtime.jsx)("h3", {
						style: {
							marginTop: 0,
							marginBottom: "0.4rem",
							fontFamily: "Space Grotesk, Avenir Next, Helvetica Neue, sans-serif"
						},
						children: (0, import_jsx_runtime.jsx)(_components.p, { children: "Composable by design" })
					}), (0, import_jsx_runtime.jsx)("p", {
						style: {
							margin: 0,
							color: "#1e3a8a",
							lineHeight: 1.6
						},
						children: (0, import_jsx_runtime.jsx)(_components.p, { children: "Build new experiences quickly using production-ready components with\npredictable APIs." })
					})]
				}),
				(0, import_jsx_runtime.jsxs)("div", {
					style: {
						border: "1px solid #93c5fd",
						borderRadius: 14,
						padding: "1rem",
						background: "#eff6ff"
					},
					children: [(0, import_jsx_runtime.jsx)("h3", {
						style: {
							marginTop: 0,
							marginBottom: "0.4rem",
							fontFamily: "Space Grotesk, Avenir Next, Helvetica Neue, sans-serif"
						},
						children: (0, import_jsx_runtime.jsx)(_components.p, { children: "Consistency at scale" })
					}), (0, import_jsx_runtime.jsx)("p", {
						style: {
							margin: 0,
							color: "#1e3a8a",
							lineHeight: 1.6
						},
						children: (0, import_jsx_runtime.jsx)(_components.p, { children: "Token-driven styling keeps product surfaces aligned across teams, squads,\nand releases." })
					})]
				}),
				(0, import_jsx_runtime.jsxs)("div", {
					style: {
						border: "1px solid #93c5fd",
						borderRadius: 14,
						padding: "1rem",
						background: "#eff6ff"
					},
					children: [(0, import_jsx_runtime.jsx)("h3", {
						style: {
							marginTop: 0,
							marginBottom: "0.4rem",
							fontFamily: "Space Grotesk, Avenir Next, Helvetica Neue, sans-serif"
						},
						children: (0, import_jsx_runtime.jsx)(_components.p, { children: "Built-in trust signals" })
					}), (0, import_jsx_runtime.jsx)("p", {
						style: {
							margin: 0,
							color: "#1e3a8a",
							lineHeight: 1.6
						},
						children: (0, import_jsx_runtime.jsx)(_components.p, { children: "Accessible interaction patterns and documented behavior reduce quality\nrisk before launch." })
					})]
				})
			]
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "business-impact",
			children: "Business impact"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)("div", {
			style: {
				border: "1px solid #60a5fa",
				borderRadius: 16,
				padding: "1rem 1.1rem",
				background: "linear-gradient(140deg, #dbeafe 0%, #ffffff 80%)",
				marginBottom: "1.4rem"
			},
			children: (0, import_jsx_runtime.jsxs)("ul", {
				style: {
					margin: 0,
					paddingLeft: "1.1rem",
					color: "#1e40af",
					lineHeight: 1.8
				},
				children: [
					(0, import_jsx_runtime.jsx)("li", { children: "Reduce interface rework by standardizing components and behaviors." }),
					(0, import_jsx_runtime.jsx)("li", { children: "Shorten delivery cycles with patterns teams can ship on day one." }),
					(0, import_jsx_runtime.jsx)("li", { children: "Strengthen design-to-dev alignment with a shared visual language." }),
					(0, import_jsx_runtime.jsx)("li", { children: "Scale product quality without scaling UI maintenance overhead." })
				]
			})
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "what-buyers-receive",
			children: "What buyers receive"
		}),
		"\n",
		(0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "grid",
				gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
				gap: "0.8rem"
			},
			children: [
				(0, import_jsx_runtime.jsxs)("div", {
					style: {
						border: "1px solid #93c5fd",
						borderRadius: 12,
						padding: "0.9rem",
						background: "#eff6ff"
					},
					children: [(0, import_jsx_runtime.jsx)("strong", { children: "A cohesive component library" }), (0, import_jsx_runtime.jsx)("p", {
						style: {
							margin: "0.4rem 0 0 0",
							color: "#1e3a8a"
						},
						children: (0, import_jsx_runtime.jsx)(_components.p, { children: "Modern UI building blocks ready for product-grade interfaces." })
					})]
				}),
				(0, import_jsx_runtime.jsxs)("div", {
					style: {
						border: "1px solid #93c5fd",
						borderRadius: 12,
						padding: "0.9rem",
						background: "#eff6ff"
					},
					children: [(0, import_jsx_runtime.jsx)("strong", { children: "Theme-ready foundations" }), (0, import_jsx_runtime.jsx)("p", {
						style: {
							margin: "0.4rem 0 0 0",
							color: "#1e3a8a"
						},
						children: (0, import_jsx_runtime.jsx)(_components.p, { children: "Design tokens and variables that support brand and scale needs." })
					})]
				}),
				(0, import_jsx_runtime.jsxs)("div", {
					style: {
						border: "1px solid #93c5fd",
						borderRadius: 12,
						padding: "0.9rem",
						background: "#eff6ff"
					},
					children: [(0, import_jsx_runtime.jsx)("strong", { children: "Storybook documentation" }), (0, import_jsx_runtime.jsx)("p", {
						style: {
							margin: "0.4rem 0 0 0",
							color: "#1e3a8a"
						},
						children: (0, import_jsx_runtime.jsx)(_components.p, { children: "A clear source of truth for adoption, QA, and stakeholder alignment." })
					})]
				})
			]
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
}))();
export { MDXContent as default };

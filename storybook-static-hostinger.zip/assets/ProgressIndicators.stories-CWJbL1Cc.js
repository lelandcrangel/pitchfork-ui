import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { B as ProgressCircle, ut as init_dist, z as ProgressBar } from "./dist-D1zMThSa.js";
//#region src/ProgressIndicators.stories.tsx
var ProgressIndicators_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	InteractiveCircle: () => InteractiveCircle,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, InteractiveCircle, __namedExportsOrder;
var init_ProgressIndicators_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Progress Indicators",
		component: ProgressBar,
		tags: ["ai-generated", "test"],
		args: {
			value: 62,
			max: 100,
			showValue: true
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, { ...args }) };
	InteractiveCircle = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressCircle, {
		value: args.value ?? 62,
		max: args.max ?? 100,
		showValue: args.showValue
	}) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <ProgressBar {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	InteractiveCircle.parameters = {
		...InteractiveCircle.parameters,
		docs: {
			...InteractiveCircle.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <ProgressCircle value={args.value ?? 62} max={args.max ?? 100} showValue={args.showValue} />\n}",
				...InteractiveCircle.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive", "InteractiveCircle"];
}));
//#endregion
init_ProgressIndicators_stories();
export { Interactive, InteractiveCircle, __namedExportsOrder, meta as default, init_ProgressIndicators_stories as n, ProgressIndicators_stories_exports as t };

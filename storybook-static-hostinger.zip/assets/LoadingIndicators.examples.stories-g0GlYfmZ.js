import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { D as LoadingSpinner, E as LoadingSkeleton, T as LoadingDots, l as Card, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/LoadingIndicators.examples.stories.tsx
var LoadingIndicators_examples_stories_exports = /* @__PURE__ */ __exportAll({
	DotsVariants: () => DotsVariants,
	SkeletonContentBlock: () => SkeletonContentBlock,
	SpinnerSizes: () => SpinnerSizes,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, SpinnerSizes, DotsVariants, SkeletonContentBlock, __namedExportsOrder;
var init_LoadingIndicators_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Loading Indicators",
		component: LoadingSpinner,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		]
	};
	SpinnerSizes = {
		args: { size: 24 },
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				alignItems: "center",
				display: "flex",
				gap: 16
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSpinner, {
					size: 16,
					label: "Loading small"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSpinner, {
					size: 24,
					label: "Loading medium"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSpinner, {
					size: 36,
					label: "Loading large"
				})
			]
		})
	};
	DotsVariants = {
		args: { size: 24 },
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				alignItems: "center",
				display: "flex",
				gap: 16
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingDots, {
					size: "sm",
					label: "Loading small"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingDots, {
					size: "md",
					label: "Loading medium"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingDots, {
					size: "lg",
					label: "Loading large"
				})
			]
		})
	};
	SkeletonContentBlock = {
		args: { size: 24 },
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			style: {
				display: "grid",
				gap: 12,
				maxWidth: 380,
				padding: 16
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
					width: "55%",
					height: 16
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
					width: "100%",
					height: 14
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
					width: "92%",
					height: 14
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
					width: "75%",
					height: 14
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingSkeleton, {
					width: 120,
					height: 30,
					rounded: true
				})
			]
		})
	};
	SpinnerSizes.parameters = {
		...SpinnerSizes.parameters,
		docs: {
			...SpinnerSizes.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    size: 24\n  },\n  render: () => <div style={{\n    alignItems: 'center',\n    display: 'flex',\n    gap: 16\n  }}>\n      <LoadingSpinner size={16} label=\"Loading small\" />\n      <LoadingSpinner size={24} label=\"Loading medium\" />\n      <LoadingSpinner size={36} label=\"Loading large\" />\n    </div>\n}",
				...SpinnerSizes.parameters?.docs?.source
			}
		}
	};
	DotsVariants.parameters = {
		...DotsVariants.parameters,
		docs: {
			...DotsVariants.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    size: 24\n  },\n  render: () => <div style={{\n    alignItems: 'center',\n    display: 'flex',\n    gap: 16\n  }}>\n      <LoadingDots size=\"sm\" label=\"Loading small\" />\n      <LoadingDots size=\"md\" label=\"Loading medium\" />\n      <LoadingDots size=\"lg\" label=\"Loading large\" />\n    </div>\n}",
				...DotsVariants.parameters?.docs?.source
			}
		}
	};
	SkeletonContentBlock.parameters = {
		...SkeletonContentBlock.parameters,
		docs: {
			...SkeletonContentBlock.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    size: 24\n  },\n  render: () => <Card style={{\n    display: 'grid',\n    gap: 12,\n    maxWidth: 380,\n    padding: 16\n  }}>\n      <LoadingSkeleton width=\"55%\" height={16} />\n      <LoadingSkeleton width=\"100%\" height={14} />\n      <LoadingSkeleton width=\"92%\" height={14} />\n      <LoadingSkeleton width=\"75%\" height={14} />\n      <LoadingSkeleton width={120} height={30} rounded />\n    </Card>\n}",
				...SkeletonContentBlock.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"SpinnerSizes",
		"DotsVariants",
		"SkeletonContentBlock"
	];
}));
//#endregion
init_LoadingIndicators_examples_stories();
export { DotsVariants, SkeletonContentBlock, SpinnerSizes, __namedExportsOrder, meta as default, init_LoadingIndicators_examples_stories as n, LoadingIndicators_examples_stories_exports as t };

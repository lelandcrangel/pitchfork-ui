import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { ModernLeadingWarning, ModernTrailingError, PillLeadingBrand, PillTrailingSuccess, n as init_BadgeGroup_examples_stories, t as BadgeGroup_examples_stories_exports } from "./BadgeGroup.examples.stories-D3GfejPp.js";
import { n as init_BadgeGroup_stories, t as BadgeGroup_stories_exports } from "./BadgeGroup.stories-D_E6tNBH.js";
//#region src/BadgeGroup.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: BadgeGroup_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "badge-group",
			children: "Badge Group"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Badge groups combine a compact label segment and a message segment, matching Untitled UI style patterns." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "pill-leading-brand",
			children: "Pill leading brand"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: PillLeadingBrand,
			meta: BadgeGroup_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "pill-trailing-success",
			children: "Pill trailing success"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: PillTrailingSuccess,
			meta: BadgeGroup_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "modern-leading-warning",
			children: "Modern leading warning"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: ModernLeadingWarning,
			meta: BadgeGroup_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "modern-trailing-error",
			children: "Modern trailing error"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: ModernTrailingError,
			meta: BadgeGroup_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_BadgeGroup_stories();
	init_BadgeGroup_examples_stories();
}))();
export { MDXContent as default };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Button.stories.tsx
var Button_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Interactive, __namedExportsOrder;
var init_Button_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Components/Button",
		component: Button,
		tags: ["ai-generated", "test"],
		args: {
			children: "Button",
			variant: "primary",
			size: "md"
		},
		argTypes: {
			variant: {
				control: "select",
				options: [
					"primary",
					"secondary",
					"ghost"
				]
			},
			size: {
				control: "select",
				options: [
					"sm",
					"md",
					"lg"
				]
			}
		}
	};
	Interactive = { args: {
		children: "Interactive button",
		variant: "primary",
		size: "md"
	} };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    children: 'Interactive button',\n    variant: 'primary',\n    size: 'md'\n  }\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Button_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Button_stories as n, Button_stories_exports as t };

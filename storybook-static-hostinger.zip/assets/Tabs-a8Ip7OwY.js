import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { CompactSmall, FullWidth, Pills, Underline, n as init_Tabs_examples_stories, t as Tabs_examples_stories_exports } from "./Tabs.examples.stories-A4vdtzF-.js";
import { n as init_Tabs_stories, t as Tabs_stories_exports } from "./Tabs.stories-Cdl7CzGp.js";
//#region src/Tabs.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Tabs_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "tabs",
			children: "Tabs"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Tabs help users switch between related content areas without leaving the current view." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "underline",
			children: "Underline"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "A classic section-navigation pattern for content-heavy interfaces." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Underline,
			meta: Tabs_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "pills",
			children: "Pills"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Pill tabs are useful for compact filters and segmented controls." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Pills,
			meta: Tabs_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "full-width",
			children: "Full width"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Use full-width tabs to distribute options evenly across constrained layouts." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: FullWidth,
			meta: Tabs_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "compact-small",
			children: "Compact small"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "A small-size variant for denser utility surfaces." }),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: CompactSmall,
			meta: Tabs_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Tabs_stories();
	init_Tabs_examples_stories();
}))();
export { MDXContent as default };

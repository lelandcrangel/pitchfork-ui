import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { a as Breadcrumbs, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Breadcrumbs.examples.stories.tsx
var Breadcrumbs_examples_stories_exports = /* @__PURE__ */ __exportAll({
	CurrentInMiddle: () => CurrentInMiddle,
	CustomSeparator: () => CustomSeparator,
	Default: () => Default,
	ShortPath: () => ShortPath,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var meta, Default, ShortPath, CustomSeparator, CurrentInMiddle, __namedExportsOrder;
var init_Breadcrumbs_examples_stories = __esmMin((() => {
	init_dist();
	meta = {
		title: "Examples/Breadcrumbs",
		component: Breadcrumbs,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { items: [
			{
				label: "Home",
				href: "#"
			},
			{
				label: "Dashboard",
				href: "#"
			},
			{
				label: "Projects",
				href: "#"
			},
			{ label: "Pitchfork UI" }
		] }
	};
	Default = {};
	ShortPath = { args: { items: [{
		label: "Home",
		href: "#"
	}, { label: "Profile" }] } };
	CustomSeparator = { args: { separator: ">" } };
	CurrentInMiddle = { args: { items: [
		{
			label: "Home",
			href: "#"
		},
		{
			label: "Design",
			href: "#"
		},
		{
			label: "Assets",
			current: true
		},
		{
			label: "Unused",
			href: "#"
		}
	] } };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{}",
				...Default.parameters?.docs?.source
			}
		}
	};
	ShortPath.parameters = {
		...ShortPath.parameters,
		docs: {
			...ShortPath.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    items: [{\n      label: 'Home',\n      href: '#'\n    }, {\n      label: 'Profile'\n    }]\n  }\n}",
				...ShortPath.parameters?.docs?.source
			}
		}
	};
	CustomSeparator.parameters = {
		...CustomSeparator.parameters,
		docs: {
			...CustomSeparator.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    separator: '>'\n  }\n}",
				...CustomSeparator.parameters?.docs?.source
			}
		}
	};
	CurrentInMiddle.parameters = {
		...CurrentInMiddle.parameters,
		docs: {
			...CurrentInMiddle.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    items: [{\n      label: 'Home',\n      href: '#'\n    }, {\n      label: 'Design',\n      href: '#'\n    }, {\n      label: 'Assets',\n      current: true\n    }, {\n      label: 'Unused',\n      href: '#'\n    }]\n  }\n}",
				...CurrentInMiddle.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"ShortPath",
		"CustomSeparator",
		"CurrentInMiddle"
	];
}));
//#endregion
init_Breadcrumbs_examples_stories();
export { CurrentInMiddle, CustomSeparator, Default, ShortPath, __namedExportsOrder, meta as default, init_Breadcrumbs_examples_stories as n, Breadcrumbs_examples_stories_exports as t };

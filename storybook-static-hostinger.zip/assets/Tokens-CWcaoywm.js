import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
//#region ../../packages/tokens/src/tokens/color.json
var color, color_default;
var init_color = __esmMin((() => {
	color = {
		"base": {
			"white": {
				"$value": "#ffffff",
				"$type": "color"
			},
			"black": {
				"$value": "#0b0b0f",
				"$type": "color"
			}
		},
		"gray": {
			"50": {
				"$value": "#f8fafc",
				"$type": "color"
			},
			"100": {
				"$value": "#f1f5f9",
				"$type": "color"
			},
			"200": {
				"$value": "#e2e8f0",
				"$type": "color"
			},
			"300": {
				"$value": "#cbd5e1",
				"$type": "color"
			},
			"400": {
				"$value": "#94a3b8",
				"$type": "color"
			},
			"500": {
				"$value": "#64748b",
				"$type": "color"
			},
			"600": {
				"$value": "#475569",
				"$type": "color"
			},
			"700": {
				"$value": "#334155",
				"$type": "color"
			},
			"800": {
				"$value": "#1e293b",
				"$type": "color"
			},
			"900": {
				"$value": "#0f172a",
				"$type": "color"
			}
		},
		"brand": {
			"50": {
				"$value": "#eff6ff",
				"$type": "color"
			},
			"100": {
				"$value": "#dbeafe",
				"$type": "color"
			},
			"200": {
				"$value": "#bfdbfe",
				"$type": "color"
			},
			"300": {
				"$value": "#93c5fd",
				"$type": "color"
			},
			"400": {
				"$value": "#60a5fa",
				"$type": "color"
			},
			"500": {
				"$value": "#3b82f6",
				"$type": "color"
			},
			"600": {
				"$value": "#2563eb",
				"$type": "color"
			},
			"700": {
				"$value": "#1d4ed8",
				"$type": "color"
			},
			"800": {
				"$value": "#1e40af",
				"$type": "color"
			},
			"900": {
				"$value": "#1e3a8a",
				"$type": "color"
			}
		},
		"semantic": {
			"background": {
				"default": {
					"$value": "{color.base.white}",
					"$type": "color"
				},
				"subtle": {
					"$value": "{color.gray.50}",
					"$type": "color"
				}
			},
			"text": {
				"default": {
					"$value": "{color.gray.900}",
					"$type": "color"
				},
				"muted": {
					"$value": "{color.gray.500}",
					"$type": "color"
				},
				"inverse": {
					"$value": "{color.base.white}",
					"$type": "color"
				}
			},
			"border": {
				"default": {
					"$value": "{color.gray.200}",
					"$type": "color"
				},
				"strong": {
					"$value": "{color.gray.300}",
					"$type": "color"
				}
			},
			"action": {
				"primary": {
					"$value": "{color.brand.700}",
					"$type": "color"
				},
				"primaryHover": {
					"$value": "{color.brand.800}",
					"$type": "color"
				},
				"primaryText": {
					"$value": "{color.base.white}",
					"$type": "color"
				}
			}
		}
	};
	color_default = { color };
}));
//#endregion
//#region ../../packages/tokens/src/tokens/size.json
var space, radius, size_default;
var init_size = __esmMin((() => {
	space = {
		"0": {
			"$value": "0px",
			"$type": "dimension"
		},
		"1": {
			"$value": "4px",
			"$type": "dimension"
		},
		"2": {
			"$value": "8px",
			"$type": "dimension"
		},
		"3": {
			"$value": "12px",
			"$type": "dimension"
		},
		"4": {
			"$value": "16px",
			"$type": "dimension"
		},
		"5": {
			"$value": "20px",
			"$type": "dimension"
		},
		"6": {
			"$value": "24px",
			"$type": "dimension"
		}
	};
	radius = {
		"sm": {
			"$value": "6px",
			"$type": "dimension"
		},
		"md": {
			"$value": "8px",
			"$type": "dimension"
		},
		"lg": {
			"$value": "12px",
			"$type": "dimension"
		},
		"full": {
			"$value": "9999px",
			"$type": "dimension"
		}
	};
	size_default = {
		space,
		radius
	};
}));
//#endregion
//#region ../../packages/tokens/src/tokens/typography.json
var font, typography_default;
var init_typography = __esmMin((() => {
	font = {
		"family": { "sans": {
			"$value": "Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif",
			"$type": "fontFamily"
		} },
		"size": {
			"sm": {
				"$value": "14px",
				"$type": "dimension"
			},
			"md": {
				"$value": "16px",
				"$type": "dimension"
			},
			"lg": {
				"$value": "18px",
				"$type": "dimension"
			}
		},
		"weight": {
			"medium": {
				"$value": "500",
				"$type": "fontWeight"
			},
			"semibold": {
				"$value": "600",
				"$type": "fontWeight"
			}
		}
	};
	typography_default = { font };
}));
//#endregion
//#region ../../packages/tokens/src/tokens/shadow.json
var shadow, shadow_default;
var init_shadow = __esmMin((() => {
	shadow = {
		"sm": {
			"$value": "0 1px 2px rgb(15 23 42 / 0.08)",
			"$type": "shadow"
		},
		"md": {
			"$value": "0 8px 24px rgb(15 23 42 / 0.12)",
			"$type": "shadow"
		}
	};
	shadow_default = { shadow };
}));
//#endregion
//#region src/Tokens.mdx
function _createMdxContent(props) {
	const _components = {
		code: "code",
		h1: "h1",
		h2: "h2",
		p: "p",
		pre: "pre",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { title: "Foundations/Tokens" }),
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "design-tokens",
			children: "Design Tokens"
		}),
		"\n",
		(0, import_jsx_runtime.jsxs)(_components.p, { children: [
			"Tokens live in ",
			(0, import_jsx_runtime.jsx)(_components.code, { children: "packages/tokens/src/tokens" }),
			" and are compiled by Style Dictionary."
		] }),
		"\n",
		(0, import_jsx_runtime.jsxs)(_components.p, { children: [
			"The React package imports generated CSS variables from ",
			(0, import_jsx_runtime.jsx)(_components.code, { children: "@pitchfork-ui/tokens/css" }),
			"."
		] }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "css-custom-properties-generated",
			children: "CSS Custom Properties (Generated)"
		}),
		"\n",
		(0, import_jsx_runtime.jsxs)(_components.p, { children: [
			"All design tokens are compiled to CSS custom properties in ",
			(0, import_jsx_runtime.jsx)(_components.code, { children: "@pitchfork-ui/tokens/css" }),
			"."
		] }),
		"\n",
		(0, import_jsx_runtime.jsx)(CssVariableTable, { rows: cssVariableRows }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "dark-theme-layer",
			children: "Dark Theme Layer"
		}),
		"\n",
		(0, import_jsx_runtime.jsxs)(_components.p, { children: [
			"The React theme adds a dark override layer using ",
			(0, import_jsx_runtime.jsx)(_components.code, { children: "[data-theme='dark']" }),
			", remapping semantic tokens while preserving the same variable API."
		] }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.pre, { children: (0, import_jsx_runtime.jsx)(_components.code, {
			className: "language-css",
			children: "[data-theme='dark'] {\n  --color-semantic-background-default: var(--color-gray-900);\n  --color-semantic-text-default: var(--color-gray-50);\n  --color-semantic-action-primary: var(--color-brand-500);\n}\n"
		}) }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "To activate dark mode on any subtree:" }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.pre, { children: (0, import_jsx_runtime.jsx)(_components.code, {
			className: "language-html",
			children: "<div data-theme=\"dark\">...</div>\n"
		}) }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "component-alias-variables",
			children: "Component Alias Variables"
		}),
		"\n",
		(0, import_jsx_runtime.jsxs)(_components.p, { children: [
			"Component-level aliases are available in the React theme layer (",
			(0, import_jsx_runtime.jsx)(_components.code, { children: "packages/react/src/styles/theme.css" }),
			") to make per-component theming simpler without changing semantic token names."
		] }),
		"\n",
		(0, import_jsx_runtime.jsx)(AliasTable, { rows: aliasRows }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "color",
			children: "Color"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(ColorPreview, {}),
		"\n",
		(0, import_jsx_runtime.jsx)(TokenTable, { rows: colorRows }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "spacing",
			children: "Spacing"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(SpacingPreview, {}),
		"\n",
		(0, import_jsx_runtime.jsx)(TokenTable, { rows: spacingRows }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "radius",
			children: "Radius"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(RadiusPreview, {}),
		"\n",
		(0, import_jsx_runtime.jsx)(TokenTable, { rows: radiusRows }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "typography",
			children: "Typography"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(TypographyPreview, {}),
		"\n",
		(0, import_jsx_runtime.jsx)(TokenTable, { rows: typographyRows }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "shadow",
			children: "Shadow"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(ShadowPreview, {}),
		"\n",
		(0, import_jsx_runtime.jsx)(TokenTable, { rows: shadowRows })
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime, flattenTokens, colorRows, spacingRows, radiusRows, typographyRows, shadowRows, colorValueByName, resolveReference, resolvedColorRows, toCssVarName, cssVariableRows, aliasRows, isRenderableColor, PreviewGrid, PreviewCard, MetaCode, TokenTable, CssVariableTable, AliasTable, ColorPreview, SpacingPreview, RadiusPreview, TypographyPreview, ShadowPreview;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_color();
	init_size();
	init_typography();
	init_shadow();
	flattenTokens = (node, path = []) => {
		if (!node || typeof node !== "object") return [];
		if ("$value" in node) return [{
			name: path.join("."),
			value: String(node.$value),
			type: node.$type ? String(node.$type) : "-"
		}];
		return Object.entries(node).flatMap(([key, value]) => flattenTokens(value, [...path, key]));
	};
	colorRows = flattenTokens(color_default);
	spacingRows = flattenTokens(size_default.space, ["space"]);
	radiusRows = flattenTokens(size_default.radius, ["radius"]);
	typographyRows = flattenTokens(typography_default);
	shadowRows = flattenTokens(shadow_default);
	colorValueByName = Object.fromEntries(colorRows.map((row) => [row.name, row.value]));
	resolveReference = (value, lookup, depth = 0) => {
		if (typeof value !== "string") return value;
		if (depth > 8) return value;
		if (!value.startsWith("{") || !value.endsWith("}")) return value;
		const next = lookup[value.slice(1, -1)];
		if (!next) return value;
		return resolveReference(next, lookup, depth + 1);
	};
	resolvedColorRows = colorRows.map((row) => ({
		...row,
		resolvedValue: resolveReference(row.value, colorValueByName)
	}));
	toCssVarName = (name) => `--${name.replace(/([a-z0-9])([A-Z])/g, "$1-$2").replace(/\./g, "-").toLowerCase()}`;
	cssVariableRows = [
		...colorRows,
		...spacingRows,
		...radiusRows,
		...typographyRows,
		...shadowRows
	].map((row) => ({
		cssVar: toCssVarName(row.name),
		value: row.value,
		type: row.type
	}));
	aliasRows = [
		{
			name: "--pf-button-primary-bg",
			mapsTo: "--color-semantic-action-primary"
		},
		{
			name: "--pf-button-primary-bg-hover",
			mapsTo: "--color-semantic-action-primary-hover"
		},
		{
			name: "--pf-button-primary-text",
			mapsTo: "--color-semantic-action-primary-text"
		},
		{
			name: "--pf-button-secondary-bg",
			mapsTo: "--color-semantic-background-default"
		},
		{
			name: "--pf-button-secondary-border",
			mapsTo: "--color-semantic-border-default"
		},
		{
			name: "--pf-button-secondary-text",
			mapsTo: "--color-semantic-text-default"
		},
		{
			name: "--pf-field-label",
			mapsTo: "--color-semantic-text-default"
		},
		{
			name: "--pf-field-description",
			mapsTo: "--color-semantic-text-muted"
		},
		{
			name: "--pf-input-bg",
			mapsTo: "--color-semantic-background-default"
		},
		{
			name: "--pf-input-border",
			mapsTo: "--color-semantic-border-default"
		},
		{
			name: "--pf-input-text",
			mapsTo: "--color-semantic-text-default"
		},
		{
			name: "--pf-input-placeholder",
			mapsTo: "--color-semantic-text-muted"
		},
		{
			name: "--pf-surface-bg",
			mapsTo: "--color-semantic-background-default"
		},
		{
			name: "--pf-surface-border",
			mapsTo: "--color-semantic-border-default"
		},
		{
			name: "--pf-select-menu-bg",
			mapsTo: "--color-semantic-background-default"
		},
		{
			name: "--pf-select-menu-border",
			mapsTo: "--color-semantic-text-muted"
		},
		{
			name: "--pf-select-option-active-bg",
			mapsTo: "--color-semantic-action-primary"
		},
		{
			name: "--pf-select-option-active-text",
			mapsTo: "--color-semantic-action-primary-text"
		}
	];
	isRenderableColor = (value) => typeof value === "string" && /^(#|rgb\(|hsl\()/i.test(value.trim());
	PreviewGrid = ({ children }) => (0, import_jsx_runtime.jsx)("div", {
		style: {
			display: "grid",
			gap: "12px",
			gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
			marginBottom: "20px"
		},
		children
	});
	PreviewCard = ({ children }) => (0, import_jsx_runtime.jsx)("div", {
		style: {
			border: "1px solid var(--color-semantic-border-default)",
			borderRadius: "8px",
			padding: "12px",
			background: "var(--color-semantic-background-default)"
		},
		children
	});
	MetaCode = ({ children }) => (0, import_jsx_runtime.jsx)("code", {
		style: {
			display: "block",
			fontSize: "11px",
			lineHeight: 1.3,
			overflowWrap: "anywhere",
			wordBreak: "break-word"
		},
		children
	});
	TokenTable = ({ rows }) => (0, import_jsx_runtime.jsxs)("table", { children: [(0, import_jsx_runtime.jsx)("thead", { children: (0, import_jsx_runtime.jsxs)("tr", { children: [
		(0, import_jsx_runtime.jsx)("th", { children: "Token" }),
		(0, import_jsx_runtime.jsx)("th", { children: "Value" }),
		(0, import_jsx_runtime.jsx)("th", { children: "Type" })
	] }) }), (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => (0, import_jsx_runtime.jsxs)("tr", { children: [
		(0, import_jsx_runtime.jsx)("td", { children: (0, import_jsx_runtime.jsx)("code", { children: row.name }) }),
		(0, import_jsx_runtime.jsx)("td", { children: (0, import_jsx_runtime.jsx)("code", { children: row.value }) }),
		(0, import_jsx_runtime.jsx)("td", { children: (0, import_jsx_runtime.jsx)("code", { children: row.type }) })
	] }, row.name)) })] });
	CssVariableTable = ({ rows }) => (0, import_jsx_runtime.jsxs)("table", { children: [(0, import_jsx_runtime.jsx)("thead", { children: (0, import_jsx_runtime.jsxs)("tr", { children: [
		(0, import_jsx_runtime.jsx)("th", { children: "CSS Variable" }),
		(0, import_jsx_runtime.jsx)("th", { children: "Value" }),
		(0, import_jsx_runtime.jsx)("th", { children: "Type" })
	] }) }), (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => (0, import_jsx_runtime.jsxs)("tr", { children: [
		(0, import_jsx_runtime.jsx)("td", { children: (0, import_jsx_runtime.jsx)("code", { children: row.cssVar }) }),
		(0, import_jsx_runtime.jsx)("td", { children: (0, import_jsx_runtime.jsx)("code", { children: row.value }) }),
		(0, import_jsx_runtime.jsx)("td", { children: (0, import_jsx_runtime.jsx)("code", { children: row.type }) })
	] }, row.cssVar)) })] });
	AliasTable = ({ rows }) => (0, import_jsx_runtime.jsxs)("table", { children: [(0, import_jsx_runtime.jsx)("thead", { children: (0, import_jsx_runtime.jsxs)("tr", { children: [(0, import_jsx_runtime.jsx)("th", { children: "Alias Variable" }), (0, import_jsx_runtime.jsx)("th", { children: "Maps To" })] }) }), (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => (0, import_jsx_runtime.jsxs)("tr", { children: [(0, import_jsx_runtime.jsx)("td", { children: (0, import_jsx_runtime.jsx)("code", { children: row.name }) }), (0, import_jsx_runtime.jsx)("td", { children: (0, import_jsx_runtime.jsx)("code", { children: row.mapsTo }) })] }, row.name)) })] });
	ColorPreview = () => (0, import_jsx_runtime.jsx)(PreviewGrid, { children: resolvedColorRows.map((row) => {
		const swatchValue = row.resolvedValue;
		const renderable = isRenderableColor(swatchValue);
		return (0, import_jsx_runtime.jsxs)(PreviewCard, { children: [(0, import_jsx_runtime.jsx)("div", { style: {
			height: "48px",
			borderRadius: "6px",
			border: "1px solid var(--color-semantic-border-default)",
			background: renderable ? swatchValue : "transparent",
			backgroundImage: renderable ? "none" : "linear-gradient(45deg, #f1f5f9 25%, #e2e8f0 25%, #e2e8f0 50%, #f1f5f9 50%, #f1f5f9 75%, #e2e8f0 75%, #e2e8f0 100%)",
			backgroundSize: "12px 12px"
		} }), (0, import_jsx_runtime.jsxs)("div", {
			style: {
				marginTop: "8px",
				fontSize: "12px"
			},
			children: [
				(0, import_jsx_runtime.jsx)("div", { children: (0, import_jsx_runtime.jsx)(MetaCode, { children: row.name }) }),
				(0, import_jsx_runtime.jsx)("div", { children: (0, import_jsx_runtime.jsx)(MetaCode, { children: row.value }) }),
				row.resolvedValue !== row.value ? (0, import_jsx_runtime.jsx)("div", { children: (0, import_jsx_runtime.jsx)(MetaCode, { children: row.resolvedValue }) }) : null
			]
		})] }, row.name);
	}) });
	SpacingPreview = () => (0, import_jsx_runtime.jsx)(PreviewGrid, { children: spacingRows.map((row) => (0, import_jsx_runtime.jsxs)(PreviewCard, { children: [
		(0, import_jsx_runtime.jsx)("div", {
			style: { marginBottom: "8px" },
			children: (0, import_jsx_runtime.jsx)(MetaCode, { children: row.name })
		}),
		(0, import_jsx_runtime.jsx)("div", {
			style: { marginBottom: "8px" },
			children: (0, import_jsx_runtime.jsx)(MetaCode, { children: row.value })
		}),
		(0, import_jsx_runtime.jsx)("div", { style: {
			height: "10px",
			borderRadius: "9999px",
			background: "var(--color-semantic-action-primary)",
			width: row.value,
			minWidth: row.value === "0px" ? "2px" : void 0
		} })
	] }, row.name)) });
	RadiusPreview = () => (0, import_jsx_runtime.jsx)(PreviewGrid, { children: radiusRows.map((row) => (0, import_jsx_runtime.jsxs)(PreviewCard, { children: [
		(0, import_jsx_runtime.jsx)("div", {
			style: { marginBottom: "8px" },
			children: (0, import_jsx_runtime.jsx)(MetaCode, { children: row.name })
		}),
		(0, import_jsx_runtime.jsx)("div", {
			style: { marginBottom: "8px" },
			children: (0, import_jsx_runtime.jsx)(MetaCode, { children: row.value })
		}),
		(0, import_jsx_runtime.jsx)("div", { style: {
			height: "48px",
			background: "var(--color-semantic-background-subtle)",
			border: "1px solid var(--color-semantic-border-default)",
			borderRadius: row.value
		} })
	] }, row.name)) });
	TypographyPreview = () => (0, import_jsx_runtime.jsx)(PreviewGrid, { children: typographyRows.map((row) => {
		const style = {
			margin: 0,
			lineHeight: 1.3
		};
		if (row.type === "fontFamily") style.fontFamily = row.value;
		if (row.type === "fontWeight") style.fontWeight = row.value;
		if (row.type === "dimension" && row.name.startsWith("font.size")) style.fontSize = row.value;
		return (0, import_jsx_runtime.jsxs)(PreviewCard, { children: [
			(0, import_jsx_runtime.jsx)("div", {
				style: { marginBottom: "8px" },
				children: (0, import_jsx_runtime.jsx)(MetaCode, { children: row.name })
			}),
			(0, import_jsx_runtime.jsx)("div", {
				style: { marginBottom: "8px" },
				children: (0, import_jsx_runtime.jsx)(MetaCode, { children: row.value })
			}),
			(0, import_jsx_runtime.jsx)("p", {
				style,
				children: "The quick brown fox jumps over the lazy dog."
			})
		] }, row.name);
	}) });
	ShadowPreview = () => (0, import_jsx_runtime.jsx)(PreviewGrid, { children: shadowRows.map((row) => (0, import_jsx_runtime.jsxs)(PreviewCard, { children: [
		(0, import_jsx_runtime.jsx)("div", {
			style: { marginBottom: "8px" },
			children: (0, import_jsx_runtime.jsx)(MetaCode, { children: row.name })
		}),
		(0, import_jsx_runtime.jsx)("div", {
			style: { marginBottom: "8px" },
			children: (0, import_jsx_runtime.jsx)(MetaCode, { children: row.value })
		}),
		(0, import_jsx_runtime.jsx)("div", { style: {
			height: "56px",
			borderRadius: "8px",
			background: "#ffffff",
			boxShadow: row.value
		} })
	] }, row.name)) });
}))();
export { AliasTable, ColorPreview, CssVariableTable, MetaCode, PreviewCard, PreviewGrid, RadiusPreview, ShadowPreview, SpacingPreview, TokenTable, TypographyPreview, aliasRows, colorRows, colorValueByName, cssVariableRows, MDXContent as default, flattenTokens, isRenderableColor, radiusRows, resolveReference, resolvedColorRows, shadowRows, spacingRows, toCssVarName, typographyRows };

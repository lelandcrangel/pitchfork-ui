import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { c as Calendar, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Calendar.examples.stories.tsx
var Calendar_examples_stories_exports = /* @__PURE__ */ __exportAll({
	BoundedYearRange: () => BoundedYearRange,
	Default: () => Default,
	DisabledWeekends: () => DisabledWeekends,
	NoOutsideDays: () => NoOutsideDays,
	WithError: () => WithError,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var disableWeekends, meta, Default, NoOutsideDays, DisabledWeekends, BoundedYearRange, WithError, __namedExportsOrder;
var init_Calendar_examples_stories = __esmMin((() => {
	init_dist();
	disableWeekends = (date) => {
		const day = date.getDay();
		return day === 0 || day === 6;
	};
	meta = {
		title: "Examples/Calendar",
		component: Calendar,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			label: "Event date",
			description: "Choose a date for the event.",
			defaultValue: new Date(2026, 4, 22)
		}
	};
	Default = {};
	NoOutsideDays = { args: { showOutsideDays: false } };
	DisabledWeekends = { args: {
		description: "Weekends are unavailable for scheduling.",
		disabledDates: disableWeekends
	} };
	BoundedYearRange = { args: {
		description: "Year options are constrained for quicker selection.",
		startYear: 2020,
		endYear: 2030
	} };
	WithError = { args: { error: "Please select a valid date before continuing." } };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{}",
				...Default.parameters?.docs?.source
			}
		}
	};
	NoOutsideDays.parameters = {
		...NoOutsideDays.parameters,
		docs: {
			...NoOutsideDays.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    showOutsideDays: false\n  }\n}",
				...NoOutsideDays.parameters?.docs?.source
			}
		}
	};
	DisabledWeekends.parameters = {
		...DisabledWeekends.parameters,
		docs: {
			...DisabledWeekends.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    description: 'Weekends are unavailable for scheduling.',\n    disabledDates: disableWeekends\n  }\n}",
				...DisabledWeekends.parameters?.docs?.source
			}
		}
	};
	BoundedYearRange.parameters = {
		...BoundedYearRange.parameters,
		docs: {
			...BoundedYearRange.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    description: 'Year options are constrained for quicker selection.',\n    startYear: 2020,\n    endYear: 2030\n  }\n}",
				...BoundedYearRange.parameters?.docs?.source
			}
		}
	};
	WithError.parameters = {
		...WithError.parameters,
		docs: {
			...WithError.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    error: 'Please select a valid date before continuing.'\n  }\n}",
				...WithError.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"NoOutsideDays",
		"DisabledWeekends",
		"BoundedYearRange",
		"WithError"
	];
}));
//#endregion
init_Calendar_examples_stories();
export { BoundedYearRange, Default, DisabledWeekends, NoOutsideDays, WithError, __namedExportsOrder, meta as default, init_Calendar_examples_stories as n, Calendar_examples_stories_exports as t };

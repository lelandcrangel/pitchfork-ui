import { a as __exportAll, i as __esmMin, s as __toESM } from "./preload-helper-UB4_TMNL.js";
import { k as require_react } from "./iframe-DMCHwO1W.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { Q as SlideoutMenu, o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/SlideoutMenu.examples.stories.tsx
var SlideoutMenu_examples_stories_exports = /* @__PURE__ */ __exportAll({
	LargePanel: () => LargePanel,
	LeftPlacement: () => LeftPlacement,
	RightPlacement: () => RightPlacement,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_react, import_jsx_runtime, meta, RightPlacement, LeftPlacement, LargePanel, __namedExportsOrder;
var init_SlideoutMenu_examples_stories = __esmMin((() => {
	import_react = /* @__PURE__ */ __toESM(require_react(), 1);
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Slideout Menu",
		component: SlideoutMenu,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { open: false }
	};
	RightPlacement = { render: () => {
		const [open, setOpen] = (0, import_react.useState)(false);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => setOpen(true),
			children: "Open right slideout"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlideoutMenu, {
			open,
			onOpenChange: setOpen,
			title: "Right placement",
			description: "Default placement for supporting side tasks.",
			footer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen(false),
				children: "Done"
			}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { margin: 0 },
				children: "This drawer slides in from the right."
			})
		})] });
	} };
	LeftPlacement = { render: () => {
		const [open, setOpen] = (0, import_react.useState)(false);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => setOpen(true),
			children: "Open left slideout"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlideoutMenu, {
			open,
			onOpenChange: setOpen,
			placement: "left",
			title: "Left placement",
			description: "Useful for navigation or secondary controls.",
			footer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen(false),
				children: "Close"
			}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { margin: 0 },
				children: "This drawer slides in from the left."
			})
		})] });
	} };
	LargePanel = { render: () => {
		const [open, setOpen] = (0, import_react.useState)(false);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => setOpen(true),
			children: "Open large slideout"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SlideoutMenu, {
			open,
			onOpenChange: setOpen,
			size: "lg",
			title: "Large panel",
			description: "Use large size for longer forms or richer detail layouts.",
			footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				onClick: () => setOpen(false),
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen(false),
				children: "Save"
			})] }),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { marginTop: 0 },
				children: "This example uses the large size variant to provide more room."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { marginBottom: 0 },
				children: "Keep critical tasks concise and consider progressive disclosure for complex workflows."
			})]
		})] });
	} };
	RightPlacement.parameters = {
		...RightPlacement.parameters,
		docs: {
			...RightPlacement.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => {\n    const [open, setOpen] = useState(false);\n    return <>\n        <Button onClick={() => setOpen(true)}>Open right slideout</Button>\n        <SlideoutMenu open={open} onOpenChange={setOpen} title=\"Right placement\" description=\"Default placement for supporting side tasks.\" footer={<Button onClick={() => setOpen(false)}>Done</Button>}>\n          <p style={{\n          margin: 0\n        }}>This drawer slides in from the right.</p>\n        </SlideoutMenu>\n      </>;\n  }\n}",
				...RightPlacement.parameters?.docs?.source
			}
		}
	};
	LeftPlacement.parameters = {
		...LeftPlacement.parameters,
		docs: {
			...LeftPlacement.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => {\n    const [open, setOpen] = useState(false);\n    return <>\n        <Button onClick={() => setOpen(true)}>Open left slideout</Button>\n        <SlideoutMenu open={open} onOpenChange={setOpen} placement=\"left\" title=\"Left placement\" description=\"Useful for navigation or secondary controls.\" footer={<Button onClick={() => setOpen(false)}>Close</Button>}>\n          <p style={{\n          margin: 0\n        }}>This drawer slides in from the left.</p>\n        </SlideoutMenu>\n      </>;\n  }\n}",
				...LeftPlacement.parameters?.docs?.source
			}
		}
	};
	LargePanel.parameters = {
		...LargePanel.parameters,
		docs: {
			...LargePanel.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => {\n    const [open, setOpen] = useState(false);\n    return <>\n        <Button onClick={() => setOpen(true)}>Open large slideout</Button>\n        <SlideoutMenu open={open} onOpenChange={setOpen} size=\"lg\" title=\"Large panel\" description=\"Use large size for longer forms or richer detail layouts.\" footer={<>\n              <Button variant=\"secondary\" onClick={() => setOpen(false)}>\n                Cancel\n              </Button>\n              <Button onClick={() => setOpen(false)}>Save</Button>\n            </>}>\n          <p style={{\n          marginTop: 0\n        }}>\n            This example uses the large size variant to provide more room.\n          </p>\n          <p style={{\n          marginBottom: 0\n        }}>\n            Keep critical tasks concise and consider progressive disclosure for\n            complex workflows.\n          </p>\n        </SlideoutMenu>\n      </>;\n  }\n}",
				...LargePanel.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"RightPlacement",
		"LeftPlacement",
		"LargePanel"
	];
}));
//#endregion
init_SlideoutMenu_examples_stories();
export { LargePanel, LeftPlacement, RightPlacement, __namedExportsOrder, meta as default, init_SlideoutMenu_examples_stories as n, SlideoutMenu_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { d as CardFooter, f as CardHeader, l as Card, o as Button, u as CardContent, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Card.examples.stories.tsx
var Card_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Basic: () => Basic,
	WithLongContent: () => WithLongContent,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, expect, meta, Basic, WithLongContent, __namedExportsOrder;
var init_Card_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	({expect} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Card",
		component: Card,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			style: { maxWidth: 480 },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Project summary" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: "This card composes header, content, and footer slots." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardFooter, {
					style: {
						display: "flex",
						gap: 8
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Save" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						children: "Cancel"
					})]
				})
			]
		})
	};
	Basic = { play: async ({ canvas }) => {
		await expect(canvas.getByRole("button", { name: /cancel/i })).toBeVisible();
	} };
	WithLongContent = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		style: { maxWidth: 480 },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Release notes" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: "A longer body demonstrates spacing and section borders while preserving readable rhythm." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardFooter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				children: "Dismiss"
			}) })
		]
	}) };
	Basic.parameters = {
		...Basic.parameters,
		docs: {
			...Basic.parameters?.docs,
			source: {
				originalSource: "{\n  play: async ({\n    canvas\n  }) => {\n    await expect(canvas.getByRole('button', {\n      name: /cancel/i\n    })).toBeVisible();\n  }\n}",
				...Basic.parameters?.docs?.source
			}
		}
	};
	WithLongContent.parameters = {
		...WithLongContent.parameters,
		docs: {
			...WithLongContent.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <Card style={{\n    maxWidth: 480\n  }}>\n      <CardHeader>\n        <strong>Release notes</strong>\n      </CardHeader>\n      <CardContent>\n        A longer body demonstrates spacing and section borders while preserving\n        readable rhythm.\n      </CardContent>\n      <CardFooter>\n        <Button variant=\"ghost\">Dismiss</Button>\n      </CardFooter>\n    </Card>\n}",
				...WithLongContent.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Basic", "WithLongContent"];
}));
//#endregion
init_Card_examples_stories();
export { Basic, WithLongContent, __namedExportsOrder, meta as default, init_Card_examples_stories as n, Card_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { p as Carousel, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Carousel.examples.stories.tsx
var Carousel_examples_stories_exports = /* @__PURE__ */ __exportAll({
	AutoPlay: () => AutoPlay,
	Default: () => Default,
	NoIndicators: () => NoIndicators,
	NoLoop: () => NoLoop,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Default, NoLoop, AutoPlay, NoIndicators, __namedExportsOrder;
var init_Carousel_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Carousel",
		component: Carousel,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { slides: [
			{
				title: "Design review",
				text: "Slides can hold rich content areas and callouts.",
				background: "#111827"
			},
			{
				title: "Engineering sync",
				text: "Use a carousel to surface the most recent updates.",
				background: "#1d4ed8"
			},
			{
				title: "Launch notes",
				text: "Keep users focused on one panel at a time.",
				background: "#0f766e"
			}
		].map((slide) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			style: {
				background: `linear-gradient(135deg, ${slide.background} 0%, color-mix(in srgb, ${slide.background} 72%, white) 100%)`,
				color: "#fff",
				minHeight: 180,
				padding: 16
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
				style: { margin: 0 },
				children: slide.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: {
					marginBottom: 0,
					marginTop: 8
				},
				children: slide.text
			})]
		}, slide.title)) }
	};
	Default = {};
	NoLoop = { args: { loop: false } };
	AutoPlay = { args: {
		autoPlay: true,
		autoPlayInterval: 2500
	} };
	NoIndicators = { args: { showIndicators: false } };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{}",
				...Default.parameters?.docs?.source
			}
		}
	};
	NoLoop.parameters = {
		...NoLoop.parameters,
		docs: {
			...NoLoop.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    loop: false\n  }\n}",
				...NoLoop.parameters?.docs?.source
			}
		}
	};
	AutoPlay.parameters = {
		...AutoPlay.parameters,
		docs: {
			...AutoPlay.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    autoPlay: true,\n    autoPlayInterval: 2500\n  }\n}",
				...AutoPlay.parameters?.docs?.source
			}
		}
	};
	NoIndicators.parameters = {
		...NoIndicators.parameters,
		docs: {
			...NoIndicators.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    showIndicators: false\n  }\n}",
				...NoIndicators.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"NoLoop",
		"AutoPlay",
		"NoIndicators"
	];
}));
//#endregion
init_Carousel_examples_stories();
export { AutoPlay, Default, NoIndicators, NoLoop, __namedExportsOrder, meta as default, init_Carousel_examples_stories as n, Carousel_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { o as Button, ut as init_dist, x as HeaderNavigation } from "./dist-D1zMThSa.js";
//#region src/HeaderNavigation.stories.tsx
var HeaderNavigation_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_HeaderNavigation_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/HeaderNavigation",
		component: HeaderNavigation,
		tags: ["ai-generated", "test"],
		args: {
			brand: "Pitchfork UI",
			items: [
				{
					label: "Overview",
					href: "#",
					active: true
				},
				{
					label: "Projects",
					href: "#"
				},
				{
					label: "Team",
					href: "#"
				},
				{
					label: "Settings",
					href: "#"
				}
			],
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				children: "Create project"
			})
		},
		argTypes: {
			items: { control: false },
			actions: { control: false },
			brand: { control: "text" }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeaderNavigation, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <HeaderNavigation {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_HeaderNavigation_stories();
export { Interactive, __namedExportsOrder, meta as default, init_HeaderNavigation_stories as n, HeaderNavigation_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { nt as Tabs, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Tabs.examples.stories.tsx
var Tabs_examples_stories_exports = /* @__PURE__ */ __exportAll({
	CompactSmall: () => CompactSmall,
	FullWidth: () => FullWidth,
	Pills: () => Pills,
	Underline: () => Underline,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, projectItems, compactItems, meta, Underline, Pills, FullWidth, CompactSmall, __namedExportsOrder;
var init_Tabs_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	projectItems = [
		{
			value: "roadmap",
			label: "Roadmap",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { margin: 0 },
				children: "Prioritize milestones by customer impact and engineering confidence."
			})
		},
		{
			value: "delivery",
			label: "Delivery",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { margin: 0 },
				children: "Sprint completion is at 92% with two carry-over tickets this cycle."
			})
		},
		{
			value: "risks",
			label: "Risks",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { margin: 0 },
				children: "Primary risk is API response latency in peak traffic windows."
			})
		}
	];
	compactItems = [
		{
			value: "all",
			label: "All",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { margin: 0 },
				children: "Showing all notifications."
			})
		},
		{
			value: "mentions",
			label: "Mentions",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { margin: 0 },
				children: "Showing only mentions."
			})
		},
		{
			value: "alerts",
			label: "Alerts",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { margin: 0 },
				children: "Showing high-priority alerts."
			})
		},
		{
			value: "muted",
			label: "Muted",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { margin: 0 },
				children: "Showing muted threads."
			})
		}
	];
	meta = {
		title: "Examples/Tabs",
		component: Tabs,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { items: projectItems }
	};
	Underline = {};
	Pills = { args: { variant: "pills" } };
	FullWidth = { args: {
		fullWidth: true,
		variant: "pills"
	} };
	CompactSmall = { args: {
		items: compactItems,
		size: "sm"
	} };
	Underline.parameters = {
		...Underline.parameters,
		docs: {
			...Underline.parameters?.docs,
			source: {
				originalSource: "{}",
				...Underline.parameters?.docs?.source
			}
		}
	};
	Pills.parameters = {
		...Pills.parameters,
		docs: {
			...Pills.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    variant: 'pills'\n  }\n}",
				...Pills.parameters?.docs?.source
			}
		}
	};
	FullWidth.parameters = {
		...FullWidth.parameters,
		docs: {
			...FullWidth.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    fullWidth: true,\n    variant: 'pills'\n  }\n}",
				...FullWidth.parameters?.docs?.source
			}
		}
	};
	CompactSmall.parameters = {
		...CompactSmall.parameters,
		docs: {
			...CompactSmall.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    items: compactItems,\n    size: 'sm'\n  }\n}",
				...CompactSmall.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Underline",
		"Pills",
		"FullWidth",
		"CompactSmall"
	];
}));
//#endregion
init_Tabs_examples_stories();
export { CompactSmall, FullWidth, Pills, Underline, __namedExportsOrder, meta as default, init_Tabs_examples_stories as n, Tabs_examples_stories_exports as t };

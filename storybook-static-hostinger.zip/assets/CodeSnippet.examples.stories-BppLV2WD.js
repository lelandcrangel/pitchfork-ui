import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { h as CodeSnippet, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/CodeSnippet.examples.stories.tsx
var CodeSnippet_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	Scrollable: () => Scrollable,
	ToolbarOnly: () => ToolbarOnly,
	WithLineNumbers: () => WithLineNumbers,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var compactCode, apiCode, longCode, meta, Default, WithLineNumbers, Scrollable, ToolbarOnly, __namedExportsOrder;
var init_CodeSnippet_examples_stories = __esmMin((() => {
	init_dist();
	compactCode = `const status = getStatus();
return status === 'ok' ? 'Ready' : 'Needs attention';`;
	apiCode = `fetch('/api/projects', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ name: 'Pitchfork UI' }),
});`;
	longCode = `export function useKeyboardShortcut(
  key: string,
  callback: () => void,
) {
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() === key.toLowerCase()) {
        callback();
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [key, callback]);
}`;
	meta = {
		title: "Examples/CodeSnippet",
		component: CodeSnippet,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			title: "example.ts",
			language: "typescript",
			code: compactCode
		}
	};
	Default = {};
	WithLineNumbers = { args: {
		title: "api-request.ts",
		code: apiCode,
		showLineNumbers: true
	} };
	Scrollable = { args: {
		title: "useKeyboardShortcut.ts",
		code: longCode,
		showLineNumbers: true,
		maxHeight: 160
	} };
	ToolbarOnly = { args: {
		title: void 0,
		language: void 0,
		code: compactCode
	} };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{}",
				...Default.parameters?.docs?.source
			}
		}
	};
	WithLineNumbers.parameters = {
		...WithLineNumbers.parameters,
		docs: {
			...WithLineNumbers.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    title: 'api-request.ts',\n    code: apiCode,\n    showLineNumbers: true\n  }\n}",
				...WithLineNumbers.parameters?.docs?.source
			}
		}
	};
	Scrollable.parameters = {
		...Scrollable.parameters,
		docs: {
			...Scrollable.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    title: 'useKeyboardShortcut.ts',\n    code: longCode,\n    showLineNumbers: true,\n    maxHeight: 160\n  }\n}",
				...Scrollable.parameters?.docs?.source
			}
		}
	};
	ToolbarOnly.parameters = {
		...ToolbarOnly.parameters,
		docs: {
			...ToolbarOnly.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    title: undefined,\n    language: undefined,\n    code: compactCode\n  }\n}",
				...ToolbarOnly.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"WithLineNumbers",
		"Scrollable",
		"ToolbarOnly"
	];
}));
//#endregion
init_CodeSnippet_examples_stories();
export { Default, Scrollable, ToolbarOnly, WithLineNumbers, __namedExportsOrder, meta as default, init_CodeSnippet_examples_stories as n, CodeSnippet_examples_stories_exports as t };

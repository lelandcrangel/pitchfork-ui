import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { at as Tooltip, o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Tooltip.stories.tsx
var Tooltip_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_Tooltip_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Tooltip",
		component: Tooltip,
		tags: ["ai-generated", "test"],
		args: {
			content: "This action saves your current workspace.",
			placement: "top",
			delay: 120,
			disabled: false
		},
		argTypes: {
			placement: {
				control: "inline-radio",
				options: [
					"top",
					"bottom",
					"left",
					"right"
				]
			},
			delay: { control: {
				type: "number",
				min: 0,
				max: 1e3,
				step: 20
			} },
			disabled: { control: "boolean" }
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
		...args,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Hover me" })
	}) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <Tooltip {...args}>\n      <Button>Hover me</Button>\n    </Tooltip>\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Tooltip_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Tooltip_stories as n, Tooltip_stories_exports as t };

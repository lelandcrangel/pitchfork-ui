import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Basic, WithLongContent, n as init_Card_examples_stories, t as Card_examples_stories_exports } from "./Card.examples.stories-DRBOLbNA.js";
import { n as init_Card_stories, t as Card_stories_exports } from "./Card.stories-DAudCH2g.js";
//#region src/Card.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Card_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "card",
			children: "Card"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Cards group related content and actions into a clear, bordered surface." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "basic",
			children: "Basic"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Basic,
			meta: Card_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-long-content",
			children: "With Long Content"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithLongContent,
			meta: Card_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Card_stories();
	init_Card_examples_stories();
}))();
export { MDXContent as default };

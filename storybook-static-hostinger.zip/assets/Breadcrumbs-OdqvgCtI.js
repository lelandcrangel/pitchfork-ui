import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { CurrentInMiddle, CustomSeparator, Default, ShortPath, n as init_Breadcrumbs_examples_stories, t as Breadcrumbs_examples_stories_exports } from "./Breadcrumbs.examples.stories-ChHQa4UV.js";
import { n as init_Breadcrumbs_stories, t as Breadcrumbs_stories_exports } from "./Breadcrumbs.stories-Cjnk5Ucq.js";
//#region src/Breadcrumbs.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Breadcrumbs_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "breadcrumbs",
			children: "Breadcrumbs"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Breadcrumbs communicate hierarchy and give users quick links back to parent locations." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: Breadcrumbs_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "short-path",
			children: "Short path"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: ShortPath,
			meta: Breadcrumbs_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "custom-separator",
			children: "Custom separator"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: CustomSeparator,
			meta: Breadcrumbs_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "current-in-middle",
			children: "Current in middle"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: CurrentInMiddle,
			meta: Breadcrumbs_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Breadcrumbs_stories();
	init_Breadcrumbs_examples_stories();
}))();
export { MDXContent as default };

import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { b as init_chunk_A242L54C, y as __toESM } from "./iframe-DMCHwO1W.js";
import { D as require_memoizerific, E as init_chunk_ZCFV7BZB, T as init_chunk_3LY4VQVK, w as dedent } from "./blocks-OZ7n4nQC.js";
//#region ../../node_modules/storybook/dist/_browser-chunks/formatter-EIJCOSYU.js
var formatter;
//#endregion
__esmMin((() => {
	init_chunk_ZCFV7BZB();
	init_chunk_3LY4VQVK();
	init_chunk_A242L54C();
	formatter = (0, __toESM(require_memoizerific(), 1).default)(2)(async (type, source) => type === !1 ? source : dedent(source));
}))();
export { formatter };

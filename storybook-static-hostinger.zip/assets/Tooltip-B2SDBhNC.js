import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Bottom, Disabled, Left, Right, Top, n as init_Tooltip_examples_stories, t as Tooltip_examples_stories_exports } from "./Tooltip.examples.stories-DPY_fwXP.js";
import { n as init_Tooltip_stories, t as Tooltip_stories_exports } from "./Tooltip.stories-mzCgu_WX.js";
//#region src/Tooltip.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Tooltip_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "tooltip",
			children: "Tooltip"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Tooltips provide concise contextual guidance on hover or focus without disrupting layout." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "top",
			children: "Top"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Top,
			meta: Tooltip_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "bottom",
			children: "Bottom"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Bottom,
			meta: Tooltip_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "left",
			children: "Left"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Left,
			meta: Tooltip_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "right",
			children: "Right"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Right,
			meta: Tooltip_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled",
			children: "Disabled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Disabled,
			meta: Tooltip_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Tooltip_stories();
	init_Tooltip_examples_stories();
}))();
export { MDXContent as default };

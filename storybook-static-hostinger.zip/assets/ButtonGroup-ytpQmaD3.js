import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Default, Disabled, DisabledItem, LeadingIcon, MultipleSelection, WithDot, n as init_ButtonGroup_examples_stories, t as ButtonGroup_examples_stories_exports } from "./ButtonGroup.examples.stories-CHQhCCe6.js";
import { n as init_ButtonGroup_stories, t as ButtonGroup_stories_exports } from "./ButtonGroup.stories-CMLmHiN4.js";
//#region src/ButtonGroup.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: ButtonGroup_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "button-group",
			children: "Button Group"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Button groups present related choices in a compact horizontal control." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: ButtonGroup_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "leading-icon",
			children: "Leading Icon"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: LeadingIcon,
			meta: ButtonGroup_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-dot",
			children: "With Dot"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithDot,
			meta: ButtonGroup_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled",
			children: "Disabled"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Disabled,
			meta: ButtonGroup_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "disabled-item",
			children: "Disabled Item"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: DisabledItem,
			meta: ButtonGroup_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "multiple-selection",
			children: "Multiple Selection"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: MultipleSelection,
			meta: ButtonGroup_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_ButtonGroup_stories();
	init_ButtonGroup_examples_stories();
}))();
export { MDXContent as default };

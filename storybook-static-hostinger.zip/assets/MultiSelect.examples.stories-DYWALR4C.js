import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { N as MultiSelect, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/MultiSelect.examples.stories.tsx
var MultiSelect_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	Disabled: () => Disabled,
	WithDefaultValues: () => WithDefaultValues,
	WithError: () => WithError,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var expect, meta, Default, WithDefaultValues, WithError, Disabled, __namedExportsOrder;
var init_MultiSelect_examples_stories = __esmMin((() => {
	init_dist();
	({expect} = __STORYBOOK_MODULE_TEST__);
	meta = {
		title: "Examples/Multi Select",
		component: MultiSelect,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			label: "Tech stack",
			description: "Select all tools your team uses daily.",
			placeholder: "Choose one or more",
			options: [
				{
					value: "react",
					label: "React"
				},
				{
					value: "typescript",
					label: "TypeScript"
				},
				{
					value: "storybook",
					label: "Storybook"
				},
				{
					value: "figma",
					label: "Figma",
					disabled: true
				}
			]
		}
	};
	Default = { play: async ({ canvas, userEvent }) => {
		const trigger = canvas.getByRole("button", { name: /tech stack/i });
		await userEvent.click(trigger);
		await userEvent.click(canvas.getByRole("option", { name: /react/i }));
		await userEvent.click(canvas.getByRole("option", { name: /typescript/i }));
		await expect(trigger).toHaveTextContent(/react/i);
		await expect(trigger).toHaveTextContent(/typescript/i);
	} };
	WithDefaultValues = { args: { defaultValue: ["react", "storybook"] } };
	WithError = { args: { error: "Select at least two tools before continuing." } };
	Disabled = { args: {
		disabled: true,
		defaultValue: ["react"]
	} };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  play: async ({\n    canvas,\n    userEvent\n  }) => {\n    const trigger = canvas.getByRole('button', {\n      name: /tech stack/i\n    });\n    await userEvent.click(trigger);\n    await userEvent.click(canvas.getByRole('option', {\n      name: /react/i\n    }));\n    await userEvent.click(canvas.getByRole('option', {\n      name: /typescript/i\n    }));\n    await expect(trigger).toHaveTextContent(/react/i);\n    await expect(trigger).toHaveTextContent(/typescript/i);\n  }\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	WithDefaultValues.parameters = {
		...WithDefaultValues.parameters,
		docs: {
			...WithDefaultValues.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    defaultValue: ['react', 'storybook']\n  }\n}",
				...WithDefaultValues.parameters?.docs?.source
			}
		}
	};
	WithError.parameters = {
		...WithError.parameters,
		docs: {
			...WithError.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    error: 'Select at least two tools before continuing.'\n  }\n}",
				...WithError.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    disabled: true,\n    defaultValue: ['react']\n  }\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"WithDefaultValues",
		"WithError",
		"Disabled"
	];
}));
//#endregion
init_MultiSelect_examples_stories();
export { Default, Disabled, WithDefaultValues, WithError, __namedExportsOrder, meta as default, init_MultiSelect_examples_stories as n, MultiSelect_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { at as Tooltip, o as Button, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Tooltip.examples.stories.tsx
var Tooltip_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Bottom: () => Bottom,
	Disabled: () => Disabled,
	Left: () => Left,
	Right: () => Right,
	Top: () => Top,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Top, Bottom, Left, Right, Disabled, __namedExportsOrder;
var init_Tooltip_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Tooltip",
		component: Tooltip,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: {
			content: "This action saves your current workspace.",
			placement: "top",
			delay: 120
		}
	};
	Top = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
		...args,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Top tooltip" })
	}) };
	Bottom = {
		args: {
			placement: "bottom",
			content: "Available after payment is confirmed."
		},
		render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
			...args,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Bottom tooltip" })
		})
	};
	Left = {
		args: {
			placement: "left",
			content: "This field is synced across all projects."
		},
		render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
			...args,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Left tooltip" })
		})
	};
	Right = {
		args: {
			placement: "right",
			content: "Use this to open advanced settings."
		},
		render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
			...args,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Right tooltip" })
		})
	};
	Disabled = {
		args: {
			disabled: true,
			content: "This should not appear while disabled."
		},
		render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
			...args,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Disabled tooltip" })
		})
	};
	Top.parameters = {
		...Top.parameters,
		docs: {
			...Top.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <Tooltip {...args}>\n      <Button>Top tooltip</Button>\n    </Tooltip>\n}",
				...Top.parameters?.docs?.source
			}
		}
	};
	Bottom.parameters = {
		...Bottom.parameters,
		docs: {
			...Bottom.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    placement: 'bottom',\n    content: 'Available after payment is confirmed.'\n  },\n  render: args => <Tooltip {...args}>\n      <Button>Bottom tooltip</Button>\n    </Tooltip>\n}",
				...Bottom.parameters?.docs?.source
			}
		}
	};
	Left.parameters = {
		...Left.parameters,
		docs: {
			...Left.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    placement: 'left',\n    content: 'This field is synced across all projects.'\n  },\n  render: args => <Tooltip {...args}>\n      <Button>Left tooltip</Button>\n    </Tooltip>\n}",
				...Left.parameters?.docs?.source
			}
		}
	};
	Right.parameters = {
		...Right.parameters,
		docs: {
			...Right.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    placement: 'right',\n    content: 'Use this to open advanced settings.'\n  },\n  render: args => <Tooltip {...args}>\n      <Button>Right tooltip</Button>\n    </Tooltip>\n}",
				...Right.parameters?.docs?.source
			}
		}
	};
	Disabled.parameters = {
		...Disabled.parameters,
		docs: {
			...Disabled.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    disabled: true,\n    content: 'This should not appear while disabled.'\n  },\n  render: args => <Tooltip {...args}>\n      <Button>Disabled tooltip</Button>\n    </Tooltip>\n}",
				...Disabled.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Top",
		"Bottom",
		"Left",
		"Right",
		"Disabled"
	];
}));
//#endregion
init_Tooltip_examples_stories();
export { Bottom, Disabled, Left, Right, Top, __namedExportsOrder, meta as default, init_Tooltip_examples_stories as n, Tooltip_examples_stories_exports as t };

import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { Default, Inset, Vertical, WithLabel, n as init_ContentDivider_examples_stories, t as ContentDivider_examples_stories_exports } from "./ContentDivider.examples.stories-Dnv98uDJ.js";
import { n as init_ContentDivider_stories, t as ContentDivider_stories_exports } from "./ContentDivider.stories-ChmWwBuw.js";
//#region src/ContentDivider.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: ContentDivider_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "content-divider",
			children: "Content Divider"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "ContentDivider visually separates content areas with optional labels." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: ContentDivider_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "with-label",
			children: "With label"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: WithLabel,
			meta: ContentDivider_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "vertical",
			children: "Vertical"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Vertical,
			meta: ContentDivider_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "inset",
			children: "Inset"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Inset,
			meta: ContentDivider_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_ContentDivider_stories();
	init_ContentDivider_examples_stories();
}))();
export { MDXContent as default };

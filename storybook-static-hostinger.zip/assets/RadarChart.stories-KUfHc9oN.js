import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { H as RadarChart, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/RadarChart.stories.tsx
var RadarChart_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_RadarChart_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Radar Charts",
		component: RadarChart,
		tags: ["ai-generated", "test"],
		args: {
			size: 280,
			levels: 4,
			showAxes: true,
			showLegend: true,
			data: [
				{
					label: "Usability",
					value: 78
				},
				{
					label: "Performance",
					value: 64
				},
				{
					label: "Security",
					value: 82
				},
				{
					label: "Reliability",
					value: 73
				},
				{
					label: "Scalability",
					value: 69
				}
			]
		}
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadarChart, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <RadarChart {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_RadarChart_stories();
export { Interactive, __namedExportsOrder, meta as default, init_RadarChart_stories as n, RadarChart_stories_exports as t };

import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { X as Select, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/Select.stories.tsx
var Select_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var options, meta, Interactive, __namedExportsOrder;
var init_Select_stories = __esmMin((() => {
	init_dist();
	options = [
		{
			value: "starter",
			label: "Starter plan"
		},
		{
			value: "pro",
			label: "Pro plan"
		},
		{
			value: "enterprise",
			label: "Enterprise plan",
			disabled: true
		}
	];
	meta = {
		title: "Components/Select",
		component: Select,
		tags: ["ai-generated", "test"],
		args: {
			label: "Pricing tier",
			description: "Choose the plan that fits your team.",
			placeholder: "Choose a plan",
			options
		}
	};
	Interactive = { args: {
		label: "Interactive select",
		description: "Change options and state from controls.",
		placeholder: "Choose a plan",
		options
	} };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  args: {\n    label: 'Interactive select',\n    description: 'Change options and state from controls.',\n    placeholder: 'Choose a plan',\n    options\n  }\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_Select_stories();
export { Interactive, __namedExportsOrder, meta as default, init_Select_stories as n, Select_stories_exports as t };

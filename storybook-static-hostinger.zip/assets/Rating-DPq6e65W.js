import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { BadgeDefault, BadgeSmall, StarsCompact, StarsDefault, StarsLarge, n as init_Rating_examples_stories, t as Rating_examples_stories_exports } from "./Rating.examples.stories-bkJre5Bp.js";
import { n as init_Rating_stories, t as Rating_stories_exports } from "./Rating.stories-CKE-dg4R.js";
//#region src/Rating.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Rating_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "rating",
			children: "Rating"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Rating components communicate average score at a glance with stars or a compact badge." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "stars-default",
			children: "Stars default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: StarsDefault,
			meta: Rating_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "stars-compact",
			children: "Stars compact"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: StarsCompact,
			meta: Rating_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "stars-large",
			children: "Stars large"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: StarsLarge,
			meta: Rating_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "badge-default",
			children: "Badge default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: BadgeDefault,
			meta: Rating_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "badge-small",
			children: "Badge small"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: BadgeSmall,
			meta: Rating_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Rating_stories();
	init_Rating_examples_stories();
}))();
export { MDXContent as default };

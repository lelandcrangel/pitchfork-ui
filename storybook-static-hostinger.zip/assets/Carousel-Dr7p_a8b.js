import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { AutoPlay, Default, NoIndicators, NoLoop, n as init_Carousel_examples_stories, t as Carousel_examples_stories_exports } from "./Carousel.examples.stories-BVgQTrb6.js";
import { n as init_Carousel_stories, t as Carousel_stories_exports } from "./Carousel.stories-DlqjMhVN.js";
//#region src/Carousel.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: Carousel_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "carousel",
			children: "Carousel"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "Carousel displays a sequence of slides with previous/next controls and optional indicator dots." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "default",
			children: "Default"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: Default,
			meta: Carousel_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "no-loop",
			children: "No loop"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: NoLoop,
			meta: Carousel_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "auto-play",
			children: "Auto play"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: AutoPlay,
			meta: Carousel_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "no-indicators",
			children: "No indicators"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: NoIndicators,
			meta: Carousel_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_Carousel_stories();
	init_Carousel_examples_stories();
}))();
export { MDXContent as default };

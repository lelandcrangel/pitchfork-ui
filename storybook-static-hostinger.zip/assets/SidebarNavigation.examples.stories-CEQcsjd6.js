import { a as __exportAll, i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { Z as SidebarNavigation, r as Badge, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/SidebarNavigation.examples.stories.tsx
var SidebarNavigation_examples_stories_exports = /* @__PURE__ */ __exportAll({
	Default: () => Default,
	Minimal: () => Minimal,
	WithDisabledItems: () => WithDisabledItems,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
var import_jsx_runtime, meta, Default, WithDisabledItems, Minimal, __namedExportsOrder;
var init_SidebarNavigation_examples_stories = __esmMin((() => {
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Examples/Sidebar Navigation",
		component: SidebarNavigation,
		tags: [
			"ai-generated",
			"test",
			"examplesHidden"
		],
		args: { sections: [{ items: [{ label: "Item" }] }] }
	};
	Default = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarNavigation, {
		header: "Acme Inc",
		sections: [{
			title: "General",
			items: [
				{
					label: "Dashboard",
					active: true
				},
				{
					label: "Notifications",
					badge: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "4" })
				},
				{ label: "Analytics" }
			]
		}, {
			title: "Management",
			items: [
				{ label: "Members" },
				{ label: "Teams" },
				{ label: "Permissions" }
			]
		}],
		footer: "Plan: Growth"
	}) };
	WithDisabledItems = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarNavigation, { sections: [{
		title: "Navigation",
		items: [
			{
				label: "Home",
				active: true
			},
			{ label: "Reports" },
			{
				label: "Audit log",
				disabled: true
			},
			{
				label: "Security",
				disabled: true
			}
		]
	}] }) };
	Minimal = { render: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarNavigation, { sections: [{ items: [
		{
			label: "Overview",
			active: true
		},
		{ label: "Updates" },
		{ label: "Help" }
	] }] }) };
	Default.parameters = {
		...Default.parameters,
		docs: {
			...Default.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <SidebarNavigation header=\"Acme Inc\" sections={[{\n    title: 'General',\n    items: [{\n      label: 'Dashboard',\n      active: true\n    }, {\n      label: 'Notifications',\n      badge: <Badge>4</Badge>\n    }, {\n      label: 'Analytics'\n    }]\n  }, {\n    title: 'Management',\n    items: [{\n      label: 'Members'\n    }, {\n      label: 'Teams'\n    }, {\n      label: 'Permissions'\n    }]\n  }]} footer=\"Plan: Growth\" />\n}",
				...Default.parameters?.docs?.source
			}
		}
	};
	WithDisabledItems.parameters = {
		...WithDisabledItems.parameters,
		docs: {
			...WithDisabledItems.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <SidebarNavigation sections={[{\n    title: 'Navigation',\n    items: [{\n      label: 'Home',\n      active: true\n    }, {\n      label: 'Reports'\n    }, {\n      label: 'Audit log',\n      disabled: true\n    }, {\n      label: 'Security',\n      disabled: true\n    }]\n  }]} />\n}",
				...WithDisabledItems.parameters?.docs?.source
			}
		}
	};
	Minimal.parameters = {
		...Minimal.parameters,
		docs: {
			...Minimal.parameters?.docs,
			source: {
				originalSource: "{\n  render: () => <SidebarNavigation sections={[{\n    items: [{\n      label: 'Overview',\n      active: true\n    }, {\n      label: 'Updates'\n    }, {\n      label: 'Help'\n    }]\n  }]} />\n}",
				...Minimal.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = [
		"Default",
		"WithDisabledItems",
		"Minimal"
	];
}));
//#endregion
init_SidebarNavigation_examples_stories();
export { Default, Minimal, WithDisabledItems, __namedExportsOrder, meta as default, init_SidebarNavigation_examples_stories as n, SidebarNavigation_examples_stories_exports as t };

import { a as __exportAll, i as __esmMin, s as __toESM } from "./preload-helper-UB4_TMNL.js";
import { k as require_react } from "./iframe-DMCHwO1W.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { o as Button, ot as TreeView, ut as init_dist } from "./dist-D1zMThSa.js";
//#region src/TreeView.stories.tsx
var TreeView_stories_exports = /* @__PURE__ */ __exportAll({
	Interactive: () => Interactive,
	__namedExportsOrder: () => __namedExportsOrder,
	default: () => meta
});
function InteractiveWithControls(args) {
	const treeRef = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gap: 12
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				gap: 8
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				onClick: () => treeRef.current?.expandAll(),
				children: "Expand all"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "secondary",
				onClick: () => treeRef.current?.collapseAll(),
				children: "Collapse all"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreeView, {
			ref: treeRef,
			...args
		})]
	});
}
var import_react, import_jsx_runtime, meta, Interactive, __namedExportsOrder;
var init_TreeView_stories = __esmMin((() => {
	import_react = /* @__PURE__ */ __toESM(require_react(), 1);
	init_dist();
	import_jsx_runtime = require_jsx_runtime();
	meta = {
		title: "Components/Tree Views",
		component: TreeView,
		tags: ["ai-generated", "test"],
		args: {
			nodes: [{
				value: "workspace",
				label: "Workspace",
				children: [
					{
						value: "design",
						label: "Design",
						children: [{
							value: "mocks",
							label: "Mocks.fig"
						}, {
							value: "assets",
							label: "Assets"
						}]
					},
					{
						value: "engineering",
						label: "Engineering",
						children: [{
							value: "frontend",
							label: "Frontend"
						}, {
							value: "backend",
							label: "Backend"
						}]
					},
					{
						value: "operations",
						label: "Operations",
						disabled: true
					}
				]
			}],
			defaultExpandedValues: ["workspace", "design"],
			defaultSelectedValue: "assets"
		},
		argTypes: { nodes: { control: false } }
	};
	Interactive = { render: (args) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InteractiveWithControls, { ...args }) };
	Interactive.parameters = {
		...Interactive.parameters,
		docs: {
			...Interactive.parameters?.docs,
			source: {
				originalSource: "{\n  render: args => <InteractiveWithControls {...args} />\n}",
				...Interactive.parameters?.docs?.source
			}
		}
	};
	__namedExportsOrder = ["Interactive"];
}));
//#endregion
init_TreeView_stories();
export { Interactive, __namedExportsOrder, meta as default, init_TreeView_stories as n, TreeView_stories_exports as t };

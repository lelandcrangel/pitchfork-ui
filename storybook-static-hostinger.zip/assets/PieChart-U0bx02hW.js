import { i as __esmMin } from "./preload-helper-UB4_TMNL.js";
import { t as require_jsx_runtime } from "./jsx-runtime-t3EfFlgk.js";
import { L as useMDXComponents, n as Canvas, o as Meta, s as init_blocks } from "./blocks-OZ7n4nQC.js";
import { t as init_mdx_react_shim } from "./mdx-react-shim-BAGy3wV0.js";
import { ChannelSplit, CompactNoLegend, EmptyState, RevenueMix, n as init_PieChart_examples_stories, t as PieChart_examples_stories_exports } from "./PieChart.examples.stories-OYeyIt2Q.js";
import { n as init_PieChart_stories, t as PieChart_stories_exports } from "./PieChart.stories-NmT9ANNl.js";
//#region src/PieChart.mdx
function _createMdxContent(props) {
	const _components = {
		h1: "h1",
		h2: "h2",
		h3: "h3",
		p: "p",
		...useMDXComponents(),
		...props.components
	};
	return (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		(0, import_jsx_runtime.jsx)(Meta, { of: PieChart_stories_exports }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h1, {
			id: "pie-charts",
			children: "Pie Charts"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.p, { children: "PieChart visualizes part-to-whole distribution with a clean donut style and optional legend." }),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h2, {
			id: "examples",
			children: "Examples"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "revenue-mix",
			children: "Revenue mix"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: RevenueMix,
			meta: PieChart_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "channel-split",
			children: "Channel split"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: ChannelSplit,
			meta: PieChart_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "compact-without-legend",
			children: "Compact without legend"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: CompactNoLegend,
			meta: PieChart_examples_stories_exports
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(_components.h3, {
			id: "empty-state",
			children: "Empty state"
		}),
		"\n",
		(0, import_jsx_runtime.jsx)(Canvas, {
			of: EmptyState,
			meta: PieChart_examples_stories_exports
		})
	] });
}
function MDXContent(props = {}) {
	const { wrapper: MDXLayout } = {
		...useMDXComponents(),
		...props.components
	};
	return MDXLayout ? (0, import_jsx_runtime.jsx)(MDXLayout, {
		...props,
		children: (0, import_jsx_runtime.jsx)(_createMdxContent, { ...props })
	}) : _createMdxContent(props);
}
var import_jsx_runtime;
//#endregion
__esmMin((() => {
	import_jsx_runtime = require_jsx_runtime();
	init_mdx_react_shim();
	init_blocks();
	init_PieChart_stories();
	init_PieChart_examples_stories();
}))();
export { MDXContent as default };

import { i as __esmMin, n as init_preload_helper, t as __vitePreload } from "./assets/preload-helper-UB4_TMNL.js";
//#region ../../node_modules/storybook/dist/mocking-utils/mocker-runtime.js
function mockObject(options, object, mockExports = {}) {
	let finalizers = new Array(), refs = new RefTracker(), define = (container, key, value) => {
		try {
			return container[key] = value, !0;
		} catch {
			return !1;
		}
	}, mockPropertiesOf = (container, newContainer) => {
		let containerType = getType(container), isModule = containerType === "Module" || !!container.__esModule;
		for (let { key: property, descriptor } of getAllMockableProperties(container, isModule, options.globalConstructors)) {
			if (!isModule && descriptor.get) {
				try {
					Object.defineProperty(newContainer, property, descriptor);
				} catch {}
				continue;
			}
			if (isSpecialProp(property, containerType)) continue;
			let value = container[property], refId = refs.getId(value);
			if (refId !== void 0) {
				finalizers.push(() => define(newContainer, property, refs.getMockedValue(refId)));
				continue;
			}
			let type = getType(value);
			if (Array.isArray(value)) {
				define(newContainer, property, []);
				continue;
			}
			let isFunction = type.includes("Function") && typeof value == "function";
			if ((!isFunction || value._isMockFunction) && type !== "Object" && type !== "Module") {
				define(newContainer, property, value);
				continue;
			}
			if (define(newContainer, property, isFunction ? value : {})) {
				if (isFunction) {
					let mockFunction = function() {
						if (this instanceof newContainer[property]) for (let { key, descriptor: descriptor2 } of getAllMockableProperties(this, !1, options.globalConstructors)) {
							if (descriptor2.get) continue;
							let value2 = this[key];
							if (getType(value2).includes("Function") && typeof value2 == "function") {
								let original = this[key], mock2 = spyOn(this, key).mockImplementation(original), origMockReset = mock2.mockReset;
								mock2.mockRestore = mock2.mockReset = () => (origMockReset.call(mock2), mock2.mockImplementation(original), mock2);
							}
						}
					};
					if (!options.spyOn) throw new Error("[@vitest/mocker] `spyOn` is not defined. This is a Vitest error. Please open a new issue with reproduction.");
					let spyOn = options.spyOn, mock = spyOn(newContainer, property);
					if (options.type === "automock") {
						mock.mockImplementation(mockFunction);
						let origMockReset = mock.mockReset;
						mock.mockRestore = mock.mockReset = () => (origMockReset.call(mock), mock.mockImplementation(mockFunction), mock);
					}
					Object.defineProperty(newContainer[property], "length", { value: 0 });
				}
				refs.track(value, newContainer[property]), mockPropertiesOf(value, newContainer[property]);
			}
		}
	}, mockedObject = mockExports;
	mockPropertiesOf(object, mockedObject);
	for (let finalizer of finalizers) finalizer();
	return mockedObject;
}
function getType(value) {
	return Object.prototype.toString.apply(value).slice(8, -1);
}
function isSpecialProp(prop, parentType) {
	return parentType.includes("Function") && typeof prop == "string" && [
		"arguments",
		"callee",
		"caller",
		"length",
		"name"
	].includes(prop);
}
function getAllMockableProperties(obj, isModule, constructors) {
	let { Map: Map2, Object: Object2, Function: Function2, RegExp: RegExp2, Array: Array2 } = constructors, allProps = new Map2(), curr = obj;
	do {
		if (curr === Object2.prototype || curr === Function2.prototype || curr === RegExp2.prototype) break;
		collectOwnProperties(curr, (key) => {
			let descriptor = Object2.getOwnPropertyDescriptor(curr, key);
			descriptor && allProps.set(key, {
				key,
				descriptor
			});
		});
	} while (curr = Object2.getPrototypeOf(curr));
	if (isModule && !allProps.has("default") && "default" in obj) {
		let descriptor = Object2.getOwnPropertyDescriptor(obj, "default");
		descriptor && allProps.set("default", {
			key: "default",
			descriptor
		});
	}
	return Array2.from(allProps.values());
}
function collectOwnProperties(obj, collector) {
	let collect = typeof collector == "function" ? collector : (key) => collector.add(key);
	Object.getOwnPropertyNames(obj).forEach(collect), Object.getOwnPropertySymbols(obj).forEach(collect);
}
function normalizeWindowsPath(input = "") {
	return input && input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
function normalizeString(path, allowAboveRoot) {
	let res = "", lastSegmentLength = 0, lastSlash = -1, dots = 0, char = null;
	for (let index2 = 0; index2 <= path.length; ++index2) {
		if (index2 < path.length) char = path[index2];
		else {
			if (char === "/") break;
			char = "/";
		}
		if (char === "/") {
			if (!(lastSlash === index2 - 1 || dots === 1)) if (dots === 2) {
				if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
					if (res.length > 2) {
						let lastSlashIndex = res.lastIndexOf("/");
						lastSlashIndex === -1 ? (res = "", lastSegmentLength = 0) : (res = res.slice(0, lastSlashIndex), lastSegmentLength = res.length - 1 - res.lastIndexOf("/")), lastSlash = index2, dots = 0;
						continue;
					} else if (res.length > 0) {
						res = "", lastSegmentLength = 0, lastSlash = index2, dots = 0;
						continue;
					}
				}
				allowAboveRoot && (res += res.length > 0 ? "/.." : "..", lastSegmentLength = 2);
			} else res.length > 0 ? res += `/${path.slice(lastSlash + 1, index2)}` : res = path.slice(lastSlash + 1, index2), lastSegmentLength = index2 - lastSlash - 1;
			lastSlash = index2, dots = 0;
		} else char === "." && dots !== -1 ? ++dots : dots = -1;
	}
	return res;
}
function a(n) {
	return String(n);
}
function C(n = !1) {
	let e = typeof process < "u" ? process : void 0, i = e?.env || {}, g = e?.argv || [];
	return !("NO_COLOR" in i || g.includes("--no-color")) && ("FORCE_COLOR" in i || g.includes("--color") || e?.platform === "win32" || n && i.TERM !== "dumb" || "CI" in i) || typeof window < "u" && !!window.chrome;
}
function p(n = !1) {
	let e = C(n), i = (r, t, c, o) => {
		let l = "", s = 0;
		do
			l += r.substring(s, o) + c, s = o + t.length, o = r.indexOf(t, s);
		while (~o);
		return l + r.substring(s);
	}, g = (r, t, c = r) => {
		let o = (l) => {
			let s = String(l), b = s.indexOf(t, r.length);
			return ~b ? r + i(s, t, c, b) + t : r + s + t;
		};
		return o.open = r, o.close = t, o;
	}, u = { isColorSupported: e }, d = (r) => `\x1B[${r}m`;
	for (let [r, t] of h) u[r] = e ? g(d(t[0]), d(t[1]), t[2]) : a;
	return u;
}
function _mergeNamespaces(n, m) {
	return m.forEach(function(e) {
		e && typeof e != "string" && !Array.isArray(e) && Object.keys(e).forEach(function(k) {
			if (k !== "default" && !(k in n)) {
				var d = Object.getOwnPropertyDescriptor(e, k);
				Object.defineProperty(n, k, d.get ? d : {
					enumerable: !0,
					get: function() {
						return e[k];
					}
				});
			}
		});
	}), Object.freeze(n);
}
function getDefaultExportFromCjs(x) {
	return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, "default") ? x.default : x;
}
function requireReactIs_production() {
	if (hasRequiredReactIs_production) return reactIs_production;
	hasRequiredReactIs_production = 1;
	var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler"), REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition"), REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference");
	function typeOf(object) {
		if (typeof object == "object" && object !== null) {
			var $$typeof = object.$$typeof;
			switch ($$typeof) {
				case REACT_ELEMENT_TYPE: switch (object = object.type, object) {
					case REACT_FRAGMENT_TYPE:
					case REACT_PROFILER_TYPE:
					case REACT_STRICT_MODE_TYPE:
					case REACT_SUSPENSE_TYPE:
					case REACT_SUSPENSE_LIST_TYPE:
					case REACT_VIEW_TRANSITION_TYPE: return object;
					default: switch (object = object && object.$$typeof, object) {
						case REACT_CONTEXT_TYPE:
						case REACT_FORWARD_REF_TYPE:
						case REACT_LAZY_TYPE:
						case REACT_MEMO_TYPE: return object;
						case REACT_CONSUMER_TYPE: return object;
						default: return $$typeof;
					}
				}
				case REACT_PORTAL_TYPE: return $$typeof;
			}
		}
	}
	return reactIs_production.ContextConsumer = REACT_CONSUMER_TYPE, reactIs_production.ContextProvider = REACT_CONTEXT_TYPE, reactIs_production.Element = REACT_ELEMENT_TYPE, reactIs_production.ForwardRef = REACT_FORWARD_REF_TYPE, reactIs_production.Fragment = REACT_FRAGMENT_TYPE, reactIs_production.Lazy = REACT_LAZY_TYPE, reactIs_production.Memo = REACT_MEMO_TYPE, reactIs_production.Portal = REACT_PORTAL_TYPE, reactIs_production.Profiler = REACT_PROFILER_TYPE, reactIs_production.StrictMode = REACT_STRICT_MODE_TYPE, reactIs_production.Suspense = REACT_SUSPENSE_TYPE, reactIs_production.SuspenseList = REACT_SUSPENSE_LIST_TYPE, reactIs_production.isContextConsumer = function(object) {
		return typeOf(object) === REACT_CONSUMER_TYPE;
	}, reactIs_production.isContextProvider = function(object) {
		return typeOf(object) === REACT_CONTEXT_TYPE;
	}, reactIs_production.isElement = function(object) {
		return typeof object == "object" && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
	}, reactIs_production.isForwardRef = function(object) {
		return typeOf(object) === REACT_FORWARD_REF_TYPE;
	}, reactIs_production.isFragment = function(object) {
		return typeOf(object) === REACT_FRAGMENT_TYPE;
	}, reactIs_production.isLazy = function(object) {
		return typeOf(object) === REACT_LAZY_TYPE;
	}, reactIs_production.isMemo = function(object) {
		return typeOf(object) === REACT_MEMO_TYPE;
	}, reactIs_production.isPortal = function(object) {
		return typeOf(object) === REACT_PORTAL_TYPE;
	}, reactIs_production.isProfiler = function(object) {
		return typeOf(object) === REACT_PROFILER_TYPE;
	}, reactIs_production.isStrictMode = function(object) {
		return typeOf(object) === REACT_STRICT_MODE_TYPE;
	}, reactIs_production.isSuspense = function(object) {
		return typeOf(object) === REACT_SUSPENSE_TYPE;
	}, reactIs_production.isSuspenseList = function(object) {
		return typeOf(object) === REACT_SUSPENSE_LIST_TYPE;
	}, reactIs_production.isValidElementType = function(type) {
		return typeof type == "string" || typeof type == "function" || type === REACT_FRAGMENT_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type == "object" && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_CONSUMER_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_CLIENT_REFERENCE || type.getModuleId !== void 0);
	}, reactIs_production.typeOf = typeOf, reactIs_production;
}
function requireReactIs$1() {
	return hasRequiredReactIs$1 || (hasRequiredReactIs$1 = 1, reactIs$1.exports = requireReactIs_production()), reactIs$1.exports;
}
function requireReactIs_production_min() {
	if (hasRequiredReactIs_production_min) return reactIs_production_min;
	hasRequiredReactIs_production_min = 1;
	var b = Symbol.for("react.element"), c = Symbol.for("react.portal"), d = Symbol.for("react.fragment"), e = Symbol.for("react.strict_mode"), f2 = Symbol.for("react.profiler"), g = Symbol.for("react.provider"), h2 = Symbol.for("react.context"), k = Symbol.for("react.server_context"), l = Symbol.for("react.forward_ref"), m = Symbol.for("react.suspense"), n = Symbol.for("react.suspense_list"), p2 = Symbol.for("react.memo"), q = Symbol.for("react.lazy"), t = Symbol.for("react.offscreen"), u = Symbol.for("react.module.reference");
	function v(a2) {
		if (typeof a2 == "object" && a2 !== null) {
			var r = a2.$$typeof;
			switch (r) {
				case b: switch (a2 = a2.type, a2) {
					case d:
					case f2:
					case e:
					case m:
					case n: return a2;
					default: switch (a2 = a2 && a2.$$typeof, a2) {
						case k:
						case h2:
						case l:
						case q:
						case p2:
						case g: return a2;
						default: return r;
					}
				}
				case c: return r;
			}
		}
	}
	return reactIs_production_min.ContextConsumer = h2, reactIs_production_min.ContextProvider = g, reactIs_production_min.Element = b, reactIs_production_min.ForwardRef = l, reactIs_production_min.Fragment = d, reactIs_production_min.Lazy = q, reactIs_production_min.Memo = p2, reactIs_production_min.Portal = c, reactIs_production_min.Profiler = f2, reactIs_production_min.StrictMode = e, reactIs_production_min.Suspense = m, reactIs_production_min.SuspenseList = n, reactIs_production_min.isAsyncMode = function() {
		return !1;
	}, reactIs_production_min.isConcurrentMode = function() {
		return !1;
	}, reactIs_production_min.isContextConsumer = function(a2) {
		return v(a2) === h2;
	}, reactIs_production_min.isContextProvider = function(a2) {
		return v(a2) === g;
	}, reactIs_production_min.isElement = function(a2) {
		return typeof a2 == "object" && a2 !== null && a2.$$typeof === b;
	}, reactIs_production_min.isForwardRef = function(a2) {
		return v(a2) === l;
	}, reactIs_production_min.isFragment = function(a2) {
		return v(a2) === d;
	}, reactIs_production_min.isLazy = function(a2) {
		return v(a2) === q;
	}, reactIs_production_min.isMemo = function(a2) {
		return v(a2) === p2;
	}, reactIs_production_min.isPortal = function(a2) {
		return v(a2) === c;
	}, reactIs_production_min.isProfiler = function(a2) {
		return v(a2) === f2;
	}, reactIs_production_min.isStrictMode = function(a2) {
		return v(a2) === e;
	}, reactIs_production_min.isSuspense = function(a2) {
		return v(a2) === m;
	}, reactIs_production_min.isSuspenseList = function(a2) {
		return v(a2) === n;
	}, reactIs_production_min.isValidElementType = function(a2) {
		return typeof a2 == "string" || typeof a2 == "function" || a2 === d || a2 === f2 || a2 === e || a2 === m || a2 === n || a2 === t || typeof a2 == "object" && a2 !== null && (a2.$$typeof === q || a2.$$typeof === p2 || a2.$$typeof === g || a2.$$typeof === h2 || a2.$$typeof === l || a2.$$typeof === u || a2.getModuleId !== void 0);
	}, reactIs_production_min.typeOf = v, reactIs_production_min;
}
function requireReactIs() {
	return hasRequiredReactIs || (hasRequiredReactIs = 1, reactIs.exports = requireReactIs_production_min()), reactIs.exports;
}
function createSimpleStackTrace(options) {
	let { message = "$$stack trace error", stackTraceLimit = 1 } = options || {}, limit = Error.stackTraceLimit, prepareStackTrace = Error.prepareStackTrace;
	Error.stackTraceLimit = stackTraceLimit, Error.prepareStackTrace = (e) => e.stack;
	let stackTrace = new Error(message).stack || "";
	return Error.prepareStackTrace = prepareStackTrace, Error.stackTraceLimit = limit, stackTrace;
}
function requireJsTokens() {
	if (hasRequiredJsTokens) return jsTokens_1;
	hasRequiredJsTokens = 1;
	var Identifier, JSXIdentifier, JSXPunctuator, JSXString, JSXText, KeywordsWithExpressionAfter, KeywordsWithNoLineTerminatorAfter, LineTerminatorSequence, MultiLineComment, Newline, NumericLiteral, Punctuator, RegularExpressionLiteral, SingleLineComment, StringLiteral, Template, TokensNotPrecedingObjectLiteral, TokensPrecedingExpression, WhiteSpace;
	return RegularExpressionLiteral = /\/(?![*\/])(?:\[(?:(?![\]\\]).|\\.)*\]|(?![\/\\]).|\\.)*(\/[$_\u200C\u200D\p{ID_Continue}]*|\\)?/uy, Punctuator = /--|\+\+|=>|\.{3}|\??\.(?!\d)|(?:&&|\|\||\?\?|[+\-%&|^]|\*{1,2}|<{1,2}|>{1,3}|!=?|={1,2}|\/(?![\/*]))=?|[?~,:;[\](){}]/y, Identifier = /(\x23?)(?=[$_\p{ID_Start}\\])(?:[$_\u200C\u200D\p{ID_Continue}]|\\u[\da-fA-F]{4}|\\u\{[\da-fA-F]+\})+/uy, StringLiteral = /(['"])(?:(?!\1)[^\\\n\r]|\\(?:\r\n|[^]))*(\1)?/y, NumericLiteral = /(?:0[xX][\da-fA-F](?:_?[\da-fA-F])*|0[oO][0-7](?:_?[0-7])*|0[bB][01](?:_?[01])*)n?|0n|[1-9](?:_?\d)*n|(?:(?:0(?!\d)|0\d*[89]\d*|[1-9](?:_?\d)*)(?:\.(?:\d(?:_?\d)*)?)?|\.\d(?:_?\d)*)(?:[eE][+-]?\d(?:_?\d)*)?|0[0-7]+/y, Template = /[`}](?:[^`\\$]|\\[^]|\$(?!\{))*(`|\$\{)?/y, WhiteSpace = /[\t\v\f\ufeff\p{Zs}]+/uy, LineTerminatorSequence = /\r?\n|[\r\u2028\u2029]/y, MultiLineComment = /\/\*(?:[^*]|\*(?!\/))*(\*\/)?/y, SingleLineComment = /\/\/.*/y, JSXPunctuator = /[<>.:={}]|\/(?![\/*])/y, JSXIdentifier = /[$_\p{ID_Start}][$_\u200C\u200D\p{ID_Continue}-]*/uy, JSXString = /(['"])(?:(?!\1)[^])*(\1)?/y, JSXText = /[^<>{}]+/y, TokensPrecedingExpression = /^(?:[\/+-]|\.{3}|\?(?:InterpolationIn(?:JSX|Template)|NoLineTerminatorHere|NonExpressionParenEnd|UnaryIncDec))?$|[{}([,;<>=*%&|^!~?:]$/, TokensNotPrecedingObjectLiteral = /^(?:=>|[;\]){}]|else|\?(?:NoLineTerminatorHere|NonExpressionParenEnd))?$/, KeywordsWithExpressionAfter = /^(?:await|case|default|delete|do|else|instanceof|new|return|throw|typeof|void|yield)$/, KeywordsWithNoLineTerminatorAfter = /^(?:return|throw|yield)$/, Newline = RegExp(LineTerminatorSequence.source), jsTokens_1 = function* (input, { jsx = !1 } = {}) {
		var braces, firstCodePoint, isExpression, lastIndex, lastSignificantToken, length, match, mode, nextLastIndex, nextLastSignificantToken, parenNesting, postfixIncDec, punctuator, stack;
		for ({length} = input, lastIndex = 0, lastSignificantToken = "", stack = [{ tag: "JS" }], braces = [], parenNesting = 0, postfixIncDec = !1; lastIndex < length;) {
			switch (mode = stack[stack.length - 1], mode.tag) {
				case "JS":
				case "JSNonExpressionParen":
				case "InterpolationInTemplate":
				case "InterpolationInJSX":
					if (input[lastIndex] === "/" && (TokensPrecedingExpression.test(lastSignificantToken) || KeywordsWithExpressionAfter.test(lastSignificantToken)) && (RegularExpressionLiteral.lastIndex = lastIndex, match = RegularExpressionLiteral.exec(input))) {
						lastIndex = RegularExpressionLiteral.lastIndex, lastSignificantToken = match[0], postfixIncDec = !0, yield {
							type: "RegularExpressionLiteral",
							value: match[0],
							closed: match[1] !== void 0 && match[1] !== "\\"
						};
						continue;
					}
					if (Punctuator.lastIndex = lastIndex, match = Punctuator.exec(input)) {
						switch (punctuator = match[0], nextLastIndex = Punctuator.lastIndex, nextLastSignificantToken = punctuator, punctuator) {
							case "(":
								lastSignificantToken === "?NonExpressionParenKeyword" && stack.push({
									tag: "JSNonExpressionParen",
									nesting: parenNesting
								}), parenNesting++, postfixIncDec = !1;
								break;
							case ")":
								parenNesting--, postfixIncDec = !0, mode.tag === "JSNonExpressionParen" && parenNesting === mode.nesting && (stack.pop(), nextLastSignificantToken = "?NonExpressionParenEnd", postfixIncDec = !1);
								break;
							case "{":
								Punctuator.lastIndex = 0, isExpression = !TokensNotPrecedingObjectLiteral.test(lastSignificantToken) && (TokensPrecedingExpression.test(lastSignificantToken) || KeywordsWithExpressionAfter.test(lastSignificantToken)), braces.push(isExpression), postfixIncDec = !1;
								break;
							case "}":
								switch (mode.tag) {
									case "InterpolationInTemplate":
										if (braces.length === mode.nesting) {
											Template.lastIndex = lastIndex, match = Template.exec(input), lastIndex = Template.lastIndex, lastSignificantToken = match[0], match[1] === "${" ? (lastSignificantToken = "?InterpolationInTemplate", postfixIncDec = !1, yield {
												type: "TemplateMiddle",
												value: match[0]
											}) : (stack.pop(), postfixIncDec = !0, yield {
												type: "TemplateTail",
												value: match[0],
												closed: match[1] === "`"
											});
											continue;
										}
										break;
									case "InterpolationInJSX": if (braces.length === mode.nesting) {
										stack.pop(), lastIndex += 1, lastSignificantToken = "}", yield {
											type: "JSXPunctuator",
											value: "}"
										};
										continue;
									}
								}
								postfixIncDec = braces.pop(), nextLastSignificantToken = postfixIncDec ? "?ExpressionBraceEnd" : "}";
								break;
							case "]":
								postfixIncDec = !0;
								break;
							case "++":
							case "--":
								nextLastSignificantToken = postfixIncDec ? "?PostfixIncDec" : "?UnaryIncDec";
								break;
							case "<":
								if (jsx && (TokensPrecedingExpression.test(lastSignificantToken) || KeywordsWithExpressionAfter.test(lastSignificantToken))) {
									stack.push({ tag: "JSXTag" }), lastIndex += 1, lastSignificantToken = "<", yield {
										type: "JSXPunctuator",
										value: punctuator
									};
									continue;
								}
								postfixIncDec = !1;
								break;
							default: postfixIncDec = !1;
						}
						lastIndex = nextLastIndex, lastSignificantToken = nextLastSignificantToken, yield {
							type: "Punctuator",
							value: punctuator
						};
						continue;
					}
					if (Identifier.lastIndex = lastIndex, match = Identifier.exec(input)) {
						switch (lastIndex = Identifier.lastIndex, nextLastSignificantToken = match[0], match[0]) {
							case "for":
							case "if":
							case "while":
							case "with": lastSignificantToken !== "." && lastSignificantToken !== "?." && (nextLastSignificantToken = "?NonExpressionParenKeyword");
						}
						lastSignificantToken = nextLastSignificantToken, postfixIncDec = !KeywordsWithExpressionAfter.test(match[0]), yield {
							type: match[1] === "#" ? "PrivateIdentifier" : "IdentifierName",
							value: match[0]
						};
						continue;
					}
					if (StringLiteral.lastIndex = lastIndex, match = StringLiteral.exec(input)) {
						lastIndex = StringLiteral.lastIndex, lastSignificantToken = match[0], postfixIncDec = !0, yield {
							type: "StringLiteral",
							value: match[0],
							closed: match[2] !== void 0
						};
						continue;
					}
					if (NumericLiteral.lastIndex = lastIndex, match = NumericLiteral.exec(input)) {
						lastIndex = NumericLiteral.lastIndex, lastSignificantToken = match[0], postfixIncDec = !0, yield {
							type: "NumericLiteral",
							value: match[0]
						};
						continue;
					}
					if (Template.lastIndex = lastIndex, match = Template.exec(input)) {
						lastIndex = Template.lastIndex, lastSignificantToken = match[0], match[1] === "${" ? (lastSignificantToken = "?InterpolationInTemplate", stack.push({
							tag: "InterpolationInTemplate",
							nesting: braces.length
						}), postfixIncDec = !1, yield {
							type: "TemplateHead",
							value: match[0]
						}) : (postfixIncDec = !0, yield {
							type: "NoSubstitutionTemplate",
							value: match[0],
							closed: match[1] === "`"
						});
						continue;
					}
					break;
				case "JSXTag":
				case "JSXTagEnd":
					if (JSXPunctuator.lastIndex = lastIndex, match = JSXPunctuator.exec(input)) {
						switch (lastIndex = JSXPunctuator.lastIndex, nextLastSignificantToken = match[0], match[0]) {
							case "<":
								stack.push({ tag: "JSXTag" });
								break;
							case ">":
								stack.pop(), lastSignificantToken === "/" || mode.tag === "JSXTagEnd" ? (nextLastSignificantToken = "?JSX", postfixIncDec = !0) : stack.push({ tag: "JSXChildren" });
								break;
							case "{":
								stack.push({
									tag: "InterpolationInJSX",
									nesting: braces.length
								}), nextLastSignificantToken = "?InterpolationInJSX", postfixIncDec = !1;
								break;
							case "/": lastSignificantToken === "<" && (stack.pop(), stack[stack.length - 1].tag === "JSXChildren" && stack.pop(), stack.push({ tag: "JSXTagEnd" }));
						}
						lastSignificantToken = nextLastSignificantToken, yield {
							type: "JSXPunctuator",
							value: match[0]
						};
						continue;
					}
					if (JSXIdentifier.lastIndex = lastIndex, match = JSXIdentifier.exec(input)) {
						lastIndex = JSXIdentifier.lastIndex, lastSignificantToken = match[0], yield {
							type: "JSXIdentifier",
							value: match[0]
						};
						continue;
					}
					if (JSXString.lastIndex = lastIndex, match = JSXString.exec(input)) {
						lastIndex = JSXString.lastIndex, lastSignificantToken = match[0], yield {
							type: "JSXString",
							value: match[0],
							closed: match[2] !== void 0
						};
						continue;
					}
					break;
				case "JSXChildren":
					if (JSXText.lastIndex = lastIndex, match = JSXText.exec(input)) {
						lastIndex = JSXText.lastIndex, lastSignificantToken = match[0], yield {
							type: "JSXText",
							value: match[0]
						};
						continue;
					}
					switch (input[lastIndex]) {
						case "<":
							stack.push({ tag: "JSXTag" }), lastIndex++, lastSignificantToken = "<", yield {
								type: "JSXPunctuator",
								value: "<"
							};
							continue;
						case "{":
							stack.push({
								tag: "InterpolationInJSX",
								nesting: braces.length
							}), lastIndex++, lastSignificantToken = "?InterpolationInJSX", postfixIncDec = !1, yield {
								type: "JSXPunctuator",
								value: "{"
							};
							continue;
					}
			}
			if (WhiteSpace.lastIndex = lastIndex, match = WhiteSpace.exec(input)) {
				lastIndex = WhiteSpace.lastIndex, yield {
					type: "WhiteSpace",
					value: match[0]
				};
				continue;
			}
			if (LineTerminatorSequence.lastIndex = lastIndex, match = LineTerminatorSequence.exec(input)) {
				lastIndex = LineTerminatorSequence.lastIndex, postfixIncDec = !1, KeywordsWithNoLineTerminatorAfter.test(lastSignificantToken) && (lastSignificantToken = "?NoLineTerminatorHere"), yield {
					type: "LineTerminatorSequence",
					value: match[0]
				};
				continue;
			}
			if (MultiLineComment.lastIndex = lastIndex, match = MultiLineComment.exec(input)) {
				lastIndex = MultiLineComment.lastIndex, Newline.test(match[0]) && (postfixIncDec = !1, KeywordsWithNoLineTerminatorAfter.test(lastSignificantToken) && (lastSignificantToken = "?NoLineTerminatorHere")), yield {
					type: "MultiLineComment",
					value: match[0],
					closed: match[1] !== void 0
				};
				continue;
			}
			if (SingleLineComment.lastIndex = lastIndex, match = SingleLineComment.exec(input)) {
				lastIndex = SingleLineComment.lastIndex, postfixIncDec = !1, yield {
					type: "SingleLineComment",
					value: match[0]
				};
				continue;
			}
			firstCodePoint = String.fromCodePoint(input.codePointAt(lastIndex)), lastIndex += firstCodePoint.length, lastSignificantToken = firstCodePoint, postfixIncDec = !1, yield {
				type: mode.tag.startsWith("JSX") ? "JSXInvalid" : "Invalid",
				value: firstCodePoint
			};
		}
	}, jsTokens_1;
}
function normalizeWindowsPath2(input = "") {
	return input && input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE2, (r) => r.toUpperCase());
}
function cwd() {
	return typeof process < "u" && typeof process.cwd == "function" ? process.cwd().replace(/\\/g, "/") : "/";
}
function normalizeString2(path, allowAboveRoot) {
	let res = "", lastSegmentLength = 0, lastSlash = -1, dots = 0, char = null;
	for (let index2 = 0; index2 <= path.length; ++index2) {
		if (index2 < path.length) char = path[index2];
		else {
			if (char === "/") break;
			char = "/";
		}
		if (char === "/") {
			if (!(lastSlash === index2 - 1 || dots === 1)) if (dots === 2) {
				if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
					if (res.length > 2) {
						let lastSlashIndex = res.lastIndexOf("/");
						lastSlashIndex === -1 ? (res = "", lastSegmentLength = 0) : (res = res.slice(0, lastSlashIndex), lastSegmentLength = res.length - 1 - res.lastIndexOf("/")), lastSlash = index2, dots = 0;
						continue;
					} else if (res.length > 0) {
						res = "", lastSegmentLength = 0, lastSlash = index2, dots = 0;
						continue;
					}
				}
				allowAboveRoot && (res += res.length > 0 ? "/.." : "..", lastSegmentLength = 2);
			} else res.length > 0 ? res += `/${path.slice(lastSlash + 1, index2)}` : res = path.slice(lastSlash + 1, index2), lastSegmentLength = index2 - lastSlash - 1;
			lastSlash = index2, dots = 0;
		} else char === "." && dots !== -1 ? ++dots : dots = -1;
	}
	return res;
}
function extractLocation(urlLike) {
	if (!urlLike.includes(":")) return [urlLike];
	let parts = /(.+?)(?::(\d+))?(?::(\d+))?$/.exec(urlLike.replace(/^\(|\)$/g, ""));
	if (!parts) return [urlLike];
	let url = parts[1];
	if (url.startsWith("async ") && (url = url.slice(6)), url.startsWith("http:") || url.startsWith("https:")) {
		let urlObj = new URL(url);
		urlObj.searchParams.delete("import"), urlObj.searchParams.delete("browserv"), url = urlObj.pathname + urlObj.hash + urlObj.search;
	}
	if (url.startsWith("/@fs/")) {
		let isWindows = /^\/@fs\/[a-zA-Z]:\//.test(url);
		url = url.slice(isWindows ? 5 : 4);
	}
	return [
		url,
		parts[2] || void 0,
		parts[3] || void 0
	];
}
function parseSingleFFOrSafariStack(raw) {
	let line = raw.trim();
	if (SAFARI_NATIVE_CODE_REGEXP.test(line) || (line.includes(" > eval") && (line = line.replace(/ line (\d+)(?: > eval line \d+)* > eval:\d+:\d+/g, ":$1")), !line.includes("@") && !line.includes(":"))) return null;
	let functionNameRegex = /((.*".+"[^@]*)?[^@]*)(@)/, matches = line.match(functionNameRegex), functionName = matches && matches[1] ? matches[1] : void 0, [url, lineNumber, columnNumber] = extractLocation(line.replace(functionNameRegex, ""));
	return !url || !lineNumber || !columnNumber ? null : {
		file: url,
		method: functionName || "",
		line: Number.parseInt(lineNumber),
		column: Number.parseInt(columnNumber)
	};
}
function parseSingleStack(raw) {
	let line = raw.trim();
	return CHROME_IE_STACK_REGEXP.test(line) ? parseSingleV8Stack(line) : parseSingleFFOrSafariStack(line);
}
function parseSingleV8Stack(raw) {
	let line = raw.trim();
	if (!CHROME_IE_STACK_REGEXP.test(line)) return null;
	line.includes("(eval ") && (line = line.replace(/eval code/g, "eval").replace(/(\(eval at [^()]*)|(,.*$)/g, ""));
	let sanitizedLine = line.replace(/^\s+/, "").replace(/\(eval code/g, "(").replace(/^.*?\s+/, ""), location2 = sanitizedLine.match(/ (\(.+\)$)/);
	sanitizedLine = location2 ? sanitizedLine.replace(location2[0], "") : sanitizedLine;
	let [url, lineNumber, columnNumber] = extractLocation(location2 ? location2[1] : sanitizedLine), method = location2 && sanitizedLine || "", file = url && ["eval", "<anonymous>"].includes(url) ? void 0 : url;
	return !file || !lineNumber || !columnNumber ? null : (method.startsWith("async ") && (method = method.slice(6)), file.startsWith("file://") && (file = file.slice(7)), file = file.startsWith("node:") || file.startsWith("internal:") ? file : resolve(file), method && (method = method.replace(/__vite_ssr_import_\d+__\./g, "")), {
		method,
		file,
		line: Number.parseInt(lineNumber),
		column: Number.parseInt(columnNumber)
	});
}
function createCompilerHints(options) {
	let globalThisAccessor = options?.globalThisKey || "__vitest_mocker__";
	function _mocker() {
		return typeof globalThis[globalThisAccessor] < "u" ? globalThis[globalThisAccessor] : new Proxy({}, { get(_, name) {
			throw new Error(`Vitest mocker was not initialized in this environment. vi.${String(name)}() is forbidden.`);
		} });
	}
	return {
		hoisted(factory) {
			if (typeof factory != "function") throw new TypeError(`vi.hoisted() expects a function, but received a ${typeof factory}`);
			return factory();
		},
		mock(path, factory) {
			if (typeof path != "string") throw new TypeError(`vi.mock() expects a string path, but received a ${typeof path}`);
			let importer = getImporter("mock");
			_mocker().queueMock(path, importer, typeof factory == "function" ? () => factory(() => _mocker().importActual(path, importer)) : factory);
		},
		unmock(path) {
			if (typeof path != "string") throw new TypeError(`vi.unmock() expects a string path, but received a ${typeof path}`);
			_mocker().queueUnmock(path, getImporter("unmock"));
		},
		doMock(path, factory) {
			if (typeof path != "string") throw new TypeError(`vi.doMock() expects a string path, but received a ${typeof path}`);
			let importer = getImporter("doMock");
			_mocker().queueMock(path, importer, typeof factory == "function" ? () => factory(() => _mocker().importActual(path, importer)) : factory);
		},
		doUnmock(path) {
			if (typeof path != "string") throw new TypeError(`vi.doUnmock() expects a string path, but received a ${typeof path}`);
			_mocker().queueUnmock(path, getImporter("doUnmock"));
		},
		async importActual(path) {
			return _mocker().importActual(path, getImporter("importActual"));
		},
		async importMock(path) {
			return _mocker().importMock(path, getImporter("importMock"));
		}
	};
}
function getImporter(name) {
	let stackArray = createSimpleStackTrace({ stackTraceLimit: 5 }).split(`
`);
	return parseSingleStack(stackArray[stackArray.findIndex((stack2) => stack2.includes(` at Object.${name}`) || stack2.includes(`${name}@`)) + 1])?.file || "";
}
function cleanVersion(url) {
	return url.replace(versionRegexp, "");
}
function registerModuleMocker(interceptor) {
	let mocker = new BuildModuleMocker(interceptor("__vitest_mocker__"), {
		resolveId(id, importer) {
			return rpc2("resolveId", {
				id,
				importer
			});
		},
		resolveMock(id, importer, options) {
			return rpc2("resolveMock", {
				id,
				importer,
				options
			});
		},
		async invalidate(ids) {
			return rpc2("invalidate", { ids });
		}
	}, (...args) => globalThis.__STORYBOOK_MODULE_TEST__.spyOn(...args), { root: "" });
	return globalThis.__vitest_mocker__ = mocker, createCompilerHints({ globalThisKey: "__vitest_mocker__" });
}
var MockerRegistry, AutomockedModule, AutospiedModule, RedirectedModule, ManualMockedModule, RefTracker, _DRIVE_LETTER_START_RE, _UNC_REGEX, _IS_ABSOLUTE_RE, _DRIVE_LETTER_RE, _EXTNAME_RE, normalize, join, isAbsolute, extname, h, reactIs$1, reactIs_production, hasRequiredReactIs_production, hasRequiredReactIs$1, reactIsExports$1, ReactIs19, reactIs, reactIs_production_min, hasRequiredReactIs_production_min, hasRequiredReactIs, reactIsExports, ReactIs18, jsTokens_1, hasRequiredJsTokens, reservedWords, chars, intToChar, charToInt, UrlType, _DRIVE_LETTER_START_RE2, _IS_ABSOLUTE_RE2, resolve, isAbsolute2, CHROME_IE_STACK_REGEXP, SAFARI_NATIVE_CODE_REGEXP, now, ModuleMocker, versionRegexp, ModuleMockerInterceptor, rpc2, BuildModuleMocker;
//#endregion
__esmMin((() => {
	init_preload_helper();
	MockerRegistry = class {
		registryByUrl = /* @__PURE__ */ new Map();
		registryById = /* @__PURE__ */ new Map();
		clear() {
			this.registryByUrl.clear(), this.registryById.clear();
		}
		keys() {
			return this.registryByUrl.keys();
		}
		add(mock) {
			this.registryByUrl.set(mock.url, mock), this.registryById.set(mock.id, mock);
		}
		register(typeOrEvent, raw, id, url, factoryOrRedirect) {
			let type = typeof typeOrEvent == "object" ? typeOrEvent.type : typeOrEvent;
			if (typeof typeOrEvent == "object") {
				let event = typeOrEvent;
				if (event instanceof AutomockedModule || event instanceof AutospiedModule || event instanceof ManualMockedModule || event instanceof RedirectedModule) throw new TypeError(`[vitest] Cannot register a mock that is already defined. Expected a JSON representation from \`MockedModule.toJSON\`, instead got "${event.type}". Use "registry.add()" to update a mock instead.`);
				if (event.type === "automock") {
					let module = AutomockedModule.fromJSON(event);
					return this.add(module), module;
				} else if (event.type === "autospy") {
					let module = AutospiedModule.fromJSON(event);
					return this.add(module), module;
				} else if (event.type === "redirect") {
					let module = RedirectedModule.fromJSON(event);
					return this.add(module), module;
				} else throw event.type === "manual" ? /* @__PURE__ */ new Error("Cannot set serialized manual mock. Define a factory function manually with `ManualMockedModule.fromJSON()`.") : /* @__PURE__ */ new Error(`Unknown mock type: ${event.type}`);
			}
			if (typeof raw != "string") throw new TypeError("[vitest] Mocks require a raw string.");
			if (typeof url != "string") throw new TypeError("[vitest] Mocks require a url string.");
			if (typeof id != "string") throw new TypeError("[vitest] Mocks require an id string.");
			if (type === "manual") {
				if (typeof factoryOrRedirect != "function") throw new TypeError("[vitest] Manual mocks require a factory function.");
				let mock = new ManualMockedModule(raw, id, url, factoryOrRedirect);
				return this.add(mock), mock;
			} else if (type === "automock" || type === "autospy") {
				let mock = type === "automock" ? new AutomockedModule(raw, id, url) : new AutospiedModule(raw, id, url);
				return this.add(mock), mock;
			} else if (type === "redirect") {
				if (typeof factoryOrRedirect != "string") throw new TypeError("[vitest] Redirect mocks require a redirect string.");
				let mock = new RedirectedModule(raw, id, url, factoryOrRedirect);
				return this.add(mock), mock;
			} else throw new Error(`[vitest] Unknown mock type: ${type}`);
		}
		delete(id) {
			this.registryByUrl.delete(id);
		}
		get(id) {
			return this.registryByUrl.get(id);
		}
		getById(id) {
			return this.registryById.get(id);
		}
		has(id) {
			return this.registryByUrl.has(id);
		}
	}, AutomockedModule = class {
		type = "automock";
		constructor(raw, id, url) {
			this.raw = raw, this.id = id, this.url = url;
		}
		static fromJSON(data) {
			return new AutospiedModule(data.raw, data.id, data.url);
		}
		toJSON() {
			return {
				type: this.type,
				url: this.url,
				raw: this.raw,
				id: this.id
			};
		}
	}, AutospiedModule = class _AutospiedModule {
		type = "autospy";
		constructor(raw, id, url) {
			this.raw = raw, this.id = id, this.url = url;
		}
		static fromJSON(data) {
			return new _AutospiedModule(data.raw, data.id, data.url);
		}
		toJSON() {
			return {
				type: this.type,
				url: this.url,
				id: this.id,
				raw: this.raw
			};
		}
	}, RedirectedModule = class _RedirectedModule {
		type = "redirect";
		constructor(raw, id, url, redirect) {
			this.raw = raw, this.id = id, this.url = url, this.redirect = redirect;
		}
		static fromJSON(data) {
			return new _RedirectedModule(data.raw, data.id, data.url, data.redirect);
		}
		toJSON() {
			return {
				type: this.type,
				url: this.url,
				raw: this.raw,
				id: this.id,
				redirect: this.redirect
			};
		}
	}, ManualMockedModule = class _ManualMockedModule {
		cache;
		type = "manual";
		constructor(raw, id, url, factory) {
			this.raw = raw, this.id = id, this.url = url, this.factory = factory;
		}
		async resolve() {
			if (this.cache) return this.cache;
			let exports;
			try {
				exports = await this.factory();
			} catch (err) {
				let vitestError = /* @__PURE__ */ new Error("[vitest] There was an error when mocking a module. If you are using \"vi.mock\" factory, make sure there are no top level variables inside, since this call is hoisted to top of the file. Read more: https://vitest.dev/api/vi.html#vi-mock");
				throw vitestError.cause = err, vitestError;
			}
			if (exports === null || typeof exports != "object" || Array.isArray(exports)) throw new TypeError(`[vitest] vi.mock("${this.raw}", factory?: () => unknown) is not returning an object. Did you mean to return an object with a "default" key?`);
			return this.cache = exports;
		}
		static fromJSON(data, factory) {
			return new _ManualMockedModule(data.raw, data.id, data.url, factory);
		}
		toJSON() {
			return {
				type: this.type,
				url: this.url,
				id: this.id,
				raw: this.raw
			};
		}
	};
	RefTracker = class {
		idMap = /* @__PURE__ */ new Map();
		mockedValueMap = /* @__PURE__ */ new Map();
		getId(value) {
			return this.idMap.get(value);
		}
		getMockedValue(id) {
			return this.mockedValueMap.get(id);
		}
		track(originalValue, mockedValue) {
			let newId = this.idMap.size;
			return this.idMap.set(originalValue, newId), this.mockedValueMap.set(newId, mockedValue), newId;
		}
	};
	_DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
	_UNC_REGEX = /^[/\\]{2}/, _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/, _DRIVE_LETTER_RE = /^[A-Za-z]:$/, _EXTNAME_RE = /.(\.[^./]+|\.)$/, normalize = function(path) {
		if (path.length === 0) return ".";
		path = normalizeWindowsPath(path);
		let isUNCPath = path.match(_UNC_REGEX), isPathAbsolute = isAbsolute(path), trailingSeparator = path[path.length - 1] === "/";
		return path = normalizeString(path, !isPathAbsolute), path.length === 0 ? isPathAbsolute ? "/" : trailingSeparator ? "./" : "." : (trailingSeparator && (path += "/"), _DRIVE_LETTER_RE.test(path) && (path += "/"), isUNCPath ? isPathAbsolute ? `//${path}` : `//./${path}` : isPathAbsolute && !isAbsolute(path) ? `/${path}` : path);
	}, join = function(...segments) {
		let path = "";
		for (let seg of segments) if (seg) if (path.length > 0) {
			let pathTrailing = path[path.length - 1] === "/", segLeading = seg[0] === "/";
			pathTrailing && segLeading ? path += seg.slice(1) : path += pathTrailing || segLeading ? seg : `/${seg}`;
		} else path += seg;
		return normalize(path);
	};
	isAbsolute = function(p2) {
		return _IS_ABSOLUTE_RE.test(p2);
	}, extname = function(p2) {
		if (p2 === "..") return "";
		let match = _EXTNAME_RE.exec(normalizeWindowsPath(p2));
		return match && match[1] || "";
	};
	h = Object.entries({
		reset: [0, 0],
		bold: [
			1,
			22,
			"\x1B[22m\x1B[1m"
		],
		dim: [
			2,
			22,
			"\x1B[22m\x1B[2m"
		],
		italic: [3, 23],
		underline: [4, 24],
		inverse: [7, 27],
		hidden: [8, 28],
		strikethrough: [9, 29],
		black: [30, 39],
		red: [31, 39],
		green: [32, 39],
		yellow: [33, 39],
		blue: [34, 39],
		magenta: [35, 39],
		cyan: [36, 39],
		white: [37, 39],
		gray: [90, 39],
		bgBlack: [40, 49],
		bgRed: [41, 49],
		bgGreen: [42, 49],
		bgYellow: [43, 49],
		bgBlue: [44, 49],
		bgMagenta: [45, 49],
		bgCyan: [46, 49],
		bgWhite: [47, 49],
		blackBright: [90, 39],
		redBright: [91, 39],
		greenBright: [92, 39],
		yellowBright: [93, 39],
		blueBright: [94, 39],
		magentaBright: [95, 39],
		cyanBright: [96, 39],
		whiteBright: [97, 39],
		bgBlackBright: [100, 49],
		bgRedBright: [101, 49],
		bgGreenBright: [102, 49],
		bgYellowBright: [103, 49],
		bgBlueBright: [104, 49],
		bgMagentaBright: [105, 49],
		bgCyanBright: [106, 49],
		bgWhiteBright: [107, 49]
	});
	a.open = "";
	a.close = "";
	p();
	reactIs$1 = { exports: {} }, reactIs_production = {};
	reactIsExports$1 = requireReactIs$1(), ReactIs19 = _mergeNamespaces({
		__proto__: null,
		default: getDefaultExportFromCjs(reactIsExports$1)
	}, [reactIsExports$1]), reactIs = { exports: {} }, reactIs_production_min = {};
	reactIsExports = requireReactIs(), ReactIs18 = _mergeNamespaces({
		__proto__: null,
		default: getDefaultExportFromCjs(reactIsExports)
	}, [reactIsExports]);
	Object.fromEntries([
		"isAsyncMode",
		"isConcurrentMode",
		"isContextConsumer",
		"isContextProvider",
		"isElement",
		"isForwardRef",
		"isFragment",
		"isLazy",
		"isMemo",
		"isPortal",
		"isProfiler",
		"isStrictMode",
		"isSuspense",
		"isSuspenseList",
		"isValidElementType"
	].map((m) => [m, (v) => ReactIs18[m](v) || ReactIs19[m](v)]));
	try {
		let { getPromiseDetails, kPending, kRejected } = process.binding("util");
		Array.isArray(getPromiseDetails(Promise.resolve()));
	} catch {}
	requireJsTokens();
	reservedWords = {
		keyword: [
			"break",
			"case",
			"catch",
			"continue",
			"debugger",
			"default",
			"do",
			"else",
			"finally",
			"for",
			"function",
			"if",
			"return",
			"switch",
			"throw",
			"try",
			"var",
			"const",
			"while",
			"with",
			"new",
			"this",
			"super",
			"class",
			"extends",
			"export",
			"import",
			"null",
			"true",
			"false",
			"in",
			"instanceof",
			"typeof",
			"void",
			"delete"
		],
		strict: [
			"implements",
			"interface",
			"let",
			"package",
			"private",
			"protected",
			"public",
			"static",
			"yield"
		]
	};
	new Set(reservedWords.keyword);
	new Set(reservedWords.strict);
	chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", intToChar = new Uint8Array(64), charToInt = new Uint8Array(128);
	for (let i = 0; i < chars.length; i++) {
		let c = chars.charCodeAt(i);
		intToChar[i] = c, charToInt[c] = i;
	}
	(function(UrlType2) {
		UrlType2[UrlType2.Empty = 1] = "Empty", UrlType2[UrlType2.Hash = 2] = "Hash", UrlType2[UrlType2.Query = 3] = "Query", UrlType2[UrlType2.RelativePath = 4] = "RelativePath", UrlType2[UrlType2.AbsolutePath = 5] = "AbsolutePath", UrlType2[UrlType2.SchemeRelative = 6] = "SchemeRelative", UrlType2[UrlType2.Absolute = 7] = "Absolute";
	})(UrlType || (UrlType = {}));
	_DRIVE_LETTER_START_RE2 = /^[A-Za-z]:\//;
	_IS_ABSOLUTE_RE2 = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
	resolve = function(...arguments_) {
		arguments_ = arguments_.map((argument) => normalizeWindowsPath2(argument));
		let resolvedPath = "", resolvedAbsolute = !1;
		for (let index2 = arguments_.length - 1; index2 >= -1 && !resolvedAbsolute; index2--) {
			let path = index2 >= 0 ? arguments_[index2] : cwd();
			!path || path.length === 0 || (resolvedPath = `${path}/${resolvedPath}`, resolvedAbsolute = isAbsolute2(path));
		}
		return resolvedPath = normalizeString2(resolvedPath, !resolvedAbsolute), resolvedAbsolute && !isAbsolute2(resolvedPath) ? `/${resolvedPath}` : resolvedPath.length > 0 ? resolvedPath : ".";
	};
	isAbsolute2 = function(p2) {
		return _IS_ABSOLUTE_RE2.test(p2);
	}, CHROME_IE_STACK_REGEXP = /^\s*at .*(?:\S:\d+|\(native\))/m, SAFARI_NATIVE_CODE_REGEXP = /^(?:eval@)?(?:\[native code\])?$/;
	({now} = Date), ModuleMocker = class {
		registry = new MockerRegistry();
		queue = /* @__PURE__ */ new Set();
		mockedIds = /* @__PURE__ */ new Set();
		constructor(interceptor, rpc3, spyOn, config) {
			this.interceptor = interceptor, this.rpc = rpc3, this.spyOn = spyOn, this.config = config;
		}
		async prepare() {
			this.queue.size && await Promise.all([...this.queue.values()]);
		}
		async resolveFactoryModule(id) {
			let mock = this.registry.get(id);
			if (!mock || mock.type !== "manual") throw new Error(`Mock ${id} wasn't registered. This is probably a Vitest error. Please, open a new issue with reproduction.`);
			return await mock.resolve();
		}
		getFactoryModule(id) {
			let mock = this.registry.get(id);
			if (!mock || mock.type !== "manual") throw new Error(`Mock ${id} wasn't registered. This is probably a Vitest error. Please, open a new issue with reproduction.`);
			if (!mock.cache) throw new Error(`Mock ${id} wasn't resolved. This is probably a Vitest error. Please, open a new issue with reproduction.`);
			return mock.cache;
		}
		async invalidate() {
			let ids = Array.from(this.mockedIds);
			ids.length && (await this.rpc.invalidate(ids), await this.interceptor.invalidate(), this.registry.clear());
		}
		async importActual(id, importer) {
			let resolved = await this.rpc.resolveId(id, importer);
			if (resolved == null) throw new Error(`[vitest] Cannot resolve "${id}" imported from "${importer}"`);
			let ext = extname(resolved.id), url = new URL(resolved.url, location.href), query = `_vitest_original&ext${ext}`, actualUrl = `${url.pathname}${url.search ? `${url.search}&${query}` : `?${query}`}${url.hash}`;
			return this.wrapDynamicImport(() => __vitePreload(() => import(
				/* @vite-ignore */
				actualUrl
), [])).then((mod) => {
				if (!resolved.optimized || typeof mod.default > "u") return mod;
				let m = mod.default;
				return m?.__esModule ? m : {
					...typeof m == "object" && !Array.isArray(m) || typeof m == "function" ? m : {},
					default: m
				};
			});
		}
		async importMock(rawId, importer) {
			await this.prepare();
			let { resolvedId, resolvedUrl, redirectUrl } = await this.rpc.resolveMock(rawId, importer, { mock: "auto" }), mockUrl = this.resolveMockPath(cleanVersion(resolvedUrl)), mock = this.registry.get(mockUrl);
			if (!mock) if (redirectUrl) mock = new RedirectedModule(rawId, resolvedId, mockUrl, new URL(this.resolveMockPath(cleanVersion(redirectUrl)), location.href).toString());
			else mock = new AutomockedModule(rawId, resolvedId, mockUrl);
			if (mock.type === "manual") return await mock.resolve();
			if (mock.type === "automock" || mock.type === "autospy") {
				let url = new URL(`/@id/${resolvedId}`, location.href), query = url.search ? `${url.search}&t=${now()}` : `?t=${now()}`, moduleObject = await __vitePreload(() => import(
					/* @vite-ignore */
					`${url.pathname}${query}&mock=${mock.type}${url.hash}`
), []);
				return this.mockObject(moduleObject, mock.type);
			}
			return __vitePreload(() => import(
				/* @vite-ignore */
				mock.redirect
), []);
		}
		mockObject(object, moduleType = "automock") {
			return mockObject({
				globalConstructors: {
					Object,
					Function,
					Array,
					Map,
					RegExp
				},
				spyOn: this.spyOn,
				type: moduleType
			}, object);
		}
		queueMock(rawId, importer, factoryOrOptions) {
			let promise = this.rpc.resolveMock(rawId, importer, { mock: typeof factoryOrOptions == "function" ? "factory" : factoryOrOptions?.spy ? "spy" : "auto" }).then(async ({ redirectUrl, resolvedId, resolvedUrl, needsInterop, mockType }) => {
				let mockUrl = this.resolveMockPath(cleanVersion(resolvedUrl));
				this.mockedIds.add(resolvedId);
				let factory = typeof factoryOrOptions == "function" ? async () => {
					let data = await factoryOrOptions();
					return needsInterop ? { default: data } : data;
				} : void 0, mockRedirect = typeof redirectUrl == "string" ? new URL(this.resolveMockPath(cleanVersion(redirectUrl)), location.href).toString() : null, module;
				mockType === "manual" ? module = this.registry.register("manual", rawId, resolvedId, mockUrl, factory) : mockType === "autospy" ? module = this.registry.register("autospy", rawId, resolvedId, mockUrl) : mockType === "redirect" ? module = this.registry.register("redirect", rawId, resolvedId, mockUrl, mockRedirect) : module = this.registry.register("automock", rawId, resolvedId, mockUrl), await this.interceptor.register(module);
			}).finally(() => {
				this.queue.delete(promise);
			});
			this.queue.add(promise);
		}
		queueUnmock(id, importer) {
			let promise = this.rpc.resolveId(id, importer).then(async (resolved) => {
				if (!resolved) return;
				let mockUrl = this.resolveMockPath(cleanVersion(resolved.url));
				this.mockedIds.add(resolved.id), this.registry.delete(mockUrl), await this.interceptor.delete(mockUrl);
			}).finally(() => {
				this.queue.delete(promise);
			});
			this.queue.add(promise);
		}
		wrapDynamicImport(moduleFactory) {
			return typeof moduleFactory == "function" ? new Promise((resolve2, reject) => {
				this.prepare().finally(() => {
					moduleFactory().then(resolve2, reject);
				});
			}) : moduleFactory;
		}
		resolveMockPath(path) {
			let config = this.config, fsRoot = join("/@fs/", config.root);
			return path.startsWith(config.root) ? path.slice(config.root.length) : path.startsWith(fsRoot) ? path.slice(fsRoot.length) : path;
		}
	}, versionRegexp = /(\?|&)v=\w{8}/;
	ModuleMockerInterceptor = class {
		mocks = new MockerRegistry();
		constructor() {}
		/**
		* Called by ModuleMocker when `sb.mock()` is executed. We just store the mock in our registry.
		* The dynamic MSW handler will pick it up on the next relevant network request. Currently, we
		* don't use this.mocks in any way. Mocks will be registered in the user's preview file and live
		* until the end. There is no way to invalidate or delete them.
		*/
		async register(module) {
			this.mocks.add(module);
		}
		async delete(url) {
			this.mocks.delete(url);
		}
		async invalidate() {
			this.mocks.clear();
		}
	}, rpc2 = (method) => {
		switch (method) {
			case "resolveId": return Promise.resolve({
				id: "",
				url: "",
				optimized: !1
			});
			case "resolveMock": return Promise.resolve({
				mockType: "dummy",
				resolvedId: "",
				resolvedUrl: "",
				redirectUrl: "",
				needsInterop: !1
			});
			case "invalidate": return Promise.resolve();
		}
	}, BuildModuleMocker = class extends ModuleMocker {
		queueMock() {}
	};
	globalThis.__STORYBOOK_MOCKER__ = registerModuleMocker(() => new ModuleMockerInterceptor());
}))();
